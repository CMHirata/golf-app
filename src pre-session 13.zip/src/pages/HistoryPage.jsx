// ─── pages/HistoryPage.jsx ────────────────────────────────────────────────────
// Round history: list, filter, cumulative winnings, export/import.
//
// H-1 swipe: Strip tracks finger in real time with zero setState during the
// gesture. All tracking state is in refs. The sliding div is updated via
// direct DOM style manipulation (slideRef.current.style.transform). React
// state is only written once at touchend for the snap position.
// This avoids the iOS Safari issue where setState mid-gesture causes React
// to replace event handler references, breaking subsequent touchmove events.

import { useState, useMemo, useCallback, useRef } from 'react';
import { ls, SK } from '../services/storage.js';
import { roundLib } from '../services/roundLib.js';
import { playerLib } from '../services/playerLib.js';
import { courseLib } from '../services/courseLib.js';
import { Btn, Card, G, GA, RED, fmtDate, ShareOrientationPicker } from '../components/ui.jsx';
import {
  ImportModal, ImportConflictModal,
  likelySameCourse, likelySamePlayer, diffCourses,
} from './ImportModals.jsx';
import { RoundSummaryModal } from './RoundSummaryModal.jsx';
import { triggerRoundShare, buildPayoutArgs, computePerMatchPayouts, buildShareImage } from '../services/roundUtils.js';
import { computePayouts } from '../engine/payouts.js';

const RANGES = [['ytd','YTD'],['week','7d'],['month','30d'],['year','12mo'],['all','All']];

function fmtMoney(v) {
  return v > 0 ? `+$${Math.abs(v).toFixed(2)}` : v < 0 ? `-$${Math.abs(v).toFixed(2)}` : '$0';
}

function mergeById(existing, incoming) {
  const map = new Map(existing.map(r => [r.id, r]));
  incoming.forEach(r => { if (r.id) map.set(r.id, r); });
  return Array.from(map.values());
}

// ── SVG icons for swipe strip ─────────────────────────────────────────────────
const IconShare = ({ color = '#fff', size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
    <polyline points="16 6 12 2 8 6"/>
    <line x1="12" y1="2" x2="12" y2="15"/>
  </svg>
);

const IconEdit = ({ color = '#fff', size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </svg>
);

const IconTrash = ({ color = '#fff', size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/>
    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
    <path d="M10 11v6"/>
    <path d="M14 11v6"/>
    <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
  </svg>
);

const IconDownload = ({ color = G, size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="7 10 12 15 17 10"/>
    <line x1="12" y1="15" x2="12" y2="3"/>
  </svg>
);

const IconUpload = ({ color = '#666', size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="7 14 12 9 17 14"/>
    <line x1="12" y1="9" x2="12" y2="21"/>
  </svg>
);

// ── Swipe strip colors — bright app palette ───────────────────────────────────
const STRIP_SHARE  = '#1a472a';   // app primary green
const STRIP_EDIT   = '#fff9e6';   // pale yellow — uses dark text (matches PALE_YELLOW in ui.jsx)
const STRIP_DELETE = '#c0392b';   // app RED token

// ── Swipeable round row ────────────────────────────────────────────────────────
const REVEAL_W = 180;

function SwipeableRoundRow({ r, canEdit, onEdit, onDelete, onOpenSummary, onShare, openId, setOpenId }) {
  const isOpen = openId === r.id;

  const [snapOffset, setSnapOffset] = useState(0);

  const rowRef        = useRef(null);
  const slideRef      = useRef(null);
  const stripRef      = useRef(null);
  const overlayRef    = useRef(null);
  const touchStartX   = useRef(null);
  const wasOpen       = useRef(false);
  const committed     = useRef(false);
  const liveOffset    = useRef(0);
  const rawDx         = useRef(0);

  const setTransform = (px, animated) => {
    if (!slideRef.current) return;
    slideRef.current.style.transition = animated ? 'transform 0.2s ease' : 'none';
    slideRef.current.style.transform  = `translateX(${px}px)`;
    liveOffset.current = px;

    if (!wasOpen.current) {
      const rowW         = rowRef.current?.offsetWidth || 360;
      const deleteThresh = rowW * 0.8;
      const isDeleteZone = rawDx.current <= -deleteThresh;
      if (overlayRef.current) {
        overlayRef.current.style.opacity    = isDeleteZone ? '1' : '0';
        overlayRef.current.style.transition = animated ? 'opacity 0.15s ease' : 'none';
      }
    }
  };

  const snapClose = useCallback(() => {
    setTransform(0, true);
    if (overlayRef.current) overlayRef.current.style.opacity = '0';
    setSnapOffset(0);
    setOpenId(prev => prev === r.id ? null : prev);
  }, [r.id, setOpenId]);

  const snapOpen = useCallback(() => {
    setTransform(-REVEAL_W, true);
    setSnapOffset(-REVEAL_W);
    setOpenId(r.id);
  }, [r.id, setOpenId]);

  const onTouchStart = (e) => {
    touchStartX.current = e.touches[0].clientX;
    wasOpen.current     = isOpen;
    committed.current   = false;
    rawDx.current       = 0;
    if (slideRef.current) slideRef.current.style.transition = 'none';
  };

  const onTouchMove = (e) => {
    if (touchStartX.current === null) return;
    const dx = e.touches[0].clientX - touchStartX.current;
    rawDx.current = dx;
    if (!committed.current) {
      if (Math.abs(dx) <= 6) return;
      committed.current = true;
    }
    const base     = wasOpen.current ? -REVEAL_W : 0;
    const clamped  = Math.min(0, base + dx);
    setTransform(clamped, false);
  };

  const onTouchEnd = () => {
    if (touchStartX.current === null) return;
    touchStartX.current = null;
    if (!committed.current) {
      if (wasOpen.current) { snapClose(); } else { setTransform(0, false); onOpenSummary(); }
      return;
    }
    const dx           = rawDx.current;
    const rowW         = rowRef.current?.offsetWidth || 360;
    const deleteThresh = rowW * 0.8;
    if (!wasOpen.current && dx <= -deleteThresh) {
      snapClose();
      if (window.confirm('Delete this round? This cannot be undone.')) onDelete();
      return;
    }
    if (wasOpen.current && liveOffset.current > -REVEAL_W / 2) { snapClose(); return; }
    if (!wasOpen.current && liveOffset.current < -REVEAL_W / 2) { snapOpen(); }
    else if (wasOpen.current && liveOffset.current <= -REVEAL_W / 2) { snapOpen(); }
    else { snapClose(); }
  };

  const syncedOffset = isOpen ? snapOffset : 0;
  if (slideRef.current) {
    const currentPx = parseInt(slideRef.current.style.transform.replace('translateX(', '').replace('px)', '') || '0');
    if (currentPx !== syncedOffset && !committed.current) {
      slideRef.current.style.transition = 'transform 0.2s ease';
      slideRef.current.style.transform  = `translateX(${syncedOffset}px)`;
    }
  }

  const hasTouch    = 'ontouchstart' in window;
  const playerNames = (r.players || []).map(p => typeof p === 'string' ? p : p.name).join(', ');
  const numNines    = (r.course_snapshot?.nines || []).length;
  const ninesSuffix = numNines > 2 && r.front_nine && r.back_nine ? ` - ${r.front_nine}/${r.back_nine}` : '';

  return (
    <div ref={rowRef} style={{ position:'relative', borderRadius:12, overflow:'hidden', border:'1.5px solid #e0ece0', background:'#fff' }}>

      {/* Full-tile delete overlay */}
      {hasTouch && (
        <div ref={overlayRef}
          style={{ position:'absolute', inset:0, background:STRIP_DELETE, opacity:0,
            display:'flex', alignItems:'center', justifyContent:'center',
            flexDirection:'column', gap:8, pointerEvents:'none',
            transition:'opacity 0.15s ease', zIndex:10 }}>
          <IconTrash color="#fff" size={28} />
          <span style={{ fontSize:13, fontWeight:700, color:'#fff', letterSpacing:'0.3px' }}>Release to delete</span>
        </div>
      )}

      {/* Action strip */}
      {hasTouch && (
        <div ref={stripRef} style={{ position:'absolute', top:0, right:0, bottom:0, width:REVEAL_W, display:'flex', alignItems:'stretch' }}>
          <button
            onClick={(e) => { e.stopPropagation(); snapClose(); onShare && onShare(); }}
            style={{ flex:1, border:'none', background:STRIP_SHARE, color:'#fff', fontWeight:700, fontSize:11,
              cursor:'pointer', fontFamily:'inherit', display:'flex', flexDirection:'column',
              alignItems:'center', justifyContent:'center', gap:4 }}>
            <IconShare color="#fff" size={17} />
            <span>Share</span>
          </button>
          {canEdit && (
            <button
              onClick={(e) => { e.stopPropagation(); snapClose(); onEdit(); }}
              style={{ flex:1, border:'none', background:STRIP_EDIT, color:G, fontWeight:700, fontSize:11,
                cursor:'pointer', fontFamily:'inherit', display:'flex', flexDirection:'column',
                alignItems:'center', justifyContent:'center', gap:4 }}>
              <IconEdit color={G} size={17} />
              <span>Edit</span>
            </button>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); snapClose(); if (window.confirm('Delete this round? This cannot be undone.')) onDelete(); }}
            style={{ flex:1, border:'none', background:STRIP_DELETE, color:'#fff', fontWeight:700, fontSize:11,
              cursor:'pointer', fontFamily:'inherit', display:'flex', flexDirection:'column',
              alignItems:'center', justifyContent:'center', gap:4 }}>
            <IconTrash color="#fff" size={17} />
            <span>Delete</span>
          </button>
        </div>
      )}

      {/* Sliding row content */}
      <div
        ref={slideRef}
        onTouchStart={hasTouch ? onTouchStart : undefined}
        onTouchMove={hasTouch ? onTouchMove : undefined}
        onTouchEnd={hasTouch ? onTouchEnd : undefined}
        onClick={hasTouch ? undefined : onOpenSummary}
        style={{
          position:'relative', zIndex:1, background:'#fff',
          transform:`translateX(${syncedOffset}px)`,
          transition:'transform 0.2s ease',
          cursor:'pointer',
        }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:8, padding:'10px 12px' }}>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontWeight:700, fontSize:13, color:G }}>{r.course_name || 'Unknown Course'}{ninesSuffix}</div>
            <div style={{ fontSize:11, color:'#888', marginTop:1 }}>{fmtDate(r.date)} · {playerNames}</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:4, marginTop:4, alignItems:'center' }}>
              {(r.active_games || []).map(g => (
                <span key={g} style={{ background:GA, color:G, borderRadius:20, padding:'2px 8px', fontSize:10, fontWeight:600 }}>{g}</span>
              ))}
            </div>
          </div>

          {/* Desktop buttons */}
          {!hasTouch && (
            <div style={{ display:'flex', gap:4, flexShrink:0, alignItems:'center' }} onClick={e => e.stopPropagation()}>
              <button onClick={() => onShare && onShare()}
                style={{ border:`1.5px solid ${STRIP_SHARE}`, background:'#eef6f1', borderRadius:6,
                  cursor:'pointer', fontSize:11, fontWeight:700, padding:'3px 8px', color:STRIP_SHARE, fontFamily:'inherit' }}>
                Share
              </button>
              {canEdit && (
                <button onClick={onEdit}
                  style={{ border:'1.5px solid #bbb', background:'#f5f5f5', borderRadius:6,
                    cursor:'pointer', fontSize:11, fontWeight:700, padding:'3px 8px', color:'#444', fontFamily:'inherit' }}>
                  Edit
                </button>
              )}
              <button onClick={() => { if (window.confirm('Delete this round? This cannot be undone.')) onDelete(); }}
                style={{ border:'none', background:'none', cursor:'pointer', padding:'2px 4px', lineHeight:1 }}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <circle cx="8" cy="8" r="7.5" stroke={RED} strokeWidth="1.2" fill="none"/>
                  <line x1="5" y1="5" x2="11" y2="11" stroke={RED} strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="11" y1="5" x2="5" y2="11" stroke={RED} strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
            </div>
          )}
          {hasTouch && <div style={{ color:'#ccc', fontSize:16, flexShrink:0, alignSelf:'center' }}>‹</div>}
        </div>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function HistoryPage({ onLoadRound }) {
  const [rounds,             setRounds]             = useState(() => roundLib.list());
  const [range,              setRange]              = useState('ytd');
  const [summaryRound,       setSummaryRound]       = useState(null);
  const [openRowId,          setOpenRowId]          = useState(null);
  const [importModal,        setImportModal]        = useState(null);
  const [conflictModal,      setConflictModal]      = useState(null);
  const [showWinningsDetail, setShowWinningsDetail] = useState(false);

  const [shareRound,    setShareRound]    = useState(null);
  const [shareStatus,   setShareStatus]   = useState('idle');
  const [shareError,    setShareError]    = useState('');
  const [showOrienPick, setShowOrienPick] = useState(false);
  const [editUnlocked,  setEditUnlocked]  = useState(false);

  const handleShareRound = useCallback((r) => {
    setShareRound(r);
    setShowOrienPick(true);
  }, []);

  const handleShareWithOrientation = useCallback(async (orientation) => {
    if (!shareRound) return;
    setShowOrienPick(false);
    setShareStatus('building');
    setShareError('');
    try {
      const ar = roundLib.toActiveRound(shareRound);
      const { bank, breakdown } = computePayouts(buildPayoutArgs(ar));
      const matchPayouts = (ar.activeGames || []).includes('Match / Nassau')
        ? computePerMatchPayouts(ar.matches || [], ar.activePlayers, ar.scores, ar.hcps, ar.courseHcps, ar.minCourseHcp, ar.manualPresses || {})
        : [];
      const blob = await buildShareImage(shareRound, ar, bank, breakdown, matchPayouts, orientation);
      await triggerRoundShare(shareRound, ar, bank, breakdown, matchPayouts, blob, orientation);
      setShareStatus('done');
    } catch(err) {
      if (err?.name === 'AbortError') { setShareStatus('idle'); return; }
      console.error('Share failed:', err);
      setShareError('Could not share. Try again.');
      setShareStatus('error');
    }
  }, [shareRound]);

  const now = new Date();

  const filtered = useMemo(() => rounds.filter(r => {
    const d = new Date(r.date);
    if (range === 'week')  { const w = new Date(now); w.setDate(now.getDate()-7);         return d >= w; }
    if (range === 'month') { const m = new Date(now); m.setMonth(now.getMonth()-1);       return d >= m; }
    if (range === 'year')  { const y = new Date(now); y.setFullYear(now.getFullYear()-1); return d >= y; }
    if (range === 'ytd')   return d.getFullYear() === now.getFullYear();
    return true;
  }).sort((a, b) => new Date(b.date) - new Date(a.date)), [rounds, range]);

  const mostRecentDate = filtered[0]?.date || null;

  const cumulative = useMemo(() => {
    const byGame = {}, byPlayer = {};
    filtered.forEach(r => (r.breakdown || []).forEach(({ game, rows }) => {
      if (!byGame[game]) byGame[game] = {};
      (rows || []).filter(row => row.net != null).forEach(({ name, net }) => {
        byGame[game][name] = (byGame[game][name] || 0) + net;
        byPlayer[name]     = (byPlayer[name]     || 0) + net;
      });
    }));
    return { byGame, byPlayer };
  }, [filtered]);

  const handleDelete = useCallback((id) => { roundLib.delete(id); setRounds(roundLib.list()); }, []);

  const handleExport = async () => {
    const filename = `golf_backup_${new Date().toISOString().slice(0,10)}.json`;
    const payload  = { exportedAt: new Date().toISOString(), appVersion: 'golf-scorekeeper-v4', players: playerLib.list(), courses: courseLib.list(), rounds: roundLib.list() };
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    if (navigator.canShare && navigator.canShare({ files: [new File([blob], filename, { type: 'application/json' })] })) {
      try { await navigator.share({ files: [new File([blob], filename, { type: 'application/json' })], title: 'Golf Scorekeeper Backup' }); return; }
      catch (err) { if (err.name === 'AbortError') return; }
    }
    if (typeof window.showSaveFilePicker === 'function') {
      try { const h = await window.showSaveFilePicker({ suggestedName: filename, types: [{ description: 'Golf Backup (JSON)', accept: { 'application/json': ['.json'] } }] }); const w = await h.createWritable(); await w.write(json); await w.close(); return; }
      catch (err) { if (err.name === 'AbortError') return; }
    }
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  };

  const handleImportFile = async (file) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      const n = { players: parsed.players||[], courses: parsed.courses||[], rounds: parsed.rounds||[] };
      if (!n.players.length && !n.courses.length && !n.rounds.length) { alert('No importable data found.'); return; }
      setImportModal({ parsed: n });
    } catch(e) { alert(`Could not read file: ${e.message}`); }
  };

  const handleImportConfirmSections = (sel) => {
    const { parsed } = importModal; setImportModal(null);
    const conflicts = [];
    if (sel.courses && parsed.courses?.length) {
      const ec = ls.get(SK.courses) || [];
      parsed.courses.forEach(inc => {
        const im = ec.find(e => e.id === inc.id);
        if (im) { const d = diffCourses(im, inc); if (d.length) conflicts.push({ type:'course', existing:im, incoming:inc }); return; }
        const nm = ec.find(e => likelySameCourse(e.name, inc.name));
        if (nm) conflicts.push({ type:'course', existing:nm, incoming:inc });
      });
    }
    if (sel.players && parsed.players?.length) {
      const ep = ls.get(SK.players) || [];
      parsed.players.forEach(inc => {
        const im = ep.find(e => e.id === inc.id);
        if (im) { const f=['name','gender','ghin','email','phone']; if (f.some(k=>(im[k]||'')!==(inc[k]||''))) conflicts.push({ type:'player', existing:im, incoming:inc }); return; }
        const nm = ep.find(e => likelySamePlayer(e.name, inc.name));
        if (nm) conflicts.push({ type:'player', existing:nm, incoming:inc });
      });
    }
    if (conflicts.length > 0) setConflictModal({ conflicts, pendingSel:sel, pendingParsed:parsed });
    else applyImport(sel, parsed, {});
  };

  const handleConflictsResolved = (decisions) => {
    const { pendingSel, pendingParsed } = conflictModal; setConflictModal(null); applyImport(pendingSel, pendingParsed, decisions);
  };

  const applyImport = (sel, parsed, decisions) => {
    const cr={}, pr={}; let ci=0;
    if (sel.courses && parsed.courses?.length) {
      const ec = ls.get(SK.courses)||[];
      parsed.courses.forEach(inc => {
        const im=ec.find(e=>e.id===inc.id);
        if(im){const d=diffCourses(im,inc);if(!d.length){cr[inc.id]='skip';return;} const dec=decisions[ci++]||{action:'keep'}; if(dec.action==='replace')cr[inc.id]=inc; else if(dec.action==='merge'&&dec.merged)cr[inc.id]=dec.merged; else cr[inc.id]='skip';return;}
        const nm=ec.find(e=>likelySameCourse(e.name,inc.name));
        if(nm){const dec=decisions[ci++]||{action:'keep'};if(dec.action==='keep')cr[inc.id]='skip';else if(dec.action==='replace')cr[inc.id]={...inc,id:nm.id};else if(dec.action==='merge'&&dec.merged)cr[inc.id]=dec.merged;else cr[inc.id]='skip';}
      });
    }
    if (sel.players && parsed.players?.length) {
      const ep=ls.get(SK.players)||[];const f=['name','gender','ghin','email','phone'];
      parsed.players.forEach(inc=>{
        const im=ep.find(e=>e.id===inc.id);
        if(im){if(!f.some(k=>(im[k]||'')!==(inc[k]||''))){pr[inc.id]='skip';return;}const dec=decisions[ci++]||{action:'keep'};pr[inc.id]=dec.action==='replace'?inc:'skip';return;}
        const nm=ep.find(e=>likelySamePlayer(e.name,inc.name));
        if(nm){const dec=decisions[ci++]||{action:'keep'};pr[inc.id]=dec.action==='replace'?{...inc,id:nm.id}:'skip';}
      });
    }
    const summary=[];
    if(sel.players&&parsed.players?.length){const ex=ls.get(SK.players)||[];const tm=parsed.players.map(p=>{const res=pr[p.id];if(res==='skip')return null;if(res&&typeof res==='object')return res;return p;}).filter(Boolean);ls.set(SK.players,mergeById(ex,tm));summary.push(`${tm.length} player${tm.length!==1?'s':''}`);}
    if(sel.courses&&parsed.courses?.length){const ex=ls.get(SK.courses)||[];const tm=parsed.courses.map(c=>{const res=cr[c.id];if(res==='skip')return null;if(res&&typeof res==='object')return res;return c;}).filter(Boolean);ls.set(SK.courses,mergeById(ex,tm));summary.push(`${tm.length} course${tm.length!==1?'s':''}`);}
    if(sel.rounds&&parsed.rounds?.length){const ex=ls.get(SK.rounds)||[];ls.set(SK.rounds,mergeById(ex,parsed.rounds));setRounds(roundLib.list());summary.push(`${parsed.rounds.length} round${parsed.rounds.length!==1?'s':''}`);}
    const sk=Object.values({...cr,...pr}).filter(v=>v==='skip').length;
    alert(`Imported: ${summary.join(', ')}${sk>0?` (${sk} duplicate${sk!==1?'s':''} skipped)`:''}.`);
  };

  return (
    <div style={{ minHeight:'100vh', background:'#eef4ee' }} onClick={() => setOpenRowId(null)}>

      {/* ── Header: lockup logo left, "History" right ── */}
      <div style={{
        background: G,
        padding: '8px 16px 7px',
        position: 'sticky', top: 0, zIndex: 10,
        boxShadow: '0 2px 12px rgba(0,0,0,.2)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <img
          src="/logo_lockup.png"
          alt="The Card"
          style={{ height: 58, width: 'auto', display: 'block' }}
        />
        <div style={{
          color: '#fff',
          fontWeight: 800,
          fontSize: 16,
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
          fontFamily: 'inherit',
        }}>
          History
        </div>
      </div>

      <div style={{ padding:'12px 14px', maxWidth:520, margin:'0 auto', display:'flex', flexDirection:'column', gap:10 }}>

        {/* ── Date range filter — equal-width pills ── */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:5 }}>
          {RANGES.map(([v, l]) => (
            <button key={v} onClick={() => setRange(v)}
              style={{
                padding: '5px 0',
                borderRadius: 20,
                border: `1.5px solid ${range === v ? G : '#ddd'}`,
                background: range === v ? GA : '#fff',
                cursor: 'pointer',
                fontSize: 12,
                fontWeight: 600,
                color: range === v ? G : '#777',
                fontFamily: 'inherit',
                textAlign: 'center',
              }}>
              {l}
            </button>
          ))}
        </div>
        <div style={{ fontSize:11, color:'#999', paddingLeft:2 }}>
          {filtered.length} round{filtered.length !== 1 ? 's' : ''} in range
        </div>

        {/* ── Cumulative winnings ── */}
        {filtered.length > 0 && Object.keys(cumulative.byPlayer).length > 0 && (() => {
          const sp = Object.entries(cumulative.byPlayer).sort((a,b) => b[1] - a[1]);
          return (
            <div onClick={() => setShowWinningsDetail(true)}
              style={{ background:'#fff', borderRadius:14, boxShadow:'0 1px 5px rgba(0,0,0,.07)', overflow:'hidden', cursor:'pointer' }}>
              <div style={{ padding:'10px 14px 7px' }}>
                <div style={{ fontWeight:700, fontSize:13, color:G }}>Cumulative Winnings</div>
              </div>
              <table style={{ borderCollapse:'collapse', fontSize:13, width:'100%' }}>
                <thead><tr>
                  <th style={{ textAlign:'left', padding:'4px 8px 4px 14px', background:'#f0f4f0', color:'#666', fontSize:11 }}>Player</th>
                  <th style={{ textAlign:'right', padding:'4px 14px 4px 8px', background:'#f0f4f0', color:'#666', fontSize:11, fontWeight:700 }}>Total</th>
                </tr></thead>
                <tbody>{sp.map(([name, total], i) => (
                  <tr key={i} style={{ height:32, background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                    <td style={{ padding:'4px 8px 4px 14px', fontWeight:600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', maxWidth:220 }}>{name}</td>
                    <td style={{ padding:'4px 14px 4px 8px', textAlign:'right', fontWeight:700, color: total > 0 ? '#27ae60' : total < 0 ? RED : '#666' }}>{fmtMoney(total)}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          );
        })()}

        {/* ── Round rows ── */}
        <Card>
          <div style={{ fontWeight:700, fontSize:13, color:G, marginBottom:9 }}>Rounds</div>
          {rounds.length === 0 && <p style={{ fontSize:13, color:'#aaa', textAlign:'center', padding:'16px 0' }}>No rounds saved yet.</p>}
          <div style={{ display:'flex', flexDirection:'column', gap:7 }}>
            {filtered.map((r) => (
              <SwipeableRoundRow
                key={r.id} r={r}
                canEdit={!!(onLoadRound && (editUnlocked || r.date === mostRecentDate))}
                onEdit={() => onLoadRound && onLoadRound(r)}
                onDelete={() => handleDelete(r.id)}
                onOpenSummary={() => { setOpenRowId(null); setSummaryRound(r); }}
                onShare={() => { setOpenRowId(null); handleShareRound(r); }}
                openId={openRowId}
                setOpenId={setOpenRowId}
              />
            ))}
          </div>
          {/* ── Edit lock/unlock toggle ── */}
          {onLoadRound && filtered.length > 0 && (
            <div style={{ display:'flex', justifyContent:'center', marginTop:10 }}>
              <button
                onClick={(e) => { e.stopPropagation(); setEditUnlocked(u => !u); }}
                title={editUnlocked ? 'Lock editing to most recent rounds only' : 'Unlock editing for all rounds'}
                style={{
                  border: 'none', background: 'none', cursor: 'pointer', padding: '4px 10px',
                  display: 'flex', alignItems: 'center', gap: 5,
                  color: editUnlocked ? G : '#bbb',
                  fontSize: 11, fontWeight: 600, fontFamily: 'inherit',
                }}>
                {editUnlocked ? (
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                    stroke={G} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
                  </svg>
                ) : (
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                    stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                  </svg>
                )}
                {editUnlocked ? 'All rounds editable' : 'Edit locked'}
              </button>
            </div>
          )}
        </Card>

        {/* ── Backup & Restore ── */}
        <Card>
          <div style={{ fontWeight:700, fontSize:13, color:G, marginBottom:4 }}>Backup &amp; Restore</div>
          <div style={{ fontSize:12, color:'#888', marginBottom:10 }}>Export saves <strong>all</strong> players, courses, and rounds. Import lets you choose what to restore.</div>
          <div style={{ display:'flex', gap:8 }}>
            <button
              onClick={handleExport}
              style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6,
                padding:'8px 0', border:`1.5px solid ${G}`, borderRadius:9,
                background:'#fff', color:G, fontWeight:700, fontSize:12,
                cursor:'pointer', fontFamily:'inherit' }}>
              <IconDownload color={G} size={14} />
              Export
            </button>
            <button
              onClick={() => document.getElementById('imp-f').click()}
              style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6,
                padding:'8px 0', border:'1.5px solid #ddd', borderRadius:9,
                background:'#f8f8f8', color:'#666', fontWeight:700, fontSize:12,
                cursor:'pointer', fontFamily:'inherit' }}>
              <IconUpload color="#666" size={14} />
              Import
            </button>
            <input id="imp-f" type="file" accept=".json" style={{ display:'none' }}
              onChange={e => { handleImportFile(e.target.files?.[0]); e.target.value = ''; }}/>
          </div>
        </Card>

      </div>

      {summaryRound && <RoundSummaryModal r={summaryRound} onClose={() => setSummaryRound(null)}/>}

      {showOrienPick && (
        <ShareOrientationPicker
          onPick={handleShareWithOrientation}
          onDismiss={() => setShowOrienPick(false)}
        />
      )}

      {/* Share error toast */}
      {shareStatus === 'error' && shareError && (
        <div style={{ position:'fixed', bottom:80, left:'50%', transform:'translateX(-50%)',
          background:RED, color:'#fff', borderRadius:10, padding:'10px 18px',
          fontSize:13, fontWeight:600, zIndex:500, whiteSpace:'nowrap' }}
          onClick={() => setShareStatus('idle')}>
          {shareError} (tap to dismiss)
        </div>
      )}

      {/* Winnings detail modal — unchanged */}
      {showWinningsDetail && (() => {
        const bgn=(g)=>g.replace(/[^\w\s]/g,'').trim().split(/\s+/)[0];
        const gk=Object.keys(cumulative.byGame);const seen=new Set();
        const games=gk.map(g=>({key:g,base:bgn(g)})).filter(({base})=>{if(seen.has(base))return false;seen.add(base);return true;}).sort((a,b)=>a.base.localeCompare(b.base));
        const gt=(base,name)=>gk.filter(g=>bgn(g)===base).reduce((s,g)=>s+(cumulative.byGame[g]?.[name]||0),0);
        const sp=Object.entries(cumulative.byPlayer).sort((a,b)=>b[1]-a[1]);
        const RH=34, HH=30;
        return (
          <div style={{ position:'fixed',inset:0,background:'rgba(0,0,0,.55)',zIndex:500,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:16 }} onClick={()=>setShowWinningsDetail(false)}>
            <div style={{ background:'#fff',borderRadius:18,width:'100%',maxWidth:600,maxHeight:'85vh',display:'flex',flexDirection:'column',overflow:'hidden' }} onClick={e=>e.stopPropagation()}>
              <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',padding:'16px 18px 12px',borderBottom:'1px solid #eee',flexShrink:0 }}>
                <div><div style={{ fontWeight:800,fontSize:16,color:G }}>Cumulative Winnings</div><div style={{ fontSize:11,color:'#aaa',marginTop:1 }}>swipe right to see all games</div></div>
                <button onClick={()=>setShowWinningsDetail(false)} style={{ border:'none',background:'none',fontSize:20,color:'#bbb',cursor:'pointer',lineHeight:1,padding:'0 4px' }}>✕</button>
              </div>
              <div style={{ flex:1,overflowY:'auto',display:'flex',alignItems:'stretch' }}>
                <div style={{ flexShrink:0,zIndex:2,boxShadow:'2px 0 6px rgba(0,0,0,.06)' }}>
                  <table style={{ borderCollapse:'collapse',fontSize:13,tableLayout:'fixed' }}>
                    <thead><tr style={{ height:HH }}>
                      <th style={{ textAlign:'left',padding:'4px 8px 4px 16px',background:'#f0f4f0',color:'#555',fontSize:11,whiteSpace:'nowrap',minWidth:110 }}>Player</th>
                      <th style={{ textAlign:'right',padding:'4px 14px 4px 6px',background:'#f0f4f0',color:'#555',fontSize:11,fontWeight:800,whiteSpace:'nowrap',minWidth:72 }}>Total</th>
                    </tr></thead>
                    <tbody>{sp.map(([name,total],i)=>(
                      <tr key={i} style={{ height:RH,background:i%2===0?'#fff':'#fafafa' }}>
                        <td style={{ padding:'4px 8px 4px 16px',fontWeight:600,whiteSpace:'nowrap',maxWidth:160,overflow:'hidden',textOverflow:'ellipsis' }}>{name}</td>
                        <td style={{ padding:'4px 14px 4px 6px',textAlign:'right',fontWeight:700,whiteSpace:'nowrap',color:total>0?'#27ae60':total<0?RED:'#555' }}>{fmtMoney(total)}</td>
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
                <div style={{ width:1,background:'#d8ead8',flexShrink:0 }}/>
                <div style={{ overflowX:'auto',flex:1 }}>
                  {games.length===0?<div style={{ padding:'20px 16px',fontSize:12,color:'#aaa' }}>No game breakdown available.</div>:(
                    <table style={{ borderCollapse:'collapse',fontSize:12,tableLayout:'fixed' }}>
                      <thead><tr style={{ height:HH }}>{games.map(({base})=><th key={base} style={{ textAlign:'center',padding:'4px 10px',background:'#f0f4f0',color:'#555',fontSize:11,whiteSpace:'nowrap',minWidth:80 }}>{base}</th>)}</tr></thead>
                      <tbody>{sp.map(([name],i)=>(
                        <tr key={i} style={{ height:RH,background:i%2===0?'#fff':'#fafafa' }}>
                          {games.map(({base})=>{const v=gt(base,name);return <td key={base} style={{ padding:'4px 10px',textAlign:'center',whiteSpace:'nowrap',color:v>0?'#27ae60':v<0?RED:'#999',fontWeight:v!==0?600:400 }}>{v!==0?fmtMoney(v):'—'}</td>;})}
                        </tr>
                      ))}</tbody>
                    </table>
                  )}
                </div>
              </div>
              <div style={{ padding:'10px 18px',borderTop:'1px solid #eee',flexShrink:0 }}>
                <button onClick={()=>setShowWinningsDetail(false)} style={{ width:'100%',padding:'10px',borderRadius:10,border:`1.5px solid ${G}`,background:GA,color:G,fontWeight:700,fontSize:14,cursor:'pointer',fontFamily:'inherit' }}>Close</button>
              </div>
            </div>
          </div>
        );
      })()}

      {importModal && <ImportModal parsed={importModal.parsed} onConfirm={handleImportConfirmSections} onClose={() => setImportModal(null)}/>}
      {conflictModal && <ImportConflictModal conflicts={conflictModal.conflicts} onResolved={handleConflictsResolved} onClose={() => { setConflictModal(null); alert('Import cancelled.'); }}/>}
    </div>
  );
}
