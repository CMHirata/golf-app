// ─── pages/RoundSummaryModal.jsx ──────────────────────────────────────────────
// Read-only full-screen modal: scorecard + game tables + payouts.
//
// Portrait:  scorecard = Front 9 over Back 9; game tables = portrait (unchanged).
// Landscape: modal fills full screen; scorecard = 18-hole single row;
//            game tables receive isLandscape=true for 18-hole layout.
//
// Scorecard column widths match game table COL_W so holes align vertically.
// Payouts section: no emojis, left-justified headers, per-match breakdown.

import { useMemo, useState, useEffect, useCallback } from 'react';
import { G, RED, fmtDate, ShareOrientationPicker } from '../components/ui.jsx';
import { roundLib } from '../services/roundLib.js';
import { restoreDotDefs, COL_W, TOT_W, NAME_MIN } from './scorecard/scorecardUtils.js';
import { MatchNassauTable } from './tables/MatchNassauTable.jsx';
import { SixesTable }       from './tables/SixesTable.jsx';
import { SkinsTable }       from './tables/SkinsTable.jsx';
import { NinesTable }       from './tables/NinesTable.jsx';
import { StablefordTable }  from './tables/StablefordTable.jsx';
import { StrokePlayTable }  from './tables/StrokePlayTable.jsx';
import { DotsTable }        from './tables/DotsTable.jsx';
import { TotalsCard }       from './scorecard/TotalsCard.jsx';
import { computePayouts }   from '../engine/payouts.js';
import { buildPayoutArgs, computePerMatchPayouts, cleanGameName, triggerRoundShare, buildShareImage } from '../services/roundUtils.js';

const FRONT = [0,1,2,3,4,5,6,7,8];
const BACK  = [9,10,11,12,13,14,15,16,17];

const fmtMoney = (v) =>
  v > 0 ? `+$${Math.abs(v).toFixed(2)}` : v < 0 ? `-$${Math.abs(v).toFixed(2)}` : '$0';

function SectionLabel({ children }) {
  return (
    <div style={{ fontSize:11, fontWeight:700, color:G, marginBottom:6, marginTop:14,
      textTransform:'uppercase', letterSpacing:'0.5px' }}>
      {children}
    </div>
  );
}

// ── Landscape detection ────────────────────────────────────────────────────────
function useIsLandscape() {
  const [ls, setLs] = useState(() => window.innerWidth > window.innerHeight);
  useEffect(() => {
    const upd = () => setLs(window.innerWidth > window.innerHeight);
    window.addEventListener('resize', upd);
    window.addEventListener('orientationchange', upd);
    return () => { window.removeEventListener('resize', upd); window.removeEventListener('orientationchange', upd); };
  }, []);
  return ls;
}

// ── Read-only scorecard ────────────────────────────────────────────────────────
// Uses same COL_W / TOT_W / NAME_MIN as GameTable so hole columns align.
// Portrait: Front 9 over Back 9 (two separate tables, identical widths).
// Landscape: single 18-hole table with F9 / B9 / Tot subtotals.
function ReadOnlyScorecard({ players, scores, pars, hcps, courseSnapshot, isLandscape, frontNineName, backNineName, courseHcps, minCourseHcp, dotMode }) {
  const womenSI = useMemo(() => {
    if (!courseSnapshot?.nines) return null;
    const allW = courseSnapshot.nines.flatMap(n => n.handicapsWomen || []);
    return allW.length >= 18 ? allW.slice(0, 18) : (allW.length > 0 ? allW : null);
  }, [courseSnapshot]);

  const genders   = players.map(p => (p.gender || '').toLowerCase());
  const hasFemale = genders.some(g => g === 'f' || g === 'female' || g === 'w');
  const hasMale   = genders.some(g => g === 'm' || g === 'male' || !g);
  const mixed     = hasFemale && hasMale;
  const allFem    = hasFemale && !hasMale;

  const siRows = [];
  if (mixed && womenSI) {
    siRows.push({ label: 'Stroke Index (M)', vals: hcps });
    siRows.push({ label: 'Stroke Index (W)', vals: womenSI });
  } else if (allFem && womenSI) {
    siRows.push({ label: 'Stroke Index', vals: womenSI });
  } else {
    siRows.push({ label: 'Stroke Index', vals: hcps });
  }

  const parF = FRONT.reduce((s,h) => s + (pars[h]||0), 0);
  const parB = BACK.reduce((s,h)  => s + (pars[h]||0), 0);

  // Handicap stroke dots — small green circles, absolutely positioned bottom-right
  const hcpDots = (pi, h) => {
    if (!dotMode || dotMode === 'gross' || !courseHcps) return null;
    const ch   = courseHcps[pi] ?? 0;
    const rank = hcps[h] ?? 0;
    let strokes = 0;
    if (dotMode === 'netofflow') {
      const diff = ch - (minCourseHcp ?? 0);
      strokes = diff > 0 ? Math.max(0, Math.floor(diff/18) + (rank <= diff%18 ? 1 : 0)) : 0;
    } else {
      strokes = Math.max(0, Math.floor(ch/18) + (rank <= ch%18 ? 1 : 0));
    }
    if (strokes <= 0) return null;
    return Array.from({ length: strokes }).map((_, i) =>
      <div key={i} style={{ width:3, height:3, borderRadius:'50%', background:G, flexShrink:0 }}/>
    );
  };

  // Shared styles for score cells
  const scoreTd = (h, pi) => {
    const s = parseInt(scores[h]?.[pi]) || 0;
    const dots = s ? hcpDots(pi, h) : null;
    return <td key={h} style={{ textAlign:'center', padding:'1px', color: s ? '#222' : '#ccc', fontSize:10 }}>
      <div style={{ position:'relative', display:'inline-block', minWidth:12 }}>
        {s||'·'}
        {dots && <div style={{ position:'absolute', bottom:0, right:-1, display:'flex', gap:1, pointerEvents:'none' }}>{dots}</div>}
      </div>
    </td>;
  };

  // Shared header cell style
  const totHdr = { textAlign:'center', padding:'2px 3px', background:'#e8f0e8', color:G, fontWeight:800, fontSize:10 };
  const parTd  = (h) => <td key={h} style={{ textAlign:'center', fontSize:9, color:G, fontWeight:600, background:'#f8fbf8' }}>{pars[h]||''}</td>;
  const siTd   = (vals, h) => <td key={h} style={{ textAlign:'center', fontSize:9, color:'#ccc', background:'#fafcfa' }}>{vals?.[h]||''}</td>;

  if (isLandscape) {
    // Single 18-hole table — minWidth matches GameTable landscape minWidth
    const tableMinW = NAME_MIN + 18*COL_W + 2*TOT_W + TOT_W;
    return (
      <div style={{ overflowX:'auto', marginBottom:10 }}>
        <table style={{ borderCollapse:'collapse', tableLayout:'fixed', width:'100%', minWidth: tableMinW, fontSize:10 }}>
          <colgroup>
            <col style={{ minWidth: NAME_MIN }}/>
            {FRONT.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
            {BACK.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
            <col style={{ width: TOT_W }}/>
          </colgroup>
          <thead>
            <tr>
              <th style={{ textAlign:'left', padding:'2px 6px', background:'#f0f4f0', color:'#555', fontSize:10 }}></th>
              {FRONT.map(h => <th key={h} style={{ textAlign:'center', padding:'2px 1px', background:'#f0f4f0', color:'#555', fontWeight:400, fontSize:10 }}>{h+1}</th>)}
              <th style={totHdr}>F9</th>
              {BACK.map(h => <th key={h} style={{ textAlign:'center', padding:'2px 1px', background:'#f0f4f0', color:'#555', fontWeight:400, fontSize:10 }}>{h+1}</th>)}
              <th style={totHdr}>B9</th>
              <th style={{ ...totHdr, background:'#d8ead8' }}>Tot</th>
            </tr>
            <tr>
              <td style={{ padding:'1px 6px', fontSize:9, color:G, fontWeight:700, background:'#f8fbf8' }}>Par</td>
              {FRONT.map(h => parTd(h))}
              <td style={{ textAlign:'center', fontSize:9, fontWeight:700, color:G, background:'#eef4ee' }}>{parF}</td>
              {BACK.map(h => parTd(h))}
              <td style={{ textAlign:'center', fontSize:9, fontWeight:700, color:G, background:'#eef4ee' }}>{parB}</td>
              <td style={{ textAlign:'center', fontSize:9, fontWeight:700, color:G, background:'#eaf4ea' }}>{parF+parB}</td>
            </tr>
            {siRows.map(({ label, vals }) => (
              <tr key={label}>
                <td style={{ padding:'1px 6px', fontSize:9, color:'#aaa', background:'#fafcfa' }}>{label}</td>
                {FRONT.map(h => siTd(vals, h))}
                <td style={{ background:'#fafcfa' }}/>
                {BACK.map(h => siTd(vals, h))}
                <td style={{ background:'#fafcfa' }}/><td style={{ background:'#fafcfa' }}/>
              </tr>
            ))}
          </thead>
          <tbody>
            {players.map((p, pi) => {
              const name = typeof p === 'string' ? p : p.name;
              const f9 = FRONT.reduce((s,h) => s + (parseInt(scores[h]?.[pi])||0), 0);
              const b9 = BACK.reduce((s,h)  => s + (parseInt(scores[h]?.[pi])||0), 0);
              return (
                <tr key={pi} style={{ background: pi%2===0 ? '#fff' : '#f5fbf5' }}>
                  <td style={{ padding:'2px 6px', fontWeight:600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', fontSize:11 }}>{name}</td>
                  {FRONT.map(h => scoreTd(h, pi))}
                  <td style={{ textAlign:'center', fontWeight:700, background:'#eef4ee', color:G, padding:'1px 2px', fontSize:10 }}>{f9||'-'}</td>
                  {BACK.map(h => scoreTd(h, pi))}
                  <td style={{ textAlign:'center', fontWeight:700, background:'#eef4ee', color:G, padding:'1px 2px', fontSize:10 }}>{b9||'-'}</td>
                  <td style={{ textAlign:'center', fontWeight:800, background:'#e8f4e8', color:G, padding:'1px 3px', fontSize:10 }}>{(f9+b9)||'-'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  // Portrait: two stacked half-tables. Each uses same COL_W/TOT_W/NAME_MIN as GameTable.
  // R-3: Use named nine labels if available, matching ScoreGrid.jsx format.
  const frontLabel = frontNineName ? `Front 9 (${frontNineName})` : 'Front 9';
  const backLabel  = backNineName  ? `Back 9 (${backNineName})`   : 'Back 9';

  const renderHalf = (hs, label, parTot, isFront) => (
    <div style={{ marginBottom:10 }}>
      <div style={{ fontSize:10, fontWeight:600, color:'#888', marginBottom:3 }}>{label}</div>
      <div style={{ overflowX:'auto' }}>
        <table style={{ borderCollapse:'collapse', tableLayout:'fixed', width:'100%', minWidth: NAME_MIN + 9*COL_W + TOT_W, fontSize:10 }}>
          <colgroup>
            <col style={{ minWidth: NAME_MIN }}/>
            {hs.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
          </colgroup>
          <thead>
            <tr>
              <th style={{ textAlign:'left', padding:'2px 6px', background:'#f0f4f0', color:'#555', fontSize:10 }}></th>
              {hs.map(h => <th key={h} style={{ textAlign:'center', padding:'2px 1px', background:'#f0f4f0', color:'#555', fontWeight:400 }}>{h+1}</th>)}
              <th style={totHdr}>{isFront ? 'F9' : 'B9'}</th>
            </tr>
            <tr>
              <td style={{ padding:'1px 6px', fontSize:9, color:G, fontWeight:700, background:'#f8fbf8' }}>Par</td>
              {hs.map(h => parTd(h))}
              <td style={{ textAlign:'center', fontSize:9, fontWeight:700, color:G, background:'#eef4ee' }}>{parTot}</td>
            </tr>
            {siRows.map(({ label: siLabel, vals }) => (
              <tr key={siLabel}>
                <td style={{ padding:'1px 6px', fontSize:9, color:'#aaa', background:'#fafcfa' }}>{siLabel}</td>
                {hs.map(h => siTd(vals, h))}
                <td style={{ background:'#fafcfa' }}/>
              </tr>
            ))}
          </thead>
          <tbody>
            {players.map((p, pi) => {
              const name = typeof p === 'string' ? p : p.name;
              const tot  = hs.reduce((s,h) => s + (parseInt(scores[h]?.[pi])||0), 0);
              return (
                <tr key={pi} style={{ background: pi%2===0 ? '#fff' : '#f5fbf5' }}>
                  <td style={{ padding:'2px 6px', fontWeight:600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', fontSize:11 }}>{name}</td>
                  {hs.map(h => scoreTd(h, pi))}
                  <td style={{ textAlign:'center', fontWeight:700, background:'#eef4ee', color:G, padding:'1px 2px', fontSize:10 }}>{tot||'-'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <>
      {renderHalf(FRONT, frontLabel, parF, true)}
      {renderHalf(BACK,  backLabel,  parB, false)}
    </>
  );
}

// ── Dots columnar payout row ───────────────────────────────────────────────────
function DotsColTable({ entry }) {
  if (!entry?.colHeaders?.length || !entry?.rows?.length) return null;
  const headers   = entry.colHeaders;
  const rows      = entry.rows;
  const fmtCol    = v => v > 0 ? `+$${Math.abs(v).toFixed(2)}` : v < 0 ? `-$${Math.abs(v).toFixed(2)}` : '$0';
  const colClr    = v => v > 0 ? '#27ae60' : v < 0 ? RED : '#888';
  const isTot     = (i) => i === headers.length - 1;
  const COL_W     = 52;  // px — fixed width for each data column
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11,
                    marginTop: 2, tableLayout: 'fixed' }}>
      <colgroup>
        <col/>  {/* name column — takes all remaining space */}
        {headers.map((_, i) => <col key={i} style={{ width: COL_W }}/>)}
      </colgroup>
      <thead>
        <tr>
          <td style={{ padding: '2px 0', color: '#888', fontWeight: 500, fontSize: 10 }}></td>
          {headers.map((h, i) => (
            <td key={i} style={{ padding: '2px 4px',
                                  textAlign: isTot(i) ? 'right' : 'center',
                                  color: '#888',
                                  fontSize: 10, fontWeight: isTot(i) ? 700 : 500,
                                  borderBottom: '1px solid #e8f0e8',
                                  whiteSpace: 'nowrap' }}>
              {h}
            </td>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, ri) => (
          <tr key={ri} style={{ borderBottom: '1px solid #f8f8f8' }}>
            <td style={{ padding: '2px 0', color: '#555', fontSize: 11,
                         overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {r.name}
            </td>
            {(r.matchCols || []).map((v, ci) => (
              <td key={ci} style={{ padding: '2px 4px',
                                     textAlign: isTot(ci) ? 'right' : 'center',
                                     fontWeight: isTot(ci) ? 700 : 600,
                                     color: colClr(v), fontSize: isTot(ci) ? 12 : 11,
                                     whiteSpace: 'nowrap' }}>
                {fmtCol(v)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ── Payouts section ────────────────────────────────────────────────────────────
// No emojis. Left-justified subheaders.
function PayoutsSummary({ bank, breakdown, matchPayouts }) {
  if (!bank || !Object.keys(bank).length) {
    return <div style={{ fontSize:12, color:'#aaa', padding:'8px 0', textAlign:'center' }}>No payout data available.</div>;
  }

  const sorted = Object.entries(bank).sort((a,b) => b[1]-a[1]);
  const otherEntries = (breakdown || []).filter(e =>
    e.game !== '🥊 Match / Nassau' && e.game !== 'Match / Nassau'
  );

  const subHeader = (text) => (
    <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:3, paddingBottom:2,
      borderBottom:'1px solid #e8f0e8' }}>
      {text}
    </div>
  );

  const renderPayRow = (name, net, i) => (
    <div key={i} style={{ display:'flex', justifyContent:'space-between', fontSize:11,
      padding:'2px 0', borderBottom:'1px solid #f8f8f8' }}>
      <span style={{ color:'#555' }}>{name}</span>
      <span style={{ fontWeight:600, color: net>0?'#27ae60':net<0?RED:'#888' }}>{fmtMoney(net)}</span>
    </div>
  );

  return (
    <>
      {/* Overall totals */}
      <div style={{ fontSize:11, fontWeight:700, color:'#555', marginBottom:6 }}>Overall (all games)</div>
      {sorted.map(([name, v], i) => (
        <div key={i} style={{ display:'flex', justifyContent:'space-between', fontSize:13,
          padding:'5px 0', borderBottom:'1px solid #f0f8f0' }}>
          <span style={{ fontWeight:500 }}>{name}</span>
          <span style={{ fontWeight:700, color: v>0?'#27ae60':v<0?RED:'#888' }}>{fmtMoney(v)}</span>
        </div>
      ))}

      <div style={{ marginTop:12 }}>
        <div style={{ fontSize:11, fontWeight:700, color:'#888', marginBottom:8 }}>By game</div>

        {/* Per-match payouts */}
        {matchPayouts.map((match, mi) => {
          const nonZero = match.rows.filter(r => r.net !== 0);
          if (!nonZero.length) return null;
          return (
            <div key={`match_${mi}`} style={{ marginBottom:10 }}>
              {subHeader(match.label)}
              {nonZero.map((r, i) => renderPayRow(r.name, r.net, i))}
            </div>
          );
        })}

        {/* Other games */}
        {otherEntries.map((entry, ei) => {
          // Team Dots: always render when colHeaders present — do not suppress on zero-net rows.
          if (entry.colHeaders) {
            return (
              <div key={`game_${ei}`} style={{ marginBottom:10 }}>
                {subHeader(cleanGameName(entry.game))}
                <DotsColTable entry={entry}/>
              </div>
            );
          }
          const rows = (entry.rows || []).filter(r => r.net != null && r.net !== 0);
          if (!rows.length) return null;
          return (
            <div key={`game_${ei}`} style={{ marginBottom:10 }}>
              {subHeader(cleanGameName(entry.game))}
              {rows.map((r, i) => renderPayRow(r.name, r.net, i))}
            </div>
          );
        })}
      </div>
    </>
  );
}

// ── Main modal ─────────────────────────────────────────────────────────────────
export function RoundSummaryModal({ r, onClose }) {
  const isLandscape = useIsLandscape();

  // S-4: share — build image eagerly on tap, then fire share sheet synchronously
  const [shareStatus,   setShareStatus]   = useState('idle');
  const [shareError,    setShareError]    = useState('');
  const [showOrienPick, setShowOrienPick] = useState(false);

  const ar = useMemo(() => {
    try { return roundLib.toActiveRound(r); }
    catch(e) { console.error('RoundSummaryModal: toActiveRound failed', e); return null; }
  }, [r]);

  const { bank, breakdown } = useMemo(() => {
    if (!ar) return { bank: r.bank || {}, breakdown: r.breakdown || [] };
    try { return computePayouts(buildPayoutArgs(ar)); }
    catch(e) { return { bank: r.bank || {}, breakdown: r.breakdown || [] }; }
  }, [ar, r]);

  const matchPayouts = useMemo(() => {
    if (!ar) return [];
    try {
      return computePerMatchPayouts(ar.matches || [], ar.activePlayers, ar.scores, ar.hcps, ar.courseHcps, ar.minCourseHcp, ar.manualPresses);
    } catch(e) { return []; }
  }, [ar]);

  const handleShare = useCallback(() => {
    if (!ar) return;
    setShowOrienPick(true);
  }, [ar]);

  const handleShareWithOrientation = useCallback(async (orientation) => {
    if (!ar) return;
    setShowOrienPick(false);
    setShareStatus('building');
    setShareError('');
    try {
      const blob = await buildShareImage(r, ar, bank, breakdown, matchPayouts, orientation);
      await triggerRoundShare(r, ar, bank, breakdown, matchPayouts, blob, orientation);
      setShareStatus('done');
    } catch(err) {
      if (err?.name === 'AbortError') { setShareStatus('idle'); return; }
      console.error('Share failed:', err);
      setShareError('Could not share. Try again.');
      setShareStatus('error');
    }
  }, [ar, r, bank, breakdown, matchPayouts]);

  if (!ar) return (
    <div style={{ position:'fixed',inset:0,background:'rgba(0,0,0,.5)',zIndex:300,
      display:'flex',alignItems:'center',justifyContent:'center',padding:16 }} onClick={onClose}>
      <div style={{ background:'#fff',borderRadius:16,padding:24,maxWidth:400,width:'100%' }} onClick={e=>e.stopPropagation()}>
        <div style={{ color:RED, fontWeight:700 }}>Could not load round data.</div>
        <button onClick={onClose} style={{ marginTop:12,padding:'8px 20px',borderRadius:8,border:`1px solid ${G}`,background:'#eef4ee',color:G,fontWeight:700,cursor:'pointer',fontFamily:'inherit' }}>Close</button>
      </div>
    </div>
  );

  const {
    activePlayers: players, pars, hcps, courseHcps, minCourseHcp,
    scores, activeGames, gameOpts,
    matches, sixesTeams, skinsPlayers, stablefordPlayers,
    ninesPlayers, strokePlayPlayers, dotsPlayers,
    dots: rawDots, dotEntries, manualPresses,
    frontNine, backNine,
  } = ar;

  const dots = restoreDotDefs(rawDots);

  const ninesSuffix = (() => {
    const n = (r.course_snapshot?.nines || []).length;
    return n > 2 && frontNine && backNine ? ` · ${frontNine} / ${backNine}` : '';
  })();

  // Full-screen in landscape; floating window in portrait
  const modalStyle = isLandscape
    ? { width:'100%', maxWidth:'100vw', height:'100vh', borderRadius:0 }
    : { width:'calc(100% - 32px)', maxWidth:560, maxHeight:'93vh', borderRadius:20 };

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.45)', zIndex:300,
      display:'flex', flexDirection:'column', alignItems:'center',
      justifyContent: isLandscape ? 'flex-start' : 'center' }}
      onClick={onClose}>

      <div style={{ background:'#eef4ee', ...modalStyle,
        display:'flex', flexDirection:'column', overflow:'hidden' }}
        onClick={e=>e.stopPropagation()}>

        {/* Header */}
        <div style={{ background:G, padding: isLandscape ? '10px 18px' : '16px 18px 14px', flexShrink:0 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
            <div>
              <div style={{ fontWeight:800, fontSize: isLandscape ? 15 : 17, color:'#fff' }}>
                {r.course_name || 'Unknown Course'}{ninesSuffix}
              </div>
              <div style={{ fontSize:12, color:'#a8d8a8', marginTop:2 }}>
                {fmtDate(r.date)} · Read-only summary
              </div>
            </div>
            <button onClick={onClose}
              style={{ border:'none', background:'rgba(255,255,255,.15)', borderRadius:20, width:32, height:32,
                display:'flex', alignItems:'center', justifyContent:'center',
                cursor:'pointer', color:'#fff', fontSize:16, flexShrink:0 }}>
              ✕
            </button>
          </div>
          {/* Player chips: Name · HI · CH · Tee — equal-width, 2-per-row (or 3 if exactly 3) */}
          <PlayerChipsGrid players={players} courseHcps={courseHcps} selectedTee={r.selected_tee} />
        </div>

        {/* Scrollable body */}
        <div style={{ flex:1, overflowY:'auto', padding: isLandscape ? '4px 10px 12px' : '4px 14px 20px' }}>

          <SectionLabel>Scorecard</SectionLabel>
          <ReadOnlyScorecard
            players={players} scores={scores} pars={pars} hcps={hcps}
            courseSnapshot={r.course_snapshot}
            isLandscape={isLandscape}
            frontNineName={frontNine}
            backNineName={backNine}
            courseHcps={courseHcps}
            minCourseHcp={minCourseHcp}
            dotMode={(() => {
              // Derive handicap dot mode — same priority as deriveShareDotMode in roundUtils:
              // net > NOL-full-field > NOL-subset > gross.
              // Only check active scoring games; exclude Dots (always gross for scoring).
              const scoringKeys = ['Skins','Stableford','Nines','Stroke Play','Sixes'];
              const matchModes  = (matches||[]).map(m => m.grossNetNOL ?? m.scoring ?? 'net');
              const gameModes   = scoringKeys
                .filter(k => (activeGames||[]).includes(k))
                .map(k => gameOpts?.[k]?.grossNetNOL ?? gameOpts?.[k]?.scoring ?? 'net');
              const allModes = [...gameModes, ...matchModes];
              if (!allModes.length) return 'gross';
              if (allModes.some(m => m === 'net')) return 'net';
              if (allModes.some(m => m === 'netofflow')) return 'netofflow';
              return 'gross';
            })()}
          />

          <TotalsCard
            players={players}
            pars={pars}
            scores={scores}
            courseHcps={courseHcps}
            hcps={hcps}
          />

          {activeGames?.length > 0 && (
            <>
              <SectionLabel>Game Results</SectionLabel>

              {activeGames.includes('Nines') && (
                <NinesTable players={players} scores={scores} pars={pars} hcps={hcps}
                  opts={gameOpts?.Nines} courseHcps={courseHcps} minCourseHcp={minCourseHcp}
                  ninesPlayers={ninesPlayers} isLandscape={isLandscape}/>
              )}
              {activeGames.includes('Stableford') && (
                <StablefordTable players={players} scores={scores} pars={pars} hcps={hcps}
                  opts={gameOpts?.Stableford} courseHcps={courseHcps} minCourseHcp={minCourseHcp}
                  stablefordPlayers={stablefordPlayers} isLandscape={isLandscape}/>
              )}
              {activeGames.includes('Skins') && (
                <SkinsTable players={players} scores={scores} hcps={hcps}
                  opts={gameOpts?.Skins} courseHcps={courseHcps} minCourseHcp={minCourseHcp}
                  skinsPlayerIdxs={skinsPlayers} isLandscape={isLandscape}/>
              )}
              {activeGames.includes('Stroke Play') && (
                <StrokePlayTable players={players} scores={scores} pars={pars} hcps={hcps}
                  opts={gameOpts?.['Stroke Play']} courseHcps={courseHcps} minCourseHcp={minCourseHcp}
                  strokePlayPlayers={strokePlayPlayers} isLandscape={isLandscape}/>
              )}
              {activeGames.includes('Match / Nassau') && (
                <MatchNassauTable
                  players={players} scores={scores} hcps={hcps}
                  matches={matches || []} courseHcps={courseHcps} minCourseHcp={minCourseHcp}
                  manualPresses={manualPresses || {}} setManualPresses={() => {}}
                  isLandscape={isLandscape}
                />
              )}
              {activeGames.includes('Sixes') && (
                <SixesTable players={players} scores={scores} hcps={hcps}
                  opts={gameOpts?.Sixes} sixesTeams={sixesTeams}
                  courseHcps={courseHcps} minCourseHcp={minCourseHcp}
                  manualPresses={manualPresses || {}} setManualPresses={() => {}}/>
              )}
              {(activeGames.includes('Dots') || activeGames.includes('Specials')) && (
                <DotsTable players={players} dots={dots} dotEntries={dotEntries}
                  sixesTeams={sixesTeams} matches={matches}
                  gameOpts={gameOpts} dotsPlayers={dotsPlayers}
                  isLandscape={isLandscape}/>
              )}
            </>
          )}

          <SectionLabel>Payouts</SectionLabel>
          <PayoutsSummary bank={bank} breakdown={breakdown} matchPayouts={matchPayouts} />

          {/* S-4: Share Summary */}
          <div style={{ marginTop: 20 }}>
            {shareStatus === 'error' && (
              <div style={{ fontSize:12, color:RED, marginBottom:8, textAlign:'center' }}>{shareError}</div>
            )}
            <button
              onClick={handleShare}
              disabled={shareStatus === 'building'}
              style={{
                width:'100%', display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                padding:'13px 0', borderRadius:14,
                background: shareStatus === 'building' ? '#aaa' : G,
                border:'none', cursor: shareStatus === 'building' ? 'not-allowed' : 'pointer',
                color:'#fff', fontWeight:700, fontSize:14, fontFamily:'inherit',
              }}>
              {shareStatus === 'building' ? 'Building…' : shareStatus === 'done' ? 'Shared ✓' : 'Share Summary'}
            </button>
          </div>
        </div>
      </div>

      {showOrienPick && (
        <ShareOrientationPicker
          onPick={handleShareWithOrientation}
          onDismiss={() => setShowOrienPick(false)}
        />
      )}

    </div>
  );
}

// ── PlayerChipsGrid ────────────────────────────────────────────────────────────
// Equal-width chips. If exactly 3 players, all 3 on one row.
// Otherwise 2-per-row. Each chip is ~half the available width.
function PlayerChipsGrid({ players, courseHcps, selectedTee }) {
  const n = players.length;
  // 3 players → single row of 3; all other counts → 2-per-row
  const cols = n === 3 ? 3 : 2;
  return (
    <div style={{ display:'grid', gridTemplateColumns:`repeat(${cols}, 1fr)`, gap:5, marginTop:8 }}>
      {players.map((p, i) => {
        const hi  = p.ghin != null && p.ghin !== '' ? p.ghin : null;
        const ch  = courseHcps[i] != null ? courseHcps[i] : (p.courseHcpVal ?? null);
        const tee = p.selectedTee || selectedTee || '';
        return (
          <div key={i} style={{ background:'rgba(255,255,255,.18)', borderRadius:20, padding:'4px 10px', fontSize:11, minWidth:0 }}>
            <span style={{ fontWeight:700, color:'#fff' }}>{p.name}</span>
            {hi  != null && <span style={{ color:'#b8d8b8', marginLeft:4 }}>HI {hi}</span>}
            {ch  != null && <span style={{ color:'#a8c8a8', marginLeft:4 }}>CH {ch}</span>}
            {tee          && <span style={{ color:'#c8e8c8', marginLeft:4 }}>{tee}</span>}
          </div>
        );
      })}
    </div>
  );
}
