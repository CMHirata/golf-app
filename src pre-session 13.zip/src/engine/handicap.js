// ─── handicap.js ─────────────────────────────────────────────────────────────
// USGA handicap math. No React. Fully unit-testable.
//
// KEY DISTINCTION:
//   Handicap Index  = the portable number on your GHIN card (e.g. 8.2, +5.4)
//   Course Handicap = strokes you get/give at a specific course/tee
//                   = Index × (Slope/113) + (Rating - Par)  → rounded to integer
//
// Plus handicaps (e.g. +5.4) are stored as negative numbers internally (-5.4).
// A player with a +5 course handicap GIVES 5 strokes back — they receive 0
// strokes on any hole, and for net off low purposes others get extra strokes
// relative to them.

export const DEF_PARS = [4,4,3,5,4,3,4,5,4, 4,3,5,4,4,3,5,4,4];
export const DEF_HCP  = [7,11,15,1,5,17,3,9,13, 8,16,2,6,12,18,4,10,14];

// ─── Parsing ─────────────────────────────────────────────────────────────────

/**
 * Parse a handicap index string to a float.
 * Handles plus handicaps entered as "+5.4", "5.4+", or just "-5.4".
 * Plus handicaps are returned as negative numbers.
 */
export function parseIndex(raw) {
  if (raw === null || raw === undefined || raw === '') return 0;
  const s = String(raw).trim();
  if (s.startsWith('+') || s.endsWith('+')) {
    return -(parseFloat(s.replace(/\+/g, '')) || 0);
  }
  return parseFloat(s) || 0;
}

/**
 * Compute course handicap from handicap index.
 * courseHandicap = round(Index x Slope/113 + (Rating - Par))
 * Returns a signed integer — negative means plus handicap (gives strokes).
 */
export function courseHandicap(index, slope, rating, par) {
  const idx = typeof index === 'string' ? parseIndex(index) : (index || 0);
  if (!slope || !rating || !par) return Math.round(idx);
  return Math.round(idx * (slope / 113) + (rating - par));
}

/**
 * Legacy helper — used where we need the integer course handicap.
 * Accepts raw ghin string and optional tee data.
 */
export const chp = (ghin, slope, rating, par) => {
  const idx = parseIndex(ghin);
  if (slope && rating && par) return courseHandicap(idx, slope, rating, par);
  return Math.round(idx);
};

// ─── Stroke allocation ────────────────────────────────────────────────────────

/**
 * How many strokes does a player receive on a specific hole?
 * courseHcp: signed integer course handicap
 * rank: hole stroke index 1-18 (1 = hardest)
 *
 * Standard allocation: a player with courseHcp 20 gets:
 *   - 1 stroke on all 18 holes (rank 1-18)
 *   - 2 strokes on the 2 hardest holes (rank 1-2)
 */
export function hdcpStrokesFromCourseHcp(courseHcp, rank) {
  if (courseHcp <= 0) return 0;
  return Math.floor(courseHcp / 18) + (rank <= courseHcp % 18 ? 1 : 0);
}

/** Net off low: strokes relative to the lowest course handicap in the group. */
function netOffLow(gross, courseHcp, minCourseHcp, rank) {
  const diff = courseHcp - minCourseHcp;
  const strokes = Math.floor(diff / 18) + (rank <= diff % 18 ? 1 : 0);
  return gross - strokes;
}

/** Standard net: just subtract stroke allocation. */
function netOf(gross, courseHcp, rank) {
  return gross - hdcpStrokesFromCourseHcp(courseHcp, rank);
}

/**
 * How many strokes does this player receive on this hole for a given scoring mode?
 * Returns the count (0, 1, or 2) for UI dot display.
 */
export function strokesForMode(courseHcp, hcpRank, minCourseHcp, mode) {
  if (mode === 'gross') return 0;
  if (mode === 'netofflow') {
    const diff = (courseHcp || 0) - (minCourseHcp || 0);
    return Math.floor(diff / 18) + (hcpRank <= diff % 18 ? 1 : 0);
  }
  return hdcpStrokesFromCourseHcp(courseHcp || 0, hcpRank);
}

/** Apply the correct scoring mode to a gross score. */
export function scoreForMode(gross, courseHcp, rank, minCourseHcp, mode) {
  if (!gross) return null;
  if (mode === 'gross')     return gross;
  if (mode === 'netofflow') return netOffLow(gross, courseHcp, minCourseHcp, rank);
  return netOf(gross, courseHcp, rank);
}

/**
 * Compute a player's Adjusted Gross Score (AGS) for GHIN posting purposes,
 * applying the USGA World Handicap System Net Double Bogey cap per hole.
 *
 * Per-hole cap: par + 2 (double bogey) + hdcpStrokesFromCourseHcp(courseHcp, rank)
 * This is "Net Double Bogey" — the maximum score per hole since 2020 WHS.
 * The strokes term uses standard net allocation (not NOL), regardless of the
 * scoring mode used for any active game.
 *
 * Only scored holes (gross > 0) contribute. Unscored holes are skipped so the
 * function works correctly mid-round on the live scorecard.
 *
 * @param {Array}  scores    — scores[hole][pi], the full 18-hole score array
 * @param {number} pi        — player index
 * @param {Array}  pars      — par[hole] for all 18 holes
 * @param {Array}  hcps      — hcps[hole] stroke index (rank 1–18) for all 18 holes
 * @param {number} courseHcp — signed integer course handicap for this player
 * @returns {number} Total adjusted gross score (0 if no holes scored)
 */
export function escTotal(scores, pi, pars, hcps, courseHcp) {
  let total = 0;
  for (let h = 0; h < 18; h++) {
    const gross = parseInt(scores[h]?.[pi]) || 0;
    if (!gross) continue;
    const cap = (pars[h] || 0) + 2 + hdcpStrokesFromCourseHcp(courseHcp, hcps[h]);
    total += Math.min(gross, cap);
  }
  return total;
}

// ─── Stableford ──────────────────────────────────────────────────────────────
// Modified Stableford scoring (default):
//   d = par - net_score  (positive = under par)
//   albatross (+3) = 5, eagle (+2) = 4, birdie (+1) = 3
//   par (0) = 2, bogey (-1) = 1, double bogey or worse = 0
//
// KEY: d = par − net. Positive d = under par (good score). Key '3' means
// albatross (+3) = 5 pts; '-3' means triple bogey or worse = 0 pts.
// Lower/more-negative key → worse score. This is counterintuitive — the sign
// follows the "par minus net" convention, not a points scale.
export const DEFAULT_STAB = { '-3':0, '-2':0, '-1':1, '0':2, '1':3, '2':4, '3':5, '4':6 };

export function stabPts(gross, par, courseHcp, rank, minCourseHcp, mode, stabTable) {
  if (!gross) return null;
  const net = scoreForMode(gross, courseHcp, rank, minCourseHcp, mode || 'net');
  const d   = Math.max(-3, Math.min(4, par - net));
  const t   = stabTable || DEFAULT_STAB;
  return t[String(d)] ?? 0;
}

// ─── Interleaved 18-hole layout from two nines ────────────────────────────────
export function buildLayout(nines, frontName, backName) {
  const front = nines.find(n => n.name === frontName) || nines[0];
  const back  = nines.find(n => n.name === backName)  || nines[1] || nines[0];

  const fp = front?.pars      || DEF_PARS.slice(0, 9);
  const bp = back?.pars       || DEF_PARS.slice(9);
  const fh = front?.handicaps || [1,3,5,7,9,11,13,15,17];
  const bh = back?.handicaps  || [2,4,6,8,10,12,14,16,18];

  const cf = new Array(9);
  const cb = new Array(9);
  [...fh].map((h,i) => ({h,i})).sort((a,b) => a.h-b.h).forEach(({i}, r) => cf[i] = 2*r+1);
  [...bh].map((h,i) => ({h,i})).sort((a,b) => a.h-b.h).forEach(({i}, r) => cb[i] = 2*r+2);

  return {
    pars:      [...fp, ...bp],
    hcps:      [...cf, ...cb],
    frontName: front?.name || 'Front',
    backName:  back?.name  || 'Back',
  };
}

// ─── Group course handicap helpers ───────────────────────────────────────────

/**
 * Compute course handicaps for all players given per-player tee data.
 * Returns signed integers — negative = plus handicap.
 *
 * tees: array of tee objects, one per player in the same order as players[].
 * Each tee may be null/undefined — courseHandicap degrades to round(index)
 * when slope/rating are absent.
 * Callers are responsible for building the tees array; any shared-tee or
 * fallback logic lives in the caller (e.g. roundLib.toActiveRound), not here.
 */
export function groupCourseHandicaps(players, tees, pars) {
  const par = pars ? pars.reduce((a, b) => a + b, 0) : 72;
  return players.map((p, i) => {
    const tee = tees[i];
    return courseHandicap(parseIndex(p.ghin), tee?.slope, tee?.rating, par);
  });
}

/** Minimum (lowest) course handicap in group — the baseline for net-off-low. */
export function minGroupHandicap(courseHcps) {
  return Math.min(...courseHcps);
}
