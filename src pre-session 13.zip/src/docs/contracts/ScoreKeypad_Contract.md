# ScoreKeypad Contract

_Version 1.1 DRAFT — April 2026_
_Supersedes v1.0 DRAFT._
_Changes in v1.1: Layout redesigned — header and hint rows removed; phone-style digit order (1-2-3 top); all buttons equal width; bottom row ⌫/0/X; navigation row ←/✓/→; X now auto-advances like any digit input._
_Status: DRAFT — requires owner review and approval before any implementation code is written._
_New contract. Does not supersede any existing contract._
_All implementation must conform to this contract once marked AUTHORITATIVE._
_If code conflicts with this contract, the contract wins._

---

**Engine file(s):** `games.js`, `payouts.js`, `handicap.js`
**UI component:** `ScoreKeypad.jsx` (new), `ZoomModal.jsx` (modified — keypad replaces hidden input)
**Payout logic location:** No payout logic in keypad. Engine receives `'X'` as a raw score value.
**Cross-references:**
- `App_Data_Model_Contract.md` §5 — `scores[h][i]` valid values (amended by this contract)
- `Round_Lifecycle_Contract.md` §12.3 — score normalization invariant (amended by this contract)
- `Handicap_Contract.md` §3 — ESC calculation (amended by this contract)
- `Payout_Contract.md` §2 — engine interpretation of X scores (amended by this contract)
- All game contracts — "X comes in last" rule (each amended by this contract)
- `UI_Component_Contract.md` — new component registered here

---

## §1. Overview

### §1.1 Purpose

`ScoreKeypad` is a custom in-app numeric keypad that replaces the iOS system
keyboard for all score entry throughout the app. It renders inside the existing
`ZoomModal` 3-hole window as a drop-in replacement for the hidden `<input>`
keyboard-summon pattern. The system keyboard is never invoked for score entry.

The keypad adds two score-entry actions not possible with the system keyboard:
- **X** — player picked up their ball (see §4)
- **Long-press X** — player is leaving the round or a game (see §5; scope of
  this contract is UI only — the resolver logic is specified in the
  Early Departure Contract)

### §1.2 Scope of this contract

This contract covers:
1. The keypad component UI and behavior (§2–§3)
2. The `'X'` score type — storage, display, and engine interpretation (§4)
3. The "X always loses" invariant across all games (§4.5)
4. Contract amendments required in other documents (§9)

This contract does **not** cover:
- Early departure / "leave game" resolver logic — see Early Departure Contract
- Late arrival — see Late Arrival Contract
- ZoomModal layout changes beyond keypad integration — out of scope
- Any changes to `ScoreGrid.jsx` tap targets — tap behavior unchanged

---

## §2. Component Spec — `ScoreKeypad.jsx`

### §2.1 Props

```js
ScoreKeypad.propTypes = {
  // Current raw score value for the active cell: '' | digit string | 'X'
  value:          PropTypes.string.isRequired,

  // Called with new raw value on every keypress. Does not auto-advance.
  // Parent (ZoomModal) owns advance logic.
  onChange:       PropTypes.func.isRequired,

  // Called when user confirms entry (✓ button or auto-advance fires).
  // Parent (ZoomModal) advances to the next cell.
  onConfirm:      PropTypes.func.isRequired,

  // Called when user taps ← (direction: -1) or → (direction: +1).
  // Parent (ZoomModal) moves the active cell in the given direction.
  // Navigation is pure movement — no confirmation, no value change.
  onNavigate:     PropTypes.func.isRequired,  // (direction: -1 | +1) => void

  // Called when user long-presses X. Parent handles resolver sheet.
  // If not provided, long-press X is disabled (no visual affordance).
  onLongPressX:   PropTypes.func,
}
```

**Note:** `par`, `hcp`, `courseHcp`, `playerName`, and `holeNumber` props are
not required by `ScoreKeypad` — the header and hint rows have been removed.
The ZoomModal chrome above the keypad already shows the player name and hole
context. If `xGrossScore()` display is needed in a future enhancement, these
props can be added back without breaking changes.

### §2.2 Layout

```
┌───────────┬───────────┬───────────┐
│     1     │     2     │     3     │
├───────────┼───────────┼───────────┤
│     4     │     5     │     6     │
├───────────┼───────────┼───────────┤
│     7     │     8     │     9     │
├───────────┼───────────┼───────────┤
│     ⌫     │     0     │     X     │
├───────────┼───────────┼───────────┤
│     ←     │     ✓     │     →     │
└───────────┴───────────┴───────────┘
```

**Grid:** 3 columns × 5 rows. Every button is equal width and equal height —
no spanning, no merged cells, no exceptions. Phone-style digit order: 1-2-3
on top row, 7-8-9 on third row (matches iOS phone keyboard).

**Rows:**
- Rows 1–3: digits 1–9
- Row 4: ⌫ (backspace), 0, X (pickup)
- Row 5: ← (prev cell), ✓ (confirm), → (next cell)

**Height:** Fixed at ~220px total. This is the non-negotiable constraint —
must not exceed this to keep the 3-hole window visible above the keypad on
a standard iPhone viewport. Each row is ~44px.

**Colors:**
- Background: `#fff` (matches card background)
- Digit buttons (1–9, 0): `#f5f5f5` background, `#222` text, `14px` bold
- `⌫` button: `#f5f5f5` background, `#888` text, `16px`
- `X` button: `AMB` (amber) background, `#fff` text, `14px` bold —
  distinct from digits but not alarming
- Long-press X active state: transitions to `RED` background (see §2.7)
- `✓` button: `G` (app green) background, `#fff` text, `14px` bold
- `←` and `→` buttons: `#f5f5f5` background, `G` color text, `16px` —
  same quiet style as ⌫ but green to signal navigation
- Border radius on all buttons: `8px`
- Thin `1px #eee` dividers between all rows and columns

### §2.3 Digit entry behavior

- Digits append to the current value string (e.g. `'1'` → tap `'2'` → `'12'`).
- Maximum displayable value: 2 digits. A third digit tap on a 2-digit value
  replaces the value entirely (restarts entry). This handles fat-finger correction
  without requiring ⌫ first.
- `⌫` removes the last character. If value is already `''`, ⌫ is a no-op.
- If current value is `'X'`, any digit tap replaces `'X'` with that digit
  (X is overridable).
- `onChange` is called after every keystroke with the new raw string value.
  Parent (ZoomModal) receives the update and reflects it immediately.

### §2.4 Auto-advance timing

Auto-advance fires `onConfirm` **700ms after the last keystroke** if the value
is non-empty. This applies to digit entries **and X** — X auto-advances
exactly like any digit input.

The 700ms timer resets on every keystroke including X. Tapping ✓ explicitly
fires `onConfirm` immediately and cancels the pending timer. Tapping ← or →
does NOT cancel the pending timer — navigation moves the active cell but
leaves any pending confirmation in place for the new cell.

### §2.5 Confirm (✓) behavior

- If value is empty: no-op (✓ is visually disabled when value is `''`).
- If value is a digit string: calls `onConfirm(value)` immediately.
- If value is `'X'`: calls `onConfirm('X')` immediately.

`onConfirm` is responsible for advancing to the next cell. The keypad does not
own navigation — it fires and forgets. ✓ is functionally equivalent to
auto-advance but fires immediately rather than after 700ms.

### §2.6 X button — single tap

Single tap on X:
1. Sets value to `'X'` immediately (replaces any current value).
2. Starts the 700ms auto-advance timer exactly as a digit tap would.
3. The cell will display `"NX"` (computed at render time from `xGrossScore()`)
   once the score is confirmed and written to `scores`.

X auto-advances identically to any digit input. No special confirmation
step is required. The user may tap ✓ to confirm immediately without waiting,
or tap ← / → to navigate away (which moves the active cell; the X value
is committed via the timer or ✓ before navigation takes effect — see §2.8).

### §2.7 X button — long press

Long-press threshold: **600ms** held on the X button.

On long-press fire:
1. Calls `onLongPressX()` if provided.
2. The keypad does not change state — it waits for the parent to dismiss it
   or show the resolver sheet.
3. If `onLongPressX` is not provided, long-press has no effect (no visual
   change beyond the active-state color shift during the hold).

Visual feedback during hold: X button transitions to `RED` background at ~300ms
(halfway point) as a warning indicator that a destructive action is approaching.

### §2.8 Navigation arrows (← and →)

The ← and → buttons move the active cell in the traversal order that
auto-advance and ⌫ use — ← moves to the previous cell, → moves to the
next cell.

**Navigation is pure movement with no side effects:**
- The current cell's value is NOT confirmed or saved when navigating.
- The auto-advance timer is NOT cancelled when navigating.
- No score is written, no `onConfirm` fires.

**The parent (ZoomModal) owns traversal order.** `onNavigate(-1)` and
`onNavigate(+1)` are the only signals the keypad sends. ZoomModal
determines which cell is "previous" and "next" using the same traversal
logic it uses for auto-advance.

**Interaction with pending timer:** If the user taps ← or → while a
700ms auto-advance timer is pending (e.g. they entered a digit and then
immediately navigated), the timer fires for the original cell after
700ms regardless. This is acceptable behavior — the score was entered
and will be committed. If the user does not want to commit the in-progress
value, they should tap ⌫ to clear it before navigating.

**Disabled state:** ← is visually disabled (reduced opacity) when the
active cell is the first cell in the traversal order. → is visually
disabled when the active cell is the last cell. The buttons are still
tappable but `onNavigate` is not called in the disabled state.

---

## §3. Integration with ZoomModal

### §3.1 What changes in ZoomModal

`ZoomModal.jsx` currently:
- Renders a hidden `<input>` and calls `.focus()` to summon the system keyboard
- Listens for `onChange` on the input to capture keystrokes
- Has its own auto-advance timer

After this change:
- The hidden `<input>` is removed entirely
- `ScoreKeypad` is rendered in its place at the bottom of the ZoomModal sheet
- ZoomModal passes `value`, `onChange`, `onConfirm`, `onNavigate`, and
  `onLongPressX` to the keypad as props
- ZoomModal owns `onConfirm` (advance to next cell), `onNavigate` (move active
  cell without confirming), and `onLongPressX` (departure resolver stub)
- The auto-advance timer moves from the hidden input logic into ZoomModal,
  triggered by `onChange` calls from the keypad
- The 3-hole window layout above the keypad is unchanged

### §3.2 What does NOT change in ZoomModal

- The 3-hole window (current hole ± 1 hole above and below)
- Player row layout and active-cell highlighting
- The overall sheet/modal presentation (slide up from bottom)
- `ScoreGrid.jsx` tap targets — tapping a cell still opens ZoomModal

### §3.3 `onLongPressX` wiring

In this session (keyboard creation), `onLongPressX` is passed as a stub:
```js
onLongPressX={() => alert('Early departure — coming soon')}
```
The full resolver is wired in the Early Departure session. This decouples
the two sessions cleanly.

### §3.4 Props ZoomModal must supply to ScoreKeypad

ZoomModal already has access to:
- `scores` — current cell value
- Current hole index and player index — already tracked in ZoomModal state

The following props from the old hidden-input approach are no longer needed
by the keypad: `par`, `hcp`, `courseHcp`, `playerName`, `holeNumber`.
These may remain available in ZoomModal for other display purposes but
are not passed to `ScoreKeypad`.

---

## §4. The X Score Type

### §4.1 Storage

`scores[h][i]` valid values are amended from:
```
'' | positive integer string
```
to:
```
'' | positive integer string | 'X'
```

`'X'` is the canonical stored value. The computed display string (e.g. `'7X'`)
is **never stored** — it is derived at render time. This is consistent with the
app's principle of never storing derived values.

### §4.2 X gross value computation

```
xGross(h, i) = pars[h] + 2 + handicapStrokes(h, i)
```

Where:
- `pars[h]` — par for hole h
- `+2` — double bogey above par
- `handicapStrokes(h, i)` — number of strokes player i receives on hole h,
  computed using the player's **full Net `courseHcps[i]`** (never NOL /
  `minCourseHcp` offset). This is the standard stroke allocation function
  already in `handicap.js`.

**This function must be added to `handicap.js`** as a pure exported function:
```js
export function xGrossScore(holeIdx, courseHcp, hcps, pars) {
  const strokes = strokesOnHole(holeIdx, courseHcp, hcps); // existing function
  return pars[holeIdx] + 2 + strokes;
}
```

### §4.3 Display of X scores

In every context where a score is displayed (ScoreGrid, ZoomModal, TotalsCard,
ReadOnlyScorecard, share image), `'X'` is rendered as `"[N]X"` where N is
`xGrossScore(h, i, courseHcp, hcps, pars)`.

**Formatting:**
- The numeric part `N` is rendered in the standard score color/weight
- The `X` suffix is rendered in `AMB` (amber) color, same weight, slightly
  smaller (e.g. `0.85em`) — reads as a qualifier, not a separate value
- Cell background: very light amber tint (`#fffbe6` or similar) — distinct
  from normal scored cells (white) and empty cells (light gray)
- The cell is otherwise identical to a scored cell — same size, same borders

**In TotalsCard:** The X gross value is included in the player's gross total
exactly as if they had scored that number. No special display needed in totals
(the gross total just includes the X gross value numerically).

**In share image:** Same `"NX"` format, same amber `X` suffix.

### §4.4 X and ESC

An X score on a hole is **already ESC-capped by definition**:
```
xGross = par + 2 + strokes = ESC maximum for that hole
```

Therefore:
- `escTotal()` in `handicap.js` must treat `'X'` scores as already at their
  ESC maximum — no further capping is applied.
- The ESC total for a player with one or more X scores simply includes the
  computed xGross values for those holes.
- No change to the ESC algorithm is needed beyond recognizing `'X'` and
  substituting `xGrossScore()` for the raw score.

### §4.5 The "X always loses" invariant

**Core rule:** A player with an X score on a hole loses that hole to any
player with a real (non-X) score, regardless of numeric values.

**Formal statement:**
For any hole h and any two players i and j competing on that hole:
- If `scores[h][i] === 'X'` and `scores[h][j]` is a real score → j wins
- If `scores[h][i]` is a real score and `scores[h][j] === 'X'` → i wins
- If both `scores[h][i] === 'X'` and `scores[h][j] === 'X'` → tied (X ties X)
- Real scores compete normally (lower net/gross wins per game rules)

This invariant must be enforced in `payouts.js` and `games.js` for every
per-hole comparison. The implementation pattern:

```js
// In any hole-by-hole comparison:
const iIsX = scores[h][i] === 'X';
const jIsX = scores[h][j] === 'X';
if (iIsX && !jIsX) { /* j wins */ }
else if (!iIsX && jIsX) { /* i wins */ }
else if (iIsX && jIsX) { /* tied */ }
else { /* compare numeric scores normally */ }
```

### §4.6 X score per game — "comes in last" semantics

The "X always loses" invariant translates to game-specific behavior as follows:

**Nassau / Match (per-hole winner):**
- X player loses the hole to any opponent with a real score
- If all players in a match X the same hole → hole is halved
- Net X value: `xGross - handicapStrokes` = `par + 2` (net double bogey).
  This value is used for display only — the "X always loses" flag governs the
  hole result, not the numeric comparison

**Skins (per-hole low score):**
- X player cannot win a skin
- If all skin participants X the same hole → skin carries (no winner, same
  as any other tie)
- If one player has a real score on a hole where all others X → that player
  wins the skin outright

**Stableford (point accumulation):**
- X score = `xGross` gross, which in net mode = net double bogey = 0 Stableford
  points. This falls out naturally from the point table — no special case needed.
- In gross mode: `xGross` = `par + 2 + strokes` gross. Apply point table normally.

**Nines (3-player point distribution):**
- X player receives 0 points for the hole (minimum allocation)
- The remaining 9 points are distributed among the other two players based on
  their real scores (using the standard Nines distribution logic)
- If two players X the same hole: both receive 0 points, the third player
  receives all 9 points (they win by default against two pickups)
- If all three Nines players X the same hole: 3 points each (equal split —
  same as a three-way tie). This is consistent with the "X ties X" rule.

**Sixes (best-ball team, 6-hole segments):**
- X player's `xGross` is used as their score for best-ball purposes
- Since X always loses to a real score, the team's best-ball is always the
  partner's real score if available
- If both partners on a team X the same hole → team score is the lower xGross
  (since both are X, X ties X, and the lower computed value is used)

**Stroke Play (total score):**
- X gross value is included in the player's total gross score
- No special case — `xGross` is a real number and sums normally

**Dots / Specials:**
- A player with an X on a hole **cannot earn offensive dots** on that hole
  (birdie, eagle, ace — X score cannot be better than double bogey by definition)
- A player with an X **can be charged defensive/junk dots** where applicable
  (e.g. worst score on hole, three-putt if separately logged)
- Auto-mark logic must skip X holes for birdie/eagle/ace detection

### §4.7 X in net-off-low (NOL) mode

In NOL mode, the minimum course handicap player receives 0 strokes everywhere.
The X gross value still uses **full Net `courseHcps[i]`** regardless of NOL
mode — X is defined as ESC maximum which is always full-Net-based.

The "X always loses" flag still applies in NOL mode. A player receiving 0 NOL
strokes with a real score of `par + 2` on a hole still beats an opponent's X
on that hole, even though the X player's net-off-low value is the same number.

### §4.8 Can X be overwritten?

Yes. If a player entered X accidentally, tapping the cell again opens the
keypad with `'X'` displayed. Entering any digit replaces `'X'` with that digit.
The ⌫ button on `'X'` clears back to `''`. There is no confirmation required
to overwrite an X — it is treated as a normal score edit.

---

## §5. Long-Press X — Stub Spec (Early Departure Wiring)

### §5.1 What this session implements

In the keyboard creation session, `onLongPressX` is wired as a stub:
```js
onLongPressX={() => alert('Early departure — coming soon')}
```

No resolver logic is built. The stub confirms the gesture is working
and the prop wire is in place.

### §5.2 What the Early Departure session adds

The Early Departure session replaces the stub with a full resolver sheet.
The resolver sheet will:
- Show all active games the player participates in
- Offer per-game resolution options (Pay based on holes played / Abandon /
  Remove player from game)
- Write `playerJoinHoles`, `gameHoleRanges`, and `earlyEndOpts` to `activeRound`

See Early Departure Contract (separate document) for full spec.

---

## §6. ScoreKeypad Used Throughout the App

### §6.1 Usage contexts

`ScoreKeypad` is the single score entry component used in all contexts
where a numeric score is entered. In this session, the only integration
point is ZoomModal. Future contexts (if any score entry exists outside
ZoomModal) must use the same component.

### §6.2 Not used for non-score inputs

`ScoreKeypad` is for score entry only. Bet amounts, handicap indices,
course data, and other numeric fields continue to use native `<input>`
elements — the custom keypad is not a general-purpose number input.

---

## §7. Scorecard Display Changes

### §7.1 Score cell rendering for X scores

`ScoreGrid.jsx` must handle `'X'` in `scores[h][i]`:
- Compute `xGrossScore(h, i, courseHcps[i], hcps, pars)` for display
- Render as `"[N]X"` with the X in amber (§4.3)
- Apply light amber cell background (`#fffbe6`)
- All other cell behavior (tap to open ZoomModal, dot indicators, etc.)
  is unchanged

### §7.2 TotalsCard

`TotalsCard` computes gross totals from `scores`. For `'X'` values, it must
substitute `xGrossScore()` for the numeric gross value. The total is a plain
number — no X annotation in totals (the total row is a sum, not a per-hole display).

### §7.3 ReadOnlyScorecard (RoundSummaryModal)

Same rendering rules as ScoreGrid — `"[N]X"` with amber X suffix and tinted
cell background. `ReadOnlyScorecard` is read-only so no keypad integration needed.

---

## §8. Amendments to Existing Contracts

The following amendments are required. They must be reflected in the named
contracts **in the same session that implements the keypad**. No implementation
code is shipped without corresponding contract updates.

### §8.1 `App_Data_Model_Contract.md`

**§5 — `scores[h][i]` valid values:**
Add `'X'` to the valid value set. Add note: `'X'` means player picked up;
`xGrossScore()` is called to derive the numeric value for any calculation.

**§12.3 — Score normalization invariant:**
Amend to: "Score values in `scores[h][i]` are either empty string (`''`),
a valid positive integer string (e.g. `'4'`, `'10'`), or `'X'` (player
picked up). Invalid values must be sanitized to empty string before persistence.
`'X'` is a valid value and must not be sanitized away."

### §8.2 `Round_Lifecycle_Contract.md`

**§12.3 — Score normalization invariant:** Same amendment as above.

### §8.3 `Handicap_Contract.md`

**New function `xGrossScore(holeIdx, courseHcp, hcps, pars)`:**
Add to §3 (or a new §3.x): function spec, formula, and note that this value
is the ESC maximum for the hole (no further ESC capping needed).

**ESC section:** Amend to note that `'X'` scores are already ESC-capped and
`xGrossScore()` is used in place of the raw score in `escTotal()`.

### §8.4 `Payout_Contract.md`

**New §X — X score handling:**
State the "X always loses" invariant (§4.5 of this contract).
State that all game engine functions must apply this invariant before
any numeric comparison.
State that `buildPayoutArgs` passes raw `scores` to the engine; the engine
is responsible for detecting and handling `'X'` values.

### §8.5 Individual game contracts

Each of the 7 game contracts must receive a "X score behavior" subsection
referencing §4.6 of this contract and stating the game-specific semantics.
The per-game table in §4.6 is the authoritative spec; game contracts reference
it rather than duplicate it.

---

## §9. Testing Checklist (for implementation session)

1. **Keypad renders inside ZoomModal** — tap any score cell, ZoomModal opens,
   keypad is visible at bottom, system keyboard does not appear. ✓
2. **Phone-style layout** — digits 1-2-3 on top row, 7-8-9 on third row,
   ⌫/0/X on fourth row, ←/✓/→ on fifth row. All buttons equal width. ✓
3. **Digit entry** — tap 4 → display shows "4". Tap 2 → display shows "42".
   Auto-advance fires after 700ms. ✓
4. **Three-digit replacement** — enter "42", tap 8 → display resets to "8". ✓
5. **⌫ behavior** — enter "42", tap ⌫ → "4". Tap ⌫ again → "". Tap ⌫ on
   empty → no-op. ✓
6. **X single tap auto-advances** — tap X → value becomes `'X'`, 700ms timer
   starts, cell auto-advances. No ✓ required. ✓
7. **X overwrite** — tap X to set score, then tap digit → X is replaced. ✓
8. **✓ confirms immediately** — enter any value, tap ✓ → advances immediately
   without waiting 700ms. ✓
9. **✓ disabled on empty** — no value entered, ✓ is visually disabled, tap
   has no effect. ✓
10. **← navigates to previous cell** — tap ← → active cell moves to previous
    field. No score written, no confirm fired. ✓
11. **→ navigates to next cell** — tap → → active cell moves to next field.
    No score written, no confirm fired. ✓
12. **← disabled at first cell** — at first score cell in traversal order,
    ← shows reduced opacity and does not fire `onNavigate`. ✓
13. **→ disabled at last cell** — at last score cell, → shows reduced opacity
    and does not fire `onNavigate`. ✓
14. **Long-press X stub** — hold X 600ms → stub alert appears. Single tap X
    → no alert, just auto-advance. ✓
15. **X in ScoreGrid** — cell shows NX with amber X suffix, light amber
    background. ✓
16. **X in TotalsCard** — gross total includes xGross value numerically
    (no X annotation in total). ✓
17. **X in ReadOnlyScorecard** — same NX display as ScoreGrid. ✓
18. **X in share image** — NX shown in scorecard cells. ✓
19. **X does not corrupt Skins** — player with X on a hole does not win skin
    against any player with a real score. All-X hole carries the skin. ✓
20. **X in Match** — X player loses the hole to any real score. Two X players
    halve. ✓
21. **X in Nines** — X player gets 0 points. Other two players compete for
    9 points normally. ✓
22. **X in Stableford** — X score = net double bogey = 0 points. ✓
23. **X in Stroke Play** — xGross value included in total. ✓
24. **No system keyboard** — on iPhone, no system keyboard appears at any
    point during score entry. ✓

---

## §10. Known Gaps and Open Items

| # | Severity | Description |
|---|---|---|
| G-1 | Medium | `onLongPressX` resolver (Early Departure session — stub only in this session) |
| G-2 | Medium | Dots auto-mark must skip X holes for birdie/eagle/ace. Implementation detail for keypad session. |
| G-3 | Low | Score cell amber tint color — exact hex to be confirmed on device. `#fffbe6` is a starting point. |

---

## §11. Invariants

1. `'X'` is the only non-numeric non-empty valid score value. No other
   alphabetic or special character is valid in `scores[h][i]`.
2. `xGrossScore()` always returns a value ≥ `par + 2`. It is never less
   than double bogey gross.
3. The X always loses to a real score. This invariant holds across all
   7 games and all scoring modes (gross, net, NOL).
4. X ties X. Two pickups on the same hole produce no winner.
5. `'X'` is never stored as `'NX'` — computed display strings are never
   persisted. `'X'` is the canonical storage value.
6. `ScoreKeypad` is a pure UI component. It performs no engine calculations
   except calling `xGrossScore()` for display purposes.
7. The system keyboard is never invoked during score entry. Any code path
   that calls `.focus()` on a hidden input for score entry is a contract
   violation after this session.
8. `'X'` is never sanitized to `''` during score normalization. The existing
   normalization guard must explicitly allow `'X'` as a valid passthrough value.
9. All five button rows use equal-width, equal-height buttons with no spanning.
   Any layout change that introduces unequal buttons requires a contract amendment.
10. ← and → are pure navigation — they never write a score, never call
    `onConfirm`, and never clear the current value.

---

## §12. Final Rule

If implementation behavior conflicts with this contract, call out the conflict.
The implementation must be corrected. This document defines the truth.
