# APP_STATE_SUMMARY.md

This document is the lean, current-state record of where the codebase is right now,
along with durable architectural gotchas the AI must not re-break. It is **not** a
session journal — that role belongs to `BUILD_PLAN.md`, which holds the chronological
session history and the open session plan.

This file should remain short. When a session closes, update the **Current State**
paragraph to reflect the new baseline; do not stack additional session paragraphs.

---

## Update policy — read before any session entry

Before logging a session anywhere, confirm all of the following:

1. **Session designation is owner-provided.** Do not invent. If the owner has not
   specified the exact designation (e.g. "13-C.3"), stop and ask.
2. **Every test required by the relevant contract's Testing section passed on
   device.** ("Section 8" of game contracts is the conventional Testing section
   per Universal_Contract_Template.md.) Pending on-device items keep the
   session out of the Completed Sessions table in BUILD_PLAN.
3. **BUILD_PLAN.md has been reviewed and updated** to reflect what this session
   closed, partially resolved, or invalidated. This happens before the ASS update,
   not after.
4. **Any BUILD_PLAN updates that feel wrong were flagged to the owner** before
   being silently committed. Scope creep is visible, not hidden.
5. **The "Work in Flight" block below was updated** (or cleared, if the sprint
   fully completed with this session), and the **Current State** paragraph was
   refreshed to describe the new baseline.

---

## Work in Flight

_None. Session 15-L fully complete and device-confirmed. **Next session: 16-A — Wolf**._

---

## Current State

_Last refresh: May 2026 — Session 15-L complete and confirmed on device._

Session 15-L complete. Player photos are now a first-class feature. New shared components: `src/components/PlayerAvatar.jsx` (photo or initial circle, pale-yellow starred badge, `onPress`) and `src/components/ImageCropOverlay.jsx` (pan + pinch-zoom crop UI, touch-only gesture system, direct DOM transform for 60fps, lazy pinch baseline on first touchmove). Photo upload and crop on the Players page; camera-icon-free row with avatar tap opening full-screen photo expand (Change / Delete / Cancel). `App_Data_Model_Contract.md` updated to v4.0 with `photo?` field. Avatar circles rolled out to all surfaces: Players page, PlayerPickerPopup, HomePage Money List, PlayersCard, Payouts page chips, Round Summary modal chips. TotalsCard (scorecard page) shows name + scores only — avatar removed. Share image uses canvas 2D API to draw photos directly after foreignObject render, bypassing iOS Safari's failure to load `<img>` inside foreignObject. Photos are enriched from `playerLib` by name-fallback in `ResultsPage` and `RoundSummaryModal` since `activePlayers` snapshot is photo-free. Email and phone fields removed from player edit UI and schema (dead code). Sprint 15 fully closed.

---

## Tech Stack

- **React 18** (JSX, hooks) — no class components
- **Vite** — dev server and bundler
- **Pure CSS-in-JS** — all styles are inline JS objects; no external CSS libraries
- **localStorage** — sole persistence layer; no backend, no database
- **Cloudflare Pages** — app hosting (`https://the-card-1qm.pages.dev`)
- **Cloudflare Worker** — OCR parser (`scorecard-parser.thecard.workers.dev`)

---

## Implementation Gotchas (AI must not re-break these)

### H-1: `restoreDotDefs()` required after deserialization
Any code path that reads `dots` from localStorage or from `activeRound` must call
`restoreDotDefs(dots)` before using the dot definitions. Serialization strips the
`autoWhen` functions. Skipping this call causes auto-marking to silently fail.
Renamed from `restoreAutoWhen()` in Session 11-A.

### H-2: Score inputs must use `display: 'block'`
iOS expands the height of focused inputs unless `display: 'block'` is set explicitly.
Without this, focusing a score cell shifts the entire row downward. Fixed in 1-C.
Do not remove this style from score `<input>` elements.

### H-3: `activeRound` must be a deep clone on load
`getActiveRound()` in `App.jsx` must return a parsed copy from localStorage, never
a live reference. Mutating a cached reference corrupts the stored state silently.

### H-4: Landscape detection — single source of truth in `ScorecardPage`
`isLandscape` is computed once in `ScorecardPage.jsx` and passed down as a prop to
`ScoreGrid` and all game table components. `ScoreGrid` has a local fallback detection
only for the case where the prop is not supplied (e.g. read-only summary view).
Do not add a second independent landscape detector in `ScoreGrid` — it will diverge.

### H-5: `specEntries` keys encode hole + player index
`specEntries` is a flat object keyed by `"${holeIdx}_${playerIdx}_${specialId}"`.
Never key by player name — names change and collide.

### H-6: Press array is sorted and sparse — never dense
`manualPresses["Match:id:Segment"]` is a sorted array of hole indices. It may
have gaps. The engine reconstructs the hierarchy from sorted position, not from
array indices. Do not normalize to a dense array.

### H-7: `computePayouts` is always called fresh — never cache its result in state
Payouts are derived values. `computePayouts()` is called from `ResultsPage` on each
render. Do not store payout results in `activeRound` as authoritative data.

### H-8: `fromActiveRound` / `toActiveRound` must stay in sync
Both conversion functions in `roundLib.js` must handle every field in `activeRound`.
When a new field is added to `activeRound`, both functions must be updated together,
or round-trip serialization silently drops the new field.

### H-9: `buildPayoutArgs` in `App.jsx` must stay in sync with engine contracts
`buildPayoutArgs()` assembles the arguments passed to `computePayouts()`. Every
field listed in each game contract's `computePayouts` input spec must appear here.
See App Data Model Contract §10 (synchronization rule).

### H-10: `siArray` on `activePlayers` entries is the sole SI source for engines
Since 13-G.2, every `activePlayers[i]` has a `siArray: number[18]` attached at
round-start. Engine functions read `players[pi].siArray[h]` directly. The old
`hcps` parameter has been removed from all 9 engine function signatures. Do not
re-introduce `hcps` as an engine parameter.

### H-11: `scoringMode` vs `grossNetNOL` — field names
The player-level field is `grossNetNOL` (renamed in 11-I.3). The match-level field
is `scoring` (also renamed in 11-I.3, from `tiebreak`). Do not revert to old names.

### H-12: `ZoomModal` uses hidden `<input>` for iOS keyboard suppression
`ZoomModal.jsx` renders a hidden `<input readOnly onFocus={e => e.target.blur()}>`
to absorb the iOS focus event without opening the system keyboard. Do not replace
this with a `<div>` — div tap targets do not reliably suppress the keyboard on iOS.

### H-13: Sixes rotation depends on `teamAssignments` in `activeRound`
`teamAssignments` is set once at round-start and must persist across saves/reloads.
The rotation logic in `runSixesSegment` derives team composition from this array per
hole. Do not re-derive `teamAssignments` from scores — it must be the stored value.

### H-14: `NinesTable` renders 3-player only — 4-player Nines is not implemented
The Nines engine and table component assume exactly 3 players. Do not pass 4 players
to Nines. The game config UI enforces this constraint at setup time.

### H-15: `dots` serialization — `autoWhen` functions stripped by JSON
See H-1. Restated here for emphasis: `restoreDotDefs()` must be called on any
deserialized `dots` value before it is used. This applies to both localStorage reads
and history record loads.

### H-16: `ScoreKeypad` — React 18 passive touch listeners
React 18 attaches touch event listeners as passive by default.
`e.preventDefault()` in synthetic `onTouchEnd` handlers is silently ignored.
Use the `touchHandledRef` timestamp guard pattern (set on `onTouchEnd`, checked in
`onClick`) to prevent double-fire on iOS. See H-40 for the dot-key double-fire fix.

### H-17: Departure resolver — sheets are per-player, never combined
The sequenced-event model (PartialGameContract v2.0) guarantees one resolver sheet
per player per departure event. Never merge two players' departure options into a
single sheet. The `useDepartureResolver` hook enforces this; do not refactor it to
batch players.

### H-18: `gameRanges` keys — game name OR `matchDef.id`
`gameRanges` is keyed by game name (`'Stroke Play'`, `'Skins'`, etc.) for non-match
games, and by `matchDef.id` for individual Match instances. Do not assume all keys
are game names — check `ar.matches` to find match IDs.

### H-19: `roundLib.fromActiveRound` rebuilds `siArray` — never serialize it
`siArray` is rebuilt on every `toActiveRound` call from the course layout.
It is not serialized to history records. If `siArray` is absent on a reloaded
`activePlayers` entry (pre-13-G.2 legacy round), engines fall back to the
round-shared `hcps`. Do not serialize `siArray` to history.

### H-20: `specials` in Dots — `enabled` flag is required
Every dot def in `DOTS_DEF` has an `enabled` boolean. The engine checks `d.enabled`
before scoring. Do not add a new special without the `enabled` field — it will
silently score as disabled even if the user turns it on.

### H-21: Skins carryover — holes without a winner carry to next hole
The Skins engine accumulates `carry` across holes. A hole with no clear winner
(tie or all-X) increments carry. The carry is added to the next hole's pot.
Do not reset carry to 0 when a hole ties — only reset after a real winner.

### H-22: Match/Nassau — press array is hole-indexed, not segment-indexed
`manualPresses["Match:id:Segment"]` stores the hole index at which each press
was triggered, not the press sequence index. Engines sort and walk this array
to reconstruct press timing. Do not convert to sequence indices.

### H-23: `buildPlayerSI` — female players get `hcpsWomen` if present
`buildPlayerSI(player, layout)` returns `layout.hcpsWomen` for female players when
the layout has a `handicapsWomen` array. For all other cases it returns `layout.hcps`.
Do not short-circuit this to always use `layout.hcps` — women's SI differs on many
courses.

### H-24: `computePerMatchPayouts` — always pass `gameRanges` + range bounds
Since 13-C.3, `computePerMatchPayouts` accepts `gameRanges`, `roundStartHole`, and
`roundEndHole`. Always pass these — the function uses them to trim payout computation
to the active range. Passing undefined silently uses full 18-hole range, which is
wrong for partial rounds.

### H-25: `PlayerDropdown` — `closeOnSelect` defaults false
`PlayerDropdown` stays open after a player is selected by default. Pass
`closeOnSelect={true}` only when the UX explicitly calls for auto-close on single
selection. Changing the default would break all existing multi-player pickers.

### H-26: `ScoreGrid` — `holeOffset` is required for partial rounds
For rounds that don't start at hole 0, `holeOffset` must be passed to `ScoreGrid`.
Without it, hole numbers display as 1-9 regardless of actual starting hole.

### H-27: `DotsPopup` — `dotEntries` must be the raw stored format
`DotsPopup` reads and writes `dotEntries` directly. Pass the raw stored object, not
a derived or filtered copy. The popup's save callback writes the whole object back.

### H-28: `HistoryPage` — applyImport `f` array controls which player fields survive conflict resolution
See H-42 for the full explanation. Short form: adding a field to the player schema
requires adding it to `f` at both sites in `applyImport`.

### H-29: `roundLib.list()` — returns rounds sorted newest-first
`roundLib.list()` sorts by `date` descending. Do not assume insertion order.
If order matters (e.g. Money List range filter), apply `filterByRange` before
iterating.

### H-30: `RangePicker` — `ML_KEY` and history key are distinct
`ML_KEY = 'moneyListRange'`. The history page uses `'historyRange'`. Both are
passed as the second argument to `loadRangePref` / `saveRangePref`. Never share
a single key between the two pages — they maintain independent state by design.

### H-31: `NewRoundPage` — `computePlayerCH` closure must be passed as a prop
`computePlayerCH` closes over course, pars, and other setup state owned by
`NewRoundPage`. It is passed as a prop to `PlayersCard` so child components can
compute course handicap without re-implementing the closure. Do not re-implement
this logic in `PlayersCard` or any child — the parent owns it.

### H-32: `ScoreKeypad` — `kpValue` is always a raw digit string, never a decimal
The keypad stores its internal value as a digit string (e.g. `"84"` for `8.4`).
The parent converts to decimal on commit. Never pass a decimal string as `kpValue`
— the keypad will display and edit it as a raw integer.

### H-33: `KpField` — `onActivate` must call `e.target.blur()` before opening keypad
Keypad activation must blur the input first, or iOS will open the system keyboard
alongside the custom keypad. Pattern:
```js
onFocus: (e) => { e.target.blur(); onActivate(...); }
```

### H-34: `ManualCourseModal` — `KpField` tap-outside dismiss uses `touchstart`, not `click`
The keypad dismiss listener in `ManualCourseModal` is a `touchstart` handler on
`document`. Using `click` instead causes a ~300ms delay on iOS (click delay) and
misses rapid taps. Do not change the event type.

### H-35: React 18 passive touch listeners — `preventDefault` requires native listener
React 18 attaches all touch handlers as passive by default, meaning
`e.preventDefault()` in React `onTouchMove` handlers is silently ignored on iOS.
To block scroll or page gestures (e.g. inside a modal overlay), attach a native
non-passive listener via `useEffect`:
```js
useEffect(() => {
  const el = overlayRef.current;
  if (!el) return;
  const prevent = (e) => e.preventDefault();
  el.addEventListener('touchmove', prevent, { passive: false });
  return () => el.removeEventListener('touchmove', prevent);
}, []);
```
Do not use `onTouchMove={e => e.preventDefault()}` — it will not work on iOS.

### H-36: Female stroke allocation — `siArray` must use women's SI
For female players on courses with `handicapsWomen`, `buildPlayerSI` returns
`layout.hcpsWomen`. The engine reads `players[pi].siArray[h]` for stroke allocation.
If `siArray` is absent (legacy round), the engine falls back to the round-shared
`hcps` (men's SI), producing wrong allocations for women. Rounds started after
13-G.2 always have `siArray`; pre-13-G.2 rounds are unaffected (no women's SI
was stored anyway).

### H-37: `siArray` is per-player, not per-round
`activePlayers[i].siArray` is the stroke index array for player `i`. It differs
between male and female players on courses with `handicapsWomen`. The old round-level
`hcps` array (men's SI shared by all players) was removed in 13-G.2. Do not
re-introduce a shared `hcps` array on `activeRound`.

### H-38: (reserved)

### H-39: Modal background scroll lock — native non-passive `touchmove` required
Same pattern as H-35. Modals that must block page scroll behind them must attach a
native non-passive `touchmove` listener. The `ManualCourseModal` scroll-lock was the
first instance; all subsequent modal overlays follow the same pattern.

### H-40: `dotEntries` key split — always use `parts.slice(2).join('_')` for dot id extraction
`dotEntries` keys have the shape `"${h}_${pi}_${dotId}"`. Custom dot ids contain
underscores (`c_1714000000000`), so `key.split('_')[2]` returns only `'c'` — not the
full id. Every site that extracts a dot id from a key must use
`parts.slice(2).join('_')` instead of `parts[2]`. The companion check
(`parts[2] === 'team'`) is safe because `'team'` never contains underscores.
Affected files: `payouts.js`, `ScoreGrid.jsx`, `DotsTable.jsx`, `DotsPopup.jsx`.

### H-41: `SwipeableRow` gesture mechanics — all tracking state in refs, zero setState during gesture
`SwipeableRow` (and `SwipeableRoundRow`) use direct DOM style manipulation during
touch gestures — never `setState`. The sliding div is updated via `slideRef.current.style.transform`
only. React state (`snapOffset`) is written once at touchend for the snap position.
`snapClose()` must be called before any action callback (edit/delete) — calling the
action first causes a re-render that replaces event handler references mid-gesture.
Do not refactor to use `useState` for live offset tracking — it breaks on iOS Safari.

### H-42: When adding a field to an entity record, audit the import field-list
`HistoryPage.applyImport` rebuilds player records using a fixed string array of
field names (`f = ['name', 'gender', 'ghin', 'email', 'phone', 'starred', 'inMoneyLists', 'photo']`)
at two sites: conflict-detection (line ~158) and conflict-resolution (line ~199).
Any field added to the player record schema must be added to this array at both
sites or it will be silently dropped when the user imports a backup containing a
conflicting record. Brand-new (non-conflicting) records are written verbatim and
are not affected. The same audit applies if the course or round schema gains a
similar import-time field-list filter in the future. Surfaced and fixed in 15-E.1;
`photo` added in 15-L.

### H-43: Filter `course.nines` to active nines before summing `womensPar`
`groupCourseHandicaps` and `computePlayerCH` in `NewRoundPage.jsx` accept a `nines`
array for gender-aware par. This array MUST be filtered to only the active front and
back nines before being passed — never pass the full `course.nines`. On 3-nine
courses, passing all nines overcounts par by one nine (e.g. 108 instead of 72),
producing a wildly wrong course handicap for female players. Pattern:
```js
const activeNines = (course?.nines || []).filter(n => n.name === frontNine || n.name === backNine);
```
Use `activeNines` at both the `computePlayerCH` internal par sum and the
`groupCourseHandicaps` call in `handleStart`. Surfaced and fixed in 15-Bugs.1.

### H-44: `payStyle` fork must be added to ALL betMode branches, including `'perpoint'`
When adding a new payout option (like `payStyle`) to a game engine block, every `betMode` branch needs the fork — not just `'total'` and `'segments'`. In 15-J, the `'perpoint'` branches in both Stableford and Nines were initially missed because the existing pairwise-differential logic happened to be the correct "Pay Up" behavior but silently ignored `payStyle:'paywinner'`. Always audit every branch of the affected payout block when adding a new option field.

### H-45: Sixes `randomizeTeams` must enumerate pairings from real player indices, not positions
`sixesTeams` stores global player indices (e.g. 0, 2, 3, 1 — whatever order the
players appear in the `players` array). A randomize function that hardcodes `[0,1,2,3]`
as array positions will produce correct-looking assignments but will silently violate
the unique-pairing constraint when players are not in identity order. Always derive
the 3 valid pairings from `players.map((_, i) => i)` and pick two distinct ones.
The uniqueness check must mirror the `usedPairs` / `priorTeammates` logic in the
manual picker — not a simplified heuristic. Surfaced and fixed in 15-K.

### H-46: `overflow:hidden` on any ancestor of `PlayerAvatar` kills photo rendering on iOS Safari
iOS Safari does not render `<img>` elements inside a subtree that has `overflow:hidden`
combined with `border-radius` anywhere in the ancestor chain. This manifests as a
blank white square — the img element is present in the DOM, has correct `src`, correct
dimensions, and `complete:true`, but paints nothing. The fix: never put
`overflow:hidden` on a container that is an ancestor of `PlayerAvatar`. Use
`overflow:hidden` only on the `<img>` element's immediate parent if needed, or use
`border-radius` directly on the `<img>` itself for circular cropping instead.
Confirmed via Safari Web Inspector console testing in 15-L.

### H-47: `<img>` inside SVG foreignObject does not reliably render on iOS Safari
When `drawImage` is called on a canvas with an SVG data URI that contains
`<foreignObject>` with `<img>` tags, iOS Safari does not decode the images before
painting — they render as blank. This is an unfixable iOS Safari limitation.
The workaround used in `shareUtils.js`: render the foreignObject HTML with initial
circles only (no `<img>` tags for photos), then draw photos directly onto the canvas
after the foreignObject renders using the 2D canvas API (`ctx.arc` + `ctx.clip` +
`ctx.drawImage`). Avatar positions are located via `data-avatar-id` attributes on the
initial-circle divs in the probe element. Do not revert to `<img>` tags inside
foreignObject HTML for photos.

---

## Open Items

### Sprint 13 — carry-over

- **Partial-round history-reload retest** — load a full 18-hole round, reload into
  `NewRoundPage`, shorten to 9 holes, confirm all three range-aware table components
  trim correctly and the engine computes only over 9 holes. Carried over from 13-C.3
  Phase 2B. Priority: Medium.

### Sprint 14 — carry-over

- **14-A.2 Mistral OCR** — Requires real WiFi. See BUILD_PLAN 14-A detailed notes for
  exact pickup instructions. Priority: High (gated on connectivity).
- **CourseCard.jsx display changes** — Hole numbering (1-9 per nine) and 27-hole combo
  yardages shipped but not formally device-confirmed on a 27-hole course import.
  Confirm with Sahalee import in 14-A.2 or 14-B. Priority: Low.

### Sprint 15 — carry-over

- **Starred players auto-selection in New Round** — starred players surface at top of picker but are not auto-selected. Deferred; log for future sprint if demand arises.

---

## Document Index

Contract version pins below verified against each contract's actual version header.

### Current contracts and core docs

| Document | Version | Purpose |
|---|---|---|
| `ARCHITECTURE_FOUNDATIONS.md` | — | Mental models, layer system, the "why" |
| `App_Data_Model_Contract.md` | v4.0 | State schema, storage keys, mutation rules. v3.7 (13-G.2): Player schema gains `siArray`. v3.8 (15-E.1): §1 — app-preference localStorage keys documented. §1.1 NEW — range pref shape. §1.2 NEW — backup payload `settings` field. Course schema gains `nineComboNames?: string[]` (14-A). `website` field removed (14-B). Player library record has `starred?` and `inMoneyLists?` fields (15-E §5.3). §5.5 Nines betMode updated to `'perpoint' \| 'total' \| 'segments'` (15-I). v3.9 (15-J): `payStyle` added to Stroke Play, Stableford, Nines, Dots gameOpts schemas; `dotsMode` added to Dots schema. v4.0 (15-L): `photo?` added to player library record schema (§5.3); library-only, never copied to `activePlayers` snapshot. |
| `Round_Lifecycle_Contract.md` | v2.3 | Setup→score→save flow, activeRound lifecycle. v2.3 (15-E.1): §5.2 — auto-export payload now carries top-level `settings` field; cross-references App_Data_Model §1.2. |
| `Handicap_Contract.md` | v2.0 | USGA math, `buildPlayerSI`, engine SI source rule |
| `Payout_Contract.md` | v1.13 | `computePayouts` entry point, `subsetMin` pattern |
| `Nassau_Match_Contract.md` | v3.0 | Nassau/Match Play rules, press system, engine API |
| `Sixes_Contract.md` | v1.11 | Sixes team rotation, hole scoring, press system |
| `Skins_Contract.md` | v1.8 | Skins carryover, subset behavior, departure handling |
| `Stableford_Contract.md` | v1.8 | Stableford points table, `betMode`, team scoring. v1.8 (15-J): `payStyle` field added (default `'paywinner'`; individual mode only); `'perpoint'` UI label renamed "Point Spread". |
| `Nines_Contract.md` | v1.8 | Nines point table, `betMode`, blitz rule, 3-player constraint. v1.7 (15-I): `'total'` betMode added. v1.8 (15-J): `payStyle` field added (default `'payup'`); `'perpoint'` UI label renamed "Point Spread". |
| `Stroke_Play_Contract.md` | v1.8 | Stroke play `betMode`, `strokePlayPlayers` subset. v1.8 (15-J): `payStyle` field added (default `'paywinner'`). |
| `Dots_Contract.md` | v2.6 | Dots/Junk: `DOTS_DEF`, specials, mutual exclusivity, team payout. v2.6 (15-J): `dotsMode: 'spread' \| 'total'` contracted (was UI-only gap); `'total'` engine branch implemented; `payStyle` field added (default `'payup'`); "Spread" UI label renamed "Point Spread". |
| `PartialGameContract.md` | v2.2 AUTHORITATIVE | Partial round, predetermined ranges, early departure |
| `ScoreKeypad_Contract.md` | v2.4 AUTHORITATIVE | Custom keypad: universal system-keyboard replacement |
| `UI_Component_Contract.md` | v1.7 | `ui.jsx` tokens, all components, `style` prop pattern. v1.6 (15-E.1): §10 NEW — `RangePicker.jsx` shared component documented. v1.7 (15-G): §3.6 NEW — `BIRDIE_COLOR` and `BOGEY_COLOR` tokens. §4.11 NEW — ScoreGrid score-cell indicator overlay rules (eagle/birdie/par/bogey/double-bogey). |
| `Universal_Contract_Template.md` | v1.0 AUTHORITATIVE SKELETON | Template every game contract must conform to |

### Process / planning docs

| Document | Purpose |
|---|---|
| `BUILD_PLAN.md` | Authoritative session history, completed sessions table, open session plan, deferred items, decision log |
| `APP_STATE_SUMMARY.md` (this file) | Lean status, gotchas (H-1…H-47), open items, document index |
| `Session_Intro_Template.md` | Boilerplate prompt for starting a fresh chat session |
| `Session_Closing_Maintenance_Template.md` | Step-by-step closing-session checklist for BP and ASS maintenance |
| `NewRoundPage_Design_Spec.md` | 11-H output: full NewRoundPage setup UI design spec. 13-E.7: three card body sections now in `pages/new-round/NewRoundCourseCard.jsx`, `PlayersCard.jsx`, `GamesCard.jsx` |
| `Resolver_UI_Spec.md` | v1.4 — implementation-level spec for early-departure resolver |

### Superseded / historical

| Document | Status | Notes |
|---|---|---|
| `Early_Departure_Contract.md` | v1.0 DRAFT — superseded | Superseded by `PartialGameContract.md` in 13-C |
| `Late_Arrival_Contract.md` | v1.0 DRAFT — superseded | Superseded by `PartialGameContract.md` in 13-C |
| `Dots_Contract_v2_0.md`, `Dots_Contract_v2_1.md` | Stale duplicates | `Dots_Contract.md` is current at v2.6. Remove from project knowledge base when convenient. |
