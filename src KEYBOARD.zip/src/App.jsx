import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { GLOBAL_CSS, G } from './components/ui.jsx';
import { ls, SK } from './services/storage.js';
import { roundLib } from './services/roundLib.js';
import { playerLib } from './services/playerLib.js';
import { courseLib } from './services/courseLib.js';
import { computePayouts } from './engine/payouts.js';
import { buildPayoutArgs } from './services/roundUtils.js';

import HomePage           from './pages/HomePage.jsx';
import PlayersPage        from './pages/PlayersPage.jsx';
import CoursesPage        from './pages/CoursesPage.jsx';
import NewRoundPage       from './pages/NewRoundPage.jsx';
import ScorecardPage      from './pages/ScorecardPage.jsx';
import ResultsPage        from './pages/ResultsPage.jsx';
import HistoryPage        from './pages/HistoryPage.jsx';
import { RoundSummaryModal } from './pages/RoundSummaryModal.jsx';

// ── Inline SVG nav icons ──────────────────────────────────────────────────────
const IconHome = ({ size=22, color='currentColor', strokeWidth=1.6 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9.5z"/>
    <path d="M9 21V12h6v9"/>
  </svg>
);

const IconUsers = ({ size=22, color='currentColor', strokeWidth=1.6 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);

const IconMapPin = ({ size=22, color='currentColor', strokeWidth=1.6 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0z"/>
    <circle cx="12" cy="10" r="3"/>
  </svg>
);

const IconClock = ({ size=22, color='currentColor', strokeWidth=1.6 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <polyline points="12 6 12 12 16 14"/>
  </svg>
);

// ── TheCardIcon — SVG recreation of The Card logo icon ───────────────────────
// Scorecard grid with flagstick (left column), gold triangle flag, horseshoe cup.
// Renders white on the dark green button.
const TheCardIcon = ({ size = 36 }) => (
  <svg width={size} height={size} viewBox="0 0 48 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="4" y="10" width="40" height="30" rx="2" stroke="#fff" strokeWidth="2.8"/>
    <line x1="4"  y1="20" x2="44" y2="20" stroke="#fff" strokeWidth="2"/>
    <line x1="4"  y1="30" x2="44" y2="30" stroke="#fff" strokeWidth="2"/>
    <line x1="18" y1="10" x2="18" y2="40" stroke="#fff" strokeWidth="2"/>
    <line x1="31" y1="10" x2="31" y2="40" stroke="#fff" strokeWidth="2"/>
    <line x1="9"  y1="2"  x2="9"  y2="20" stroke="#fff" strokeWidth="2.8"/>
    <polygon points="9,2 9,13 20,7" fill="#c9a84c"/>
    <path d="M7 36 Q9 40 11 36" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round"/>
  </svg>
);

// ── Side tabs — flanking the center button ────────────────────────────────────
const SIDE_TABS = [
  { id: 'home',    label: 'Home',    Icon: IconHome   },
  { id: 'players', label: 'Players', Icon: IconUsers  },
  // center button rendered separately
  { id: 'courses', label: 'Courses', Icon: IconMapPin },
  { id: 'history', label: 'History', Icon: IconClock  },
];

// Center tab is "active" whenever user is in the round flow
const CENTER_FLOW_TABS = new Set(['new-round', 'scorecard', 'results']);

// ── Layout constants ──────────────────────────────────────────────────────────
// NAV_BAR_HEIGHT: fixed bottom nav bar height (px, excludes safe-area-inset).
// ACTION_BAR_HEIGHT: pinned action bar height used by Scorecard and Results.
// If either value changes, update the matching constants in ScorecardPage.jsx
// and ResultsPage.jsx as well (known duplication — tracked in ASS open items).
const NAV_BAR_HEIGHT    = 68;
const ACTION_BAR_HEIGHT = 52;

// Returns an error message if Stroke Play is active and any participating player
// has an unscored hole. Returns null if Stroke Play is inactive or all scores present.
function strokePlayIncompleteMsg(ar) {
  if (!ar.activeGames?.includes('Stroke Play')) return null;
  const idxs = ar.strokePlayPlayers?.length
    ? ar.strokePlayPlayers
    : ar.activePlayers.map((_, i) => i);
  for (const pi of idxs) {
    for (let h = 0; h < 18; h++) {
      if (!parseInt(ar.scores?.[h]?.[pi])) {
        const name = ar.activePlayers[pi]?.name || `Player ${pi + 1}`;
        return `Stroke Play: ${name} has not completed all 18 holes. All scores must be entered before viewing results.`;
      }
    }
  }
  return null;
}

// ── G-6: Shared export filename helper ────────────────────────────────────────
export function makeExportFilename() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const date = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
  const time = `${pad(now.getHours())}-${pad(now.getMinutes())}`;
  return `The Card ${date} ${time}.json`;
}

// ── G-6: Trigger a JSON export download of the full history ──────────────────
export async function triggerExport() {
  const filename = makeExportFilename();
  const payload  = {
    exportedAt: new Date().toISOString(),
    appVersion: 'golf-scorekeeper-v4',
    players:    playerLib.list(),
    courses:    courseLib.list(),
    rounds:     roundLib.list(),
  };
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: 'application/json' });

  if (navigator.canShare && navigator.canShare({ files: [new File([blob], filename, { type: 'application/json' })] })) {
    try {
      await navigator.share({
        files: [new File([blob], filename, { type: 'application/json' })],
        title: 'The Card — Golf Backup',
      });
      return;
    } catch (err) {
      if (err.name === 'AbortError') return;
    }
  }

  if (typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: [{ description: 'Golf Backup (JSON)', accept: { 'application/json': ['.json'] } }],
      });
      const writable = await handle.createWritable();
      await writable.write(json);
      await writable.close();
      return;
    } catch (err) {
      if (err.name === 'AbortError') return;
    }
  }

  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ── Helper: clear all round-related local state ───────────────────────────────
function clearRoundStorage() {
  ls.del(SK.activeRound);
  localStorage.removeItem('golf_round_setup_v5');
}

export default function App() {
  const [tab, setTab] = useState('home');
  const [loadedRoundSetup, setLoadedRoundSetup] = useState(null);

  // ── A-6: roundVersion makes inProgress reactive ───────────────────────────
  const [roundVersion, setRoundVersion] = useState(0);

  // ── A-2: newRoundKey forces NewRoundPage to remount blank ────────────────
  const [newRoundKey, setNewRoundKey] = useState(0);

  // ── R-4: summaryRound — round to show in read-only RoundSummaryModal ─────
  const [summaryRound, setSummaryRound] = useState(null);

  // Ref to NewRoundPage's handleStart — used by center button to trigger
  // Start Scoring when the user is on the new-round tab with a round in progress.
  const startTriggerRef = useRef(null);

  // ── A-6: inProgress derived from roundVersion so it updates reactively ───
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const inProgress = useMemo(() => !!ls.get(SK.activeRound), [roundVersion]);

  // ── Scroll to top on every tab change ────────────────────────────────────
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [tab]);

  const getActiveRound = useCallback(() => {
    const ar = ls.get(SK.activeRound);
    if (!ar) return ar;
    // Ensure gameOpts always has grossNetNOL set (migrates rounds saved before 11-I.3).
    // NOTE: Stableford skips the o.scoring fallback — in Stableford, opts.scoring holds
    // the team hole-scoring rule ('cumulative'|'bestball'), not a handicap mode value.
    const GNL_DEFAULTS = { 'Stroke Play': 'gross', Dots: 'gross', Stableford: 'net' };
    const go = ar.gameOpts || {};
    let changed = false;
    const migratedOpts = Object.fromEntries(
      Object.entries(go).map(([g, o]) => {
        if (o && o.grossNetNOL === undefined) {
          changed = true;
          const gnl = g === 'Stableford'
            ? (GNL_DEFAULTS[g] || 'net')
            : (o.scoring ?? (GNL_DEFAULTS[g] || 'net'));
          return [g, { ...o, grossNetNOL: gnl }];
        }
        return [g, o];
      })
    );
    if (!changed) return ar;
    return { ...ar, gameOpts: migratedOpts };
  }, []);

  const saveActiveRound = useCallback((data) => {
    ls.set(SK.activeRound, data);
    setRoundVersion(v => v + 1);
  }, []);

  const clearActiveRound = useCallback(() => {
    clearRoundStorage();
    setRoundVersion(v => v + 1);
  }, []);

  const handleStartRound = useCallback((roundState) => {
    saveActiveRound(roundState);
    setTab('scorecard');
  }, [saveActiveRound]);

  const handleGoResults = useCallback(() => {
    const ar = getActiveRound();
    if (!ar) return;
    const spErr = strokePlayIncompleteMsg(ar);
    if (spErr) { alert(spErr); return; }
    try {
      const result = computePayouts(buildPayoutArgs(ar));
      saveActiveRound({ ...ar, breakdown: result.breakdown, bank: result.bank });
    } catch(e) { console.error('Payout compute error:', e); }
    setTab('results');
  }, [getActiveRound, saveActiveRound]);

  // G-6: Auto-export on save
  const handleSaveRound = useCallback(async () => {
    const ar = getActiveRound();
    if (!ar) return;
    let arToSave = ar;
    try {
      const result = computePayouts(buildPayoutArgs(ar));
      arToSave = { ...ar, breakdown: result.breakdown, bank: result.bank };
      saveActiveRound(arToSave);
    } catch(e) {
      console.error('Payout recompute error on save:', e);
    }
    roundLib.saveFromActive(arToSave);
    clearRoundStorage();
    setRoundVersion(v => v + 1);
    setNewRoundKey(k => k + 1);
    setLoadedRoundSetup(null);
    try { await triggerExport(); } catch(e) { console.error('Auto-export error (non-fatal):', e); }
    setTab('history');
  }, [getActiveRound, saveActiveRound]);

  // ── A-1: Discard the active round ────────────────────────────────────────
  const handleDiscardRound = useCallback(() => {
    clearRoundStorage();
    setRoundVersion(v => v + 1);
    setNewRoundKey(k => k + 1);
    setLoadedRoundSetup(null);
    setTab('home');
  }, []);

  // ── A-2: New Round from HomePage ─────────────────────────────────────────
  const handleHomeNewRound = useCallback(() => {
    const existing = ls.get(SK.activeRound);
    if (existing) {
      const ok = window.confirm('Starting a new round will discard your round in progress. Continue?');
      if (!ok) return;
      clearRoundStorage();
      setRoundVersion(v => v + 1);
    }
    setNewRoundKey(k => k + 1);
    setLoadedRoundSetup(null);
    setTab('new-round');
  }, []);

  // ── Back to setup from scorecard ─────────────────────────────────────────
  const handleBackToSetup = useCallback(() => {
    const ar = getActiveRound();
    if (ar?.roundId) {
      const shim = { ...roundLib.fromActiveRound(ar), id: ar.roundId };
      setLoadedRoundSetup(roundLib.toSetupState(shim));
      setNewRoundKey(k => k + 1);
    }
    setTab('new-round');
  }, [getActiveRound]);

  // ── G-7: History-load conflict warning ───────────────────────────────────
  const handleLoadRound = useCallback((r) => {
    try {
      const existingAr = ls.get(SK.activeRound);
      if (existingAr) {
        const hasScores = existingAr.scores?.some(holeScores =>
          holeScores?.some(s => s !== '' && s != null)
        );
        if (hasScores) {
          const ok = window.confirm('Loading this round will replace your round in progress. Continue?');
          if (!ok) return;
        }
      }
      saveActiveRound(roundLib.toActiveRound(r));
      setLoadedRoundSetup(roundLib.toSetupState(r));
      setTab('new-round');
    } catch(e) {
      console.error('handleLoadRound failed:', e);
      alert('Could not load round: ' + e.message);
    }
  }, [saveActiveRound]);

  // ── Center button tap handler ─────────────────────────────────────────────
  // When a round is in progress and the user is on the new-round tab,
  // treat the center button as "Start Scoring" — run the full round assembly
  // so any setup changes are committed before navigating to the scorecard.
  // Otherwise navigate to the scorecard directly (already scored round), or
  // to new-round setup (no round in progress).
  const handleCenterTap = useCallback(() => {
    if (inProgress && tab === 'new-round') {
      startTriggerRef.current?.();
    } else if (inProgress) {
      setTab('scorecard');
    } else {
      setNewRoundKey(k => k + 1);
      setLoadedRoundSetup(null);
      setTab('new-round');
    }
  }, [inProgress, tab]);

  const centerActive = CENTER_FLOW_TABS.has(tab);

  // Landscape detection for full-width scorecard/results layout
  const [isLandscape, setIsLandscape] = useState(
    () => typeof window !== 'undefined' && window.innerWidth > window.innerHeight
  );
  useEffect(() => {
    const upd = () => setIsLandscape(window.innerWidth > window.innerHeight);
    window.addEventListener('resize', upd);
    window.addEventListener('orientationchange', upd);
    return () => { window.removeEventListener('resize', upd); window.removeEventListener('orientationchange', upd); };
  }, []);

  return (
    <div style={{
      minHeight: '100vh',
      background: '#f0f7f0',
      fontFamily: "'DM Sans','Helvetica Neue',sans-serif",
      color: '#222',
      touchAction: 'pan-y',
      WebkitTextSizeAdjust: '100%',
      overflowX: 'hidden',
      paddingBottom: `calc(${NAV_BAR_HEIGHT}px + env(safe-area-inset-bottom))`,
    }}>
      <style>{GLOBAL_CSS}</style>

      <div style={{ maxWidth: isLandscape ? 'none' : 520, margin: '0 auto' }}>
        {tab === 'home'      && <HomePage      onNewRound={handleHomeNewRound} onResume={() => setTab('scorecard')} onHistory={() => setTab('history')} inProgress={inProgress} onRoundTap={r => setSummaryRound(r)}/>}
        {tab === 'players'   && <PlayersPage />}
        {tab === 'courses'   && <CoursesPage />}
        {tab === 'new-round' && (
          <NewRoundPage
            key={newRoundKey}
            onStart={handleStartRound}
            onGoScorecard={() => setTab('scorecard')}
            onSaveEdits={() => { setLoadedRoundSetup(null); setTab('history'); }}
            inProgress={inProgress}
            loadedRound={loadedRoundSetup}
            onLoadedRoundConsumed={() => setLoadedRoundSetup(null)}
            getActiveRound={getActiveRound}
            startTriggerRef={startTriggerRef}
          />
        )}
        {tab === 'scorecard' && <ScorecardPage getActiveRound={getActiveRound} saveActiveRound={saveActiveRound} onResults={handleGoResults} onBack={handleBackToSetup} onDiscard={handleDiscardRound}/>}
        {tab === 'results'   && <ResultsPage   getActiveRound={getActiveRound} onSave={handleSaveRound} onBack={() => setTab('scorecard')}/>}
        {tab === 'history'   && <HistoryPage   onLoadRound={handleLoadRound}/>}
      </div>

      {/* ── Bottom nav — always visible ── */}
      {/* overflow:visible required so center button protrusion + ring are not clipped */}
      <nav style={{
        position: 'fixed', bottom: 0, left: 0, right: 0,
        background: '#fff',
        borderTop: '1px solid #e0ece0',
        display: 'flex',
        alignItems: 'center',
        zIndex: 50,
        height: `calc(${NAV_BAR_HEIGHT}px + env(safe-area-inset-bottom))`,
        paddingBottom: 'env(safe-area-inset-bottom)',
        overflow: 'visible',
      }}>

        {/* Left two tabs: Home, Players */}
        {/* Home gets marginLeft to push it away from the screen edge.          */}
        {/* Padding stays symmetric so the active indicator bar stays centered. */}
        {SIDE_TABS.slice(0, 2).map(({ id, label, Icon }, i) => {
          const active = tab === id;
          return (
            <button key={id} onClick={() => setTab(id)} style={{
              flex: 1, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              height: NAV_BAR_HEIGHT, padding: '0 4px',
              marginLeft: i === 0 ? 10 : 0,
              border: 'none', background: 'none', cursor: 'pointer',
              position: 'relative', gap: 3,
            }}>
              {active && <div style={{
                position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
                width: 28, height: 3, background: G, borderRadius: '0 0 4px 4px',
              }}/>}
              <Icon size={29} color={active ? G : '#aaa'} strokeWidth={active ? 2.2 : 1.6}/>
              <span style={{ fontSize: 11, fontWeight: active ? 700 : 400, color: active ? G : '#aaa', fontFamily: 'inherit', letterSpacing: '-0.1px' }}>
                {label}
              </span>
            </button>
          );
        })}

        {/* ── Center logo button ── */}
        {/* Fixed-width slot prevents the circle from squeezing the outer tabs.  */}
        {/* marginTop: -18 lifts the button 18px above the nav bar top edge.     */}
        {/* overflow:visible on <nav> ensures the ring shadow renders unclipped.  */}
        <div style={{
          flexShrink: 0, width: 76,
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          height: NAV_BAR_HEIGHT, position: 'relative',
        }}>
          {centerActive && <div style={{
            position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
            width: 28, height: 3, background: G, borderRadius: '0 0 4px 4px',
          }}/>}
          <button
            onClick={handleCenterTap}
            style={{
              width: 57, height: 57, borderRadius: '50%',
              background: G,
              border: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              position: 'relative',
              marginTop: -18,
              boxShadow: centerActive
                ? `0 0 0 2.5px #fff, 0 0 0 4.5px ${G}`
                : '0 3px 10px rgba(26,71,42,0.4)',
              flexShrink: 0,
            }}
          >
            <TheCardIcon size={36}/>
            {/* Gold dot — matches flag color, signals round in progress */}
            {inProgress && (
              <div style={{
                position: 'absolute', top: 1, right: 1,
                width: 10, height: 10,
                background: '#c9a84c',
                borderRadius: '50%',
                border: '2px solid #fff',
              }}/>
            )}
          </button>
        </div>

        {/* Right two tabs: Courses, History */}
        {/* History gets marginRight to push it away from the screen edge.       */}
        {/* Padding stays symmetric so the active indicator bar stays centered.  */}
        {SIDE_TABS.slice(2).map(({ id, label, Icon }, i) => {
          const active = tab === id;
          return (
            <button key={id} onClick={() => setTab(id)} style={{
              flex: 1, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              height: NAV_BAR_HEIGHT, padding: '0 4px',
              marginRight: i === 1 ? 10 : 0,
              border: 'none', background: 'none', cursor: 'pointer',
              position: 'relative', gap: 3,
            }}>
              {active && <div style={{
                position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
                width: 28, height: 3, background: G, borderRadius: '0 0 4px 4px',
              }}/>}
              <Icon size={29} color={active ? G : '#aaa'} strokeWidth={active ? 2.2 : 1.6}/>
              <span style={{ fontSize: 11, fontWeight: active ? 700 : 400, color: active ? G : '#aaa', fontFamily: 'inherit', letterSpacing: '-0.1px' }}>
                {label}
              </span>
            </button>
          );
        })}

      </nav>

      {/* R-4: RoundSummaryModal overlay */}
      {summaryRound && (
        <RoundSummaryModal r={summaryRound} onClose={() => setSummaryRound(null)} />
      )}
    </div>
  );
}
