# ScoreKeypad Contract

_Version 2.1 AUTHORITATIVE — April 2026_
_Supersedes v2.0._
_Changes in v2.1: Navigation row (←/✓/→) removed from keypad. Props `onConfirm`, `onNavigate`, `atFirst`, `atLast` removed. Layout is now 4 rows. §2.1 props, §2.2 layout, §2.8, §2.9 updated accordingly. Invariants #8 and #9 updated._
_Status: AUTHORITATIVE. Implementation conforms to this document._
_If code conflicts with this contract, the contract wins._

---

**Engine file(s):** `games.js`, `payouts.js`, `handicap.js`
**UI components:** `ScoreKeypad.jsx` (new), `ScoreGrid.jsx` (modified), `ZoomModal.jsx` (modified)
**Payout logic location:** No payout logic in keypad. Engine receives `'X'` as a raw score value.
**Cross-references:**
- `App_Data_Model_Contract.md` §5 — `scores[h][i]` valid values (amended by this contract)
- `Round_Lifecycle_Contract.md` §12.3 — score normalization invariant (amended by this contract)
- `Handicap_Contract.md` §3 — ESC calculation (amended by this contract)
- `Payout_Contract.md` §2 — engine interpretation of X scores (amended by this contract)
- All game contracts — "X always loses" rule (each amended by this contract)
- `UI_Component_Contract.md` — component registered here

---

## §1. Overview

### §1.1 Purpose

`ScoreKeypad` is a custom in-app numeric keypad that replaces the iOS system
keyboard for all score entry throughout the app. It renders as a fixed overlay
at the bottom of the screen and appears whenever a score cell is active — both
in the main `ScoreGrid` and inside `ZoomModal`. The system keyboard is never
invoked for score entry.

The keypad adds two score-entry actions not possible with the system keyboard:
- **X** — player picked up their ball (see §4)
- **Long-press X** — player is leaving the round or a game (see §5; resolver
  logic is specified in the Early Departure Contract; stub only in this session)

### §1.2 Architecture

`ScoreKeypad` is a **fixed-bottom screen overlay** rendered by `ScoreGrid`.
It is not embedded inside `ZoomModal`. Key architectural decisions:

- `ScoreGrid` owns all keypad state: `activeKpCell`, `kpValue`, advance/retreat
  timers, and all keypad callbacks.
- `ScoreKeypad` is a pure controlled component — it receives `value` and fires
  callbacks. It owns no score state.
- `ZoomModal` is a pure display component. It has no hidden input, no keyboard
  focus logic, and no advance/retreat logic. Tapping a cell in ZoomModal calls
  `onCellTap(h, pi)` which sets `activeKpCell` in ScoreGrid.
- `zoomHole` (the hole displayed in ZoomModal) is updated by ScoreGrid's
  `kpAdvanceCell` and `kpRetreatCell` whenever the active cell crosses a hole
  boundary and `zoomOpen` is true.
- The keypad is visible (`kpVisible`) whenever `canZoom && !!activeKpCell`.
  It is NOT suppressed when ZoomModal is open — it renders above ZoomModal
  (`zIndex: 300` vs ZoomModal's `zIndex: 200`).
- When ZoomModal opens, ScoreGrid immediately sets `activeKpCell` to the first
  empty cell on the target hole (deferred by one event loop tick via `setTimeout(0)`
  to avoid the global `touchend` dismiss handler firing on the zoom button tap).

### §1.3 Scope

This contract covers:
1. The keypad component UI and behavior (§2)
2. ScoreGrid keypad integration (§3)
3. ZoomModal integration (§3.4)
4. The `'X'` score type (§4)
5. The "X always loses" invariant across all games (§4.5)
6. Display table X handling (§7)

---

## §2. Component Spec — `ScoreKeypad.jsx`

### §2.1 Props

```js
ScoreKeypad.propTypes = {
  containerRef:  PropTypes.object,              // ref attached to outer div for dismiss detection
  visible:       PropTypes.bool.isRequired,     // show/hide the keypad
  value:         PropTypes.string.isRequired,   // '' | digit string | 'X'
  onChange:      PropTypes.func.isRequired,     // (newVal: string) => void
  onBackspace:   PropTypes.func.isRequired,     // () => void — parent handles char removal or retreat
  onLongPressX:  PropTypes.func,               // optional — () => void
}
```

Removed from v2.0: `onConfirm`, `onNavigate`, `atFirst`, `atLast` — these
were used by the navigation row (←/✓/→) which was removed in v2.1. Auto-advance
via the timer in ScoreGrid replaces `onConfirm`. Cell-to-cell navigation is
handled by tapping cells directly.

### §2.2 Layout and Position

```
position: fixed
left: 0, right: 0, bottom: 0
zIndex: 300
paddingBottom: calc(GAP + env(safe-area-inset-bottom))
```

The keypad covers the nav bar (zIndex 300 > nav zIndex 50). Content above the
keypad is not obscured — the scorecard page has sufficient bottom clearance.

Button layout (4 rows × 3 columns, all equal width, ~56px tall per row):

```
┌───────────┬───────────┬───────────┐
│     1     │     2     │     3     │
├───────────┼───────────┼───────────┤
│     4     │     5     │     6     │
├───────────┼───────────┼───────────┤
│     7     │     8     │     9     │
├───────────┼───────────┼───────────┤
│     ⌫     │     0     │     X     │
└───────────┴───────────┴───────────┘
```

The navigation row (←/✓/→) was removed in v2.1 to reduce screen space usage.
Cell advancement is handled entirely by auto-advance timing.

**Colors:**
- Digit buttons (0–9): white bg, `#222` text
- `⌫` button: `#c8c8c8` bg, `#444` text, 22px
- `X` button: `AMB` (amber) bg, `#fff` text — transitions to `RED` at 300ms during long press
- Outer container: `#e0e0e0` bg, `1px solid #bbb` top border

### §2.3 Digit entry behavior

- Opening a cell always seeds `kpValue = ''` regardless of any existing committed
  score. The first digit tap always replaces, never appends.
- Digits append to `kpValue` (e.g. tap `'1'` → `'1'`, tap `'4'` → `'14'`).
- A third digit tap on a 2-digit value resets to that digit (e.g. `'14'` + tap
  `'8'` → `'8'`). No 3-digit values.
- `'X'` in `kpValue` is replaced by any digit tap.
- `onChange(newVal)` is called on every keystroke. ScoreGrid writes the score
  immediately and schedules auto-advance.

### §2.4 Auto-advance timing

ScoreGrid owns the advance timer, not `ScoreKeypad`. The timer rule:
- Value `'1'` only: wait 700ms (two-digit entry window), then advance.
- All other values (2–9, 0, X): advance immediately on `onChange`.

### §2.5 ⌫ (Backspace) behavior

`onBackspace()` is called and ScoreGrid applies this logic:
1. If `kpValue` is non-empty: remove last character from `kpValue`; write updated value to scores.
2. If `kpValue` is empty AND committed score is non-empty: clear the committed score (write `''`); stay on cell.
3. If `kpValue` is empty AND cell is already empty: retreat to prior cell.

This matches the original iOS keyboard backspace behavior exactly.

### §2.6 X button — single tap

1. `onChange('X')` fires immediately.
2. ScoreGrid writes `'X'` to scores and advances immediately (non-1 rule).
3. Cell renders as `"NX"` (see §4.3).

### §2.7 X button — long press

Long-press threshold: **600ms**. Visual warning at **300ms** (button turns RED).
On fire: calls `onLongPressX()`. Currently a stub: `alert('Early departure — coming soon')`.

---

## §3. ScoreGrid Integration

### §3.1 Keypad state owned by ScoreGrid

```
activeKpCell:   { h, pi } | null   — which cell has keypad focus
kpValue:        string             — in-progress value ('' on open/advance/retreat)
kpAdvanceTimer: ref                — advance timeout handle
kpContainerRef: ref                — attached to ScoreKeypad outer div
zoomCardRef:    ref                — attached to ZoomModal card div
```

### §3.2 `kpVisible`

```js
const kpVisible = canZoom && !!activeKpCell;
```

Keypad is shown whenever a cell is active, regardless of whether ZoomModal is open.

### §3.3 Score cell inputs

All score cells in `ScoreGrid` use `inputMode="none" readOnly`. On
`onTouchEnd` / `onFocus` / `onMouseDown`, they call `openKeypadOnCell(h, pi)`.
X cells render as styled divs showing `NX` — tapping them also calls
`openKeypadOnCell`.

### §3.4 ZoomModal integration

ScoreGrid passes to ZoomModal:
- `activeKpCell` — drives green border on active cell
- `onCellTap` — maps to `openKeypadOnCell`; also updates `zoomHole` if the
  tapped cell is on an adjacent hole
- `cardRef` — ref attached to the ZoomModal card div for dismiss detection
- `zoomOpen` — controls modal visibility

ZoomModal has no keyboard machinery. It calls `onCellTap(h, pi)` on cell tap.

### §3.5 Dismiss handler

A `touchend` listener is active while `kpVisible`. It dismisses the keypad
(clears `activeKpCell`) unless the touch target is:
1. An `INPUT` element (score cell inputs)
2. Inside `kpContainerRef` (the keypad itself)
3. Inside `zoomCardRef` (the ZoomModal card)

### §3.6 ZoomModal open/close

**`openZoom()` / `openZoomOnHole(h)`:** Set `zoomOpen = true`, set `zoomHole`,
then defer `setActiveKpCell` by one event loop tick via `setTimeout(0)` to avoid
the dismiss handler (which fires synchronously on the same tap gesture) clearing
the cell immediately.

**`closeZoom()`:** Clears `zoomOpen`, `activeKpCell`, and `kpValue`.

### §3.7 Hole advancement in ZoomModal

`kpAdvanceCell` and `kpRetreatCell` call `setZoomHole(nh/ph)` when `zoomOpen`
is true and the advance/retreat crosses a hole boundary. This keeps ZoomModal's
3-hole window centred on the currently-active hole.

---

## §4. The X Score Type

### §4.1 Storage

`scores[h][i]` valid values:
```
'' | positive integer string | 'X'
```

`'X'` is the canonical stored value. Display strings (e.g. `'7X'`) are never stored.

### §4.2 X gross value computation

```
xGross(h, i) = pars[h] + 2 + handicapStrokes(h, i)
```

Exported from `handicap.js` as:
```js
export function xGrossScore(holeIdx, courseHcp, hcps, pars)
```

### §4.3 Display of X scores

In ScoreGrid, ZoomModal, RoundSummaryModal, and share image:
- Render as numeric part + `X` suffix
- Numeric part: normal score color/weight
- `X` suffix: `AMB` (amber) color, `0.75–0.85em`, same weight
- Cell background: `#fffbe6` (light amber tint)

In TotalsCard: xGross value included numerically in gross total. No X annotation.

### §4.4 X and ESC

X is already ESC-capped by definition (`xGross = par + 2 + strokes = ESC max`).
`escTotal()` in `handicap.js` uses `xGrossScore()` directly for X holes.

### §4.5 "X always loses" invariant

A player with X loses to any player with a real score on that hole.
Two X players on the same hole tie each other.
This holds across all 7 games and all scoring modes.

### §4.6 Per-game X behavior

| Game | X behavior |
|------|-----------|
| Skins | X cannot win a skin. All-X → tied (skin carries per carryover setting). |
| Match / Nassau | X loses hole to any real score. X vs X → halved. |
| Nines | X comes in last place. Points distributed per §4.7. |
| Stableford | Net mode: X = 0 pts (net double bogey). Gross mode: xGross applied to pts table. |
| Sixes | X player's team uses partner's score as best-ball. Both partners X → lower xGross. |
| Stroke Play | X is not valid — player cannot pick up in stroke play (see §4.8). |
| Dots | X hole: no birdie/eagle/ace auto-mark for that player. |

### §4.7 Nines X points

Three-player field:
- 1 player X: X gets 1 pt (sole last); other two compete normally for 5/3.
- 2 players X: X players get 2 pts each (tie last); real score player gets 5 pts.
- All 3 X: 3 pts each (three-way tie).

Implementation: X players are given a sentinel value of `maxRealScore + 1` so
they sort after all real scores. All X players receive the same sentinel so they
tie each other. `ninesPts()` distributes points normally from this sorted order.

### §4.8 Stroke Play and X

X is not a valid score in Stroke Play — a player cannot pick up. The engine
skips X holes for Stroke Play calculations rather than substituting xGross.
The X button is not blocked in the UI (other games may be active simultaneously),
but Stroke Play treats X holes as unscored.

---

## §5. Long-Press X — Stub

`onLongPressX` is wired as a stub:
```js
onLongPressX={() => alert('Early departure — coming soon')}
```

Full resolver logic is specified in the Early Departure Contract and will be
wired in a dedicated session.

---

## §6. Not Used for Non-Score Inputs

`ScoreKeypad` is for score entry only. Bet amounts, handicap indices, course
data, and other numeric fields continue to use native `<input>` elements.

---

## §7. Display Table X Handling

`NinesTable` and `MatchNassauTable` have their own display-layer scoring logic.
Both must handle `'X'` explicitly — `parseInt('X')` returns `NaN` and must
never be used as a score value.

- `NinesTable.holeData`: mirrors `calcNines` X logic — xFlags, allX branch,
  `maxReal + 1` sentinel for `ninesPts`.
- `MatchNassauTable.indivHoleWinner`: checks raw string for `'X'` before
  `parseInt`. X vs real → real wins. X vs X → halved (return `0`).
- `MatchNassauTable.teamHoleWinner`: X players use `Infinity` so they can never
  contribute the best-ball. `isFinite` guards on tiebreaker comparisons.

---

## §8. Invariants

1. `'X'` is the only non-numeric non-empty valid score value.
2. `xGrossScore()` always returns ≥ `par + 2`.
3. X always loses to a real score. X ties X. Holds across all 7 games.
4. `'X'` is never stored as `'NX'` — display strings are never persisted.
5. `ScoreKeypad` is a pure UI component with no engine calculations except
   `xGrossScore()` for display.
6. The system keyboard is never invoked during score entry.
7. `'X'` is never sanitized to `''` during score normalization.
8. All four button rows use equal-width, equal-height buttons. No spanning.
9. The navigation row (←/✓/→) does not exist. Any future addition of a
   navigation row requires a contract amendment and owner approval.
10. `kpValue` is always seeded as `''` when opening, advancing, or retreating
    to any cell. The first digit tap always replaces the committed score.
11. ZoomModal has no keyboard machinery. All score entry flows through
    ScoreGrid's keypad state.
12. The keypad is never suppressed when ZoomModal is open.

---

## §9. Known Open Items

| # | Severity | Description |
|---|----------|-------------|
| G-1 | Medium | `onLongPressX` resolver — Early Departure session (stub only) |
| G-2 | Low | Score cell amber tint `#fffbe6` — confirmed on device |
| G-3 | Low | Bottom clearance: scorecard page padding does not yet account for keypad height; content may scroll under keypad at bottom of round |

