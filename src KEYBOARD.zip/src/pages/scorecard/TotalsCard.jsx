// ─── scorecard/TotalsCard.jsx ─────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// Displays gross and ESC (Adjusted Gross Score) round totals for all players.
// Receives all data as props; performs no scoring calculations.
//
// ESC = Adjusted Gross Score for GHIN posting (USGA World Handicap System).
// Per-hole cap: par + 2 + hdcpStrokesFromCourseHcp(courseHcp, rank).
// Always shown regardless of the scoring mode used for active games.

import { escTotal, xGrossScore } from '../../engine/handicap.js';
import { G } from '../../components/ui.jsx';

export function TotalsCard({ players, pars, scores, courseHcps, hcps }) {
  const ALL18 = [...Array(18).keys()];

  const parTotal   = ALL18.reduce((s, h) => s + (pars[h] || 0), 0);
  // X scores contribute their computed xGross value (par+2+strokes) — §7.2
  const grossTotal = pi => ALL18.reduce((s, h) => {
    const raw = scores[h]?.[pi];
    if (raw === 'X') return s + xGrossScore(h, courseHcps[pi], hcps, pars);
    return s + (parseInt(raw) || 0);
  }, 0);

  const n = players.length;

  return (
    <div style={{ marginBottom: 14, background: '#fff', borderRadius: 12, border: '1px solid #e0ece0', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '7px 10px 5px' }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: G }}>Round Totals</span>
        <span style={{ fontSize: 10, padding: '1px 7px', borderRadius: 8, background: '#e0ece0', color: G }}>Par {parTotal}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${n}, 1fr)`, gap: 6, padding: '4px 8px 8px' }}>
        {players.map((p, pi) => {
          const gt  = grossTotal(pi);
          const esc = escTotal(scores, pi, pars, hcps, courseHcps[pi]);
          const hasScores = gt > 0;
          const parts = (p?.name || '').trim().split(/\s+/);
          const first = parts[0] || '?';
          const last  = parts.length >= 2 ? parts[parts.length - 1] : '';
          return (
            <div key={pi} style={{ textAlign: 'center', borderRadius: 8, padding: '6px 4px', background: '#f5fbf5', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: G, lineHeight: 1.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{first}</div>
              {last && <div style={{ fontSize: 10, fontWeight: 400, color: G, opacity: 0.6, lineHeight: 1.2, marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{last}</div>}
              {hasScores ? (
                <>
                  <div style={{ fontSize: 15, fontWeight: 700, color: '#222', lineHeight: 1.1 }}>{gt}</div>
                  <div style={{ fontSize: 10, color: '#888' }}>({esc} ESC)</div>
                </>
              ) : (
                <div style={{ fontSize: 13, color: '#ccc' }}>—</div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
