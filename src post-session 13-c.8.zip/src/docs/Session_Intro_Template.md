# Session Intro Meta-Template (v3.0)

_Last updated: April 2026 — concision pass; closing section removed in favor of `Session_Closing_Maintenance_Template.md`._
_This is the meta-template used by the **meta-planning chat** to draft opening messages for new build-session chats. It is not a game contract. For game contracts see `Universal_Contract_Template.md`._

---

## Meta-planning chat identity

You are an expert full-stack developer helping me build and maintain a React golf scoring app called The Card. Always read documents in this order before taking any action:

1. `ARCHITECTURE_FOUNDATIONS.md`
2. `APP_STATE_SUMMARY.md`
3. `App_Data_Model_Contract.md`
4. `Round_Lifecycle_Contract.md`
5. `UI_Component_Contract.md`

Purpose of this chat: This is a meta-planning chat. Your job here is to draft opening messages for new build session chats — not to write code or modify files. Every time I ask for a session intro, you will produce a complete, ready-to-paste opening message for a new chat tab.

Before drafting any session intro, always read these files first:
- `ARCHITECTURE_FOUNDATIONS.md`
- `APP_STATE_SUMMARY.md` (including the "Work in Flight" block at top)
- `BUILD_PLAN.md`
- The relevant contract(s) for the session scope
- The relevant source file(s) for the session scope

---

# Template: what every session intro must contain

Every session intro you draft must include all of the following sections. Do not omit any section. Do not add sections not listed here without flagging it as an addition.

---

## Section 1 — Identity and document reading order

Always opens with:

```
You are an expert full-stack developer helping me build and maintain a React
golf scoring app called The Card. Always read documents in this order before
taking any action:

  1. ARCHITECTURE_FOUNDATIONS.md
  2. APP_STATE_SUMMARY.md   (read the "Work in Flight" block at top first)
  3. App_Data_Model_Contract.md
  4. Round_Lifecycle_Contract.md
  5. UI_Component_Contract.md

Session-specific governing documents (read before the Section 4 scope items):
  [list 1–N of: PartialGameContract.md, Nassau_Match_Contract.md,
   Stableford_Contract.md, Stroke_Play_Contract.md, Nines_Contract.md,
   Skins_Contract.md, Sixes_Contract.md, Dots_Contract.md, Payout_Contract.md,
   Handicap_Contract.md, ScoreKeypad_Contract.md, Early_Departure_Contract.md,
   Late_Arrival_Contract.md]

Session-specific source files (read before writing any code):
  [list 1–N source files this session will touch or read]

Reading depth:
  - Contract-first or architecturally significant sessions: read core docs
    in full.
  - Bug fix or small feature sessions: scan headers and table of contents,
    then read in full only the sections relevant to scope. Do not full-read
    documents you are not going to act on.
```

The meta-planner is responsible for filling in the session-specific document and file lists — do **not** leave the Section 1 list at the baseline 5 for sessions that need more context. Reading order matters: core docs → session-specific contracts → source files.

The meta-planner must also classify the session's reading depth (contract-first/architectural vs bug-fix/small-feature) and state it explicitly in Section 2.

---

## Section 2 — Session goal and context

One short paragraph stating:
- The sprint and session designation (e.g. "Sprint 13 / Session 13-C.3 Phase 2B")
- Reading depth classification (contract-first/architectural OR bug-fix/small-feature)
- What this session accomplishes in plain terms (one sentence)
- What was completed immediately before this session (prior session designation + one-line summary)
- Whether contract work is required before code (yes/no; if yes, which contract and which section)
- The stability state of the app going in

Cap this section at ~120 words. If it runs longer, the scope is too broad for one session.

---

## Section 2A — Multi-part session pre-inventory (include only if this is Phase 2+ of a multi-part session)

When a session is split across multiple chats (e.g., a sprint too large for one cap), the downstream chat's intro must include an explicit inventory of what's already done and where it lives:

```
## Pre-session inventory — what's already delivered from prior phases

Files already written and staged (from Phase 1 / Phase 2A / etc.):
  [path]  — [one-line description + delivery status: "in project", "in outputs",
             "in chat", "in my local downloads folder"]
  ...

Files to be uploaded to the project at session end (bundled with this session's
deliverables):
  [path]  — [why it hasn't been uploaded yet]
  ...

Contract amendments drafted but not yet written to contract files:
  [contract.md §X.Y] — [one-line description]
  ...

Regression tests that passed in the prior phase (still valid for this session):
  [test name] — [what it proves]
  ...

DO NOT re-emit any file listed above. Reference them in the session log but
do not regenerate them.
```

If there are no pending items, omit Section 2A entirely.

---

## Section 3 — Session naming rule (always include verbatim)

```
CRITICAL — Session naming rule: The master build plan maintained outside
this chat assigns all future session designations. Never auto-assign new
session numbers or letters. Label sub-tasks as phases within the current
session only. Do not create new alphanumeric session entries in
APP_STATE_SUMMARY.md — only add a session row when the owner explicitly
provides the correct designation.
```

---

## Section 4 — Scope

A precise list of exactly what this session does. Format: one bullet per scope item with a bold label. For each item, in 1–3 lines total:
- File(s) it touches
- Correct behavior (the spec, not the implementation)
- Governing contract section, if applicable
- Decision/confirmation required from the owner before code, if any

Do not expand scope items into mini-essays. If a scope item needs more than three lines to describe, it probably belongs in a contract amendment, not the intro.

If the session is contract-first, scope is split into **Section 4A (Phase 1)** and **Section 4B (Phase 2)** — see below.

---

## Section 4A — Contract-first: Phase 1 (contract amendment)

_Include only if the session requires contract work before code._

- **What sections change** — list exact contract file + section numbers
- **What decisions must be made** — enumerate open questions; each one gets an owner answer before Phase 1 is "approved"
- **What the draft must contain before approval** — explicit list of what the owner should see
- **Approval gate language** — the exact phrase the owner will use (e.g. "Continue", "Phase 1 approved") to move to Phase 2

## Section 4B — Contract-first: Phase 2 (implementation)

_Include only if the session has a Phase 2 after Phase 1 approval._

- **Scope items** — same format as Section 4
- **Explicit statement**: "Phase 2 does not begin until the owner has approved Phase 1 with the agreed phrase."

---

## Section 5 — Files in scope

An explicit list of every file that will be touched. Anything not on this list must not be modified without owner approval. Include:
- The file path
- One-line description of what changes in it
- Change type: `new file` | `full rewrite` | `surgical str_replace only` | `str_replace preferred, full rewrite if >10 edits`

---

## Section 6 — Files explicitly out of scope

A short list of files that are adjacent but must not be touched. Helps prevent Claude from "helpfully" refactoring things that weren't asked for. At minimum always include: engine files, payout logic, and any file not directly required by the scope items.

Also include in this section:
- **Known tempting adjacent work that should NOT happen this session** — e.g. "Do not touch MatchNassauTable.jsx even though it also renders hole-range-dependent output; that is Phase 2B."

---

## Section 7 — Standard instructions (always include verbatim)

```
1. Read documents per Section 1's reading-depth classification. For bug-fix
   and small-feature sessions, scan headers first and full-read only the
   sections relevant to scope.

2. Read the session-specific source files listed in Section 1 in full.

3. [If contract-first: Read the contract sections listed in Section 4A before
   drawing any conclusions.]

4. Before writing any code, produce a [diagnostic / plan / contract draft]
   for each scope item. Output as bullets, not prose. Cap at ~150 words
   unless the session is genuinely complex. Flag any ambiguity or decision
   point and ask before resolving. Do not assume.

   Adjust instruction 4 to match the session type:
     - Bug fix session       → "diagnostic: root cause + fix, in bullets"
     - Feature session       → "plan: file-by-file change list, in bullets"
     - Contract-first session → "contract draft: present for approval before any code"
     - Audit session         → "audit findings: what you found before proposing changes"

5. Wait for explicit confirmation before producing any code.

6. Make only the changes listed in scope. Do not refactor unrelated logic.

7. Output full updated files, not diffs — EXCEPT for small surgical edits to
   large files, which should use str_replace. Rule of thumb: if the file is
   >300 lines and the change is <20 lines, prefer str_replace.

8. *** SELF-VERIFICATION REQUIRED — before presenting any file for delivery: ***

   a. Re-read the relevant scope item(s) and contract section(s) that govern
      this file.

   b. Trace through your changes. Check the usual failure modes: inverted
      guards, missing null/undefined checks, stale variable references,
      uncalled functions, renamed-field inconsistency, signature mismatches,
      and happy-path-only logic that silently no-ops on edge cases. Fix
      anything found before delivery — do not flag and ship.

   c. State the result of your self-check explicitly at the top of each
      delivered file using this exact format:
        ✅ Self-checked: [one sentence describing what you verified]
      or
        ⚠️ Self-check finding: [describe the issue found and what you
           changed to fix it]

9. Known gotchas that have bitten prior sessions — Claude must NOT:
   - Use `parseInt('X')` anywhere. `'X'` is a valid score meaning
     "picked up"; `parseInt('X')` returns NaN and corrupts all downstream
     math. Always check `raw === 'X'` as a distinct branch before parseInt.
   - Forget `restoreAutoWhen()` before using Specials from a serialized
     activeRound. JSON-serialization strips function fields; if specials
     are read without restoration, autoWhen callbacks are undefined.
   - Store derived values in activeRound. Any value that can be computed
     from `roundStartHole + roundNumHoles`, or from `scores[h][pi]`, or
     from any other stored field, is NEVER persisted. Always recompute.
   - Self-assign session designations. The owner controls all session
     names. Use "phase" within the current session only.
   - Make ZoomModal own keypad state. ZoomModal is a pure display
     component; ScoreGrid owns all keypad machinery (H-17).
   - Seed `kpValue` with anything other than `''` on cell activation.
     Any seeded value causes digit appending (H-15/H-16).

10. Cap-efficiency protocol:
    - Do not restate the scope, document reading order, or instructions
      back to the owner. Acknowledge briefly and proceed.
    - Do not narrate every step ("now I'll read X… now I'll think about
      Y…"). Output decisions and deliverables, not stream-of-consciousness.
    - For sessions touching many files: copy in-scope source files to
      `/home/claude/work/` at session start; use `create_file` for full
      replacements and `str_replace` for surgical edits; produce final
      files in `/mnt/user-data/outputs/` and deliver via `present_files`
      at session end. Do not paste full file contents into chat.
    - For long reads, use `view` with `view_range` rather than loading
      an entire file when only a section is needed.
    - Run regression tests in the working directory with `node` before
      declaring a file delivered.
```

---

## Section 8 — Testing checklist

A specific, numbered list of exactly what the owner should test on the live device before the session is considered complete. For each test:
- The exact tap/action sequence
- The pass condition (what correct looks like)
- The fail condition (what broken looks like)
- Any edge cases or combinations worth checking

Group tests by scope item. Include at minimum:
- **No-regression check** for the most likely thing to have broken (typically the full-round / default path)
- **Edge case test** for each scope item
- **Delivered-file self-check stamp verification** — open each delivered file and confirm `✅ Self-checked` (or `⚠️ Self-check finding`) appears at the top, as specified in Section 7 instruction 8c

---

## Section 9 — Session closure (always include verbatim)

```
Session closure:

Do NOT update BUILD_PLAN.md or APP_STATE_SUMMARY.md until the owner explicitly
confirms the session is closed. "Delivered" is not "closed." Device-test
results, owner confirmation of those tests, and an explicit "we're closing
this session" from the owner are all required before BP/ASS maintenance
begins.

When the owner says we're closing, follow `Session_Closing_Maintenance_Template.md`
in full. That template is the single source of truth for BP and ASS updates.
Do not improvise wrap-up steps from this intro.
```

---

# How to use this template when the owner asks for a session intro

When the owner says "write the intro for session X" or "next session is X":

1. Read `BUILD_PLAN.md` to find session X — its scope, files, contract requirements, and dependencies
2. Read `APP_STATE_SUMMARY.md` to confirm current app state and what was last completed. Read the "Work in Flight" block at the top for mid-sprint context
3. Read the relevant contracts and source files to fill in spec references and file paths accurately
4. Classify the session's reading depth (contract-first/architectural vs bug-fix/small-feature) and state it in Section 2
5. Draft the intro using all applicable sections above (1, 2, 2A if applicable, 3, 4 or 4A/4B, 5, 6, 7, 8, 9)
6. Flag anything that requires an owner decision before the session can begin — e.g. a design choice, a scope ambiguity, a contract section that's incomplete
7. Verify session designation against BUILD_PLAN.md. Do not assume the next session is the next letter — the owner may be jumping ahead, revisiting, or splitting a session

## Rules for the draft itself

- **Do not pad.** Every sentence in the intro must carry information Claude needs to do the session correctly. No filler, no preamble, no recap of what the owner just said.
- **Do not omit decision points.** If a scope item requires an owner choice (e.g. Option A vs Option B), surface it explicitly in Section 4 and ask for the decision before finalizing the intro.
- **Verify document references.** If Section 1 lists a document, that document must exist in the project. Same for Section 5 file paths.
- **Preserve guardrails verbatim.** Section 3 (naming rule), Section 7 (standard instructions including the gotchas list), and Section 9 (closure) are quoted verbatim — do not paraphrase or trim.
- **Use copy-ready formatting.** The owner should be able to copy the entire output of the meta-planner into a new chat tab without any editing. No meta-commentary ("Here's the draft:"), no markdown artifacts that won't render, no placeholders the owner would have to fill in themselves.
