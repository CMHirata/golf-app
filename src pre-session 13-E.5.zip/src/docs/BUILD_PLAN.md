# The Card — Master Build Plan

_Last updated: April 2026 — Session 13-E.4 confirmed on device. Next session: **13-E.5 — Shared `PayoutDisplay.jsx`**._
_Maintained in this chat as the authoritative sequence and history of all build sessions._
_The APP_STATE_SUMMARY.md in the project knowledge base is the authoritative record of_
_what is implemented. This file is the authoritative record of what was planned, why,_
_and in what order — including items that shifted, were skipped, reinstated, or renumbered._

---

## Critical Rules for All Future Sessions

1. **Contracts before code.** Any item marked "contract first" below must have a contract
   amendment approved before a single line of implementation code is written.

2. **Session naming is owner-assigned.** Claude must never auto-assign new session
   designations (e.g. creating "11-B" when it doesn't exist in this plan). Sub-tasks within
   a session are labeled as phases (Phase 1, Phase 2). New session rows in APP_STATE_SUMMARY.md
   are only added when the owner explicitly provides the designation.

3. **APP_STATE_SUMMARY.md is not a bug tracker.** Open items live there briefly while
   they wait for closure; once closed, they are removed (not struck through). The
   external spreadsheet is the master bug/feature tracker.

4. **Do not remove an item from ASS Open Items prematurely.** Removal requires
   owner-confirmed on-device closure of the underlying work.

5. **Derived values are never stored.** All derived state is computed from the activeRound blob.

6. **`restoreDotDefs()` is critical.** Must always be called before using dots from any
   serialized state. Was `restoreAutoWhen()` prior to Session 11-A rename.

7. **`betType` is a static config concept only.** It lives in the `GAME_CONFIGS` constant
   and must never be stored in `gameOpts`, `activeRound`, or any persisted state.
   Decision made in 11-G. Do not revisit without owner approval.

8. **Nassau terminology is retired from all user-facing surfaces.** The behavior is exposed
   as Front/Back/Overall segment bet fields. Decision made in 11-G. Do not reintroduce
   "Nassau" as a UI term without explicit owner approval.

---

## Key Architectural Decisions

These decisions should not be revisited without good reason:

1. **Contracts are authoritative over code.** When contract language and implementation
   conflict, contracts win. Code is updated to match.

2. **Write contracts before fixing engines.** The contract defines the spec the engine
   fix must conform to.

3. **Derived values are never stored.** All derived state computed from activeRound blob.

4. **Session naming is owner-assigned.** Claude never invents new session designations.

5. **Generic swipe component** extracted when adding swipe to Players/Courses (15-H),
   not before — avoid premature abstraction.

6. **Dots/Specials shim removal** only after owner confirms all saved rounds have been
   opened and re-exported. Do not rush this.

7. **Per-player tee selection (completed in 11-I.1).** If extended further, treat as
   high-risk and own a full session.

8. **Custom keypad replaces system keyboard (13-B).** `ScoreKeypad.jsx` is the sole
   score entry component throughout the app. The hidden-input / `.focus()` pattern used
   in ZoomModal is retired after 13-B. `'X'` is a valid score value (player picked up);
   it stores as `'X'`, displays as `"NX"` (N = ESC gross), and always loses to any real
   score. Confirmed decision: no system keyboard for score entry post-13-B.

9. **`'X'` score semantics (13-B).** X = player picked up. Gross value = `par + 2 +
   strokes` (full Net, never NOL). Already ESC-capped by definition. "X always loses to
   a real score; X ties X" is the universal invariant across all 7 games.

10. **Early departure via Results gateway (13-C).** There is no "End Round Early" button
    on the scorecard. Departure is declared either via long-press X on the keypad
    (proactive) or via the Results → transition gate (reactive). Contiguous trailing empty
    cells = early departure. Scattered gaps = missing scores (blocked, must enter).

11. **Late arrival: append-only exception to lineup reset (13-D).** Adding a new player
    appended to the end of the lineup, with existing players unchanged, preserves existing
    scores. All other lineup mutations still trigger a full reset (RLC §2.6).

12. **Name display convention:** always show first name (larger/darker) + last name
    (smaller/lighter) unconditionally. No collision detection. `resolveDisplayNames`
    removed from most consumers after this decision.

13. **`PlayerDropdown.jsx`** is the shared component for all player picker UI in New Round
    setup. Do not create parallel picker implementations.

14. **Nassau terminology retired (11-G).** The betting behavior formerly called "Nassau"
    is exposed as Front/Back/Overall segment bet fields. `betType` is a static UI
    dispatch concept in `GAME_CONFIGS` — never stored in round state.

15. **Wolf is the next planned game format.** `GAME_CONFIGS` design in 11-I preserves
    a clean extension point for Wolf's rotating-player and doubling mechanics. Owner has
    confirmed Wolf will not be added until rest of app is considered solid.

16. **NOL dot selector design (11-K).** Unified segmented pill control replaces Net/NOL
    toggle. All segments in a single bordered pill: Net (if mixed round) / NOL / NOL Skins
    / NOL Match A / etc. Games with identical participant sets merged into one button.
    ZoomModal inherits the selection. Center button from setup tab triggers handleStart.

17. **ScoreKeypad nav row removed (13-B).** The ←/✓/→ navigation row was removed from
    `ScoreKeypad` after device testing confirmed it consumed too much screen space. Cell
    advancement is handled entirely by auto-advance timing (700ms for `'1'`, immediate
    for all others). Backspace retreats on second tap on an empty cell. The removed props
    (`onConfirm`, `onNavigate`, `atFirst`, `atLast`) must not be re-added without owner
    approval and a contract amendment.

18. **Round length is stored as `roundStartHole` + `roundNumHoles` — `roundEndHole` is
    always derived (13-C.2).** The UI exposes Start hole + End hole (1-based), converted
    at the form boundary. The scores array is always 18 slots regardless of round length;
    `roundStartHole`/`roundNumHoles` control display and compute scope, not array shape.
    ScoreGrid renders full 9-column Front 9 / Back 9 sections; out-of-round score cells
    are gray and non-interactive. ESC is omitted for partial rounds (GHIN requires 9 or
    18 holes for official posting). `toSetupState` must restore every field that
    `NewRoundPage` reads from `initSrc` — omission causes silent data loss on round
    reload (see App_Data_Model_Contract §9 + invariant #16).

19. **Sequenced-event resolver model (13-C.7 / v2.0).** Every departure is its own
    resolver event, processed in chronological order by `eventOrder` ascending. One
    resolver sheet per departed player, never a combined multi-name sheet. Each event
    consumes carry-forward state from prior events: games already abandoned/ended are
    not re-asked; games where the current departing player was already excluded are not
    shown. Per-game-family options: Match-family (Match/Nassau, Sixes, Nines, Stableford-team)
    gets `abandon` + `end_at_k` only; Pool-family (Skins, Stableford-individual, Stroke
    Play, Dots, Specials) gets all four including universal `continue` and `exclude_player`.
    The v1.x multi-name combined-sheet model is REMOVED. See `PartialGameContract.md`
    §5.4 / §6.1.

20. **Engine departure data guardrail — dual implementation (13-C.7 / v2.1).** Scores
    stored at `scores[h][pi]` for `h > earlyDepartureOpts[pi].departureHole` are ignored
    at compute time by both the engine pipeline AND every display-side aggregator. Engine
    enforcement lives in `payouts.js applyDepartureGuardrail`. Display-side mirror lives
    in `scorecardUtils.js` (`applyDepartureGuardrailToScores`,
    `applyDepartureGuardrailToDotEntries`) and is applied by every game table,
    `TotalsCard`, plus inline copies in `roundUtils.js computePerMatchPayouts` and
    `buildShareHtml`. Both sites must remain in semantic agreement. Adding a new
    score-aggregating component imposes a contract obligation on the author to apply
    the guardrail. See PartialGameContract §11.9 / invariant 21.

21. **Carry-forward source-of-truth (13-C.7 / v2.1).** Carry-forward state for any
    event in a resolver chain MUST be derived from saved
    `activeRound.earlyDepartureOpts` filtered to entries where `eventOrder <
    currentEvent.eventOrder`. The implementation MUST NOT source carry-forward from
    in-memory chain refs (e.g., `confirmedEventsRef`) that are cleared between chains.
    Reasoning: a proactive long-press X chain N writes to `earlyDepartureOpts` and
    clears its in-memory ref; a subsequent reactive Results→ chain N+1 sourcing from
    the in-memory ref would see no carry-forward and re-prompt for games chain N
    already abandoned. See PartialGameContract invariant 24.

22. **Departure metadata round-trip mandate (13-C.7 / v2.1).** Three fields —
    `earlyDepartureOpts`, `earlyEndOpts`, `lastCompletedHole` — MUST round-trip
    faithfully through all four state representations: activeRound (camelCase) ↔
    history record (snake_case: `early_departure_opts`, `early_end_opts`,
    `last_completed_hole`) ↔ setupState (camelCase) ↔ `NewRoundPage.handleStart`
    reconstruction. `roundLib`'s three converters and `handleStart` all participate.
    Without this, navigating Back→Setup→Forward mid-round silently drops all
    locked-cell displays and resolution decisions. See PartialGameContract invariant 23.

23. **Codebase extraction pattern (13-D).** Large files are reduced by extracting
    cohesive logic blocks into purpose-named modules using the `useDepartureResolver.js`
    extraction as the template: zero logic changes, verbatim function bodies, explicit
    hook/module boundary documented in file header. Extractions are pure reorganization —
    no contract amendments required. Each extraction must include a self-check confirming
    all callbacks and return values are wired correctly before delivery.

24. **Scorecard photo parsing uses GPT-4o (13-D).** Claude vision was evaluated and
    found unreliable for dense printed scorecard OCR. GPT-4o parsed the same card
    correctly in one pass. `aiParseScorecard()` in `courseLib.js` will be rewritten to
    call the OpenAI API for the vision step. All other AI calls remain on Anthropic.

25. **Session ordering is recommended, not mandatory.** Sessions within a sprint may be
    tackled out of order when time or context constraints make it practical. The BP
    sequence reflects the preferred dependency order, but owner may deviate.

26. **Dispatcher + Shared file pattern for multi-game UI splits (13-E).** When a single
    file contains both shared sub-components and per-game UI bodies, split it as: one
    `<Name>.jsx` thin dispatcher that imports per-game panels and re-exports shared
    sub-components, one `<Name>Shared.jsx` housing the shared sub-components, and one
    `<Name><Game>.jsx` per game body. Panels import shared sub-components from
    `<Name>Shared.jsx`, never from `<Name>.jsx` (which would create a circular import:
    dispatcher → panel → dispatcher). Dispatcher re-exports from Shared so external
    callers see no API change. Established in 13-E for `GameConfig.jsx` split.
    Architectural Decision #23 (extraction pattern) applies to the per-panel verbatim
    move; this decision adds the multi-file structural rule for sibling UI bodies.

---

## Numbering History & Collision Notes

- **Sessions 1–9** were numbered sequentially as work progressed.
- **Sessions 11-B and 11-C** were auto-created by Claude mid-session during the Dots
  rework, colliding with planned future sessions. Corrected: all three phases collapsed
  into **11-A** in the ASS.
- **11-B** in this plan = Shared GameTable shell (deferred).
- **11-C** in this plan = Match/Nassau team hole display (completed).
- **11-D** in this plan = Fixed-width player name fields + PlayerDropdown (completed,
  scope exceeded plan).
- **11-E** in this plan = Disabled Btn fix + NOL label audit (completed).
- **11-G** was a planning-only session (no code). Downstream sessions renamed
  11-H, 11-I, 11-J, 11-K for cleanliness.
- **11-I split into 11-I.1, 11-I.2, 11-I.3** during execution. 11-I.1 (Players card +
  contracts) shipped on device first; 11-I.2 (game config UI rebuild) followed; 11-I.3
  (semantic field rename: `scoring` → `grossNetNOL`, AND `tiebreak` → `scoring`) was
  added later as a separate atomic rename.
- **11-M.1** is post-11-M follow-on bug fixes (SixesTable `opts`, ReadOnlyScorecard
  handicap dots, etc.) — split from 11-M proper because the bugs surfaced during
  on-device testing of 11-M's main work. Kept as a sub-session for traceability.
- **Sprint 13 restructured (April 2026).** Original 13-A (iCloud export) and 13-C
  (partial round stub) replaced with a focused sprint: 13-A = planning, 13-B = custom
  keypad, 13-C = early departure, 13-D = post-work planning + backlog restructure.
  iCloud export moved to Sprint 15. Sprint 13 is entirely dedicated to score entry,
  partial round lifecycle, and planning.
- **13-B split into 13-B, 13-B.1, 13-B.2.** 13-B = main keypad + X score work;
  13-B.1 = ZoomModal stabilization + pre-13 bug fixes (Bugs A/B/C) caught during
  device testing; 13-B.2 = contract-only correction to ScoreKeypad_Contract.md
  §3.4–§3.8 to match the 13-B.1 final implementation.
- **13-C split into 13-C (planning + contract), 13-C.2, 13-C.3 (with sub-phases 1, 2A,
  2B), then 13-C.4 onward.** The original sequence anticipated 13-C.2 through 13-C.7 as
  builds; the Phase 1 / Phase 2A / Phase 2B sub-numbering inside 13-C.3 emerged because
  the predetermined-game-ranges feature needed contract amendments (Phase 1) → engine +
  plumbing (Phase 2A) → game-table visual range trimming (Phase 2B) and the work spanned
  multiple chats. There is no 13-C.1 — that designation was unused. The 13-C planning
  session also superseded `Early_Departure_Contract.md` (v1.0 DRAFT) and
  `Late_Arrival_Contract.md` (v1.0 DRAFT) in their entirety; both are unified under
  `PartialGameContract.md`.
- **13-C.7 is a single session despite spanning multiple phases.** Mid-session, the v1.x
  multi-name combined-sheet model surfaced as ambiguous on device test. Owner approved a
  major contract amendment (PartialGameContract v1.10 → v2.0) introducing the sequenced-
  event model, per-game-family options, Reorder Departures, and skip-when-current. The
  entire arc — planning, v2.0 amendment, v2.0 build, device-test bug-fix passes, v2.1
  amendment, and code comment cleanup — is logged as a single 13-C.7 row.
- **13-C.bugs** is a named consolidated bug-fix session rather than a numbered sub-session.
  It accumulates bugs discovered after 13-C.8 delivery and is the catch-all for small
  fixes that don't warrant their own session.
- **13-D** is a planning session (no deployable code except the `useDepartureResolver`
  extraction bonus). Full backlog review, priority ranking, and sprint restructure. The
  extraction files (`useDepartureResolver.js`, updated `ScorecardPage.jsx`) are delivered
  but require device confirmation before the session is fully closed.
- **13-E split into 13-E (GameConfig) + 13-E.2 through 13-E.8 (remaining extractions).**
  Original 13-E was scoped narrowly to `GameConfig.jsx`. During the session, an audit
  surfaced six additional extraction candidates of similar scope. Rather than expanding
  13-E's surface, the candidates were sequenced as 13-E.2 through 13-E.8 sub-sessions
  to preserve token discipline (each in its own chat) and to keep test surfaces
  separable. The original 13-E delivers the `GameConfig.jsx` 7-file split and the
  associated game contract amendments; 13-E.2+ are pure code-move sessions with no
  contract amendments expected. Sub-numbering matches the existing pattern from 13-C.
- **Sprint 14 repurposed as Photo Import sprint.** Previous Sprint 14 polish sessions
  (cleanup, birdie/bogey, splash, iCloud) moved to Sprint 15. Sprint 14 is now dedicated
  entirely to scorecard photo import infrastructure.
- **14-E** (Import conflict UX overhaul) was completed out of order during Sprint 13 —
  retained at its original designation for historical accuracy.
- **Sprint 15** is the new home for display polish, UI features, and cleanup work
  previously labeled Sprint 12 / Sprint 14.
- **Sprint 16** is the new game formats sprint (Wolf, High/Low, etc.).

---

## Completed Sessions

| Session | Summary | Items Closed | Status |
|---|---|---|---|
| 1 | Initial scaffold — React/Vite setup, localStorage, basic score grid | — | Confirmed on device |
| 2 | Handicap engine — `scoreForMode`, stroke allocation, ESC | — | Confirmed on device |
| 3 | Skins engine + SkinsTable live display | — | Confirmed on device |
| 4 | Match/Nassau engine + MatchNassauTable | — | Confirmed on device |
| 5 | Stableford + Nines engines + tables | — | Confirmed on device |
| 6 | Sixes engine + SixesTable | — | Confirmed on device |
| 7 | Dots/Specials engine, DotsTable, DotsPopup | — | Confirmed on device |
| 8 | Stroke Play engine + StrokePlayTable | — | Confirmed on device |
| 9 | Payout aggregation, ResultsPage, share sheet | — | Confirmed on device |
| 11-A | Dots rework (auto-mark, mutual exclusivity, team mode), player name display convention | A-1, A-2, A-3 | Confirmed on device |
| 11-C | Match/Nassau team hole display | B-1 | Confirmed on device |
| 11-D | Fixed-width player name fields + PlayerDropdown shared component | A-4, B-2 | Confirmed on device |
| 11-E | Disabled Btn fix + NOL label audit | C-1, C-2 | Confirmed on device |
| 11-F | HistoryPage swipe-delete + RoundSummaryModal | E-1, E-2 | Confirmed on device |
| 11-G | Planning session — betType architecture, Nassau terminology retirement, Wolf extension point | — | Planning only — no device test needed |
| 11-H | NewRoundPage design spec | — | Planning + contract only — no device test needed |
| 11-I.1 | Players card redesign + PlayerDropdown contracts | — | Confirmed on device |
| 11-I.2 | Game config UI rebuild (GameSection, GameConfig, MatchCard, BetPillRow) | A-6, A-7, A-8 | Confirmed on device |
| 11-I.3 | Semantic field rename: `scoring` → `grossNetNOL`, `tiebreak` → `scoring` | — | Confirmed on device |
| 11-J | Course library (courseLib, CourseCard, CourseSearchModal, ManualCourseModal, PhotoImportModal stub) | — | Confirmed on device |
| 11-K | NOL dot selector unified pill design + implementation | C-3, C-4, C-5, C-6 | Confirmed on device |
| 11-L | HomePage leaderboard + active round banner | — | Confirmed on device |
| 11-M | CoursesPage CRUD + CourseMergeModal + course search | — | Confirmed on device |
| 11-M.1 | Post-11-M bug fixes (SixesTable opts, ReadOnlyScorecard handicap dots) | — | Confirmed on device |
| 13-A | Sprint 13 planning — score entry architecture, custom keypad contract | — | Planning + contract only — no device test needed |
| 13-B | Custom keypad (ScoreKeypad.jsx), X score type, ZoomModal wiring | — | Confirmed on device |
| 13-B.1 | ZoomModal stabilization + pre-13 bug fixes (Bugs A/B/C) | Bugs A, B, C | Confirmed on device |
| 13-B.2 | ScoreKeypad_Contract.md §3.4–§3.8 correction to match 13-B.1 implementation | — | Contract only — no device test needed |
| 13-C | Early departure planning + PartialGameContract v1.0 | — | Planning + contract only — no device test needed |
| 13-C.2 | Round length (start/end hole), ScoreGrid gray cells, TotalsCard round-scoped | — | Confirmed on device |
| 13-C.3 | Predetermined game ranges (gameRanges), range-aware engine calls, game table trimming (Phase 1 + 2A + 2B) | D-1, D-2 (partial), D-3, D-4 | Confirmed on device |
| 13-C.4 | Mid-round game start (late arrival) — deferred after game-by-game analysis confirmed use case too rare to justify cost | — | Planning only — no device test needed |
| 13-C.5 | Early departure proactive entry (long-press X), DepartureResolverSheet v1.0, resolver spec | D-1, D-3, D-5 (initial) | Confirmed on device |
| 13-C.6 | Early departure display polish + MatchNassauTable Total format, undo gesture, PartialGameContract v1.10 | — | Confirmed on device |
| 13-C.7 | Early departure reactive entry + v2.0 sequenced-event model + full v2.0 build + v2.1 contract amendment. Long arc: planning → v2.0 amendment → build → device-test bug-fix passes → v2.1 amendment → code comment cleanup. Five contracts amended. | D-1, D-3, D-5 (re-closed under v2.0); G-1, G-2, G-3, G-4 | Confirmed on device |
| 13-C.8 | Engine departure handling — `payouts.js` full rewrite driving payout computation from `earlyDepartureOpts`/`earlyEndOpts`. Match per-instance breakdown (Option A). Sixes columnar breakdown. Team Dots parent-lock in resolver. Three contracts amended (Payout_Contract v1.13, Resolver_UI_Spec v1.3, App_Data_Model_Contract v3.6). | — | Confirmed on device |
| 14-E | Import conflict UX overhaul + id-less record fix. Completed out of sequence during Sprint 13. | — | Confirmed on device |
| 13-D | Post-work planning session. Full file inventory + line-count audit. `ScorecardPage.jsx` diagnosed (999 lines; departure resolver chain cause). `useDepartureResolver.js` hook extracted as bonus deliverable — `ScorecardPage` drops from 999 → 584 lines. Full backlog review + priority ranking. GPT-4o evaluated as superior to Claude vision for scorecard photo OCR. Chambers Bay course JSON exported. Full sprint restructure (Sprints 14–16 repurposed). BUILD_PLAN and APP_STATE_SUMMARY updated per closing template. | — | Confirmed on device |
| 13-C.bugs | Consolidated bug-fix session. Bug 1: `MatchNassauTable` Total-format mis-split fixed — non-Nassau matches now use canonical hole-9 boundary for portrait split instead of midpoint derivation; full 9-column half-tables with out-of-range cells rendered in muted green tint matching table palette. Bug 2 (keypad scroll-jump): diagnosed as `onClick`-only pattern on digit buttons — deferred to 13-F with full findings documented in BP. Bug 3 (course handicap reset on back/forth nav): could not be reproduced on device; original code determined correct; fix reverted. | — | Confirmed on device |
| 13-E | `GameConfig.jsx` (1,292 lines) split into 7-file dispatcher + Shared pattern: `GameConfig.jsx` (~298 lines, dispatcher + re-exports), `GameConfigShared.jsx` (~359 lines: `BetSection`, `PlayerSubsetDropdown`, `GameRangePill`, `GameRangePopup`, `validateGameRange`, `PRESS_OPTS`), and six per-game panel files (`GameConfigStrokePlay`, `GameConfigSkins`, `GameConfigStableford`, `GameConfigNines`, `GameConfigSixes`, `GameConfigDots`). Circular import resolved via `GameConfigShared` — panels import from Shared, dispatcher imports panels and re-exports from Shared. `NewRoundPage` and `MatchCard` need zero import changes. Architectural pattern (dispatcher + Shared) added as Decision #26. Game contract setup-UI sections amended (Dots v2.5, Nines v1.6, Stableford v1.7, Sixes v1.11). NewRoundPage_Design_Spec Wolf extension point updated to reference the new panel-file convention. Skins display regression surfaced during testing — folded into 13-E.4 scope (likely pre-existing). | — | Confirmed on device |
| 13-E.2 | `App.jsx` slim-down (530 → 321 lines). Four extractions per Architectural Decision #23: `components/NavIcons.jsx` (five SVG icons + `SIDE_TABS` + `CENTER_FLOW_TABS`), `components/BottomNav.jsx` (bottom-nav `<nav>` block as a component receiving `tab`/`setTab`/`inProgress`/`centerActive`/`onCenterTap`/`navBarHeight`), `services/exportUtils.js` (`makeExportFilename` + `triggerExport`), `hooks/useIsLandscape.js` (deduped from App.jsx + `RoundSummaryModal.jsx`). H-4 preserved (ScorecardPage continues computing its own); H-11 preserved (App.jsx `handleCenterTap` still owns the `startTriggerRef` call; BottomNav delegates to the `onCenterTap` prop). RoundSummaryModal: surgical str_replace swapping local `useIsLandscape` for the shared import. `G` token import dropped from App.jsx (no longer used after `<nav>` extraction). New top-level `src/hooks/` directory established for cross-cutting hooks. | — | Confirmed on device |
| 13-E.3 | `HistoryPage.jsx` slim-down (736 → 482 lines). Two extractions per Architectural Decision #23: `pages/history/SwipeableRoundRow.jsx` (~243 lines — swipe row component, strip color constants `STRIP_SHARE`/`STRIP_EDIT`/`STRIP_DELETE`, and `REVEAL_W` constant) and `pages/history/HistoryIcons.jsx` (~70 lines — five named SVG icon exports). New `src/pages/history/` subdirectory established. H-1 swipe behavior (zero-setState-during-gesture, direct DOM transform updates) preserved verbatim per Architectural Decision #5 — generic swipe component deferred to 15-H when Players/Courses adopt swipe and there are two real call sites. In-flight discovery: the original `IconDownload` and `IconUpload` glyphs were reversed (download arrow on the Export button, upload arrow on the Import button) — replaced with circle-up / circle-down glyphs that read cleanly at the 14px button size. Component names retained so `HistoryPage.jsx` imports were not affected. Pre-existing dead import flagged for 15-F: `Btn` is imported from `ui.jsx` in `HistoryPage.jsx` but never referenced in the body (predates this session; left as-is per verbatim-move discipline). | — | Confirmed on device |
| 13-E.4 | `ScoreGrid.jsx` depart-prompt extraction + Skins empty-state regression fix + resolver header copy edge case. (1) Extracted inline depart-prompt JSX (~63 lines) from `ScoreGrid.jsx` into new `pages/scorecard/DepartPromptModal.jsx` — pure render given 4 props (`playerName`, `holeNumber`, `onCancel`, `onConfirm`); state (`departPrompt`) and both handlers remain in `ScoreGrid`. (2) Fixed Skins-only display regression: removed `if (!rows.length) return null` gate from `SkinsTable.jsx` so the `GameSection` header skeleton renders from round start, matching Stableford / Nines / Sixes empty-state pattern. H-28 guardrail (`applyDepartureGuardrailToScores`) unaffected. (3) Out-of-scope fix at owner direction: `DepartureResolverSheet` header copy produced "Chris left after hole 0" on long-press X on hole 1. Added optional `roundStartHole` prop (default `0`) to `DepartureResolverSheet`; threaded from `ScorecardPage`; when `departureHole < roundStartHole` header reads "left before hole [roundStartHole + 1]" — covers first hole of any range (full or partial round). `PartialGameContract.md` → v2.2, `Resolver_UI_Spec.md` → v1.4. | — | Confirmed on device |

---

## Open Session Plan

> **Next session: 13-E.5 — Shared `PayoutDisplay.jsx`.** Sprint 13 remaining: 13-E.x sub-session series (E.5 through E.8 — pure code moves and dedupe extractions, no contract amendments expected) and 13-F (keypad fixes). Sprint 14 = photo import. Sprint 15 = display polish + features. Sprint 16 = new game formats. Session ordering within 13-E.x is recommended, not mandatory.

---

### Sprint 13 — Remaining

_Sessions 13-E.2, 13-E.3, 13-E.4 complete and confirmed on device — see Completed Sessions table above. Next session: **13-E.5**._

**13-E.x sub-session series** *(pure code moves; no contract amendments expected)*

The 13-E split surfaced multiple additional extraction candidates. The original 13-E session was scoped narrowly to `GameConfig.jsx` only. The remaining extractions are sequenced as 13-E.2 through 13-E.8; 13-E.2 (App.jsx slim-down) is now complete and confirmed on device. Each remaining session runs in its own chat window with a dedicated `Session_13E_X_Intro.md` produced in the meta-planning chat. Order is recommended — Phase 1 items are pure code moves with zero behavioral risk; Phase 2 dedupes across two files; Phase 3 tackles the largest files; Phase 4 is the touchier remaining extraction.

**Phase 2 — dedupe across files (eliminates parallel implementations):**

- **13-E.5: Shared `PayoutDisplay.jsx`.** Extract `DotsColTable`, `SubHeader`, `PayRow`, `splitGameHeader`, `fmtMoney`, plus a `PayoutsSection` component receiving `{ breakdown, bank, matchPayouts }`. Both `RoundSummaryModal.jsx` and `ResultsPage.jsx` consume it — currently duplicated verbatim across both files. Saves ~150 lines of duplication; locks payout display to one source of truth. **Owner-required: Phase 1 side-by-side diff before any extraction.** Risk: moderate.

**Phase 3 — big files:**

- **13-E.6: `roundUtils.js` → `shareUtils.js`.** Extract `buildShareHtml`, `buildSharePdf`, `buildShareImage`, `triggerRoundShare`, plus share-only helpers (`fmtMoney`, `fmtDate`, `xe`, `deriveShareDotMode`, the logo loader). roundUtils.js: 1394 → ~614. Risk: low (clean import boundary, single consumer in App.jsx via `triggerRoundShare`). The inline `applyDepartureGuardrail` copy in `buildShareHtml` (per H-28 / PartialGameContract §11.9) moves with it intact.
- **13-E.7: `NewRoundPage.jsx` → 3 cards.** Extract `CourseCard.jsx` (~190 lines), `PlayersCard.jsx` (~110 lines), `GamesCard.jsx` (~230 lines). NewRoundPage: 1414 → ~700. State ownership does not move; mutation discipline preserved. Risk: moderate-high — biggest prop surface, biggest test surface (entire setup flow, every game tile, reload from history).

**Phase 4 — touchier:**

- **13-E.8: `RoundSummaryModal` → `ReadOnlyScorecard.jsx`.** Extract the read-only scorecard component (~240 lines) into its own file. RoundSummaryModal: ~600 lines (down from 839, net of 13-E.2 hook dedup, 13-E.5 PayoutDisplay dedup, and this session). Should follow 13-E.5 (so PayoutDisplay is already shared). Risk: moderate.

No contract amendments are expected for any 13-E.x session unless an audit surfaces a divergence between two parallel implementations (most likely in 13-E.5). If a contract change is needed, the relevant session intro instructs the AI to stop and flag.

**13-F: Keypad Fixes + Input Polish** *(deferred until 13-E.x complete; touches NewRoundPage after E.7 cleans it)*
- Custom keypad not wired to setup inputs (bet amounts, handicap fields) — iOS system
  keyboard appears instead. All setup numeric fields should use the custom keypad.
- No decimal point on custom keypad — cannot enter cents on bets. Replace X key
  contextually with "." when in a currency input context.
- No "+" on custom keypad — cannot enter plus handicaps. Replace X key contextually
  with "+" when in a handicap input context.
- **Keypad scroll-jump + responsiveness fix (13-C.bugs findings):** Root cause confirmed —
  digit and backspace buttons use `onClick` only. On iOS Safari, `onClick` fires ~300ms
  after touch and allows the browser to interpret near-border taps as scroll gestures.
  The X button already uses `onTouchStart`/`onTouchEnd` + `preventDefault` correctly.
  Fix: apply the same `onTouchEnd` + `preventDefault` pattern to all digit (0–9) and
  backspace (⌫) buttons in `ScoreKeypad.jsx`. This also closes the responsiveness gap
  vs. the iOS system keyboard — target feel is identical to native. Score cell `onTouchEnd`
  already has `preventDefault`; the keypad buttons are the remaining gap.
- **ScoreGrid `renderHalf` / `renderLandscape` / keypad subsystem extraction** (deferred
  from 13-E series). The two render functions form a coherent block but their closure
  list is large (13+ props would have to thread through). Defer until active regressions
  (NOL scoring bug, Sixes results card, specials auto-recording) are resolved — too much
  surface area to reorganize under active bugs. Likely becomes its own multi-session
  sprint.
- Files: `ScoreKeypad.jsx`, `NewRoundPage.jsx`, `ScoreGrid.jsx`
- Priority: High

---

### Sprint 14 — Scorecard Photo Import

_Sprint 14 is dedicated entirely to course photo import infrastructure._

**14-A: Parse Engine Swap — GPT-4o** *(contract-first lite: spec the review screen before coding)*
- Rewrite `aiParseScorecard()` in `courseLib.js` to call OpenAI GPT-4o vision API
  instead of Anthropic. GPT-4o evaluated in Session 13-D and found materially superior
  for dense printed scorecard OCR (Sahalee card: GPT-4o 100% correct in one pass;
  Claude required two passes with systematic errors on tee ratings and handicap values).
- Wire OpenAI API key (client-side for personal-use PWA; document key storage approach).
- `aiSearchCourses()` remains on Anthropic — text-only, no vision, Claude adequate.
- Files: `courseLib.js`
- Priority: High
- Requires: OpenAI API key decision (Option A: hardcode in bundle for personal PWA)

**14-B: Review / Correction Grid** *(after 14-A)*
- Build `CourseImportReviewModal.jsx` — editable per-hole grid (par, handicap, yardage
  per hole) displayed between parse result and save. Uncertain values flagged in amber.
  "Enter manually instead" escape hatch opens `ManualCourseModal` pre-populated with
  parsed values.
- Prompt engineering: add per-field confidence flags to the GPT-4o prompt so uncertain
  values are surfaced rather than silently guessed.
- Files: new `CourseImportReviewModal.jsx`, `courseLib.js` (prompt amendment),
  `PhotoImportModal.jsx` (wire review step)
- Priority: High

**14-C: Photo Guidance + UI Polish** *(fold into 14-B if session capacity allows)*
- Add photo guidance tips in `PhotoImportModal`: "lay flat, shoot straight down, one
  nine per photo for 3-nine cards."
- Review photo slot labels and instruction copy for clarity.
- Files: `PhotoImportModal.jsx`
- Priority: Medium

---

### Sprint 15 — Display Polish + Features

_Sessions within Sprint 15 may be tackled in any order._

**15-A: Display Polish — Summary, History, Modals**
- Move player name tiles out of header on round summaries (`RoundSummaryModal.jsx`).
- Remove Match/Nassau label from history tiles (`HistoryPage.jsx`).
- Remove front/back label from summary/report headers; smart line-break on long course
  names at " - " (remove the dash in the process) — e.g. "PGA West - Nicklaus
  Tournament Course" breaks cleanly.
- Replace all remaining `window.confirm` / `window.alert` system dialogs with custom
  styled modals throughout the app (Discard round and any other remaining OS prompts).
- Files: `RoundSummaryModal.jsx`, `HistoryPage.jsx`, `roundUtils.js`, `ScorecardPage.jsx`
- Priority: Medium

**15-B: Game Table Display Consistency Pass**
- Audit all game tile chip/total labels across all games (e.g. "pts", "$") — decide
  once whether labels appear, apply uniformly.
- Audit player name chip display consistency across all game tables.
- D-2: "pts" label on Nines total chips (original item, now part of broader audit).
- Files: `NinesTable.jsx`, `SkinsTable.jsx`, `StablefordTable.jsx`, `SixesTable.jsx`,
  `MatchNassauTable.jsx`, `StrokePlayTable.jsx`, `DotsTable.jsx`, `ScoreGrid.jsx`
- Priority: Medium

**15-C: Results Page Refinement**
- General results page layout and presentation refinement pass.
- Files: `ResultsPage.jsx`
- Priority: Medium

**15-D: Save Game Settings as Defaults**
- A-5: Pre-fill NewRoundPage game config with last round's settings.
- Files: `NewRoundPage.jsx`, `roundLib.js`
- Priority: Medium

**15-E: Players / Courses Enhancements**
- G-1: Starred/favorite players float to top of player list and all pickers.
- G-2: Include/exclude players from leaderboard — filter one-off players off home
  screen money list.
- Swipe-left Edit/Delete on Players and Courses pages, matching HistoryPage pattern.
  Extract generic swipe component at same time (avoid third copy of HistoryPage logic).
- Files: `PlayersPage.jsx`, `CoursesPage.jsx`, `HomePage.jsx` + new generic swipe component
- Priority: Low (G-1, G-2), Low (swipe)

**15-F: Cleanup Pass**
- F-5: Remove legacy shims (confirm all saved rounds migrated before removing).
- F-6: Hint text review and cleanup.
- I-5: Delete dead `hooks.js`.
- H-1: Sahalee hole numbering 1–9 per nine + yardage total fix.
- History date range persistence across sessions.
- ScoreGrid legacy keyboard dead code cleanup (~60 lines: `advanceRef`, `handleKeyDown`,
  `handleScore`, `scheduleAdvance`, `cancelAdvance`, `pendingAdvance`).
- Dots auto-mark loop bounds fix (iterate `roundStartHole..roundEndHole`, not `0..17`).
- Files: misc
- Priority: Low

**15-G: Advanced Scorecard Options** *(contract first)*
- C-7: Birdie/bogey indicators — visual indicators (circle/square) on score cells.
  Amend `UI_Component_Contract.md`.
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`
- Priority: Low

**15-H: Verify iCloud Export Naming**
- I-2: Confirm save-to-Files flow on iOS Safari behaves correctly with current naming
  convention (`The Card YYYY-MM-DD HH-MM.json`). Verification only; may require minor
  filename fix.
- In-app splash screen on cold load (~1.5s, logo on green).
- Files: `App.jsx`
- Priority: Low

---

### Sprint 16 — New Game Formats

_Each format requires its own contract session before any code._
_Wolf will not be added until the rest of the app is considered solid by the owner._

1. **Wolf** — rotating Wolf player; highest priority next format. `GAME_CONFIGS` in
   11-I preserves extension point for Wolf's doubling mechanic. `GameConfigWolf.jsx`
   extension point reserved in 13-E `GameConfig` split.
2. **High/Low** — low ball + high ball per hole.
3. **Banker (Quota)**, **Scotch/Greensomes**, **Chapman/Pinehurst**.
4. **Bingo Bango Bongo**, **Vegas**, **Round Robin**, **Snake**, **Rabbit/Flags/String** — deferred.
5. **Uneven team matches (1v2)** — deferred.

---

## Items Requiring Contract Work

| Item | Contract | Notes |
|---|---|---|
| 15-G: Birdie/bogey indicators | `UI_Component_Contract.md` | Amend before ScoreGrid changes |
| Sprint 16: Wolf | New `Wolf_Contract.md` | Full contract session before any code |
| Sprint 16: High/Low | New `HighLow_Contract.md` | Full contract session before any code |
| Sprint 16: other formats | New contracts per format | Full contract session each |

---

## Decision Log

### Pending Decisions

| Decision | Context | Options | Notes |
|---|---|---|---|
| OpenAI API key storage method for photo import | Sprint 14 — `aiParseScorecard()` needs auth | A: Hardcode in bundle (simple, key exposed in JS); B: Prompt at runtime, store in localStorage; C: Proxy via tiny backend | Option A recommended for personal-use PWA. Decide before 14-A. |

### Confirmed Decisions

| Decision | Session | Notes |
|---|---|---|
| Contracts are authoritative over code | 11-G | When contract and implementation conflict, contract wins |
| `betType` never stored in round state | 11-G | Static UI dispatch concept in `GAME_CONFIGS` only |
| Nassau terminology retired from UI | 11-G | Exposed as Front/Back/Overall segment bet fields |
| Wolf deferred until app is solid | 11-G | Extension point preserved in `GAME_CONFIGS` |
| Per-player tee selection | 11-I.1 | Completed; treat any extension as high-risk |
| `scoring` → `grossNetNOL` rename | 11-I.3 | Semantic field rename; all contracts updated |
| ScoreKeypad nav row removed | 13-B | Device testing confirmed too much screen space |
| Auto-advance timing: 700ms for `'1'`, immediate for others | 13-B | Cell advancement post-nav-row removal |
| `'X'` score semantics | 13-B | X = picked up; gross = par+2+strokes; always loses to real score |
| Round length stored as `roundStartHole` + `roundNumHoles` | 13-C.2 | `roundEndHole` always derived |
| Early departure via Results gateway only | 13-C | No "End Round Early" button on scorecard |
| Sequenced-event resolver model (v2.0) | 13-C.7 | One sheet per player, never combined; v1.x model REMOVED |
| Match/Nassau breakdown per-instance (Option A) | 13-C.8 | Each match emits its own columnar row; combined header retired |
| GPT-4o for scorecard photo OCR | 13-D | Claude vision unreliable on dense printed cards; GPT-4o 100% correct in one pass on Sahalee card |
| Codebase extraction before feature work | 13-D | 13-E refactor pass immediately after 13-C.bugs, before Sprint 14+ |
| Sprint 14 repurposed as Photo Import sprint | 13-D | Previous Sprint 14 polish content moved to Sprint 15 |
| Keypad scroll-jump root cause identified | 13-C.bugs | `onClick`-only pattern on digit buttons causes ~300ms iOS latency and scroll-gesture misfire on border taps. Fix: replace `onClick` with `onTouchStart`/`onTouchEnd` + `preventDefault` on all digit and backspace buttons, matching the pattern already used on score cells and the X button. Target feel: identical to iOS system keyboard (immediate response, no scroll). Deferred to 13-F. |
| Dispatcher + Shared file pattern for multi-game UI splits | 13-E | Established as the canonical pattern for splitting files containing both shared sub-components and per-game UI bodies. See Decision #26. |
| 13-E remaining extractions sequenced as 13-E.2 through 13-E.8 sub-sessions | 13-E | Six additional extraction candidates surfaced during 13-E audit. Owner directed each be its own chat session rather than expanding 13-E's surface, to preserve token discipline and keep test surfaces separable. |

---

## Deferred / Deprioritized

| Item | Priority | Reason deferred |
|---|---|---|
| 11-B: Shared GameTable shell | Low | Pattern already working; documentation value only |
| Dark mode | Deferred | Token structure ready in `ui.jsx`; low demand |
| Undo delete toast | Deferred | Low impact |
| Match scorecard rows collapse by default | Deferred | Low priority |
| CoursesPage GHIN/USGA API import | Deferred | External dependency; low priority |
| Scorecard gear icon options menu | Deferred | Design decision still open |
| Press modal live match status display | Deferred | Low priority UX enhancement |
| `buildShareImage` range-awareness | Deferred | Owner directed — revisit alongside 15-H |
| Mid-round Round Summary access gating | Deferred | Owner directed — revisit when partial-round UX fully complete |
| "Overall" → "Total" full internal rename | Deferred | Risky rename, low user impact; requires migration shim |
| Pinch-zoom with snap-back on scorecard | Deferred | Unusual UX pattern; risk of breaking touch handling in ScoreGrid |
| Sponsor/staking mechanic for non-betting player | Deferred | Contract-first; non-trivial engine work; narrow use case |
| Lock/pin scorecard toggle | Deferred | Contract-first; revisit when scorecard UX is fully stable |
| API key / Face ID security gate | Deferred | Personal-use PWA; not worth complexity for current distribution |
| Replace PNG logos with SVG | Deferred | When designer provides SVG files |
| Handicap multiplier | Deferred | Contract-first (Handicap_Contract.md); revisit when demand clear |
| D-15: Team Dots → Individual Dots after parent ends | Deferred | Complex; wait for real demand |
| Multi-instance for non-Match games | Deferred | Major scope; no current need |
| Wrap-around rounds | Deferred indefinitely | Rare use case; major cross-layer complexity |
| 13-C.4 Mid-Round Game Start (late arrival) | Deferred | Owner confirmed use case too rare to justify cost |
| Bingo Bango Bongo, Vegas, Round Robin, Snake, Rabbit/Flags/String | Deferred | Lower priority game formats |
| Uneven team matches (1v2) | Deferred | Structural complexity; wait for demand |
| MatchNassauTable column headers for non-zero-start matches | Deferred | Polish — post-13-E |
| "Computed over holes 1–k" notes in game table footers | Deferred | Polish — post-13-E |
| Game range indicator in game table headers | Deferred | Polish — post-13-E |
| Stroke Play §14 G-2 `effMin` not received from `subsetMin()` | Deferred | Architectural inconsistency only; results correct |
