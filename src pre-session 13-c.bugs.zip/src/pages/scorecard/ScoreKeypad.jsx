// ─── scorecard/ScoreKeypad.jsx ────────────────────────────────────────────────
// Custom in-app numeric keypad — fixed overlay at very bottom of screen.
// Covers the nav bar (zIndex 300 > nav bar zIndex 50).
// Appears when a score cell is active; dismisses on outside tap.
// 4 rows: 1-2-3 / 4-5-6 / 7-8-9 / ⌫-0-X
//
// Props:
//   containerRef  {ref}      — attached to outer div so parent can detect inside-taps
//   visible       {bool}     — show/hide the keypad
//   value         {string}   — current in-progress value: '' | digit string | 'X'
//   onChange      {func}     — (newVal: string) => void
//   onBackspace   {func}     — () => void — remove last char or retreat if empty
//   onLongPressX  {func}     optional — long press X handler

import { useRef, useCallback, useEffect, useState } from 'react';
import { AMB, RED } from '../../components/ui.jsx';

const LONG_PRESS_MS   = 600;
const LONG_PRESS_WARN = 300;
const ROW_H           = 56;
const GAP             = 3;

export function ScoreKeypad({
  containerRef, visible, value, onChange, onBackspace,
  onLongPressX,
}) {
  const [xWarning, setXWarning] = useState(false);
  const longPressTimer = useRef(null);
  const warnTimer      = useRef(null);
  const longPressFired = useRef(false);
  const xMouseTimer    = useRef(null);
  const xMouseFired    = useRef(false);

  const clearLongPress = useCallback(() => {
    if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
    if (warnTimer.current)      { clearTimeout(warnTimer.current);      warnTimer.current = null; }
    setXWarning(false);
  }, []);

  useEffect(() => () => clearLongPress(), [clearLongPress]);

  const handleDigit = useCallback((d) => {
    let next;
    if (value === 'X')          next = d;
    else if (value.length >= 2) next = d;
    else                        next = value + d;
    onChange(next);
  }, [value, onChange]);

  const handleBackspace = useCallback(() => {
    onBackspace();
  }, [onBackspace]);

  const handleXTap = useCallback(() => {
    onChange('X');
  }, [onChange]);

  // Touch long-press for X
  const handleXTouchStart = useCallback(() => {
    longPressFired.current = false;
    if (!onLongPressX) return;
    warnTimer.current = setTimeout(() => setXWarning(true), LONG_PRESS_WARN);
    longPressTimer.current = setTimeout(() => {
      longPressFired.current = true;
      clearLongPress();
      onLongPressX();
    }, LONG_PRESS_MS);
  }, [onLongPressX, clearLongPress]);

  const handleXTouchEnd = useCallback((e) => {
    e.preventDefault();
    const fired = longPressFired.current;
    clearLongPress();
    if (!fired) handleXTap();
  }, [clearLongPress, handleXTap]);

  // Mouse long-press for X (desktop / dev)
  const handleXMouseDown = useCallback(() => {
    xMouseFired.current = false;
    if (!onLongPressX) return;
    warnTimer.current = setTimeout(() => setXWarning(true), LONG_PRESS_WARN);
    xMouseTimer.current = setTimeout(() => {
      xMouseFired.current = true;
      if (xMouseTimer.current) { clearTimeout(xMouseTimer.current); xMouseTimer.current = null; }
      clearLongPress();
      onLongPressX();
    }, LONG_PRESS_MS);
  }, [onLongPressX, clearLongPress]);

  const handleXMouseUp = useCallback(() => {
    if (xMouseTimer.current) { clearTimeout(xMouseTimer.current); xMouseTimer.current = null; }
    clearLongPress();
  }, [clearLongPress]);

  const handleXClick = useCallback(() => {
    if (xMouseFired.current) { xMouseFired.current = false; return; }
    handleXTap();
  }, [handleXTap]);

  if (!visible) return null;

  const xBg = xWarning ? RED : AMB;

  const btn = (label, handler, bg, color, extra = {}) => (
    <button
      key={label}
      onClick={handler}
      style={{
        flex: 1, height: ROW_H,
        border: 'none', borderRadius: 6,
        fontSize: 18, fontWeight: 700, fontFamily: 'inherit',
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        userSelect: 'none', WebkitUserSelect: 'none',
        WebkitTapHighlightColor: 'transparent',
        background: bg, color,
        ...extra,
      }}
    >{label}</button>
  );

  const row = (children) => (
    <div style={{ display: 'flex', gap: GAP }}>{children}</div>
  );

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        left: 0, right: 0, bottom: 0,
        zIndex: 300,
        background: '#e0e0e0',
        borderTop: '1px solid #bbb',
        paddingTop: GAP,
        paddingLeft: GAP,
        paddingRight: GAP,
        paddingBottom: `calc(${GAP}px + env(safe-area-inset-bottom))`,
        display: 'flex',
        flexDirection: 'column',
        gap: GAP,
      }}
    >
      {row(<>
        {btn('1', () => handleDigit('1'), '#fff', '#222')}
        {btn('2', () => handleDigit('2'), '#fff', '#222')}
        {btn('3', () => handleDigit('3'), '#fff', '#222')}
      </>)}
      {row(<>
        {btn('4', () => handleDigit('4'), '#fff', '#222')}
        {btn('5', () => handleDigit('5'), '#fff', '#222')}
        {btn('6', () => handleDigit('6'), '#fff', '#222')}
      </>)}
      {row(<>
        {btn('7', () => handleDigit('7'), '#fff', '#222')}
        {btn('8', () => handleDigit('8'), '#fff', '#222')}
        {btn('9', () => handleDigit('9'), '#fff', '#222')}
      </>)}
      {row(<>
        {btn('⌫', handleBackspace, '#c8c8c8', '#444', { fontSize: 22 })}
        {btn('0', () => handleDigit('0'), '#fff', '#222')}
        <button
          style={{
            flex: 1, height: ROW_H,
            border: 'none', borderRadius: 6,
            fontSize: 18, fontWeight: 700, fontFamily: 'inherit',
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            userSelect: 'none', WebkitUserSelect: 'none',
            WebkitTapHighlightColor: 'transparent',
            background: xBg, color: '#fff',
          }}
          onTouchStart={handleXTouchStart}
          onTouchEnd={handleXTouchEnd}
          onTouchCancel={clearLongPress}
          onMouseDown={handleXMouseDown}
          onMouseUp={handleXMouseUp}
          onClick={handleXClick}
        >X</button>
      </>)}
    </div>
  );
}
