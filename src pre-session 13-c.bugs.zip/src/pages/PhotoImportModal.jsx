// ─── PhotoImportModal.jsx ──────────────────────────────────────────────────────
// Pure render component — no logic, no state mutations beyond local form state.
// Allows the user to photograph up to three scorecard panels and have the AI
// parse tees, ratings, slopes, yardages, pars, and stroke indices from them.
// On success calls onImport(courseData); on cancel calls onClose().

import { useState } from 'react';
import { Btn, Inp, G, GA, AMB, AMBBG, RED } from '../components/ui.jsx';
import { aiParseScorecard } from '../services/courseLib.js';

export default function PhotoImportModal({ onImport, onClose }) {
  const [photo1, setPhoto1] = useState(null);
  const [photo2, setPhoto2] = useState(null);
  const [photo3, setPhoto3] = useState(null);
  const [parsed, setParsed]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState('');
  const [missing, setMissing] = useState([]);
  const [manFill, setManFill] = useState({});

  const readFile = file => new Promise((res, rej) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const b64 = dataUrl.split(',')[1];
      const mediaType = ['image/jpeg','image/png','image/gif','image/webp'].includes(file.type) ? file.type : 'image/jpeg';
      res({ b64, mediaType, thumb: dataUrl });
    };
    reader.onerror = rej;
    reader.readAsDataURL(file);
  });

  const handleFile = async (file, slot) => {
    if (!file) return;
    try {
      const photo = await readFile(file);
      if      (slot === 1) { setPhoto1(photo); setParsed(null); setErr(''); }
      else if (slot === 2) { setPhoto2(photo); setParsed(null); setErr(''); }
      else                 { setPhoto3(photo); setParsed(null); setErr(''); }
    } catch(e) { setErr('Could not read image file.'); }
  };

  const analyse = async () => {
    if (!photo1) return;
    setLoading(true); setErr(''); setParsed(null);
    try {
      const photos = [photo1, photo2, photo3].filter(Boolean);
      const d = await aiParseScorecard(photos);
      setParsed(d);
      const miss = [];
      if (!d.tees?.some(t => t.rating)) miss.push('men\'s rating');
      if (!d.tees?.some(t => t.slope))  miss.push('men\'s slope');
      setMissing(miss);
    } catch(e) { setErr(`Could not read scorecard: ${e.message}`); }
    setLoading(false);
  };

  const finish = () => {
    const c = JSON.parse(JSON.stringify(parsed || { courseName: 'Imported', nines: [], tees: [{ name: "Men's" }] }));
    if (!c.tees?.length) c.tees = [{ name: "Men's" }];
    if (manFill.rating) c.tees[0].rating = parseFloat(manFill.rating);
    if (manFill.slope)  c.tees[0].slope  = parseInt(manFill.slope);
    onImport({ name: c.courseName, location: c.location || '', nines: c.nines || [], tees: c.tees || [] });
  };

  const slotStyle = filled => ({
    display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
    gap:4, padding:8, borderRadius:10, cursor:'pointer', fontSize:12, fontWeight:600,
    border:`1.5px solid ${filled ? G : '#ddd'}`, background: filled ? GA : '#fafafa',
    color: filled ? G : '#888', minHeight:80, position:'relative', overflow:'hidden',
  });

  const totalPhotos = [photo1, photo2, photo3].filter(Boolean).length;

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.55)', zIndex:300, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }} onClick={onClose}>
      <div style={{ background:'#fff', borderRadius:20, padding:22, width:'100%', maxWidth:460, maxHeight:'92vh', overflowY:'auto' }} onClick={e=>e.stopPropagation()}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
          <div>
            <div style={{ fontWeight:800, fontSize:17, color:G }}>Scan Scorecard</div>
            <div style={{ fontSize:11, color:'#888' }}>AI reads all tees, ratings, slopes, yardages & handicaps</div>
          </div>
          <button onClick={onClose} style={{ border:'none', background:'none', fontSize:24, cursor:'pointer', color:'#aaa' }}>×</button>
        </div>
        <div style={{ background:AMBBG, color:AMB, borderRadius:8, padding:'8px 11px', fontSize:12, marginBottom:14 }}>
          💡 Capture all scorecard panels — tee/rating side, par/handicap side, and women's tee data if on a separate panel.
        </div>
        {err && <div style={{ background:'#fce8e8', color:RED, borderRadius:8, padding:'9px 12px', fontSize:13, marginBottom:10 }}>{err}</div>}
        {loading ? (
          <div style={{ textAlign:'center', padding:32 }}>
            <div style={{ color:'#888', fontSize:14, marginTop:8, fontWeight:600 }}>Reading scorecard…</div>
            <div style={{ color:'#aaa', fontSize:12, marginTop:4 }}>Extracting all tees, ratings, yardages &amp; handicaps (15–30s)</div>
          </div>
        ) : (
          <div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:14 }}>
              {[1,2,3].map(slot => {
                const photo = slot===1 ? photo1 : slot===2 ? photo2 : photo3;
                const labels = ['Tees/Ratings','Pars/Handicaps','Women\'s / Extra'];
                return (
                  <div key={slot}>
                    <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4, textAlign:'center' }}>
                      {labels[slot-1]} {slot===1 && <span style={{color:RED}}>*</span>}
                    </div>
                    <label style={slotStyle(!!photo)}>
                      {photo
                        ? <img src={photo.thumb} alt={`Side ${slot}`} style={{ width:'100%', height:72, objectFit:'cover', borderRadius:6 }}/>
                        : <><span style={{ fontSize:20 }}>📄</span><span>Tap to add</span></>
                      }
                      <input type="file" accept="image/*" style={{ position:'absolute', opacity:0, inset:0, cursor:'pointer' }}
                        onChange={e => { handleFile(e.target.files?.[0], slot); e.target.value=''; }}/>
                    </label>
                  </div>
                );
              })}
            </div>
            {!parsed && (
              <Btn onClick={analyse} disabled={!photo1} style={{ width:'100%', marginBottom:10 }}>
                {totalPhotos > 1 ? `Analyse ${totalPhotos} Photos` : 'Analyse Photo'}
              </Btn>
            )}
            {parsed && (
              <div>
                <div style={{ background:'#f0f8f0', border:'1.5px solid #b8d8b8', borderRadius:12, padding:12, marginBottom:10 }}>
                  <div style={{ fontWeight:700, color:G, fontSize:14 }}>{parsed.courseName || 'Course detected'}</div>
                  <div style={{ fontSize:12, color:'#888', marginBottom:6 }}>{parsed.nines?.length||0} nine(s) · {parsed.tees?.length||0} tee set(s)</div>
                  {parsed.nines?.map((n,i) => (
                    <div key={i} style={{ fontSize:12, color:'#555', marginBottom:2 }}>
                      • {n.name}: par {n.pars?.reduce((a,b)=>a+b,0)||'?'}
                      {n.handicapsWomen?.length ? ' (M+W handicaps)' : ' (M handicaps)'}
                    </div>
                  ))}
                  {parsed.tees?.map((t,i) => (
                    <div key={i} style={{ fontSize:12, color:'#555', marginBottom:2 }}>
                      • {t.name}: M {t.rating||'—'}/{t.slope||'—'}
                      {t.ratingW ? ` · W ${t.ratingW}/${t.slopeW||'—'}` : ''}
                      {t.totalYards ? ` · ${t.totalYards} yds` : ''}
                    </div>
                  ))}
                </div>
                {missing.length > 0 && (
                  <div style={{ background:AMBBG, color:AMB, borderRadius:8, padding:'8px 12px', fontSize:12, marginBottom:10 }}>
                    Could not read: {missing.join(', ')}. Enter below.
                  </div>
                )}
                {missing.some(m=>m.includes('rating')) && (
                  <div style={{ marginBottom:8 }}>
                    <div style={{ fontSize:11, fontWeight:700, color:'#666', marginBottom:3 }}>Men's Course Rating</div>
                    <Inp value={manFill.rating||''} onChange={v=>setManFill(p=>({...p,rating:v}))} placeholder="e.g. 72.3" type="number"/>
                  </div>
                )}
                {missing.some(m=>m.includes('slope')) && (
                  <div style={{ marginBottom:10 }}>
                    <div style={{ fontSize:11, fontWeight:700, color:'#666', marginBottom:3 }}>Men's Slope</div>
                    <Inp value={manFill.slope||''} onChange={v=>setManFill(p=>({...p,slope:v}))} placeholder="e.g. 131" type="number"/>
                  </div>
                )}
                <div style={{ display:'flex', gap:8 }}>
                  <Btn variant="outline" onClick={() => { setParsed(null); setErr(''); }} style={{ flex:1 }}>Retake</Btn>
                  <Btn onClick={finish} style={{ flex:2 }}>Save Course</Btn>
                </div>
              </div>
            )}
            <Btn variant="ghost" onClick={onClose} style={{ width:'100%', marginTop:8 }}>Cancel</Btn>
          </div>
        )}
      </div>
    </div>
  );
}
