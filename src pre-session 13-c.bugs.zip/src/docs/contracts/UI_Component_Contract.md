# UI Component Contract

_Version 1.3 — April 2026_
_Supersedes: v1.2_
_Changes in v1.3: §4.9 NEW — `ShareOrientationPicker` component added. Bottom-sheet modal used by all three share surfaces (`ResultsPage`, `HistoryPage`, `RoundSummaryModal`) to ask the user for Portrait or Landscape orientation before building a share image. Props: `onPick(orientation)`, `onDismiss()`. Usage pattern documented._
_Status: AUTHORITATIVE_
_All implementation must conform to this contract._
_If code conflicts with this contract, the contract wins._

---

**Primary file:** `src/components/ui.jsx`

**Cross-references:**
- `ARCHITECTURE_FOUNDATIONS.md` §2 — three-layer model; permitted direct engine calls in UI
- `ARCHITECTURE_FOUNDATIONS.md` §3 — state ownership; props-down pattern
- `App_Data_Model_Contract.md` §4 — authoritative list of permitted direct engine calls in UI components
- `Handicap_Contract.md` §3 — `strokesForMode`, `chp` semantics (used by `PopDots`)

---

## §1. Purpose and Scope

`ui.jsx` is the single source of truth for all shared UI primitives in
the app. It exports design tokens, layout components, form inputs, and
two utility formatters. Every page and table component imports from
this file. No other file may define its own versions of these
primitives.

This contract documents:

- All design tokens (color constants and their semantic roles)
- Every exported symbol — components, utilities, and the global CSS string
- Props, variants, default values, and the `style` override pattern
- The no-external-CSS rule
- Dark mode status
- Known gaps and inconsistencies

This contract does **not** cover game-table layout patterns, scorecard
grid styles, or per-page design decisions. Those are owned by their
respective component files.

---

## §2. Architectural Position

`ui.jsx` lives in `src/components/` and belongs to the UI layer. It is
a shared primitive library — not a page, not an engine file, and not a
service. The following rules govern what may and may not live here.

### §2.1 What belongs in `ui.jsx`

- Design tokens (color constants)
- Reusable layout and input components used by two or more pages
- The `GLOBAL_CSS` reset string
- Utility formatters that are (a) purely presentational, (b) not
  scorecard-specific, and (c) used by multiple pages

**Hard rule:** `ui.jsx` must not accumulate domain-specific logic
beyond primitive input normalization and presentational formatting.
Any function that interprets game state, scoring results, or round
data does not belong here regardless of how small it is. This rule
exists to prevent gradual architectural drift — the UI layer must
remain a rendering primitive, not a logic layer.

### §2.2 What does not belong in `ui.jsx`

- Game scoring logic of any kind
- State management or React hooks beyond what is required for
  self-contained display (none are currently used)
- Scorecard-specific formatters — those belong in `scorecardUtils.js`
- Page-specific layout components used by only one file

### §2.3 Engine import exception and utility scope rule

`ui.jsx` imports `strokesForMode` and `chp` from `engine/handicap.js`
for use by `PopDots`. This is the only engine import in this file and
is explicitly permitted by `ARCHITECTURE_FOUNDATIONS.md` §2:

> "Permitted exceptions are limited to direct display-only arithmetic
> transformations with no game rules involved — for example,
> `strokesForMode()` to derive a net score for display, or
> `strokesForMode()` for handicap dot counts."

No other component in `ui.jsx` may import from the engine layer. Any
future component added to this file that requires engine logic must
be validated against the permitted-calls list in
`App_Data_Model_Contract.md` §4 before the import is added.

**Utility scope rule:** Utilities in `ui.jsx` must not depend on or
interpret application state, scores, or engine-derived values. A
utility that requires knowledge of game rules, player data, or round
state does not belong in this file.

### §2.4 No-external-CSS rule

All styles in this file are inline JavaScript objects passed to the
`style` prop of native HTML elements. No CSS classes, no CSS modules,
no CSS-in-JS libraries (e.g. styled-components, Emotion), and no
Tailwind are used anywhere in this application. This rule is
app-wide, not limited to `ui.jsx`.

The sole exception is `GLOBAL_CSS` (§6), which is a minimal string of
browser-normalization rules injected once at the app root. It does not
style any component.

---

## §3. Design Tokens

All tokens are named exports from `ui.jsx`. They are plain string
constants — no theme object, no nested structure.

### §3.1 Color token table

| Export | Value | Semantic role |
|---|---|---|
| `G` | `'#1a472a'` | Primary brand green. Used for active states, headings, filled buttons, toggle-on, dots, and all primary interactive elements. |
| `GA` | `'#e8f5ec'` | Green tint — the darker of the two green washes. Used for container backgrounds, highlighted cards, and table header fills where medium emphasis is needed. |
| `GB` | `'#f2faf4'` | Green wash — the lighter of the two green washes. Used for low-emphasis backgrounds, alternating row fills, and subtle surface differentiation. |
| `RED` | `'#c0392b'` | Danger red. Used for destructive actions (`Btn` `danger` variant) and negative result indicators. |
| `AMB` | `'#b7770d'` | Amber — warning/attention. Used for the `Btn` `amber` variant and caution states. |
| `AMBBG` | `'#fff8e1'` | Amber background tint. Intended as the surface color to pair with `AMB` text. Not currently used by any component in this file (see §9 G-3). |

### §3.2 Token usage rule

All files in the app must import color tokens from `ui.jsx` rather
than hardcoding hex values. A hardcoded hex that matches a token value
is non-conforming. This rule ensures that a single change to a token
in `ui.jsx` propagates everywhere.

### §3.3 What is not tokenized

The following style values are hardcoded inline in each component and
are **not** currently declared as named tokens:

- Border radius: `8` (inputs, buttons), `10` (toggles), `16` (cards)
- Font sizes: `11`, `12`, `13`, `14`, `15`
- Standard padding values
- Shadow: `'0 1px 5px rgba(0,0,0,.07)'` (Card)
- Standard gap and margin values

This is a known gap (§9 G-1). These values are consistent across
components but undocumented. **Token formalization is intentionally
deferred** pending a planned UX design engagement that will establish
the app's visual design system. Until that work is complete, new
components must match existing implicit values exactly — do not
introduce new magic numbers that deviate from the values listed above.

### §3.4 Font family

The app's root font family is declared in `App.jsx`'s root `<div>`
style as `"'DM Sans','Helvetica Neue',sans-serif"`. All components in
`ui.jsx` use `fontFamily: 'inherit'` to inherit this value. No
component declares its own font stack.

### §3.5 Dark mode

Dark mode is **not implemented**. The token set is light-mode only.
No dark-mode variants exist for any token. This is an intentional
deferment, not a gap to be fixed. If dark mode is added in the future,
a parallel token set must be introduced and this contract updated.

---

## §4. Components

All components are named exports. All accept a `style` prop (type:
plain object, default: `{}`) that is spread over the component's own
inline styles, allowing callers to override style properties subject
to the constraints in §7. **Exception:** `SH`, `Tog`, and `PopDots`
do not accept a `style` prop (see §9 G-2).

All components use `fontFamily: 'inherit'` on any rendered text
element that accepts the property.

---

### §4.1 `Btn` — Button

**Signature:**
```js
Btn({ children, onClick, variant, small, style, disabled })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `children` | ReactNode | — | Button label content |
| `onClick` | function | — | Click handler |
| `variant` | string | `'primary'` | Controls background and text color — see variant table below |
| `small` | boolean | `false` | Reduces padding and font size |
| `style` | object | `{}` | Caller style overrides — see §7 for constraints |
| `disabled` | boolean | `false` | Disables interaction — see disabled rules below |

**Variant table:**

| `variant` value | Background | Text color | Border |
|---|---|---|---|
| `'primary'` | `G` | `#fff` | none |
| `'danger'` | `RED` | `#fff` | none |
| `'outline'` | transparent | `G` | `1.5px solid G` |
| `'amber'` | `AMB` | `#fff` | none |
| `'ghost'` | `#f0f0f0` | `#444` | none |

> **Unrecognized variant fallback:** Any unrecognized `variant` value
> silently renders with `'ghost'` styling. No error is thrown.

**Size table:**

| `small` | Padding | Font size |
|---|---|---|
| `false` (default) | `9px 18px` | `14px` |
| `true` | `5px 11px` | `12px` |

**Disabled rules:**
- When `disabled` is `true`, **`onClick` must not fire under any
  circumstance.** This guarantee must hold even if the implementation
  changes (e.g. element type is swapped, handler is wrapped). The
  native `disabled` attribute on `<button>` is the current enforcement
  mechanism; any future refactor must preserve this guarantee explicitly.
- When `disabled` is `true`, the component's `background` (`#ccc`) and
  `cursor` (`not-allowed`) styles take precedence over the caller's
  `style` prop. These properties must not be overrideable by callers.
  This is enforced by the explicit conditional spread applied after the
  caller style: `...(disabled ? { background: '#ccc', cursor: 'not-allowed' } : {})`.

**Transition:** All style properties animate with `transition: all .15s`.

---

### §4.2 `Inp` — Text Input

**Signature:**
```js
Inp({ value, onChange, placeholder, style, type, onKeyDown, fRef })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `value` | string \| number | — | Controlled value. `null` and `undefined` both render as `''` |
| `onChange` | function | — | Called with `e.target.value` as a **string** on every change |
| `placeholder` | string | — | Placeholder text |
| `style` | object | `{}` | Caller style overrides — see §7 for constraints |
| `type` | string | `'text'` | Native input `type` attribute |
| `onKeyDown` | function | — | Native `keydown` handler; passed through as-is |
| `fRef` | React ref | — | Forwarded to the underlying `<input>` via the `ref` prop. Used by callers that need programmatic focus (e.g. `ScoreGrid` keyboard advance logic) |

**`onChange` string emission rule:** `onChange` always emits a string
(the raw value of `e.target.value`). It never parses or converts the
value. Callers that need numeric behavior are responsible for parsing
the emitted string themselves. This is a frequent source of subtle
bugs — callers must not assume the emitted value is a number even when
`type="number"` is passed.

**Default styles:** `border: 1px solid #ddd`, `borderRadius: 8`,
`padding: 8px 11px`, `fontSize: 14`, `background: #fff`, `color: #222`,
`width: 100%`, `boxSizing: border-box`, `outline: none`.

**Value normalization:** `value ?? ''` ensures the input is never
uncontrolled when `null` or `undefined` is passed.

---

### §4.3 `Sel` — Select Dropdown

**Signature:**
```js
Sel({ value, onChange, options, style })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `value` | string | — | Controlled value. `null` and `undefined` both render as `''` |
| `onChange` | function | — | Called with `e.target.value` (string) on every change |
| `options` | `OptionShape[]` | — | Array of option descriptors — see below |
| `style` | object | `{}` | Caller style overrides — see §7 for constraints |

**`OptionShape`:**
```js
{ value: string, label: string, disabled?: boolean }
```
The `disabled` field is optional. When `true`, the option is rendered
but not selectable (native `<option disabled>`).

**Empty-state requirement:** When the controlled `value` can be empty,
`null`, or `undefined` at any point, the caller must include an option
with `value: ''` in the `options` array. Omitting this option when the
value resolves to `''` causes a React mismatch warning and inconsistent
selection display.

**Default styles:** `border: 1px solid #ddd`, `borderRadius: 8`,
`padding: 7px 9px`, `fontSize: 13`, `background: #fff`.

**Value normalization:** `value ?? ''` — same null-safety pattern as `Inp`.

---

### §4.4 `Tog` — Toggle Switch

**Signature:**
```js
Tog({ checked, onChange, label, small })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `checked` | boolean | — | Controlled on/off state |
| `onChange` | function | — | Called with the new boolean value (`!checked`) on click |
| `label` | string | — | Optional text label rendered to the right of the switch |
| `small` | boolean | `false` | Renders a smaller toggle — see size table below |

**Click behavior:** Clicking anywhere on the toggle track or on the
label text fires `onChange(!checked)`. Both targets trigger the same
handler. Keyboard interaction (e.g. Space/Enter to toggle) is not
currently implemented — the app is mobile-first and touch-driven.

**Size table:**

| `small` | Track width | Track height | Thumb size | Label font size |
|---|---|---|---|---|
| `false` (default) | `34px` | `19px` | `15px` | `13px` |
| `true` | `28px` | `16px` | `12px` | `11px` |

**Color:** Track is `G` when `checked`, `#ccc` when unchecked. Thumb
is always `#fff`. Both animate with `transition: background .2s` (track)
and `transition: left .2s` (thumb).

**No `style` prop.** `Tog` does not accept a `style` override prop.
See §9 G-2.

**Controlled only.** `Tog` holds no persistent internal state.
`checked` and `onChange` are both required in practice (no default for
`checked`).

---

### §4.5 `Card` — Surface Container

**Signature:**
```js
Card({ children, style })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `children` | ReactNode | — | Any content |
| `style` | object | `{}` | Caller style overrides — see §7 for constraints |

**Default styles:** `background: #fff`, `borderRadius: 16`,
`padding: 18px`, `marginBottom: 14px`,
`boxShadow: 0 1px 5px rgba(0,0,0,.07)`.

`Card` is a pure layout wrapper. It has no knowledge of its contents.
Any spacing, typography, or color changes inside a `Card` are the
caller's responsibility.

---

### §4.6 `SH` — Section Heading

**Signature:**
```js
SH({ children })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `children` | ReactNode | — | Heading text |

**Default styles:** `fontWeight: 700`, `fontSize: 15`, `color: G`,
`marginBottom: 8px`.

**No `style` prop.** `SH` does not accept a `style` override prop.
See §9 G-2. Callers that need a heading with different styling must
render their own `<div>` directly.

---

### §4.7 `BetInput` — Numeric Bet Amount Field

**Signature:**
```js
BetInput({ value, onChange, style })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `value` | number | — | Controlled numeric value |
| `onChange` | function | — | Called with a `number` (never a string) on every valid change |
| `style` | object | `undefined` | Caller style overrides, spread last. Primary use is overriding the default `width` |

**Default styles:** `width: 60px`, `border: 1px solid #ddd`,
`borderRadius: 8`, `padding: 6px 8px`, `fontSize: 13`,
`textAlign: center`.

**Input mode:** `type="text"` with `inputMode="decimal"` — this
triggers the numeric keyboard on mobile while avoiding the browser's
built-in number spinner (which is also suppressed globally by
`GLOBAL_CSS`).

**Value display rule:** When `value === 0`, the field renders as empty
string `''`. Any other numeric value renders as its string
representation.

**Transient invalid state:** Invalid characters (e.g. letters, symbols)
are allowed to appear in the DOM temporarily during typing. They do
not trigger `onChange` — the stored state is unaffected. On blur, the
field re-parses the displayed value and normalizes: valid numbers call
`onChange(n)`; unparseable values call `onChange(0)` and the field
snaps back to empty. This means the UI and state can briefly diverge
during active typing — this is intentional behavior, not a bug.

**Change behavior:**
- Empty string or lone `.` → calls `onChange(0)`
- Valid `parseFloat` result → calls `onChange(n)`
- Invalid input (letters, symbols) → no `onChange` call; DOM displays
  the typed characters until blur normalization fires

**Blur behavior:** On blur, re-parses the displayed value and calls
`onChange` with the numeric result, or `onChange(0)` if unparseable.
This ensures the stored value is always a valid number after the user
leaves the field.

**`onChange` contract:** `onChange` is always called with a `number`,
never a string. Callers must store the result as a number.

---

### §4.8 `PopDots` — Handicap Stroke Dots

**Signature:**
```js
PopDots({ ghin, hcpRank, minGhin, mode })
```

| Prop | Type | Default | Description |
|---|---|---|---|
| `ghin` | number | — | Player's GHIN handicap index |
| `hcpRank` | number | — | The hole's handicap rank (1–18, where 1 = hardest) |
| `minGhin` | number | — | The minimum GHIN in the relevant player group (used for NOL calculations) |
| `mode` | string | `'net'` | Scoring mode: `'gross'`, `'net'`, or `'netofflow'`. Defaults to `'net'` when absent or falsy |

**Behavior:** Renders a row of small filled circles (3×3px, color `G`)
in the bottom-right corner of a score cell, showing how many strokes
the player receives on that hole under the active scoring mode. Returns
`null` when stroke count is zero or negative — renders nothing.

**GHIN consistency rule:** The `ghin` value passed to `PopDots` must
be the same value used to derive `courseHcps` in the active round. Do
not pass a modified, overridden, or independently sourced GHIN value.
A mismatched value causes the dot count to disagree with the handicap
strokes applied by the engine, producing a confusing and incorrect display.

**Engine dependency:** Calls `strokesForMode(chp(ghin), hcpRank, minGhin, mode)`
from `engine/handicap.js`. This is the only engine call in `ui.jsx`
and is explicitly permitted (see §2.3).

**Positioning:** Absolutely positioned (`position: absolute, bottom: 2, right: 2`).
The caller's container must be `position: relative` for dots to appear
correctly.

**No `style` prop.** `PopDots` does not accept a `style` override.
Its size and position are fixed.

---

### §4.9 `ShareOrientationPicker` — Share Image Orientation Modal

```js
ShareOrientationPicker({ onPick, onDismiss })
```

A bottom-sheet modal that asks the user to choose between Portrait and
Landscape before a share image is built. Rendered as a fixed overlay
above all other content (z-index 200).

**Props:**

| Prop | Type | Description |
|---|---|---|
| `onPick` | `(orientation: 'portrait' \| 'landscape') => void` | Called when user taps an orientation button |
| `onDismiss` | `() => void` | Called when user taps the backdrop |

**Behavior:**
- Renders a semi-transparent black backdrop (`rgba(0,0,0,0.45)`) that fills the viewport
- The sheet slides up from the bottom with rounded top corners (`border-radius: 18px 18px 0 0`)
- Two equal-width buttons: Portrait (left) and Landscape (right), each with an inline SVG icon, label, and subtitle
- Tapping a button calls `onPick(orientation)` — the caller is responsible for dismissing the picker (typically by toggling `showOrienPick` state)
- Tapping the backdrop calls `onDismiss` without triggering a share
- `e.stopPropagation()` prevents sheet taps from bubbling to the backdrop

**No `style` prop.** Layout and color are fixed to match the app design system (`G` token for borders and text).

**Usage pattern** — all three share surfaces use identical state + handler pattern:

```js
const [showOrienPick, setShowOrienPick] = useState(false);

const handleShare = () => setShowOrienPick(true);

const handleShareWithOrientation = async (orientation) => {
  setShowOrienPick(false);
  setShareStatus('building');
  // ... build and share
};

// In render:
{showOrienPick && (
  <ShareOrientationPicker
    onPick={handleShareWithOrientation}
    onDismiss={() => setShowOrienPick(false)}
  />
)}
```

**Share surfaces:** `ResultsPage`, `HistoryPage`, `RoundSummaryModal`.
All three import `ShareOrientationPicker` from `ui.jsx`.

---

## §5. Utility Exports

These are pure functions, not components. They live in `ui.jsx` because
they are presentational, have no scorecard dependency, and are used
across multiple non-scorecard pages. Per §2.3, utilities here must not
depend on or interpret application state, scores, or engine-derived
values.

### §5.1 `fmtDollar`

```js
fmtDollar(v: number) → string
```

Formats a dollar amount as a signed string.

| Input | Output |
|---|---|
| positive number | `'+$X.XX'` |
| negative number | `'-$X.XX'` |
| zero | `'$0'` |

Always uses two decimal places for non-zero values. Uses `Math.abs`
for the magnitude so the sign is always the leading character.

**Rounding caveat:** Uses standard JavaScript floating-point
arithmetic. Results are subject to standard JS rounding behavior
(e.g. `1.005` may round to `1.00`). This function is not suitable for
financial-grade precision — it is a display formatter only. Payout
calculations are performed by the engine; this function only formats
the result for display.

### §5.2 `fmtDate`

```js
fmtDate(dateStr: string) → string
```

Converts an ISO date string (`'YYYY-MM-DD'`) to a locale-style display
string (`'M/D/YYYY'`) without timezone shift.

**Behavior:** Splits on `'-'` and reconstructs using `parseInt` to
strip leading zeros from month and day. Returns the original string
unchanged if it does not contain exactly three parts separated by
`'-'`. Returns `''` for falsy input.

| Input | Output |
|---|---|
| `'2026-04-11'` | `'4/11/2026'` |
| `'2026-12-01'` | `'12/1/2026'` |
| `''` / `null` / `undefined` | `''` |
| malformed string | original string |

**Malformed input caveat:** No date validation is performed beyond
structure checking (three parts separated by `'-'`). A string like
`'2026-99-99'` passes the split check and will display as
`'99/99/2026'`. The function does not validate month or day ranges.
Callers are responsible for ensuring well-formed ISO date strings are
passed.

**Rationale for timezone-safe approach:** Using `new Date(dateStr)`
would shift dates by the local UTC offset on some devices, causing
off-by-one date display errors. Parsing manually avoids this.

---

## §6. `GLOBAL_CSS`

```js
export const GLOBAL_CSS: string
```

A template-literal string of CSS rules injected once at the app root
via `<style>{GLOBAL_CSS}</style>` inside `App.jsx`'s render output.

**Purpose:** Browser normalization only. Contains no component styles.

**Current rules:**

| Rule | Purpose |
|---|---|
| `* { box-sizing: border-box; }` | Ensures padding is included in element dimensions everywhere |
| `* { -webkit-tap-highlight-color: transparent; }` | Removes the blue flash on tap in mobile WebKit browsers |
| `input[type="number"] spinner suppression` | Hides the browser's built-in increment/decrement arrows on number inputs (WebKit) |
| `body { touch-action: pan-y; }` | Prevents horizontal swipe gestures from interfering with vertical scrolling on touch devices |
| `body { overscroll-behavior: none; }` | Prevents pull-to-refresh and bounce scrolling |
| `table { table-layout: fixed; }` | Forces all tables to fixed-width column layout for consistent scorecard grid rendering. **This rule applies globally to every table in the app.** Any future table that requires auto or dynamic column sizing must explicitly override `table-layout` in its own inline styles. |

**Injection rule:** `GLOBAL_CSS` must be injected exactly once, in
`App.jsx`. It must not be injected in any page or component. Multiple
injections would produce duplicate rules with no functional harm, but
it is non-conforming.

**Modification rule:** Changes to `GLOBAL_CSS` affect the entire app.
Any modification must be reviewed for unintended side effects across
all pages and table components before being applied.

---

## §7. The `style` Override Pattern

All components that accept a `style` prop spread it over their own
default styles, giving the caller override authority. The exact spread
position varies by component to protect semantically critical
properties:

```js
// Standard pattern — caller wins on all non-protected properties
style={{ ...defaultStyles, ...style }}

// Required pattern for Btn — disabled state properties are protected
style={{ ...defaultStyles, ...style, ...(disabled ? { background: '#ccc', cursor: 'not-allowed' } : {}) }}
```

**Two constraints apply to all callers using `style` overrides:**

1. **Token rule:** Any color value in a `style` override must use a
   token imported from `ui.jsx` (§3.1). Hardcoded hex values that
   match or approximate token values are non-conforming.

2. **Semantic protection rule:** Caller `style` must not override
   interaction-critical or semantically meaningful styles. Specifically:
   - Do not override `background` or `cursor` on a disabled `Btn`
     (these are enforced at the component level per §4.1 and §9 G-5)
   - Do not override `background` or `color` on `Btn` in ways that
     make one variant visually indistinguishable from another
   - Do not override visibility-affecting properties (`display: none`,
     `opacity: 0`, `visibility: hidden`) on interactive controls

**Components with `style` prop:** `Btn`, `Inp`, `Sel`, `Card`, `BetInput`

**Components without `style` prop:** `Tog`, `SH`, `PopDots`
See §9 G-2 for the known gap on `Tog` and `SH`.

---

## §8. Invariants

1. **Single source of truth:** All shared UI primitives live in `ui.jsx`. No page or component file may define its own version of `Btn`, `Inp`, `Sel`, `Tog`, `Card`, `SH`, `BetInput`, or `PopDots`.
2. **Token import rule:** Any file using a color that matches a token value must import that token from `ui.jsx`. Hardcoded hex duplicates of token values are non-conforming.
3. **No external CSS:** All component styles are inline JS objects. No CSS library, CSS module, or class-based styling is used anywhere in the app.
4. **`fontFamily: 'inherit'`:** Every component that renders text uses `fontFamily: 'inherit'`. No component declares its own font stack.
5. **`style` spread observes constraints:** In every component that accepts a `style` prop, caller overrides are subject to the token rule and semantic protection rule defined in §7. Disabled state properties in `Btn` are never overrideable by callers.
6. **`GLOBAL_CSS` injected once:** `GLOBAL_CSS` is injected in `App.jsx` only. Never in a page or component.
7. **`BetInput.onChange` receives a number:** The `onChange` callback for `BetInput` is always called with a `number`. Callers must not treat the argument as a string.
8. **`PopDots` container must be `position: relative`:** Any caller rendering `PopDots` must ensure its immediate container is `position: relative` or the dots will escape the cell boundary.
9. **No persistent internal state in form components:** `Btn`, `Inp`, `Sel`, `Tog`, `BetInput` are all fully controlled components. None holds persistent internal state. Components may perform input normalization logic (as `BetInput` does) but must not store state that outlives a single render cycle. The caller owns all values.
10. **`null`/`undefined` value safety:** `Inp` and `Sel` both normalize `null` and `undefined` values to `''` via `value ?? ''`. Callers may pass either without causing an uncontrolled-component React warning.
11. **Unrecognized `Btn` variant falls back to `'ghost'`:** Any unrecognized value passed as `variant` silently renders with ghost styling (`#f0f0f0` background, `#444` text). No error is thrown. This fallback must be preserved in any future refactor of `Btn`.
12. **`Btn` disabled blocks all interaction:** When `disabled` is `true`, `onClick` must not fire under any circumstance. This is a behavioral guarantee, not an implementation detail. Any refactor that could allow `onClick` to fire on a disabled button is non-conforming.
13. **No domain logic in `ui.jsx`:** No function or component in this file may interpret game state, scoring results, round data, or player data. `ui.jsx` is a rendering primitive, not a logic layer.

---

## §9. Known Gaps and Open Items

| # | Severity | Description |
|---|---|---|
| G-1 | Low | No spacing, typography, or border-radius tokens are declared. Values like `borderRadius: 8`, `fontSize: 13`, and `padding: 18` are hardcoded inline in each component. Token formalization is intentionally deferred pending a planned UX design engagement. Until that work is complete, new components must match existing implicit values exactly — do not introduce new magic numbers that deviate from the values in §3.3. |
| G-2 | Low | `Tog` and `SH` do not accept a `style` override prop, inconsistent with all other components. Callers that need a custom-styled heading or toggle must render their own elements directly. Fix: add `style = {}` prop and spread it last (subject to §7 constraints) in both components. |
| G-3 | Low | `AMBBG` (`'#fff8e1'`) is declared as a token but is not confirmed used by any component in `ui.jsx`. It is available for import by page files that need an amber surface color. If confirmed unused across the entire app, it should be removed in a future cleanup pass. |
| G-4 | Low | `GA` and `GB` lack a formally documented semantic distinction beyond their values. §3.1 of this contract is now the authoritative guide. All future usage must follow the roles defined there. |
| G-5 | ✅ CLOSED | In `Btn`, the caller `style` prop was previously spread last over all styles, allowing callers to override `background` and `cursor` even when `disabled` was `true`. Fixed in session 11-E: disabled background and cursor are now applied via an explicit conditional spread after the caller `style` spread — `{ ...defaultStyles, ...style, ...(disabled ? { background: '#ccc', cursor: 'not-allowed' } : {}) }`. Confirmed on device. |

---

## §10. Final Rule

If implementation behavior conflicts with this contract, call out the
conflict. The implementation must be corrected. This document defines
the truth.
