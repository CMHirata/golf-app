// ─── scorecard/ScoreGrid.jsx ──────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// Handles the hole-by-hole score entry grid, long-press dots popup, and
// handicap dot display. All scoring math arrives via props from ScorecardPage.
// See App Data Model Contract §8 for mutation rules.

import { useRef, useCallback, useState, useEffect } from 'react';
import { G } from '../../components/ui.jsx';
import { strokesForMode, scoreForMode, xGrossScore } from '../../engine/handicap.js';
import { restoreDotDefs, COL_W, TOT_W, NAME_MIN } from './scorecardUtils.js';
import { getDotsPartner, getMatchTeamPartner, sixesSegForHole } from '../../engine/games.js';
import { DotsPopup }        from './DotsPopup.jsx';
import { ZoomModal }        from './ZoomModal.jsx';
import { ScoreKeypad }      from './ScoreKeypad.jsx';
import { NinesTable }       from '../tables/NinesTable.jsx';
import { StablefordTable }  from '../tables/StablefordTable.jsx';
import { SkinsTable }       from '../tables/SkinsTable.jsx';
import { StrokePlayTable }  from '../tables/StrokePlayTable.jsx';
import { MatchNassauTable } from '../tables/MatchNassauTable.jsx';
import { SixesTable }       from '../tables/SixesTable.jsx';
import { DotsTable }        from '../tables/DotsTable.jsx';
import { TotalsCard }       from './TotalsCard.jsx';

// ── PopDots ────────────────────────────────────────────────────────────────────
function PopDots({ courseHcp, hcpRank, minCourseHcp, mode }) {
  const n = strokesForMode(courseHcp, hcpRank, minCourseHcp, mode);
  if (n <= 0) return null;
  return (
    <div style={{ position: 'absolute', bottom: 2, right: 2, display: 'flex', gap: 1.5, pointerEvents: 'none' }}>
      {Array.from({ length: n }).map((_, i) => <div key={i} style={{ width: 3, height: 3, borderRadius: '50%', background: G }}/>)}
    </div>
  );
}

// ── DotBadge ───────────────────────────────────────────────────────────────────
function DotBadge({ count }) {
  if (!count) return null;
  return (
    <div style={{
      position: 'absolute', top: -2, right: -2,
      width: 13, height: 13, borderRadius: '50%',
      background: G, color: '#fff',
      fontSize: 7, fontWeight: 800, lineHeight: 1,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      pointerEvents: 'none', zIndex: 2,
    }}>{count}</div>
  );
}

// ── ScoreGrid ──────────────────────────────────────────────────────────────────
export function ScoreGrid({
  players, pars, hcps, courseHcps, minCourseHcp,
  effectiveMinCourseHcp, nonParticipantIdxs,
  scores, setScores,
  dotMode, isMixed, setDotModeOverride,
  nolDotGame, setNolDotGame, nolDotOptions,
  primaryMode, activeGames, gameOpts,
  matches, sixesTeams, strokePlayPlayers, skinsPlayers, stablefordPlayers, ninesPlayers,
  dotsPlayers,
  dots, dotEntries, setDotEntries,
  manualPresses, setManualPresses,
  frontLabel, backLabel,
  isLandscape: isLandscapeProp,
  zoomTriggerRef,
  // 13-C.2: Round length — defaults preserve full 18-hole behavior when props
  // are absent. Drives column count, cell navigation bounds, and firstEmptyHole.
  roundStartHole = 0,
  roundNumHoles  = 18,
}) {
  // 13-C.2: Derived end hole (never stored per PartialGameContract §1A.3, §14.17)
  const roundEndHole = roundStartHole + roundNumHoles - 1;
  // 13-C.2: inRound(h) tells the renderer whether a hole is part of the round.
  // Out-of-round cells within a rendered Front 9 / Back 9 section display as
  // a non-interactive gray cell with an em-dash `–` (invariant #15).
  const inRound = (h) => h >= roundStartHole && h <= roundEndHole;
  // 13-C.2: Front 9 is rendered in full (9 columns) whenever the round contains
  // ANY front-9 hole; same for Back 9. Out-of-round columns within a rendered
  // half display as gray non-interactive cells. This keeps the familiar 9-per-
  // side scorecard layout regardless of round length while honoring the
  // "display `–` for holes not played" invariant. For a full round both halves
  // render and every cell is in-round → identical output to pre-13-C.2.
  const FULL_FRONT = [0,1,2,3,4,5,6,7,8];
  const FULL_BACK  = [9,10,11,12,13,14,15,16,17];
  const anyFrontInRound = roundStartHole <= 8;
  const anyBackInRound  = roundEndHole   >= 9;
  const refs  = useRef({});
  const [popup,    setPopup]    = useState(null);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [zoomHole, setZoomHole] = useState(0);

  // ── ScoreKeypad state (13-B addition) ──────────────────────────────────────
  const [activeKpCell,  setActiveKpCell]  = useState(null); // { h, pi } | null
  const [kpValue,       setKpValue]       = useState('');
  const kpAdvanceTimer  = useRef(null);
  const kpContainerRef  = useRef(null);
  const zoomCardRef     = useRef(null); // attached to ZoomModal card — exempts it from dismiss handler
  const savedKpCellRef  = useRef(null); // saved cell to restore after DotsPopup closes
  const activeKpCellRef = useRef(null); // always-current mirror of activeKpCell for use in closures

  // Keep activeKpCellRef always current — used inside setTimeout closures in startLongPress
  useEffect(() => { activeKpCellRef.current = activeKpCell; }, [activeKpCell]);
  const firstEmptyHole = useCallback(() => {
    // 13-C.2: Search bounded by round. Falls back to last hole of round, not 17.
    for (let h = roundStartHole; h <= roundEndHole; h++) {
      for (let pi = 0; pi < players.length; pi++) {
        const v = scores[h]?.[pi];
        if (v === '' || v == null) return h;
      }
    }
    return roundEndHole;
  }, [scores, players.length, roundStartHole, roundEndHole]);

  const openZoom = useCallback(() => {
    setZoomHole(firstEmptyHole());
    setZoomOpen(true);
  }, [firstEmptyHole]);

  // Expose openZoom to parent (ScorecardPage) for landscape zoom button
  useEffect(() => {
    if (zoomTriggerRef) zoomTriggerRef.current = openZoom;
  }, [openZoom, zoomTriggerRef]);

  const closeZoom = useCallback(() => {
    setZoomOpen(false);
    setActiveKpCell(null);
    setKpValue('');
  }, []);

  // When ZoomModal opens, activate the first empty cell on the target hole.
  // Deferred by one tick so the dismiss handler (touchend) doesn't immediately
  // clear it (the zoom button tap fires touchend after setZoomOpen).
  useEffect(() => {
    if (!zoomOpen) return;
    const timer = setTimeout(() => {
      let targetPi = 0;
      for (let pi = 0; pi < players.length; pi++) {
        const v = scores[zoomHole]?.[pi];
        if (v === '' || v == null) { targetPi = pi; break; }
      }
      setActiveKpCell({ h: zoomHole, pi: targetPi });
      setKpValue('');
    }, 0);
    return () => clearTimeout(timer);
  }, [zoomOpen]); // eslint-disable-line react-hooks/exhaustive-deps

  // H-4: isLandscape passed from ScorecardPage; fall back to local detection.
  const [isLandscapeLocal, setIsLandscapeLocal] = useState(
    () => typeof window !== 'undefined' && window.innerWidth > window.innerHeight
  );
  useEffect(() => {
    if (isLandscapeProp !== undefined) return;
    const update = () => setIsLandscapeLocal(window.innerWidth > window.innerHeight);
    window.addEventListener('resize', update);
    window.addEventListener('orientationchange', update);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('orientationchange', update);
    };
  }, [isLandscapeProp]);
  const isLandscape = isLandscapeProp !== undefined ? isLandscapeProp : isLandscapeLocal;

  // Read-only guard: zoom/keypad only available when setScores is provided
  const canZoom = !!setScores;

  // Keypad visible whenever a cell is active. Shows above ZoomModal (zIndex 300 > 200).
  const kpVisible = canZoom && !!activeKpCell;

  const dotsGameActive = activeGames.includes('Dots') || activeGames.includes('Specials');

  const SCORING_SPECIAL_PRIORITY = ['ace', 'condor', 'albatross', 'eagle', 'birdie'];

  const autoMark = useCallback((h, pi, g) => {
    if (!dotsGameActive) return;
    const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    if (!dtIdxs.includes(pi)) return;

    const par = pars[h];
    const dotsOpts   = gameOpts?.Dots || gameOpts?.Specials || {};
    const dotScoring = dotsOpts.grossNetNOL ?? dotsOpts.scoring;
    const gNum = parseInt(g) || 0;
    const effectiveScore = (gNum && dotScoring === 'net' && courseHcps && hcps && minCourseHcp != null)
      ? scoreForMode(gNum, courseHcps[pi], hcps[h], minCourseHcp, 'net')
      : gNum || null;

    const rawTeamMode = dotsOpts.teamMode;
    const legacyTeam  = dotsOpts.teamScoring;
    const teamSource  = rawTeamMode && rawTeamMode !== 'none'
      ? rawTeamMode
      : (legacyTeam ? 'Sixes' : 'none');
    const isTeamMode = teamSource !== 'none';
    const getPartner = () => {
      if (teamSource === 'Sixes') return getDotsPartner(pi, sixesSegForHole(h), sixesTeams, players);
      if (teamSource.startsWith('Match:')) {
        const matchId  = teamSource.slice(6);
        const teamMatch = matches?.find(m => m.id === matchId) || matches?.find(m => m.format === 'team');
        return getMatchTeamPartner(pi, teamMatch ? [teamMatch] : []);
      }
      return -1;
    };

    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);
    const restoredDots = restoreDotDefs(dots);
    const ens = restoredDots.filter(s => s.enabled);

    setDotEntries(prev => {
      const n = { ...prev };
      const autoSpecials = restoredDots.filter(s => s.enabled && s.auto && s.autoWhen && s.id !== 'team');

      if (!effectiveScore || !par) {
        autoSpecials.forEach(sp => { delete n[`${h}_${pi}_${sp.id}`]; });
      } else {
        const scoringIds = new Set(SCORING_SPECIAL_PRIORITY);
        const nonScoring = autoSpecials.filter(sp => !scoringIds.has(sp.id));
        const scoringCandidates = autoSpecials
          .filter(sp => scoringIds.has(sp.id))
          .sort((a, b) => SCORING_SPECIAL_PRIORITY.indexOf(a.id) - SCORING_SPECIAL_PRIORITY.indexOf(b.id));

        const winner = scoringCandidates.find(sp => sp.autoWhen(effectiveScore, par));

        scoringCandidates.forEach(sp => {
          const key = `${h}_${pi}_${sp.id}`;
          if (sp === winner) n[key] = 1;
          else delete n[key];
        });

        nonScoring.forEach(sp => {
          const key = `${h}_${pi}_${sp.id}`;
          if (sp.autoWhen(effectiveScore, par)) n[key] = 1;
          else delete n[key];
        });
      }

      // Always delete ALL stale companion entries written by pi on hole h,
      // regardless of which receiver they point to. This cleans up orphaned
      // companions from a previous teamMode (e.g. Sixes→Match transition).
      Object.keys(n).forEach(key => {
        const parts = key.split('_');
        if (parts[2] === 'team' && parts.length > 3 &&
            parseInt(parts[0]) === h &&
            parseInt(parts[parts.length - 1]) === pi) {
          delete n[key];
        }
      });

      if (isTeamMode) {
        const partnerIdx = getPartner();
        if (partnerIdx >= 0) {
          const compKey = `${h}_${partnerIdx}_team_dot_for_${pi}`;
          let total = 0;
          Object.entries(n).forEach(([key, v]) => {
            const cnt = entryCount(v);
            if (!cnt) return;
            const parts = key.split('_');
            if (parseInt(parts[0]) !== h || parseInt(parts[1]) !== pi) return;
            if (parts[2] === 'team') return;
            const sp = ens.find(s => s.id === parts[2]);
            if (sp) total += cnt;
          });
          if (total > 0) n[compKey] = total; else delete n[compKey];
        }
      }

      return n;
    });
  }, [pars, hcps, courseHcps, minCourseHcp, dots, dotsGameActive, gameOpts,
      dotsPlayers, players, sixesTeams, matches, setDotEntries]);

  useEffect(() => {
    if (!dotsGameActive) return;
    const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    for (let h = 0; h < 18; h++) {
      dtIdxs.forEach(pi => {
        const g = parseInt(scores[h]?.[pi]);
        if (g) autoMark(h, pi, g);
      });
    }
  }, [dotsGameActive]); // eslint-disable-line react-hooks/exhaustive-deps

  const longPressTimer = useRef({});
  const longPressFired = useRef({}); // tracks cells where long-press completed

  const startLongPress = (h, pi) => {
    if (dotsGameActive) {
      const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
      if (!dtIdxs.includes(pi)) return;
    }
    const key = `${h}_${pi}`;
    longPressFired.current[key] = false;
    longPressTimer.current[key] = setTimeout(() => {
      longPressFired.current[key] = true;
      // Save and hide the keypad while DotsPopup is open
      savedKpCellRef.current = activeKpCellRef.current;
      setActiveKpCell(null);
      setKpValue('');
      setPopup({ hole: h, pi });
    }, 500);
  };

  const cancelLongPress = (h, pi) => {
    const key = `${h}_${pi}`;
    if (longPressTimer.current[key]) {
      clearTimeout(longPressTimer.current[key]);
      delete longPressTimer.current[key];
    }
  };

  // ── Legacy keyboard advance (for any remaining input elements) ─────────────
  const advanceRef = useRef(null);
  advanceRef.current = (h, pi) => {
    const npi = pi + 1 < players.length ? pi + 1 : 0;
    const nh  = pi + 1 < players.length ? h : h + 1;
    if (nh < 18) {
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const el = refs.current[`${nh}_${npi}`];
        if (el) { el.focus(); try { el.select(); } catch (_) {} }
      }));
    }
  };

  const advanceTimer = useRef(null);
  const scheduleAdvance = useCallback((h, pi, firstDigit) => {
    if (advanceTimer.current) clearTimeout(advanceTimer.current);
    if (firstDigit === '1') {
      advanceTimer.current = setTimeout(() => { advanceTimer.current = null; advanceRef.current(h, pi); }, 700);
    } else {
      advanceRef.current(h, pi);
    }
  }, []);

  const cancelAdvance = useCallback(() => {
    if (advanceTimer.current) { clearTimeout(advanceTimer.current); advanceTimer.current = null; }
  }, []);

  const pendingAdvance = useRef(null);

  const handleKeyDown = useCallback((h, pi, e) => {
    if ((e.key === 'Enter' || e.key === 'Tab') && !e.shiftKey) {
      e.preventDefault(); cancelAdvance(); advanceRef.current(h, pi); return;
    }
    if (e.key === 'Backspace') {
      cancelAdvance();
      const cur = scores[h]?.[pi];
      if (cur === '' || cur == null || cur === 0) {
        e.preventDefault();
        const ppi = pi - 1 >= 0 ? pi - 1 : players.length - 1;
        const ph  = pi - 1 >= 0 ? h : h - 1;
        if (ph >= 0) {
          requestAnimationFrame(() => requestAnimationFrame(() => {
            const el = refs.current[`${ph}_${ppi}`];
            if (el) { el.focus(); try { el.select(); } catch (_) {} }
          }));
        }
      }
      return;
    }
    if (/^[1-9]$/.test(e.key)) {
      const curVal = String(scores[h]?.[pi] ?? '');
      if (curVal === '1') cancelAdvance();
      pendingAdvance.current = { h, pi, key: e.key };
      const el = refs.current[`${h}_${pi}`];
      if (el && el.selectionStart === 0 && el.selectionEnd === el.value.length && e.key === curVal) {
        e.preventDefault();
        const v = parseInt(e.key);
        setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = v; return n; });
        if (v) autoMark(h, pi, v);
        scheduleAdvance(h, pi, e.key);
        pendingAdvance.current = null;
      }
    }
  }, [players.length, scores, autoMark, scheduleAdvance, cancelAdvance]);

  const handleScore = (h, pi, val) => {
    // Allow 'X' through directly — do not strip via digit-only filter
    if (val === 'X') {
      setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = 'X'; return n; });
      // X does not auto-mark dots
      return;
    }
    const digits  = val.replace(/[^0-9]/g, '');
    let effective;
    if (digits.length === 2 && digits[0] === '1') effective = digits;
    else if (digits.length > 1) effective = digits[0];
    else effective = digits;
    const v = effective === '' ? '' : Math.max(1, Math.min(15, parseInt(effective) || 0));
    setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = v; return n; });
    autoMark(h, pi, v);
    if (effective !== '' && pendingAdvance.current?.h === h && pendingAdvance.current?.pi === pi) {
      const firstDigit = pendingAdvance.current.key;
      pendingAdvance.current = null;
      if (digits.length === 2) { cancelAdvance(); advanceRef.current(h, pi); }
      else scheduleAdvance(h, pi, firstDigit);
    }
  };

  const dotsScoringMode = ((gameOpts?.Dots || gameOpts?.Specials || {})).grossNetNOL ?? ((gameOpts?.Dots || gameOpts?.Specials || {})).scoring ?? 'gross';
  useEffect(() => {
    if (!dotsGameActive) return;
    const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    for (let h = 0; h < 18; h++) {
      dtIdxs.forEach(pi => {
        const g = parseInt(scores[h]?.[pi]);
        autoMark(h, pi, g || 0);
      });
    }
  }, [dotsScoringMode]); // eslint-disable-line react-hooks/exhaustive-deps

  const grossTotal = (pi, hs) => hs.reduce((s, h) => s + (parseInt(scores[h]?.[pi]) || 0), 0);
  const netTotal   = (pi, hs) => hs.reduce((s, h) => {
    const g = parseInt(scores[h]?.[pi]);
    return g ? s + (scoreForMode(g, courseHcps[pi], hcps[h], minCourseHcp, primaryMode) || 0) : s;
  }, 0);
  const parTotal   = hs => hs.reduce((s, h) => s + (pars[h] || 0), 0);

  const sc = (h, pi) => {
    if (!dotsGameActive) return 0;
    const rs = restoreDotDefs(dots);
    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);
    return rs.filter(s => s.enabled && s.id !== 'team').reduce((sum, s) => {
      return sum + entryCount(dotEntries[`${h}_${pi}_${s.id}`]);
    }, 0);
  };

  // ── ScoreKeypad callbacks (13-B addition) ──────────────────────────────────

  // Cancel the keypad advance timer
  const cancelKpAdvance = useCallback(() => {
    if (kpAdvanceTimer.current) { clearTimeout(kpAdvanceTimer.current); kpAdvanceTimer.current = null; }
  }, []);

  // Open keypad on a specific cell — always seeds kpValue='' (H-16)
  const openKeypadOnCell = useCallback((h, pi) => {
    cancelKpAdvance();
    setActiveKpCell({ h, pi });
    setKpValue('');
  }, [cancelKpAdvance]);

  // Advance to next cell after a score is committed
  const kpAdvanceCell = useCallback((h, pi) => {
    const npi = pi + 1 < players.length ? pi + 1 : 0;
    const nh  = pi + 1 < players.length ? h : h + 1;
    // 13-C.2: Cannot advance past the last hole of the round.
    if (nh > roundEndHole) {
      setActiveKpCell(null);
      setKpValue('');
      return;
    }
    // Keep ZoomModal centred on the active hole when crossing a hole boundary
    if (nh !== h) setZoomHole(nh);
    setActiveKpCell({ h: nh, pi: npi });
    setKpValue('');
  }, [players.length, setZoomHole, roundEndHole]);

  // Retreat to prior cell
  const kpRetreatCell = useCallback((h, pi) => {
    const ppi = pi - 1 >= 0 ? pi - 1 : players.length - 1;
    const ph  = pi - 1 >= 0 ? h : h - 1;
    // 13-C.2: Cannot retreat before the first hole of the round.
    if (ph < roundStartHole) return;
    // Keep ZoomModal centred on the active hole when crossing a hole boundary
    if (ph !== h) setZoomHole(ph);
    setActiveKpCell({ h: ph, pi: ppi });
    setKpValue('');
  }, [players.length, setZoomHole, roundStartHole]);

  // Schedule advance after entry — immediate for all except '1' (700ms window)
  const scheduleKpAdvance = useCallback((h, pi, val) => {
    cancelKpAdvance();
    if (val === '1') {
      kpAdvanceTimer.current = setTimeout(() => {
        kpAdvanceTimer.current = null;
        kpAdvanceCell(h, pi);
      }, 700);
    } else {
      kpAdvanceCell(h, pi);
    }
  }, [cancelKpAdvance, kpAdvanceCell]);

  // Keypad onChange — called for every digit and 'X'
  const handleKpChange = useCallback((newVal) => {
    if (!activeKpCell) return;
    const { h, pi } = activeKpCell;

    if (newVal === 'X') {
      // Write 'X' immediately and advance
      setKpValue('X');
      setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = 'X'; return n; });
      scheduleKpAdvance(h, pi, 'X');
      return;
    }

    // Digit string — interpret as score
    const digits = newVal.replace(/[^0-9]/g, '');
    let effective;
    if (digits.length === 2 && digits[0] === '1') effective = digits;
    else if (digits.length > 1) effective = digits[0];
    else effective = digits;

    const committed = effective === '' ? '' : Math.max(1, Math.min(15, parseInt(effective) || 0));
    setKpValue(effective); // show in-progress value in cell
    if (committed !== '') {
      setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = committed; return n; });
      autoMark(h, pi, committed);
      // Two-digit score: advance immediately. Single-digit '1': wait 700ms.
      const advanceKey = digits.length >= 2 ? '2' : (digits[0] || '');
      scheduleKpAdvance(h, pi, advanceKey);
    }
  }, [activeKpCell, setScores, autoMark, scheduleKpAdvance]);

  // Keypad onBackspace
  const handleKpBackspace = useCallback(() => {
    if (!activeKpCell) return;
    const { h, pi } = activeKpCell;
    cancelKpAdvance();

    if (kpValue.length > 0) {
      // Remove last char from in-progress value
      const next = kpValue.slice(0, -1);
      setKpValue(next);
      if (next === '') {
        // In-progress cleared — also clear committed score
        setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = ''; return n; });
        autoMark(h, pi, 0);
      } else {
        const v = Math.max(1, Math.min(15, parseInt(next) || 0));
        setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = v; return n; });
        autoMark(h, pi, v);
      }
    } else {
      // kpValue already empty
      const committed = scores[h]?.[pi];
      if (committed !== '' && committed != null) {
        // Clear committed score, stay on cell
        setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = ''; return n; });
        autoMark(h, pi, 0);
      } else {
        // Cell empty — retreat
        kpRetreatCell(h, pi);
      }
    }
  }, [activeKpCell, kpValue, scores, setScores, autoMark, cancelKpAdvance, kpRetreatCell]);

  // Dismiss keypad on outside tap — exempts INPUT elements, keypad container, and ZoomModal card
  useEffect(() => {
    if (!kpVisible) return;
    const handler = (e) => {
      if (e.target.tagName === 'INPUT') return;
      if (kpContainerRef.current?.contains(e.target)) return;
      if (zoomCardRef.current?.contains(e.target)) return;
      cancelKpAdvance();
      setActiveKpCell(null);
      setKpValue('');
    };
    document.addEventListener('touchend', handler, { capture: true });
    return () => document.removeEventListener('touchend', handler, { capture: true });
  }, [kpVisible, cancelKpAdvance]);

  // ── renderCell — replaces inline <input> in both renderHalf and renderLandscape
  // Renders a tappable div that opens the keypad on tap, long-presses for dots.
  // NX display: X scores show as "{xGross}X" with amber X and #fffbe6 background.
  // 13-C.2: Out-of-round cells render as a non-interactive gray cell with `–`.
  const renderCell = (h, pi, fontSize = 13, padding = '5px 0') => {
    const vertPad = (() => {
      const m = String(padding).match(/^(\d+(?:\.\d+)?)/);
      return m ? parseFloat(m[1]) * 2 : 10;
    })();
    const cellHeight = Math.round(fontSize * 1.2) + vertPad + 2;

    // 13-C.2: Out-of-round hole — gray, non-interactive, empty (no `–` char).
    // Owner preference: gray cell is a sufficient visual signal; character would
    // clash with scorecard readability. Par and M.Hcp rows keep their real values
    // (they're handled in renderHalf/renderLandscape, not here).
    if (!inRound(h)) {
      return (
        <div style={{ position: 'relative' }}>
          <div style={{
            width: '100%', boxSizing: 'border-box',
            border: '1px solid #e0e0e0',
            borderRadius: 4,
            textAlign: 'center',
            fontSize,
            fontFamily: 'inherit',
            background: '#e8e8e8',
            color: '#aaa',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: cellHeight,
            userSelect: 'none',
            WebkitUserSelect: 'none',
          }}/>
        </div>
      );
    }

    const dotCount  = sc(h, pi);
    const val       = scores[h]?.[pi] ?? '';
    const isX       = val === 'X';
    const isActive  = activeKpCell?.h === h && activeKpCell?.pi === pi;
    // In-progress kpValue display: show kpValue while this cell is active and user is mid-entry
    const displayVal = isActive && kpValue !== '' ? kpValue : (isX ? null : (val !== '' ? val : ''));

    const xGross = isX ? xGrossScore(h, courseHcps[pi], hcps, pars) : null;

    const cellStyle = {
      width: '100%', boxSizing: 'border-box',
      border: isActive ? `2px solid ${G}` : '1px solid #ddd',
      borderRadius: 4,
      textAlign: 'center',
      fontSize,
      fontFamily: 'inherit',
      background: isX ? '#fffbe6' : '#fff',
      color: '#222',
      outline: 'none',
      WebkitAppearance: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: cellHeight,
      cursor: canZoom ? 'pointer' : 'default',
      userSelect: 'none',
      WebkitUserSelect: 'none',
      position: 'relative',
    };

    if (!canZoom) {
      // Read-only — plain div, no interaction
      return (
        <div style={{ position: 'relative' }}>
          <div style={cellStyle}>
            {isX ? (
              <>{xGross}<span style={{ color: '#b8860b', fontWeight: 800, marginLeft: 1 }}>X</span></>
            ) : displayVal}
          </div>
          <DotBadge count={dotCount}/>
          {dotMode && !(dotMode === 'netofflow' && nonParticipantIdxs?.has(pi)) && (
            <PopDots courseHcp={courseHcps[pi]} hcpRank={hcps[h]}
              minCourseHcp={dotMode === 'netofflow' ? effectiveMinCourseHcp : minCourseHcp}
              mode={dotMode}/>
          )}
        </div>
      );
    }

    return (
      <div style={{ position: 'relative' }}>
        <div
          style={cellStyle}
          onMouseDown={e => {
            e.preventDefault();
            openKeypadOnCell(h, pi);
          }}
          onTouchStart={() => startLongPress(h, pi)}
          onTouchEnd={(e) => {
            e.preventDefault();
            const fired = longPressFired.current[`${h}_${pi}`];
            cancelLongPress(h, pi);
            if (!fired) openKeypadOnCell(h, pi);
          }}
          onTouchMove={() => cancelLongPress(h, pi)}
        >
          {isX ? (
            <>{xGross}<span style={{ color: '#b8860b', fontWeight: 800, marginLeft: 1 }}>X</span></>
          ) : displayVal}
        </div>
        <DotBadge count={dotCount}/>
        {dotMode && !(dotMode === 'netofflow' && nonParticipantIdxs?.has(pi)) && (
          <PopDots courseHcp={courseHcps[pi]} hcpRank={hcps[h]}
            minCourseHcp={dotMode === 'netofflow' ? effectiveMinCourseHcp : minCourseHcp}
            mode={dotMode}/>
        )}
      </div>
    );
  };

  // ── Zoom button — SVG magnifier ────────────────────────────────────────────
  const ZoomBtn = () => (
    <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 2, paddingRight: 2 }}>
      <button
        onClick={openZoom}
        title="Open zoom score entry"
        style={{
          background: 'none', border: 'none', cursor: 'pointer',
          padding: '2px 4px', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
        aria-label="Zoom score entry"
      >
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="7.5" stroke={G} strokeWidth="2.2"/>
          <line x1="17.8" y1="17.8" x2="24" y2="24" stroke={G} strokeWidth="2.4" strokeLinecap="round"/>
          <line x1="9" y1="12" x2="15" y2="12" stroke={G} strokeWidth="1.8" strokeLinecap="round"/>
          <line x1="12" y1="9" x2="12" y2="15" stroke={G} strokeWidth="1.8" strokeLinecap="round"/>
        </svg>
      </button>
    </div>
  );

  const renderHalf = (hs, halfLabel, showZoom = false) => {
    // 13-C.2: `hs` is the full 9-column Front/Back array. `inRoundHs` is the
    // subset actually played; totals (par, gross, net) are computed over the
    // in-round subset so they reflect only played holes. Par and M.Hcp rows
    // show real values for all 9 columns (owner preference — graying those
    // rows clashed with readability; only score cells go gray).
    const inRoundHs = hs.filter(inRound);
    return (
      <div style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
          <div style={{ fontWeight: 700, color: G, fontSize: 12 }}>{halfLabel}</div>
          {canZoom && showZoom && <ZoomBtn />}
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%', minWidth: NAME_MIN + hs.length * COL_W + TOT_W }}>
            <colgroup>
              <col/>
              {hs.map(h => <col key={h} style={{ width: COL_W }}/>)}
              <col style={{ width: TOT_W }}/>
            </colgroup>
            <thead><tr>
              <th style={{ padding: '4px 4px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'left' }}></th>
              {hs.map(h => <th key={h} style={{ padding: '3px 1px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              <th style={{ padding: '3px 3px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>Total</th>
            </tr></thead>
            <tbody>
              <tr>
                <td style={{ padding: '2px 6px', fontSize: 10, color: G, fontWeight: 700, background: '#f8fbf8' }}>Par</td>
                {hs.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 10, color: G, fontWeight: 600, background: '#f8fbf8' }}>{pars[h]}</td>)}
                <td style={{ textAlign: 'center', fontSize: 10, color: G, fontWeight: 700, background: '#f8fbf8' }}>{parTotal(inRoundHs)}</td>
              </tr>
              <tr>
                <td style={{ padding: '1px 6px', fontSize: 9, color: '#aaa', fontWeight: 600, background: '#fafcfa' }}>M.Hcp</td>
                {hs.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 9, color: '#ccc', background: '#fafcfa' }}>{hcps[h]}</td>)}
                <td/>
              </tr>
              {players.map((p, pi) => {
                const gt9 = grossTotal(pi, inRoundHs);
                const nt9 = netTotal(pi, inRoundHs);
                return <tr key={pi} style={{ background: pi % 2 === 0 ? '#fff' : '#f5fbf5' }}>
                  <td style={{ padding: '2px 4px', fontSize: 11, fontWeight: 600, color: '#333', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</td>
                  {hs.map(h => (
                    <td key={h} style={{ padding: 1, position: 'relative' }}>
                      {renderCell(h, pi, 13, '5px 0')}
                    </td>
                  ))}
                  <td style={{ textAlign: 'center', fontWeight: 700, color: '#222', fontSize: 11, padding: '2px 4px', whiteSpace: 'nowrap', lineHeight: 1.2 }}>
                    {gt9 || '-'}{gt9 > 0 && <><br/><span style={{ fontSize: 9, color: '#888', fontWeight: 400 }}>({nt9})</span></>}
                  </td>
                </tr>;
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderLandscape = () => {
    // 13-C.2: Render full 9-column Front and/or Back sections whenever the
    // round contains any hole in that half. Out-of-round cells show gray
    // background in SCORE rows only (via renderCell). Par and M.Hcp rows show
    // real values across all columns (owner preference — graying those rows
    // clashed with readability). Totals use in-round subsets.
    const FRONT = FULL_FRONT;
    const BACK  = FULL_BACK;
    const FRONT_IN = FRONT.filter(inRound);
    const BACK_IN  = BACK.filter(inRound);
    const ALL_IN   = [...FRONT_IN, ...BACK_IN];
    const hasFront = anyFrontInRound;
    const hasBack  = anyBackInRound;
    const isPartial = !(hasFront && hasBack);
    const frontCount = hasFront ? FRONT.length : 0;
    const backCount  = hasBack  ? BACK.length  : 0;
    const extraCols = (hasFront ? 1 : 0) + (hasBack ? 1 : 0) + 1;
    const tableMinW = NAME_MIN + (frontCount + backCount) * COL_W + extraCols * TOT_W;

    // E5 fix: for partial rounds (only Front or only Back rendered), use
    // natural table width so the name column doesn't expand to fill empty
    // space on the right. Full rounds keep width:100% to preserve existing
    // name-column stretch behavior on wide landscape screens.
    const tableWidth = isPartial ? tableMinW : '100%';

    return (
      <div style={{ marginBottom: 14 }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: tableWidth, minWidth: tableMinW }}>
            <colgroup>
              <col style={{ minWidth: NAME_MIN }}/>
              {hasFront && FRONT.map(h => <col key={h} style={{ width: COL_W }}/>)}
              {hasFront && <col style={{ width: TOT_W }}/>}
              {hasBack  && BACK.map(h  => <col key={h} style={{ width: COL_W }}/>)}
              {hasBack  && <col style={{ width: TOT_W }}/>}
              <col style={{ width: TOT_W }}/>
            </colgroup>
            <thead>
              <tr>
                <th style={{ padding: '3px 4px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'left' }}></th>
                {hasFront && FRONT.map(h => (
                  <th key={h} style={{ padding: '2px 1px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>{h+1}</th>
                ))}
                {hasFront && <th style={{ padding: '2px 3px', background: '#e8f0e8', color: G, fontSize: 10, fontWeight: 800, textAlign: 'center' }}>Total</th>}
                {hasBack  && BACK.map(h  => (
                  <th key={h} style={{ padding: '2px 1px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>{h+1}</th>
                ))}
                {hasBack  && <th style={{ padding: '2px 3px', background: '#e8f0e8', color: G, fontSize: 10, fontWeight: 800, textAlign: 'center' }}>Total</th>}
                <th style={{ padding: '2px 3px', background: '#d8ead8', color: G, fontSize: 10, fontWeight: 800, textAlign: 'center' }}>Total</th>
              </tr>
              <tr>
                <td style={{ padding: '1px 6px', fontSize: 9, color: G, fontWeight: 700, background: '#f8fbf8' }}>Par</td>
                {hasFront && FRONT.map(h => (
                  <td key={h} style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 600, background: '#f8fbf8' }}>{pars[h]}</td>
                ))}
                {hasFront && <td style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 700, background: '#f0f7f0' }}>{parTotal(FRONT_IN)}</td>}
                {hasBack  && BACK.map(h => (
                  <td key={h} style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 600, background: '#f8fbf8' }}>{pars[h]}</td>
                ))}
                {hasBack  && <td style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 700, background: '#f0f7f0' }}>{parTotal(BACK_IN)}</td>}
                <td style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 700, background: '#eaf4ea' }}>{parTotal(ALL_IN)}</td>
              </tr>
              <tr>
                <td style={{ padding: '1px 6px', fontSize: 9, color: '#aaa', fontWeight: 600, background: '#fafcfa' }}>M.Hcp</td>
                {hasFront && FRONT.map(h => (
                  <td key={h} style={{ textAlign: 'center', fontSize: 9, color: '#ccc', background: '#fafcfa' }}>{hcps[h]}</td>
                ))}
                {hasFront && <td style={{ background: '#fafcfa' }}/>}
                {hasBack  && BACK.map(h => (
                  <td key={h} style={{ textAlign: 'center', fontSize: 9, color: '#ccc', background: '#fafcfa' }}>{hcps[h]}</td>
                ))}
                {hasBack  && <td style={{ background: '#fafcfa' }}/>}
                <td style={{ background: '#fafcfa' }}/>
              </tr>
            </thead>
            <tbody>
              {players.map((p, pi) => {
                const gF = grossTotal(pi, FRONT_IN), nF = netTotal(pi, FRONT_IN);
                const gB = grossTotal(pi, BACK_IN),  nB = netTotal(pi, BACK_IN);
                return (
                  <tr key={pi} style={{ background: pi % 2 === 0 ? '#fff' : '#f5fbf5' }}>
                    <td style={{ padding: '2px 4px', fontSize: 11, fontWeight: 600, color: '#333', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</td>
                    {hasFront && FRONT.map(h => (
                      <td key={h} style={{ padding: 1, position: 'relative' }}>
                        {renderCell(h, pi, 12, '4px 0')}
                      </td>
                    ))}
                    {hasFront && (
                      <td style={{ textAlign: 'center', fontWeight: 700, color: G, fontSize: 10, padding: '1px 2px', background: '#f0f7f0', whiteSpace: 'nowrap', lineHeight: 1.1 }}>
                        {gF||'-'}{gF>0&&<><br/><span style={{ fontSize:8,color:'#888',fontWeight:400 }}>({nF})</span></>}
                      </td>
                    )}
                    {hasBack && BACK.map(h => (
                      <td key={h} style={{ padding: 1, position: 'relative' }}>
                        {renderCell(h, pi, 12, '4px 0')}
                      </td>
                    ))}
                    {hasBack && (
                      <td style={{ textAlign: 'center', fontWeight: 700, color: G, fontSize: 10, padding: '1px 2px', background: '#f0f7f0', whiteSpace: 'nowrap', lineHeight: 1.1 }}>
                        {gB||'-'}{gB>0&&<><br/><span style={{ fontSize:8,color:'#888',fontWeight:400 }}>({nB})</span></>}
                      </td>
                    )}
                    <td style={{ textAlign: 'center', fontWeight: 800, color: G, fontSize: 11, padding: '1px 3px', background: '#e8f4e8', whiteSpace: 'nowrap', lineHeight: 1.1 }}>
                      {(gF+gB)||'-'}{(gF+gB)>0&&<><br/><span style={{ fontSize:8,color:'#888',fontWeight:400 }}>(n{nF+nB})</span></>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const hasGameTables = ['Nines','Stableford','Skins','Stroke Play','Match / Nassau','Sixes'].some(g => activeGames.includes(g));

  return (
    <div>
      {/* DotsPopup — zIndex 400, renders above ZoomModal (zIndex 200) */}
      {popup && (
        <DotsPopup
          hole={popup.hole} pi={popup.pi}
          playerName={players[popup.pi]?.name}
          par={pars[popup.hole]}
          gross={parseInt(scores[popup.hole]?.[popup.pi]) || null}
          dots={dots} entries={dotEntries} setEntries={setDotEntries}
          sixesTeams={sixesTeams} matches={matches} players={players}
          gameOpts={gameOpts}
          onClose={() => {
            setPopup(null);
            // Restore keypad to the cell that was active before DotsPopup opened
            if (savedKpCellRef.current) {
              setActiveKpCell(savedKpCellRef.current);
              setKpValue('');
              savedKpCellRef.current = null;
            }
          }}
          courseHcps={courseHcps} hcps={hcps} minCourseHcp={minCourseHcp}
          paddingTop={zoomOpen ? 92 : undefined}
        />
      )}

      {/* ZoomModal — cells call onCellTap which routes to ScoreGrid's openKeypadOnCell */}
      {zoomOpen && (
        <ZoomModal
          players={players} pars={pars} hcps={hcps}
          courseHcps={courseHcps} minCourseHcp={minCourseHcp}
          effectiveMinCourseHcp={effectiveMinCourseHcp}
          nonParticipantIdxs={nonParticipantIdxs}
          scores={scores}
          dotMode={dotMode} isMixed={isMixed} setDotModeOverride={setDotModeOverride}
          nolDotGame={nolDotGame} setNolDotGame={setNolDotGame}
          nolDotOptions={nolDotOptions}
          startLongPress={startLongPress} cancelLongPress={cancelLongPress}
          dotsGameActive={dotsGameActive} sc={sc}
          zoomHole={zoomHole} setZoomHole={setZoomHole} setZoomOpen={closeZoom}
          setPopup={setPopup}
          activeKpCell={activeKpCell}
          onCellTap={(h, pi) => {
            // Don't open keypad if this tap was actually the finger-lift from a long-press
            if (longPressFired.current[`${h}_${pi}`]) return;
            openKeypadOnCell(h, pi);
          }}
          cardRef={zoomCardRef}
          roundStartHole={roundStartHole}
          roundEndHole={roundEndHole}
        />
      )}

      {isLandscape
        ? renderLandscape()
        : (
          <>
            {/* 13-C.2: Render Front 9 section (full 9 columns) whenever the  */}
            {/* round touches any front-9 hole. Out-of-round columns within   */}
            {/* the rendered section display as gray `–` (handled in          */}
            {/* renderCell). Par / M.Hcp rows also gray out via renderHalf.   */}
            {anyFrontInRound && renderHalf(FULL_FRONT, `Front 9${frontLabel ? ` (${frontLabel})` : ''}`, true)}
            {/* Back 9 section — same rule, rendered whenever round touches any back-9 hole. */}
            {anyBackInRound  && renderHalf(FULL_BACK,  `Back 9${backLabel  ? ` (${backLabel})`  : ''}`,  !anyFrontInRound)}
          </>
        )
      }
      {dotsGameActive && (
        <div style={{ fontSize: 10, color: '#888', marginBottom: 10 }}>Hold any score cell to log dots · ⚡ birdie/eagle/ace auto-marked</div>
      )}
      <div style={{ paddingTop: 4, marginTop: 4 }}>
        {/* 13-C.2: In landscape partial mode, constrain only the TotalsCard   */}
        {/* to match the compact scoregrid width. Game tables below remain     */}
        {/* full-width since column trimming is 13-C.3 scope.                  */}
        <div style={(() => {
          if (!isLandscape) return {};
          const isPartial = !(anyFrontInRound && anyBackInRound);
          if (!isPartial) return {};
          const frontCount = anyFrontInRound ? FULL_FRONT.length : 0;
          const backCount  = anyBackInRound  ? FULL_BACK.length  : 0;
          const extraCols  = (anyFrontInRound ? 1 : 0) + (anyBackInRound ? 1 : 0) + 1;
          const tableMinW  = NAME_MIN + (frontCount + backCount) * COL_W + extraCols * TOT_W;
          return { width: tableMinW, maxWidth: tableMinW };
        })()}>
          <TotalsCard
            players={players} pars={pars} scores={scores}
            courseHcps={courseHcps} hcps={hcps}
            minCourseHcp={minCourseHcp} primaryMode={primaryMode}
            roundStartHole={roundStartHole}
            roundNumHoles={roundNumHoles}
          />
        </div>
        {hasGameTables && (
          <>
            {activeGames.includes('Nines')           && <NinesTable        players={players} scores={scores} pars={pars} hcps={hcps} opts={gameOpts.Nines}          courseHcps={courseHcps} minCourseHcp={minCourseHcp} ninesPlayers={ninesPlayers}          isLandscape={isLandscape}/>}
            {activeGames.includes('Stableford')       && <StablefordTable   players={players} scores={scores} pars={pars} hcps={hcps} opts={gameOpts.Stableford}     courseHcps={courseHcps} minCourseHcp={minCourseHcp} stablefordPlayers={stablefordPlayers}  isLandscape={isLandscape}/>}
            {activeGames.includes('Skins')            && <SkinsTable        players={players} scores={scores}             hcps={hcps} opts={gameOpts.Skins}           courseHcps={courseHcps} minCourseHcp={minCourseHcp} skinsPlayerIdxs={skinsPlayers}          isLandscape={isLandscape}/>}
            {activeGames.includes('Stroke Play')      && <StrokePlayTable   players={players} scores={scores} pars={pars} hcps={hcps} opts={gameOpts['Stroke Play']} courseHcps={courseHcps} minCourseHcp={minCourseHcp} strokePlayPlayers={strokePlayPlayers}  isLandscape={isLandscape}/>}
            {activeGames.includes('Match / Nassau')   && <MatchNassauTable  players={players} scores={scores}             hcps={hcps} matches={matches || []}         courseHcps={courseHcps} minCourseHcp={minCourseHcp} manualPresses={manualPresses} setManualPresses={setManualPresses} isLandscape={isLandscape}/>}
            {activeGames.includes('Sixes') && <SixesTable players={players} scores={scores} hcps={hcps} opts={gameOpts.Sixes} courseHcps={courseHcps} minCourseHcp={minCourseHcp} sixesTeams={sixesTeams} manualPresses={manualPresses} setManualPresses={setManualPresses}/>}
          </>
        )}
        {dotsGameActive && (
          <DotsTable
            players={players} dots={dots} dotEntries={dotEntries}
            gameOpts={gameOpts} dotsPlayers={dotsPlayers}
            isLandscape={isLandscape}
            sixesTeams={sixesTeams}
            matches={matches}
          />
        )}
      </div>

      {/* ScoreKeypad — fixed-bottom overlay, hidden when ZoomModal is open */}
      <ScoreKeypad
        containerRef={kpContainerRef}
        visible={kpVisible}
        value={kpValue}
        onChange={handleKpChange}
        onBackspace={handleKpBackspace}
        onLongPressX={() => alert('Early departure — coming soon')}
      />
    </div>
  );
}
