// ─── NewRoundPage.jsx ─────────────────────────────────────────────────────────
import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ls, SK } from '../services/storage.js';
import { playerLib } from '../services/playerLib.js';
import { courseLib } from '../services/courseLib.js';
import { roundLib } from '../services/roundLib.js';
import { buildLayout, DEF_PARS, DEF_HCP, groupCourseHandicaps, minGroupHandicap, DEFAULT_STAB, courseHandicap, parseIndex } from '../engine/handicap.js';
import { DOTS_DEF, ALL_GAMES } from '../engine/games.js';
import { Btn, Sel, Inp, Tog, Card, BetInput, G, GA, GB, RED, AMB, AMBBG } from '../components/ui.jsx';
import { ACTION_BAR_HEIGHT, NAV_BAR_HEIGHT } from '../constants/layout.js';
import PlayerPickerPopup from './PlayerPickerPopup.jsx';
import GameConfig, { GameTile } from './tables/GameConfig.jsx';
import MatchCard from './MatchCard.jsx';
import { PlayerDropdown, StyledSel } from './PlayerDropdown.jsx';

const SETUP_KEY = 'golf_round_setup_v5';
const loadSetup = () => { try { return JSON.parse(localStorage.getItem(SETUP_KEY) || 'null'); } catch { return null; } };

// ─── GAME_CONFIGS ──────────────────────────────────────────────────────────────
// Static read-only constant — NEVER stored in gameOpts or any persisted state.
// Used only by the setup UI for display routing. (App_Data_Model_Contract §5.5a)
const GAME_CONFIGS = {
  'Match / Nassau': {
    betType: 'segment', modes: [{ value:'nassau', label:'Nassau' }, { value:'total', label:'Total' }],
    defaultMode: 'nassau', pressable: true, subsetPicker: false,
    scoringModes: ['gross','net','netofflow'], pairedOption: 'scoring',
  },
  'Stroke Play': {
    betType: 'segment', modes: [{ value:'total', label:'Total' }, { value:'segments', label:'F/B/T' }],
    defaultMode: 'total', pressable: false, subsetPicker: true, subsetMinPlayers: 2,
    scoringModes: ['gross','net','netofflow'], pairedOption: null,
  },
  'Nines': {
    betType: 'rate', modes: [{ value:'perpoint', label:'Per Point' }, { value:'segments', label:'F/B/T' }],
    defaultMode: 'perpoint', pressable: false, subsetPicker: true, subsetMinPlayers: 3, subsetRequired: 3,
    scoringModes: ['gross','net','netofflow'], pairedOption: 'niner',
  },
  'Stableford': {
    betType: 'rate', modes: [{ value:'perpoint', label:'Per Point' }, { value:'total', label:'Total' }, { value:'segments', label:'F/B/T' }],
    defaultMode: 'perpoint', pressable: false, subsetPicker: true, subsetMinPlayers: 2,
    scoringModes: ['gross','net','netofflow'], pairedOption: null, hasPointsTable: true,
  },
  'Skins': {
    betType: 'rate', modes: [{ value:'perSkin', label:'Per Skin' }, { value:'pot', label:'Pot' }],
    defaultMode: 'perSkin', pressable: false, subsetPicker: true, subsetMinPlayers: 2,
    scoringModes: ['gross','net','netofflow'], pairedOption: 'carryover',
  },
  'Sixes': {
    betType: 'perMatch', modes: [], defaultMode: null, pressable: true, subsetPicker: false,
    scoringModes: ['gross','net','netofflow'], pairedOption: 'scoring',
  },
  'Dots': {
    betType: 'rate', modes: [{ value:'spread', label:'Spread' }, { value:'total', label:'Total' }],
    defaultMode: 'spread', pressable: false, subsetPicker: true, subsetMinPlayers: 2,
    scoringModes: ['gross','net'], pairedOption: 'teamsMode', hasDotsTable: true,
  },
};

// ─── Helpers ───────────────────────────────────────────────────────────────────
function makeMatchId() { return `m_${Date.now()}_${Math.random().toString(36).slice(2,6)}`; }

function defaultMatch(players, format = 'individual') {
  if (format === 'individual') {
    const p1 = players.length >= 1 ? 0 : null;
    const p2 = players.length === 2 ? 1 : null;
    return { id: makeMatchId(), format: 'individual', p1, p2, grossNetNOL: 'net', autoPressF: 'none', autoPressB: 'none', autoPressO: 'none', scoring: 'none', betFront: 0, betBack: 0, betOverall: 0 };
  }
  const tA = players.length >= 4 ? [0, 1] : [];
  const tB = players.length >= 4 ? [2, 3] : [];
  return { id: makeMatchId(), format: 'team', teamA: tA, teamB: tB, grossNetNOL: 'net', autoPressF: 'none', autoPressB: 'none', autoPressO: 'none', scoring: 'none', betFront: 0, betBack: 0, betOverall: 0 };
}

// ─── CoursePickerPopup ─────────────────────────────────────────────────────────
// Bottom-sheet popup for selecting a course, mirrors PlayerPickerPopup pattern.
function CoursePickerPopup({ allCourses, snapshotCourse, selectedId, onConfirm, onClose }) {
  const [picked, setPicked] = useState(selectedId || '');
  const courses = [
    ...(snapshotCourse && !allCourses.find(c => c.id === snapshotCourse.id)
      ? [{ ...snapshotCourse, _fromHistory: true }] : []),
    ...allCourses,
  ];
  return (
    <div style={{ position:'fixed',inset:0,background:'rgba(0,0,0,.5)',zIndex:300,display:'flex',alignItems:'flex-end',justifyContent:'center' }} onClick={onClose}>
      <div style={{ background:'#fff',borderRadius:'20px 20px 0 0',width:'100%',maxWidth:520,maxHeight:'80vh',display:'flex',flexDirection:'column' }} onClick={e=>e.stopPropagation()}>
        <div style={{ overflowY:'auto',flex:1,padding:'20px 20px 8px' }}>
          <div style={{ fontWeight:800,fontSize:17,color:G,marginBottom:4 }}>Select Course</div>
          <div style={{ fontSize:11,color:'#888',marginBottom:14 }}>Tap to select</div>
          <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
            {courses.map(c => {
              const sel = picked === c.id;
              return (
                <div key={c.id} onClick={() => { setPicked(c.id); }}
                  style={{ padding:'11px 14px',borderRadius:12,border:`1.5px solid ${sel?G:'#eee'}`,background:sel?GA:'#fff',cursor:'pointer' }}>
                  <div style={{ fontWeight:700,fontSize:14,color:sel?G:'#222' }}>{c.name}{c._fromHistory ? <span style={{ fontSize:11,fontWeight:400,color:'#aaa',marginLeft:6 }}>(from history)</span> : ''}</div>
                  {c.location && <div style={{ fontSize:11,color:'#888',marginTop:1 }}>{c.location}</div>}
                  {c.tees?.length > 0 && <div style={{ fontSize:11,color:'#aaa',marginTop:1 }}>{c.tees.map(t=>t.name).join(' · ')}</div>}
                </div>
              );
            })}
          </div>
        </div>
        <div style={{ padding:'10px 20px 24px',borderTop:'1px solid #eee',background:'#fff',flexShrink:0 }}>
          <div style={{ display:'flex',gap:8 }}>
            <Btn variant="outline" onClick={onClose} style={{ flex:1 }}>Cancel</Btn>
            <Btn onClick={() => onConfirm(picked)} disabled={!picked} style={{ flex:2 }}>Confirm</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── NineDropdown ──────────────────────────────────────────────────────────────
// Styled dropdown for selecting a nine (e.g. Front 9 / Back 9).
function NineDropdown({ nines, value, onChange, label }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    document.addEventListener('touchstart', h);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('touchstart', h); };
  }, [open]);
  const selected = nines.find(n => n.name === value);
  return (
    <div ref={ref} style={{ position:'relative' }}>
      <div onClick={() => setOpen(o => !o)}
        style={{ borderRadius:20, padding:'6px 10px', border:`1.5px solid ${value ? G : '#ddd'}`, background:value ? GA : '#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', gap:4 }}>
        {selected
          ? <span style={{ fontSize:12, fontWeight:700, color:G }}>{selected.name} <span style={{ fontWeight:400, opacity:0.7 }}>(par {selected.pars?.reduce((a,b)=>a+b,0)})</span></span>
          : <span style={{ fontSize:12, color:'#aaa' }}>{label}</span>}
        <span style={{ fontSize:9, color:value ? G : '#bbb', flexShrink:0 }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && (
        <div style={{ position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:50, background:'#fff', border:`1.5px solid ${G}`, borderRadius:12, padding:'8px', boxShadow:'0 4px 16px rgba(0,0,0,0.13)' }}>
          {nines.map(n => {
            const sel = n.name === value;
            return (
              <div key={n.name} onClick={() => { onChange(n.name); setOpen(false); }}
                style={{ borderRadius:10, padding:'7px 10px', border:`1.5px solid ${sel?G:'#ddd'}`, background:sel?GA:'#f9fdf9', cursor:'pointer', marginBottom:5 }}>
                <span style={{ fontSize:12, fontWeight:700, color:sel?G:'#333' }}>{n.name}</span>
                <span style={{ fontSize:11, color:'#888', marginLeft:6 }}>par {n.pars?.reduce((a,b)=>a+b,0)}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── TeeDropdown ───────────────────────────────────────────────────────────────
// Styled dropdown for per-player tee selection.
// Trigger height matches HI/CH input fields (padding:'5px 4px', fontSize:12, borderRadius:7).
function TeeDropdown({ tees, value, onChange, label }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    document.addEventListener('touchstart', h);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('touchstart', h); };
  }, [open]);
  const selected = tees.find(t => t.name === value);
  return (
    <div ref={ref} style={{ position:'relative' }}>
      <div onClick={() => setOpen(o => !o)}
        style={{ borderRadius:7, padding:'5px 6px', border:`1px solid ${value ? G : '#ddd'}`,
                 background:value ? GA : '#fff', cursor:'pointer',
                 display:'flex', alignItems:'center', justifyContent:'space-between', gap:3,
                 width:'100%', boxSizing:'border-box' }}>
        {selected ? (
          <span style={{ fontSize:12, fontWeight:700, color:G,
                         overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', flex:1 }}>
            {selected.name}
          </span>
        ) : (
          <span style={{ fontSize:12, color:'#aaa', flex:1 }}>{label}</span>
        )}
        <span style={{ fontSize:9, color:value ? G : '#bbb', flexShrink:0 }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && (
        <div style={{ position:'absolute', top:'calc(100% + 4px)', right:0, zIndex:50,
                      background:'#fff', border:`1.5px solid ${G}`, borderRadius:12,
                      padding:'8px', boxShadow:'0 4px 16px rgba(0,0,0,0.13)', minWidth:160 }}>
          {tees.map(t => {
            const sel = t.name === value;
            return (
              <div key={t.name} onClick={() => { onChange(t.name); setOpen(false); }}
                style={{ borderRadius:10, padding:'6px 10px', border:`1.5px solid ${sel?G:'#ddd'}`,
                         background:sel?GA:'#f9fdf9', cursor:'pointer', marginBottom:5,
                         display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:12, fontWeight:700, color:sel?G:'#333' }}>{t.name}</span>
                {(t.rating || t.slope) && <span style={{ fontSize:11, color:'#888', marginLeft:8 }}>{t.rating}/{t.slope}</span>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── HIField ───────────────────────────────────────────────────────────────────
// HI input: shows "HI" as value when empty+blurred; shows raw number when focused.
function HIField({ value, onChange, onBlur }) {
  const [focused, setFocused] = useState(false);
  const G = '#1a472a';
  const hasVal = value !== '' && value != null;

  return (
    <input
      type="text"
      inputMode="decimal"
      value={focused ? value : (hasVal ? `HI: ${parseFloat(value).toFixed(1)}` : 'HI')}
      onFocus={e => { setFocused(true); setTimeout(() => e.target.select(), 0); }}
      onChange={e => onChange(e.target.value)}
      onBlur={() => { setFocused(false); if (onBlur) onBlur(value); }}
      style={{
        border:'1px solid #ddd', borderRadius:7, padding:'5px 4px',
        fontSize:12, textAlign:'center', fontFamily:'inherit',
        width:'100%', boxSizing:'border-box',
        color: hasVal ? G : '#ccc',
        fontWeight: hasVal ? 700 : 400,
      }}
    />
  );
}

// ─── CHField ───────────────────────────────────────────────────────────────────
// CH display: shows calculated or manual value; tapping enters edit mode.
// isManual=true shows an indicator that value was entered manually.
function CHField({ ch, isManual, onManualEntry }) {
  const [editing, setEditing] = useState(false);
  const [draft,   setDraft]   = useState('');
  const hasVal = ch != null;

  if (editing) {
    return (
      <input
        type="text" inputMode="numeric" autoFocus
        value={draft}
        placeholder="CH"
        onChange={e => setDraft(e.target.value)}
        onBlur={() => {
          const v = parseInt(draft);
          if (!isNaN(v) && v >= 0) onManualEntry(v);
          setEditing(false);
          setDraft('');
        }}
        onKeyDown={e => {
          if (e.key === 'Enter') e.target.blur();
          if (e.key === 'Escape') { setEditing(false); setDraft(''); }
        }}
        style={{ width:'100%', boxSizing:'border-box', border:`1px solid ${G}`, borderRadius:7,
                 padding:'5px 4px', fontSize:12, textAlign:'center', fontFamily:'inherit',
                 fontWeight:700, color:G }}
      />
    );
  }

  return (
    <div
      onClick={() => { setEditing(true); setDraft(hasVal ? String(ch) : ''); }}
      style={{ textAlign:'center', fontSize:12, fontWeight: hasVal ? 700 : 400,
               color: hasVal ? G : '#ccc',
               border:`1px solid ${isManual ? G : '#ddd'}`,
               borderRadius:7, padding:'5px 4px',
               background:'#fff', boxSizing:'border-box',
               display:'flex', alignItems:'center', justifyContent:'center',
               cursor:'text', width:'100%' }}>
      {hasVal ? `CH: ${Math.round(ch)}` : 'CH'}
    </div>
  );
}

// ─── NewRoundPage ──────────────────────────────────────────────────────────────
export default function NewRoundPage({ onStart, onGoScorecard, onSaveEdits, inProgress, loadedRound, onLoadedRoundConsumed, getActiveRound, startTriggerRef }) {
  const allPlayers = useMemo(() => playerLib.list(), []);
  const allCourses = useMemo(() => courseLib.list(), []);

  // initSrc is used for useState initializers AND by handleStart for dot_entries/
  // reloadedScores preservation. It must be frozen at mount — loadedRound is
  // cleared by onLoadedRoundConsumed after mount, causing re-renders where
  // loadedRound becomes null. Without freezing, handleStart would read the
  // post-clear initSrc (= setup draft, no dot_entries) and wipe manual dots.
  const initSrcRef = useRef(loadedRound || loadSetup());
  const initSrc    = initSrcRef.current;

  // A-10: Use local date, not UTC. toISOString() returns UTC which shows
  // tomorrow's date for US timezones after ~5pm.
  const today = (() => {
    const d = new Date();
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  })();

  const [roundDate,           setRoundDate]           = useState(loadedRound?.roundDate || today);
  const [selectedCourseId,    setSelectedCourseId]    = useState(initSrc?.selectedCourseId || '');
  const [frontNine,           setFrontNine]            = useState(initSrc?.frontNine || '');
  const [backNine,            setBackNine]             = useState(initSrc?.backNine || '');
  const [selectedTee,         setSelectedTee]          = useState(initSrc?.selectedTee || '');
  const [selectedPlayerIds,   setSelectedPlayerIds]    = useState(initSrc?.selectedPlayerIds || []);
  const [activeGames,         setActiveGames]          = useState(initSrc?.activeGames || []);
  const [gameOpts,            setGameOpts]             = useState(initSrc?.gameOpts || {});
  const [gameBets,            setGameBets]             = useState(initSrc?.gameBets || {});
  const [matches,             setMatches]              = useState(initSrc?.matches || []);
  const [strokePlayPlayers,   setStrokePlayPlayers]    = useState(initSrc?.strokePlayPlayers || []);
  const [skinsPlayers,        setSkinsPlayers]         = useState(initSrc?.skinsPlayers || []);
  const [ninesPlayers,        setNinesPlayers]         = useState(initSrc?.ninesPlayers || []);
  const [stablefordPlayers,   setStablefordPlayers]    = useState(initSrc?.stablefordPlayers || []);
  const [dotsPlayers,         setDotsPlayers]          = useState(initSrc?.dotsPlayers || []);
  // G-1 fix: sixesPlayers was missing entirely from state — added here.
  const [sixesPlayers,        setSixesPlayers]         = useState(initSrc?.sixesPlayers || []);
  const [sixesTeams,          setSixesTeams]           = useState(initSrc?.sixesTeams || [null, null, null]);
  const [dots,                setDots]                 = useState(initSrc?.dots || DOTS_DEF.map(s => ({...s})));
  const [showPlayerPicker,    setShowPlayerPicker]     = useState(false);
  const [showCoursePicker,    setShowCoursePicker]     = useState(false);
  const [isReload,            setIsReload]             = useState(!!loadedRound?.isReload);

  // 13-C.2: Round length state — stored 0-based internally, displayed 1-based in UI.
  // Defaults: start hole 1 (index 0), 18 holes (full round).
  // PartialGameContract §1A.1, §1A.2.
  const [roundStartHole, setRoundStartHole] = useState(initSrc?.roundStartHole ?? 0);
  const [roundNumHoles,  setRoundNumHoles]  = useState(initSrc?.roundNumHoles  ?? 18);

  // 13-C.2: Draft strings for the Start Hole / End Hole inputs.
  // Clamping on every keystroke snaps the field to the min/max mid-typing,
  // blocking legitimate multi-digit entries (e.g. typing "12" starts at "1"
  // which was clamped up to min 3). Decoupling the input string from the
  // numeric state lets the field hold any transient text during editing;
  // we validate and clamp only on blur. `null` means the input is not being
  // edited — it shows the committed numeric value derived from state.
  const [startHoleDraft, setStartHoleDraft] = useState(null);
  const [endHoleDraft,   setEndHoleDraft]   = useState(null);
  // Manual CH overrides: { [playerId]: number } — set when user types directly into CH field.
  // On back-to-setup restore: if a player snapshot has courseHcpVal but no ghin (meaning
  // they used a manual CH entry rather than HI), restore that value as an override so the
  // CH field shows the correct value rather than recalculating from a missing HI.
  const [playerCHOverrides, setPlayerCHOverrides] = useState(() => {
    const src = initSrc?.playerSnapshots || [];
    const overrides = {};
    src.forEach(p => {
      if (p.courseHcpVal != null && (!p.ghin || p.ghin.toString().trim() === '')) {
        overrides[p.id] = p.courseHcpVal;
      }
    });
    return overrides;
  });

  // B-2 fix: courseSnapshot and playerSnapshots are frozen into state at mount.
  // They must NEVER be recomputed from loadedRound after mount — App.jsx clears
  // loadedRound immediately after mount via onLoadedRoundConsumed, so any value
  // derived from loadedRound outside of useState would become null on the next
  // render. These are the authoritative time-capsule values for the round being
  // edited. They never fall back to the live library.
  const [courseSnapshot,  setCourseSnapshot]  = useState(initSrc?.courseSnapshot  || null);
  const [playerSnapshots, setPlayerSnapshots] = useState(initSrc?.playerSnapshots || []);

  // G-2/G-3: Per-player HI and tee state (replaces HIConfirmPopup).
  // playerHIs: { [playerId]: string } — editable HI for each player
  // playerTees: { [playerId]: string } — selected tee name per player
  // Initialized from frozen playerSnapshots (reload) or player library (new round).
  const [playerHIs, setPlayerHIs] = useState(() => {
    const src = initSrc?.playerSnapshots || [];
    return Object.fromEntries(src.map(p => [p.id, p.ghin || '']));
  });
  const [playerTees, setPlayerTees] = useState(() => {
    // Restore per-player tees from frozen snapshots (reload path), else default to selectedTee
    const src = initSrc?.playerSnapshots || [];
    const fallback = initSrc?.selectedTee || '';
    return Object.fromEntries(src.map(p => [p.id, p.selectedTee || fallback]));
  });

  useEffect(() => {
    if (loadedRound && onLoadedRoundConsumed) onLoadedRoundConsumed();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // B-3 fix: freeze roundId at mount from loadedRound (not initSrc).
  // initSrc may fall through to the setup draft on re-renders after
  // onLoadedRoundConsumed clears loadedRound — the draft has no roundId.
  // loadedRound is only available on the first render, so we capture it here.
  const roundIdRef = useRef(loadedRound?.roundId || null);

  const isReloadRef = useRef(!!loadedRound?.isReload);
  useEffect(() => {
    if (isReloadRef.current) return;
    localStorage.setItem(SETUP_KEY, JSON.stringify({
      roundDate, selectedCourseId, frontNine, backNine, selectedTee,
      selectedPlayerIds, activeGames, gameOpts, gameBets,
      matches, strokePlayPlayers, skinsPlayers, ninesPlayers, stablefordPlayers,
      dotsPlayers, sixesPlayers, sixesTeams, dots,
      // 13-C.2: Persist round length so user's choice survives reloads/drafts.
      roundStartHole, roundNumHoles,
    }));
  }, [roundDate, selectedCourseId, frontNine, backNine, selectedTee, selectedPlayerIds, activeGames,
      gameOpts, gameBets, matches, strokePlayPlayers, skinsPlayers, ninesPlayers, stablefordPlayers,
      dotsPlayers, sixesPlayers, sixesTeams, dots,
      roundStartHole, roundNumHoles]);

  // B-2 fix: In reload mode, the course comes from the frozen snapshot only —
  // never from the live library. The snapshot is the authoritative time capsule.
  // In new-round mode, the course comes from the library (user is picking a course).
  const courseFromLib  = allCourses.find(c => c.id === selectedCourseId) || null;
  const course = isReload
    ? (courseFromLib || courseSnapshot || null)
    : (courseFromLib || null);

  const handleCourseSelect = (id) => {
    setSelectedCourseId(id);
    const c = allCourses.find(x => x.id === id);
    if (c) {
      setFrontNine(c.nines?.[0]?.name || '');
      setBackNine(c.nines?.[1]?.name || c.nines?.[0]?.name || '');
      // Do not auto-pick a tee — start blank so user makes an intentional choice.
      // First player to pick a tee will propagate to all others (see TeeDropdown onChange).
      setSelectedTee('');
      setPlayerTees(prev => {
        const cleared = { ...prev };
        Object.keys(cleared).forEach(pid => { cleared[pid] = ''; });
        return cleared;
      });
    }
  };

  const toggleGame = (g) => {
    setActiveGames(prev => {
      const next = prev.includes(g) ? prev.filter(x => x !== g) : [...prev, g];
      if (g === 'Match / Nassau' && !prev.includes(g)) {
        if (matches.length === 0) setMatches([defaultMatch(activePlayers)]);
      }
      return next;
    });
  };

  const setOpt = (g, k, v) => setGameOpts(prev => ({ ...prev, [g]: { ...(prev[g]||{}), [k]: v } }));

  const layout = course ? buildLayout(course.nines || [], frontNine, backNine) : null;
  const pars   = layout?.pars || DEF_PARS;
  const hcps   = layout?.hcps || DEF_HCP;
  // Per-game default for grossNetNOL when neither field is stored.
  // NOTE: Stableford is listed here explicitly so allOpts never falls back to
  // o.scoring for grossNetNOL — in Stableford, opts.scoring holds the team
  // hole-scoring rule ('cumulative'|'bestball'), not a handicap mode value.
  const GNL_DEFAULTS = { 'Stroke Play': 'gross', Dots: 'gross', Stableford: 'net' };
  const allOpts = Object.fromEntries(ALL_GAMES.map(g => {
    const o = gameOpts[g] || {};
    // Always write grossNetNOL explicitly so activeRound never has an absent mode field.
    // Stableford skips the o.scoring fallback (collision risk — see NOTE above).
    const gnl = o.grossNetNOL ?? (g === 'Stableford' ? null : o.scoring) ?? (GNL_DEFAULTS[g] || 'net');
    return [g, { ...o, grossNetNOL: gnl, bet: gameBets[g] || 0 }];
  }));

  // playerSnapshots is frozen in state at mount (see useState above).
  // activePlayers resolves each selected ID against the live library first,
  // then falls back to the frozen snapshot. In reload mode the snapshot IS
  // the authoritative source, so players not in the current library still load.
  const activePlayers = selectedPlayerIds.map(id => {
    const snap = playerSnapshots.find(p => p.id === id);
    if (snap) return snap;                          // snapshot always wins in reload
    return allPlayers.find(p => p.id === id) || null; // new-round: live library only
  }).filter(Boolean);

  // G-2/G-3: When selectedPlayerIds changes, initialise any new players' HI and tee.
  useEffect(() => {
    setPlayerHIs(prev => {
      const next = { ...prev };
      activePlayers.forEach(p => {
        if (!(p.id in next)) next[p.id] = p.ghin || '';
      });
      return next;
    });
    setPlayerTees(prev => {
      const next = { ...prev };
      activePlayers.forEach(p => {
        if (!(p.id in next)) next[p.id] = selectedTee || '';
      });
      return next;
    });
  }, [selectedPlayerIds]); // eslint-disable-line react-hooks/exhaustive-deps

  // G-3: Compute per-player course handicap for display in the Players card.
  // Returns the manual override if set, otherwise calculates from HI.
  // Returns null if HI is absent or no tee data available.
  const computePlayerCH = (playerId, hiStr) => {
    if (playerCHOverrides[playerId] != null) return playerCHOverrides[playerId];
    // No HI entered — nothing to compute
    if (!hiStr || hiStr.toString().trim() === '') return null;
    const teeName = playerTees[playerId] || selectedTee || '';
    const tee = course?.tees?.find(t => t.name === teeName) || null;
    const totalPar = pars.reduce((a, b) => a + b, 0);
    return courseHandicap(parseIndex(hiStr), tee?.slope, tee?.rating, totalPar);
  };

  // 13-C.2: Round length validation (operates on committed state only; the
  // per-input drafts are never validated until blur).
  // Rules: start hole 1–18, end hole ≤ 18 and ≥ start + 2 (min 3 holes).
  const roundLengthError = useMemo(() => {
    if (!Number.isInteger(roundStartHole) || roundStartHole < 0 || roundStartHole > 17) {
      return 'Start hole must be between 1 and 18.';
    }
    if (!Number.isInteger(roundNumHoles) || roundNumHoles < 3) {
      return 'Round must be at least 3 holes.';
    }
    if (roundStartHole + roundNumHoles - 1 > 17) {
      return `A round starting on hole ${roundStartHole + 1} cannot end past hole 18.`;
    }
    return '';
  }, [roundStartHole, roundNumHoles]);

  const handleStart = () => {
    if (activePlayers.length < 2) { alert('Select at least 2 players'); return; }

    // 13-C.2: Block start if round length is invalid. Message is also shown
    // inline below the pickers, but we alert here to match the existing
    // validation-blocker pattern (Sixes/Nines/Stableford below).
    if (roundLengthError) { alert(roundLengthError); return; }

    // G-5: Sixes requires exactly 4 players (Round Lifecycle Contract §2.5, §14)
    if (activeGames.includes('Sixes') && activePlayers.length === 5) {
      alert('Sixes requires 4 players. A 5-player subset picker for Sixes is not yet available. Remove one player or disable Sixes to continue.');
      return;
    }

    // Nines requires exactly 3 players selected in a 4+ player round (Nines Contract §9 / G-5)
    if (activeGames.includes('Nines') && activePlayers.length > 3 && (ninesPlayers||[]).length < 3) {
      alert('Nines requires exactly 3 players to be selected. Please select 3 players in the Nines options.');
      return;
    }

    // G-4: Score-overwrite warning (Round Lifecycle Contract §2.6)
    // Only warn when lineup has changed AND the existing round has scored holes.
    const existingAr = getActiveRound ? getActiveRound() : null;
    if (existingAr) {
      const existingPlayerIds = existingAr.activePlayers?.map(p => p.id) ?? [];
      const newPlayerIds = activePlayers.map(p => p.id);
      const lineupChanged =
        existingPlayerIds.length !== newPlayerIds.length ||
        existingPlayerIds.some((id, i) => id !== newPlayerIds[i]);
      const hasScores = existingAr.scores?.some(holeScores =>
        holeScores?.some(s => s !== '' && s != null)
      );
      if (lineupChanged && hasScores) {
        const ok = window.confirm('Starting a new round will erase all current scores. Continue?');
        if (!ok) return;
      }
    }

    // Stableford team mode requires both teams fully assigned
    if (activeGames.includes('Stableford') && (gameOpts.Stableford?.format ?? 'individual') === 'team') {
      const tA = gameOpts.Stableford?.teamA ?? [];
      const tB = gameOpts.Stableford?.teamB ?? [];
      if (tA.length < 2 || tB.length < 2) {
        alert('Stableford Teams requires 2 players on each team. Please assign all players before starting.');
        return;
      }
    }


    // Update player library records if HI changed.
    const updatedPlayers = activePlayers.map(p => ({
      ...p,
      ghin: playerHIs[p.id] ?? p.ghin,
      selectedTee: playerTees[p.id] || selectedTee || '',
    }));
    updatedPlayers.forEach(p => {
      const orig = allPlayers.find(x => x.id === p.id);
      if (orig && orig.ghin !== p.ghin) playerLib.update(p.id, { ghin: p.ghin });
    });

    // G-3: Build per-player tee array for groupCourseHandicaps
    const perPlayerTees = updatedPlayers.map(p => {
      const teeName = p.selectedTee || selectedTee || '';
      return course?.tees?.find(t => t.name === teeName) || null;
    });

    const courseHcps   = groupCourseHandicaps(updatedPlayers, perPlayerTees, pars);
    // Apply manual CH overrides — if user typed a CH directly, use that instead of calculated value
    const finalCourseHcps = courseHcps.map((ch, i) => {
      const pid = updatedPlayers[i]?.id;
      return (pid && playerCHOverrides[pid] != null) ? playerCHOverrides[pid] : ch;
    });
    const minCourseHcp = minGroupHandicap(finalCourseHcps);

    // Preserve existing scores/dotEntries only when lineup is unchanged
    const existingAr2 = getActiveRound ? getActiveRound() : null;
    const existingPlayerIds2 = existingAr2?.activePlayers?.map(p => p.id) ?? [];
    const newPlayerIds2 = updatedPlayers.map(p => p.id);
    const playerLineupUnchanged =
      existingAr2 &&
      existingPlayerIds2.length === newPlayerIds2.length &&
      existingPlayerIds2.every((id, i) => id === newPlayerIds2[i]);

    const scores = isReload && initSrc?.reloadedScores?.length
      ? initSrc.reloadedScores
      : playerLineupUnchanged && existingAr2?.scores
        ? existingAr2.scores
        : Array.from({ length: 18 }, () => new Array(updatedPlayers.length).fill(''));

    const dotEntries = isReload
      ? (initSrc?.dot_entries || {})
      : playerLineupUnchanged && existingAr2?.dotEntries
        ? existingAr2.dotEntries
        : {};

    const manualPresses = isReload
      ? (initSrc?.manual_presses || {})
      : playerLineupUnchanged && existingAr2?.manualPresses
        ? existingAr2.manualPresses
        : {};

    // G-1: sixesPlayers is now included in roundState.
    // B-3 fix: roundId comes from roundIdRef (frozen at mount from loadedRound)
    // NOT from initSrc — initSrc may be the setup draft after onLoadedRoundConsumed
    // clears loadedRound, and the draft has no roundId.
    const roundState = {
      roundId:  roundIdRef.current,
      roundDate, course, frontNine, backNine, selectedTee, layout, pars, hcps,
      activePlayers: updatedPlayers.map((p, i) => ({ ...p, courseHcpVal: finalCourseHcps[i] })),
      courseHcps: finalCourseHcps, minCourseHcp,
      activeGames,
      gameOpts: allOpts,
      matches,
      strokePlayPlayers,
      skinsPlayers,
      // Auto-populate ninesPlayers for 3-player rounds (picker never shown; Nines Contract §9 G-5).
      ninesPlayers: activeGames.includes('Nines') && updatedPlayers.length === 3
        ? [0, 1, 2]
        : (ninesPlayers || []),
      stablefordPlayers,
      sixesTeams,
      sixesPlayers,
      dotsPlayers,
      dots,
      dotEntries,
      manualPresses,
      scores,
      // 13-C.2: Round length — written to activeRound blob so downstream
      // consumers (ScoreGrid, computePayouts, strokePlayIncompleteMsg) see
      // the user's choice. Defaults (0, 18) preserve full-round behavior.
      roundStartHole,
      roundNumHoles,
    };
    onStart(roundState);
  };

  // Expose handleStart to parent via ref so the center nav button can trigger
  // Start Scoring without the user having to tap the button explicitly.
  useEffect(() => {
    if (startTriggerRef) startTriggerRef.current = handleStart;
  }); // no dep array — always keep ref current with latest handleStart closure

  const handleResumeReload = () => { onGoScorecard(); };

  const handleSaveEdits = () => {
    const roundId = initSrc?.roundId;
    if (!roundId) { alert('Cannot save: original round ID missing.'); return; }

    // Build updated player snapshots reflecting any HI or tee changes made in setup.
    const updatedPlayerSnapshots = activePlayers.map(p => ({
      id:           p.id,
      name:         p.name,
      gender:       p.gender || '',
      ghin:         playerHIs[p.id] ?? p.ghin ?? '',
      courseHcpVal: p.courseHcpVal ?? null,
      selectedTee:  playerTees[p.id] || selectedTee || '',
    }));

    const changes = {
      date:                roundDate,
      course_name:         course?.name || 'Unknown',
      course_snapshot:     course       || null,
      front_nine:          frontNine,
      back_nine:           backNine,
      selected_tee:        selectedTee,
      players:             updatedPlayerSnapshots,
      active_games:        activeGames,
      game_opts:           allOpts,
      matches,
      stroke_play_players: strokePlayPlayers,
      skins_players:       skinsPlayers,
      nines_players:       ninesPlayers,
      stableford_players:  stablefordPlayers,
      sixes_teams:         sixesTeams,
      sixes_players:       sixesPlayers,
      dots_players:        dotsPlayers,
      dots,
    };
    roundLib.update(roundId, changes);
    if (onSaveEdits) onSaveEdits();
  };

  return (
    <div style={{ minHeight: '100vh', background: '#eef4ee' }}>
      <div style={{ background:G, padding:'8px 16px 7px', position:'sticky', top:0, zIndex:10, boxShadow:'0 2px 12px rgba(0,0,0,.2)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <img src="/logo_lockup.png" alt="The Card" style={{ height:58, width:'auto', display:'block' }} />
        <div style={{ color:'#fff', fontWeight:800, fontSize:16, letterSpacing:'0.12em', textTransform:'uppercase', fontFamily:'inherit' }}>
          {isReload ? 'Edit Round' : 'New Round'}
        </div>
      </div>

      <div style={{ padding: '14px 14px', maxWidth: 520, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 12, paddingBottom: ACTION_BAR_HEIGHT + 16 }}>

        {/* Reload banner */}
        {isReload && (
          <div style={{ background:'#e8f5e8', border:'1.5px solid #a0d0a0', borderRadius:12, padding:'12px 14px' }}>
            <div style={{ fontWeight:700, fontSize:13, color:G, marginBottom:4 }}>Editing Historical Round</div>
            <div style={{ fontSize:12, color:'#555', marginBottom:10 }}>
              Change the date, bets, games, or tee below, then tap <strong>Save Changes</strong> to update without touching scores.
              Or tap <strong>Go to Scorecard</strong> to correct individual scores.
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <Btn onClick={handleSaveEdits} style={{ flex:1 }}>Save Changes</Btn>
              <Btn variant="outline" onClick={handleResumeReload} style={{ flex:1 }}>Go to Scorecard</Btn>
            </div>
          </div>
        )}

        {/* Resume banner */}
        {inProgress && !isReload && (
          <div style={{ background:'#fff9e6', border:'1.5px solid #f0c040', borderRadius:12, padding:'10px 14px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div style={{ fontSize:13, color:RED, fontWeight:700 }}>Round in progress</div>
            <Btn small onClick={onGoScorecard} style={{ background:RED, color:'#fff', border:'none' }}>Resume →</Btn>
          </div>
        )}

        {/* Date */}
        <Card>
          <div style={{ fontSize:12, fontWeight:700, color:'#666', marginBottom:5 }}>Round Date</div>
          <input
            type="date"
            value={roundDate}
            onChange={e => setRoundDate(e.target.value)}
            style={{ width:'100%', boxSizing:'border-box', border:'1px solid #ddd', borderRadius:8,
              padding:'8px 10px', fontSize:13, fontFamily:'inherit', background:'#fff',
              color:G, fontWeight:600, outline:'none', WebkitAppearance:'none', display:'block' }}
          />
        </Card>

        {/* Course */}
        <Card>
          <div style={{ fontWeight:700, fontSize:14, color:G, marginBottom:8 }}>Course</div>
          {isReload && courseSnapshot && !courseFromLib && (
            <div style={{ background:'#fff8e8', border:'1px solid #f0d070', borderRadius:8, padding:'7px 11px', marginBottom:8, fontSize:12, color:'#7a5800' }}>
              <strong>{courseSnapshot.name}</strong> is not in your current course library. Using saved course data.
            </div>
          )}
          {allCourses.length === 0 && !courseSnapshot ? (
            <p style={{ fontSize:12, color:'#aaa' }}>No courses saved. Go to Courses tab to add one.</p>
          ) : (
            /* Course picker trigger — styled like player picker */
            <button onClick={() => setShowCoursePicker(true)}
              style={{ width:'100%', padding:'10px 12px', borderRadius:12, border:`1.5px solid ${course ? G : '#ddd'}`, background:course ? GA : '#fff', cursor:'pointer', fontFamily:'inherit', marginBottom: course ? 8 : 0, textAlign:'left', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              {course ? (
                <div style={{ minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:700, color:G, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{course.name}</div>
                  {course.location && <div style={{ fontSize:11, color:G, opacity:0.7, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{course.location}</div>}
                </div>
              ) : (
                <span style={{ fontSize:13, color:'#aaa' }}>Select a course…</span>
              )}
              <span style={{ fontSize:11, color: course ? G : '#bbb', flexShrink:0, marginLeft:8 }}>▼</span>
            </button>
          )}

          {/* Front 9 / Back 9 — only shown when course has more than 2 nines */}
          {course?.nines?.length > 2 && (
            <div style={{ display:'flex', gap:8, marginBottom:8 }}>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4 }}>Front 9</div>
                <NineDropdown
                  nines={course.nines}
                  value={frontNine}
                  onChange={setFrontNine}
                  label="Front 9"
                />
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4 }}>Back 9</div>
                <NineDropdown
                  nines={course.nines}
                  value={backNine}
                  onChange={setBackNine}
                  label="Back 9"
                />
              </div>
            </div>
          )}

          {/* ── 13-C.2: Round Length — Start Hole + End Hole ───────────────── */}
          {/* Stored as roundStartHole (0-based) + roundNumHoles. UI uses       */}
          {/* 1-based Start + End (inclusive). Draft-string pattern: field      */}
          {/* holds raw text during editing; validation/clamp runs on blur.     */}
          {/* Defaults: Start 1, End 18 → no-op for full rounds.                */}
          {/* A1 fix pass 4: each <input> is wrapped in a flex-centered outer   */}
          {/* <div> (same pattern as ScoreGrid's renderCell). The outer div has */}
          {/* fixed height and centers its content vertically; the input itself */}
          {/* has auto-height and no background/border. This decouples box      */}
          {/* stability from the browser's internal text-baseline quirks,       */}
          {/* which shift between empty-cursor and populated-text states on iOS.*/}
          <div style={{ display:'flex', gap:8, alignItems:'flex-start' }}>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4 }}>Start Hole</div>
              <div style={{
                // Outer shell — owns the box dimensions, border, background.
                height: 38,
                border:`1px solid ${roundLengthError ? '#c0392b' : '#ddd'}`,
                borderRadius:8,
                background:'#fff',
                display:'flex',
                alignItems:'center',
                justifyContent:'center',
                boxSizing:'border-box',
              }}>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="off"
                  autoCorrect="off"
                  spellCheck={false}
                  autoCapitalize="none"
                  value={startHoleDraft !== null ? startHoleDraft : String(roundStartHole + 1)}
                  onFocus={() => { setStartHoleDraft(''); }}
                  onChange={e => {
                    const digits = e.target.value.replace(/[^0-9]/g, '').slice(0, 2);
                    setStartHoleDraft(digits);
                  }}
                  onBlur={() => {
                    // Commit: validate draft, update state. Invalid entries revert
                    // (A6 fix). Start change preserves End Hole when still valid;
                    // only bumps End up if forced (B4 fix).
                    const raw = startHoleDraft;
                    setStartHoleDraft(null);
                    if (raw === null || raw === '') return;
                    const n = parseInt(raw, 10);
                    if (Number.isNaN(n) || n < 1 || n > 18) return;
                    const newStart = n - 1;
                    const currentEnd1b = roundStartHole + roundNumHoles;
                    const minEnd1b     = newStart + 3;
                    const newEnd1b     = Math.min(18, Math.max(minEnd1b, currentEnd1b));
                    setRoundStartHole(newStart);
                    setRoundNumHoles(newEnd1b - newStart);
                  }}
                  style={{
                    // Inner element — minimal styling; let outer div own layout.
                    width: '100%',
                    border: 'none',
                    outline: 'none',
                    background: 'transparent',
                    textAlign: 'center',
                    fontSize: 13,
                    fontFamily: 'inherit',
                    color: G,
                    fontWeight: 700,
                    padding: 0,
                    margin: 0,
                    WebkitAppearance: 'none',
                    appearance: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4 }}>End Hole</div>
              <div style={{
                height: 38,
                border:`1px solid ${roundLengthError ? '#c0392b' : '#ddd'}`,
                borderRadius:8,
                background:'#fff',
                display:'flex',
                alignItems:'center',
                justifyContent:'center',
                boxSizing:'border-box',
              }}>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="off"
                  autoCorrect="off"
                  spellCheck={false}
                  autoCapitalize="none"
                  value={endHoleDraft !== null ? endHoleDraft : String(roundStartHole + roundNumHoles)}
                  onFocus={() => { setEndHoleDraft(''); }}
                  onChange={e => {
                    const digits = e.target.value.replace(/[^0-9]/g, '').slice(0, 2);
                    setEndHoleDraft(digits);
                  }}
                  onBlur={() => {
                    const raw = endHoleDraft;
                    setEndHoleDraft(null);
                    if (raw === null || raw === '') return;
                    const n = parseInt(raw, 10);
                    const minEnd = roundStartHole + 3;
                    if (Number.isNaN(n) || n < minEnd || n > 18) return;
                    setRoundNumHoles(n - roundStartHole);
                  }}
                  style={{
                    width: '100%',
                    border: 'none',
                    outline: 'none',
                    background: 'transparent',
                    textAlign: 'center',
                    fontSize: 13,
                    fontFamily: 'inherit',
                    color: G,
                    fontWeight: 700,
                    padding: 0,
                    margin: 0,
                    WebkitAppearance: 'none',
                    appearance: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>
            </div>
          </div>
          {/* Inline description / error */}
          {!roundLengthError && (roundStartHole !== 0 || roundNumHoles !== 18) && (
            <div style={{ fontSize:11, color:'#888', marginTop:6 }}>
              Playing {roundNumHoles} holes · {roundStartHole + 1} through {roundStartHole + roundNumHoles}.
            </div>
          )}
          {roundLengthError && (
            <div style={{ fontSize:11, color:'#c0392b', marginTop:6, fontWeight:600 }}>
              {roundLengthError}
            </div>
          )}

        </Card>

        {/* Players */}
        <Card>
          <div style={{ fontWeight:700, fontSize:14, color:G, marginBottom:8 }}>Players</div>

          {activePlayers.length === 0 ? (
            /* Empty state: plain CTA button */
            <button onClick={() => setShowPlayerPicker(true)}
              style={{ width:'100%', padding:'10px 12px', borderRadius:12, border:'1.5px solid #ddd',
                       background:'#fff', cursor:'pointer', fontFamily:'inherit', textAlign:'left' }}>
              <span style={{ fontSize:13, color:'#aaa' }}>Select players…</span>
            </button>
          ) : (
            /* Populated state: per-player rows only — no summary tile */
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {activePlayers.map(p => {
                const hi      = playerHIs[p.id] ?? p.ghin ?? '';
                const ch      = computePlayerCH(p.id, hi);
                const teeName = playerTees[p.id] || selectedTee || '';
                const hasManualCH = playerCHOverrides[p.id] != null;
                const parts   = (p.name || '').trim().split(/\s+/);
                const first   = parts.slice(0, -1).join(' ') || p.name;
                const last    = parts.length >= 2 ? parts[parts.length - 1] : '';

                return (
                  <div key={p.id} style={{ background:'#f8fbf8', borderRadius:10, border:'1px solid #e8f0e8', padding:'6px 10px',
                                           display:'flex', alignItems:'center', gap:6 }}>

                    {/* Name — flex left, centers against full right-side height */}
                    <div
                      onClick={() => setShowPlayerPicker(true)}
                      style={{ flex:1, cursor:'pointer', minWidth:0 }}>
                      <div style={{ fontSize:13, fontWeight:700, color:G,
                                    overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                        {first}
                      </div>
                      {last && (
                        <div style={{ fontSize:11, fontWeight:400, color:G, opacity:0.65,
                                      overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                          {last}
                        </div>
                      )}
                    </div>

                    {/* Right side: HI+CH on top row, tee below — stacked, right-aligned */}
                    <div style={{ flexShrink:0 }}>
                      {/* Row 1: HI + CH */}
                      <div style={{ display:'flex', gap:6, marginBottom: course?.tees?.length > 0 ? 5 : 0 }}>
                        <div style={{ width:72 }}>
                          <HIField
                            value={hi}
                            onChange={v => {
                              setPlayerHIs(prev => ({ ...prev, [p.id]: v }));
                              if (hasManualCH) setPlayerCHOverrides(prev => { const n={...prev}; delete n[p.id]; return n; });
                            }}
                            onBlur={v => {
                              // Save HI to player library immediately on blur
                              const parsed = parseFloat(v);
                              if (!isNaN(parsed) && v.toString().trim() !== '') {
                                playerLib.update(p.id, { ghin: v });
                              }
                            }}
                          />
                        </div>
                        <div style={{ width:72 }}>
                          <CHField
                            ch={ch}
                            isManual={hasManualCH}
                            onManualEntry={v => {
                              setPlayerCHOverrides(prev => ({ ...prev, [p.id]: v }));
                              setPlayerHIs(prev => ({ ...prev, [p.id]: '' }));
                              playerLib.update(p.id, { ghin: '' });
                            }}
                          />
                        </div>
                      </div>
                      {/* Row 2: tee dropdown — same width as HI+CH+gap = 150px */}
                      {course?.tees?.length > 0 && (
                        <div style={{ width:150 }}>
                          <TeeDropdown
                            tees={course.tees}
                            value={teeName}
                            onChange={v => {
                              setPlayerTees(prev => {
                                const next = { ...prev };
                                // If this is the first tee pick (all others blank), fill everyone.
                                const othersAllBlank = activePlayers
                                  .filter(op => op.id !== p.id)
                                  .every(op => !prev[op.id] || prev[op.id] === '');
                                if (othersAllBlank) {
                                  activePlayers.forEach(op => { next[op.id] = v; });
                                } else {
                                  next[p.id] = v;
                                }
                                return next;
                              });
                              // Keep selectedTee in sync with first player's tee for
                              // any code paths that still read it as a fallback.
                              setSelectedTee(v);
                            }}
                            label="Select tee…"
                          />
                        </div>
                      )}
                    </div>

                  </div>
                );
              })}

            </div>
          )}
        </Card>

        {/* Games */}
        <Card>
          <div style={{ fontWeight:700, fontSize:14, color:G, marginBottom:8 }}>Games & Bets</div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {(() => {
              // Display name helper — shows "Match" for the stored key "Match / Nassau".
              const displayGameName = g => g === 'Match / Nassau' ? 'Match' : g;

              // Alphabetical order by display name.
              const sortedGames = [...ALL_GAMES].sort((a, b) =>
                displayGameName(a).localeCompare(displayGameName(b))
              );

              const tiles = [];

              sortedGames.forEach(g => {
                const on    = activeGames.includes(g);
                const opts  = gameOpts[g] || {};

                // ── Match / Nassau: special handling ────────────────────────
                if (g === 'Match / Nassau') {
                  // OFF → single collapsed placeholder tile.
                  if (!on) {
                    tiles.push(
                      <GameTile key="match-placeholder"
                        title="Match"
                        on={false}
                        onToggle={() => toggleGame(g)}
                      >
                        {/* never renders — tile is collapsed */}
                      </GameTile>
                    );
                    return;
                  }

                  // ON → one GameTile per match instance + "+ Add another Match" tile.
                  matches.forEach((m, idx) => {
                    const letter = String.fromCharCode(65 + idx); // 'A', 'B', 'C'...
                    const matchTitle = `Match ${letter}`;
                    const twoPlayers = activePlayers.length === 2;

                    // Secondary dropdown: Individual / Team (hidden for 2-player rounds)
                    const secondaryDropdown = twoPlayers ? null : (
                      <StyledSel
                        value={m.format || 'individual'}
                        onChange={v => setMatches(prev => prev.map(x => x.id === m.id ? { ...x, format: v } : x))}
                        options={[
                          { value:'individual', label:'Individual' },
                          { value:'team',       label:'Team' },
                        ]}
                        width="100%"
                      />
                    );

                    // Checkbox toggle: unchecking removes THIS match. If it's the only
                    // one, also remove the game from activeGames (reverts to placeholder).
                    const onMatchToggle = () => {
                      if (matches.length === 1) {
                        // Last match — turn off the whole game.
                        toggleGame('Match / Nassau');
                      } else {
                        // Remove just this match instance.
                        setMatches(prev => prev.filter(x => x.id !== m.id));
                        // If Dots teamMode references this match, reset to 'none'.
                        const dotsMode = gameOpts['Dots']?.teamMode;
                        if (dotsMode === `Match:${m.id}`) {
                          setOpt('Dots', 'teamMode', 'none');
                          setDotsPlayers([]);
                        }
                      }
                    };

                    tiles.push(
                      <GameTile key={m.id}
                        title={matchTitle}
                        on={true}
                        onToggle={onMatchToggle}
                        secondaryDropdown={secondaryDropdown}
                        scoring={m.grossNetNOL ?? m.scoring ?? 'net'}
                        onScoringChange={v => setMatches(prev => prev.map(x => x.id === m.id ? { ...x, grossNetNOL: v } : x))}
                        includeNOL={true}
                        showScoring={true}
                      >
                        <MatchCard
                          match={m}
                          players={activePlayers}
                          onChange={updated => setMatches(prev => prev.map(x => x.id === m.id ? updated : x))}
                        />
                      </GameTile>
                    );
                  });

                  // "+ Add another Match" tile — dashed outline, same width as tiles.
                  tiles.push(
                    <button key="add-match"
                      onClick={() => setMatches(prev => [...prev, defaultMatch(activePlayers)])}
                      style={{
                        width:'100%', padding:'9px 12px', borderRadius:12,
                        border:`1.5px dashed ${G}`, background:GA,
                        cursor:'pointer', fontSize:13, fontWeight:700, color:G,
                        fontFamily:'inherit', textAlign:'left',
                      }}>
                      + Add another Match
                    </button>
                  );
                  return;
                }

                // ── All other games ────────────────────────────────────────
                const showScoring = true;
                const includeNOL  = g !== 'Dots';
                const scoring     = opts.grossNetNOL ?? opts.scoring ?? (g === 'Dots' ? 'gross' : g === 'Stroke Play' ? 'gross' : 'net');

                // Secondary dropdown per game:
                //   Stableford: Individual / Teams (Teams disabled — Option Z, 11-L unblocks)
                //   Dots:       Individual / Sixes Teams / Match Teams (dynamic)
                let secondaryDropdown = null;

                if (g === 'Stableford' && on) {
                  const canTeam = activePlayers.length >= 4;
                  secondaryDropdown = (
                    <StyledSel
                      value={opts.format || 'individual'}
                      onChange={v => {
                        setOpt(g, 'format', v);
                        // Reset team assignments when switching back to individual
                        if (v === 'individual') {
                          setOpt(g, 'teamA', []);
                          setOpt(g, 'teamB', []);
                        }
                      }}
                      options={[
                        { value:'individual', label:'Individual' },
                        { value:'team',       label:'Teams', disabled: !canTeam },
                      ]}
                      width="100%"
                    />
                  );
                } else if (g === 'Dots' && on) {
                  const teamModeOpts = [{ value:'none', label:'Individual' }];
                  if (activeGames.includes('Sixes'))
                    teamModeOpts.push({ value:'Sixes', label:'Sixes Teams' });
                  if (activeGames.includes('Match / Nassau')) {
                    matches?.forEach((m, idx) => {
                      if (m.format === 'team') {
                        const letter = String.fromCharCode(65 + idx);
                        teamModeOpts.push({ value:`Match:${m.id}`, label:`Match ${letter} Teams` });
                      }
                    });
                  }

                  const currentTeamMode = opts.teamMode ?? (opts.teamScoring ? 'Sixes' : 'none');

                  if (teamModeOpts.length > 1) {
                    secondaryDropdown = (
                      <StyledSel
                        value={currentTeamMode}
                        onChange={v => {
                          setOpt(g, 'teamMode', v);
                          setOpt(g, 'teamScoring', false);
                          if (v === 'none') {
                            setDotsPlayers([]);
                          } else if (v === 'Sixes') {
                            const t0 = sixesTeams?.[0], t1 = sixesTeams?.[1];
                            if (t0 && t1) {
                              const idxs = [...new Set([t0.a, t0.b, t1.a, t1.b]
                                .filter(i => i != null && activePlayers[i]))]
                                .sort((a,b) => a - b);
                              setDotsPlayers(idxs.length === 4 ? idxs : []);
                            } else setDotsPlayers([]);
                          } else if (v.startsWith('Match:')) {
                            const matchId = v.slice(6); // strip 'Match:'
                            const tm = matches?.find(m => m.id === matchId);
                            if (tm) {
                              const idxs = [...new Set([...(tm.teamA || []), ...(tm.teamB || [])]
                                .filter(i => i != null && activePlayers[i]))]
                                .sort((a,b) => a - b);
                              setDotsPlayers(idxs.length >= 2 ? idxs : []);
                            } else setDotsPlayers([]);
                          }
                        }}
                        options={teamModeOpts}
                        width="100%"
                      />
                    );
                  }
                }

                tiles.push(
                  <GameTile
                    key={g}
                    title={displayGameName(g)}
                    subtitle={g === 'Dots' ? 'Specials, Junk' : null}
                    on={on}
                    onToggle={() => toggleGame(g)}
                    secondaryDropdown={secondaryDropdown}
                    scoring={scoring}
                    onScoringChange={v => setOpt(g, 'grossNetNOL', v)}
                    includeNOL={includeNOL}
                    showScoring={showScoring}
                  >
                    <GameConfig game={g} opts={opts} setOpt={(k,v) => setOpt(g, k, v)}
                      bet={gameBets[g] || 0} setBet={v => setGameBets(p => ({ ...p, [g]: v }))}
                      players={activePlayers}
                      sixesTeams={sixesTeams} setSixesTeams={setSixesTeams}
                      strokePlayPlayers={strokePlayPlayers} setStrokePlayPlayers={setStrokePlayPlayers}
                      skinsPlayers={skinsPlayers} setSkinsPlayers={setSkinsPlayers}
                      ninesPlayers={ninesPlayers} setNinesPlayers={setNinesPlayers}
                      stablefordPlayers={stablefordPlayers} setStablefordPlayers={setStablefordPlayers}
                      dotsPlayers={dotsPlayers} setDotsPlayers={setDotsPlayers}
                      dots={dots} setDots={setDots}
                    />
                  </GameTile>
                );
              });

              return tiles;
            })()}
          </div>
        </Card>

        {/* Pinned Start Round button — fixed action bar above nav bar */}
      </div>
      <div style={{ position:'fixed', bottom:NAV_BAR_HEIGHT, left:0, right:0, zIndex:20,
                    background:'#fff', borderTop:'0.5px solid #ddeedd',
                    padding:'10px 14px 12px', maxWidth:520, margin:'0 auto' }}>
        <button onClick={handleStart} disabled={activePlayers.length < 2}
          style={{ width:'100%', background: activePlayers.length < 2 ? '#ccc' : G,
                   color:'#fff', border:'none', borderRadius:14,
                   padding:'15px 20px', fontSize:15, fontWeight:700,
                   cursor: activePlayers.length < 2 ? 'not-allowed' : 'pointer',
                   fontFamily:'inherit' }}>
          {isReload ? 'Re-score Round →' : 'Start Scoring →'}
        </button>
      </div>

      {showPlayerPicker && (
        <PlayerPickerPopup allPlayers={allPlayers} selectedIds={selectedPlayerIds}
          onConfirm={ids=>{setSelectedPlayerIds(ids);setShowPlayerPicker(false);}} onClose={()=>setShowPlayerPicker(false)}/>
      )}
      {showCoursePicker && (
        <CoursePickerPopup
          allCourses={allCourses}
          snapshotCourse={isReload && courseSnapshot && !courseFromLib ? courseSnapshot : null}
          selectedId={selectedCourseId}
          onConfirm={id => { handleCourseSelect(id); setShowCoursePicker(false); }}
          onClose={() => setShowCoursePicker(false)}
        />
      )}
    </div>
  );
}
