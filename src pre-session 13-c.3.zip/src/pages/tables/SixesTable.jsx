// ─── tables/SixesTable.jsx ────────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js
//
// Display spec: Sixes_Contract.md §7 (v1.5)
// Pattern: mirrors MatchNassauTable with three 6-hole segments instead of
//          two 9-hole halves. Blue/red team chips. Magnitude-only status.

import { useState } from 'react';
import { scoreForMode } from '../../engine/handicap.js';
import { getSixesTeam, runSixesSegment } from '../../engine/games.js';
import {
  M, COL_W, TOT_W, NAME_MIN,
  scoringLabel, fmtLead, buildLeadState, lastScoredInHoles,
} from '../scorecard/scorecardUtils.js';
import { GameSection, TableDivider } from '../scorecard/GameSection.jsx';
import { PressModal, SegmentChipColumns } from '../scorecard/PressModal.jsx';

// ── Sixes-specific color tokens (blue/red, colorblind-safe) ──────────────────
const SXA_BG  = '#dbeeff';   // Team A chip background
const SXA_CLR = '#0c447c';   // Team A chip text / lead color
const SXB_BG  = '#fde8e8';   // Team B chip background
const SXB_CLR = '#791f1f';   // Team B chip text / lead color
const SXA_LED = '#185fa5';   // Team A leading — status column
const SXB_LED = '#a32d2d';   // Team B leading — status column

// ── Segment definitions ───────────────────────────────────────────────────────
const SEGS = [
  { label: 'Front 6',  holes: [0,1,2,3,4,5],         key: 'Sixes:seg0' },
  { label: 'Middle 6', holes: [6,7,8,9,10,11],        key: 'Sixes:seg1' },
  { label: 'Last 6',   holes: [12,13,14,15,16,17],    key: 'Sixes:seg2' },
];

// ── Name resolution (§7.5) ────────────────────────────────────────────────────
// Given all 4 player objects for a segment, resolve each player's display name.
// Returns an array of 4 resolved name strings (indexed by player position 0-3
// within the foursome array, not global player index).
function resolveSegmentNames(foursome) {
  const firstNames = foursome.map(p => (p?.name || '?').trim().split(/\s+/)[0]);
  const lastInits  = foursome.map(p => {
    const parts = (p?.name || '').trim().split(/\s+/);
    return parts.length >= 2 ? parts[parts.length - 1][0].toUpperCase() : '';
  });

  return firstNames.map((fn, i) => {
    // Check for first-name collision with any other player in the foursome
    const collision = firstNames.some((other, j) => j !== i && other === fn);
    if (!collision) return fn;
    // First-name collision: append last initial
    return lastInits[i] ? `${fn} ${lastInits[i]}` : fn;
    // Note: first+last-initial collision is not further disambiguated (§7.5.2 rule 3)
  });
}

// First character of each resolved name, joined by '/'
function initialsFromResolved(nameA, nameB) {
  return `${nameA[0]}/${nameB[0]}`;
}

// Strip "thru N" suffix from fmtLead text (§7.4.2)
function stripThru(text) {
  if (!text) return text;
  const idx = text.indexOf(' thru');
  return idx !== -1 ? text.slice(0, idx) : text;
}

// ─────────────────────────────────────────────────────────────────────────────

export function SixesTable({
  players, scores, hcps, opts,
  sixesTeams, courseHcps, minCourseHcp,
  manualPresses, setManualPresses,
}) {
  if (!sixesTeams?.[0] || !sixesTeams?.[1]) return null;

  const [pressModal, setPressModal] = useState(null);

  const sixesOpts = opts || {};
  const mode      = sixesOpts.grossNetNOL ?? sixesOpts.scoring  ?? 'net';
  const tiebreak  = sixesOpts.scoring ?? sixesOpts.tiebreak ?? 'none';
  const autoN     = (sixesOpts.autoPress && sixesOpts.autoPress !== 'none') ? parseInt(sixesOpts.autoPress) : 0;

  // Resolve team assignments for all 3 segments
  const segTeams = SEGS.map((_, si) => getSixesTeam(si, sixesTeams, players));

  // ── Best-ball hole winner for a given segment ─────────────────────────────
  // Returns 'a' (Team A wins), 'b' (Team B wins), 0 (tie), or null (unplayed)
  // 'a'/'b' convention matches buildLeadState expectations.
  const holeWinFn = (h, teamA, teamB) => {
    // 'X' is a valid scored value — only '' / null / undefined means unplayed
    const allScored = [...teamA, ...teamB].every(pi => {
      const v = scores[h]?.[pi];
      return v !== '' && v != null;
    });
    if (!allScored) return null;
    // 'X' treated as Infinity — always loses best-ball comparison (matches engine)
    const val = pi => {
      const raw = scores[h][pi];
      if (raw === 'X') return Infinity;
      return scoreForMode(parseInt(raw), courseHcps[pi], hcps[h], minCourseHcp, mode);
    };
    const valsA = teamA.map(val);
    const valsB = teamB.map(val);
    const bestA = Math.min(...valsA);
    const bestB = Math.min(...valsB);
    if (bestA < bestB) return 'a';
    if (bestB < bestA) return 'b';
    if (tiebreak === 'second' && teamA.length >= 2 && teamB.length >= 2) {
      const s2A = Math.max(...valsA);
      const s2B = Math.max(...valsB);
      if (s2A < s2B) return 'a';
      if (s2B < s2A) return 'b';
    } else if (tiebreak === 'cumulative' && teamA.length >= 2 && teamB.length >= 2) {
      const sumA = valsA.reduce((s, v) => s + v, 0);
      const sumB = valsB.reduce((s, v) => s + v, 0);
      if (sumA < sumB) return 'a';
      if (sumB < sumA) return 'b';
    }
    return tiebreak === 'half' ? 'half' : 0;
  };

  // ── Segment-scoped holeWinFn (closes over the segment's team arrays) ──────
  const makeSegHoleWinFn = (si) => {
    const team = segTeams[si];
    if (!team) return () => null;
    const { a, b } = team;
    const teamA = [a, b];
    const teamB = players.map((_, i) => i).filter(i => i !== a && i !== b);
    if (teamB.length < 2) return () => null;
    return (h) => holeWinFn(h, teamA, teamB);
  };

  // ── Press chip builder (mirrors MatchNassauTable.makeBetChip) ─────────────
  // bet: { startHole, label } from runSixesSegment output
  // mpKey is stored directly in pressModal state (fixes G-3/G-4)
  const makeSegChip = (bet, segHoles, segLabel, depth, totalDepths, mpKey, mpArr, winFn, nmA, nmB) => {
    const betHoles  = segHoles.filter(h => h >= (bet.startHole ?? segHoles[0]));
    const leadState = buildLeadState(winFn, betHoles);
    const lastH     = [...betHoles].reverse().find(h => leadState[h] !== undefined);
    const rawInfo   = lastH != null
      ? fmtLead(leadState[lastH].lead, leadState[lastH].matchOver, leadState[lastH].holesLeft)
      : null;
    const info = rawInfo ? { ...rawInfo, text: stripThru(rawInfo.text) } : null;

    const isTeamALeading = info && leadState[lastH]?.lead > 0;
    const isTeamBLeading = info && leadState[lastH]?.lead < 0;
    const winnerName = isTeamALeading ? nmA : isTeamBLeading ? nmB : 'All Square';

    const pressDepthBg  = depth === 0 ? null : depth === 1 ? '#e8f4fb' : '#dceef8';
    const pressDepthLbl = depth === 0 ? M.hdrClr : '#1a6b9a';
    const chipBg = info
      ? (isTeamALeading
          ? (depth > 0 ? '#c0d8f0' : SXA_BG)
          : isTeamBLeading
            ? (depth > 0 ? '#f8dede' : SXB_BG)
            : (depth > 0 ? '#e0e0f8' : '#eaeaff'))
      : (pressDepthBg || M.hdrBg);

    const existingPressHole = mpArr[depth] ?? null;
    const minHole           = bet.startHole ?? segHoles[0];
    const label             = depth === 0 ? segLabel : bet.label;
    const hasChildPress     = existingPressHole !== null;
    const isLastInChain     = depth === totalDepths - 1;
    const lastScored        = lastScoredInHoles(winFn, betHoles);
    const canAddPress       = isLastInChain && lastScored !== null && lastScored < betHoles[betHoles.length - 1];
    const pressable         = hasChildPress || canAddPress;

    const chipColor = isTeamALeading ? SXA_LED : isTeamBLeading ? SXB_LED : '#aaa';

    return {
      label, winnerName,
      value: info ? info.text : '—',
      color: chipColor,
      bg: chipBg, labelColor: pressDepthLbl,
      pressable, hasChildPress, isPress: depth > 0,
      onLongPress: () => setPressModal({
        // Store mpKey directly — no re-derivation needed in the modal render (fixes G-3/G-4)
        mpKey, betHoles, depth, minHole, existingPressHole,
        label:  `${nmA} vs ${nmB} · ${label}`,
        status: info ? info.text : '—',
        winnerName,
      }),
    };
  };

  // ── Build chips for one segment using engine output ───────────────────────
  // Mirrors MatchNassauTable.buildSegment exactly.
  // runSixesSegment returns MatchResult[] — one entry per match level (base + presses).
  const buildSegmentChips = (si, winFn, nmA, nmB) => {
    const seg    = SEGS[si];
    const mpKey  = seg.key;
    const mpArr  = (manualPresses || {})[mpKey] || [];
    const team   = segTeams[si];
    if (!team) {
      return {
        mainChip: makeSegChip(
          { startHole: seg.holes[0], label: seg.label },
          seg.holes, seg.label, 0, 1, mpKey, mpArr, winFn, nmA, nmB
        ),
        pressChips: [],
      };
    }

    // Call engine to get base + all press levels
    const engineBets = runSixesSegment(
      seg.holes, scores, players, hcps,
      team, mode, tiebreak,
      courseHcps, minCourseHcp,
      autoN, mpArr
    );

    // Fallback if engine returns null (< 4 players guard)
    if (!engineBets) {
      return {
        mainChip: makeSegChip(
          { startHole: seg.holes[0], label: seg.label },
          seg.holes, seg.label, 0, 1, mpKey, mpArr, winFn, nmA, nmB
        ),
        pressChips: [],
      };
    }

    const total = engineBets.length || 1;
    const [main, ...presses] = engineBets;

    return {
      mainChip:   makeSegChip(main,   seg.holes, seg.label, 0,      total, mpKey, mpArr, winFn, nmA, nmB),
      pressChips: presses.map((pb, pi) =>
        makeSegChip(pb, seg.holes, seg.label, pi + 1, total, mpKey, mpArr, winFn, nmA, nmB)
      ),
    };
  };

  // ── Render one segment block ──────────────────────────────────────────────
  const renderSegment = (si) => {
    const seg  = SEGS[si];
    const team = segTeams[si];
    if (!team) return null;

    const { a, b } = team;
    const teamBIdx = players.map((_, i) => i).filter(i => i !== a && i !== b);
    if (teamBIdx.length < 2) return null;
    const [c, d] = teamBIdx;

    // Name resolution — pass the 4 players in segment order [a, b, c, d]
    const foursome    = [players[a], players[b], players[c], players[d]];
    const resolved    = resolveSegmentNames(foursome);
    // resolved[0]=a, [1]=b, [2]=c, [3]=d
    const nmA = `${resolved[0]}/${resolved[1]}`;
    const nmB = `${resolved[2]}/${resolved[3]}`;
    const initA = initialsFromResolved(resolved[0], resolved[1]);
    const initB = initialsFromResolved(resolved[2], resolved[3]);

    const winFn     = makeSegHoleWinFn(si);

    // Base segment lead state (for base row status column)
    const leadState = buildLeadState(winFn, seg.holes);
    const lastH     = [...seg.holes].reverse().find(h => leadState[h] !== undefined);
    const rawInfo   = lastH != null
      ? fmtLead(leadState[lastH].lead, leadState[lastH].matchOver, leadState[lastH].holesLeft)
      : null;
    const statusInfo = rawInfo ? { ...rawInfo, text: stripThru(rawInfo.text) } : null;
    const statusColor = statusInfo
      ? (leadState[lastH].lead > 0 ? SXA_LED : leadState[lastH].lead < 0 ? SXB_LED : '#888')
      : '#aaa';

    // Engine output for press rows (§7.3 / §8)
    const mpArr      = (manualPresses || {})[seg.key] || [];
    const engineBets = runSixesSegment(
      seg.holes, scores, players, hcps,
      team, mode, tiebreak,
      courseHcps, minCourseHcp,
      autoN, mpArr
    );
    // Slice off the base row — we render it separately; keep only press rows
    const pressRows = engineBets ? engineBets.slice(1) : [];

    return (
      <div key={si}>
        {si > 0 && <TableDivider/>}

        {/* Segment header: "Front 6 · TeamA vs TeamB" */}
        <div style={{ padding: '5px 10px 2px', fontSize: 10, color: '#888' }}>
          <span style={{ fontWeight: 600 }}>{seg.label}</span>
          <span style={{ margin: '0 4px' }}>·</span>
          <span style={{ color: SXA_LED, fontWeight: 500 }}>{nmA}</span>
          <span style={{ color: '#aaa', margin: '0 4px' }}>vs</span>
          <span style={{ color: SXB_LED, fontWeight: 500 }}>{nmB}</span>
        </div>

        {/* Hole table */}
        <div style={{ padding: '0 8px 4px', overflowX: 'auto' }}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%', minWidth: NAME_MIN + 6 * COL_W + TOT_W }}>
            <colgroup>
              <col/>
              {seg.holes.map(h => <col key={h} style={{ width: COL_W }}/>)}
              <col style={{ width: TOT_W }}/>
            </colgroup>
            <thead>
              <tr>
                <th style={{ padding: '2px 6px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'left' }}></th>
                {seg.holes.map(h => (
                  <th key={h} style={{ padding: '2px 1px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>
                ))}
                <th style={{ padding: '2px 4px', background: M.totBg, color: M.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {/* Base segment row */}
              <tr style={{ background: '#f5fbf5' }}>
                <td style={{ padding: '2px 6px', fontSize: 10, color: '#888', fontWeight: 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}></td>
                {seg.holes.map(h => {
                  const w = winFn(h);
                  if (w === null) return (
                    <td key={h} style={{ textAlign: 'center', color: '#ddd', fontSize: 11 }}>·</td>
                  );
                  if (w === 0 || w === 'half') return (
                    <td key={h} style={{ textAlign: 'center', color: '#bbb', fontSize: 12 }}>–</td>
                  );
                  const isA = w === 'a';
                  return (
                    <td key={h} style={{ textAlign: 'center', padding: '1px' }}>
                      <span style={{
                        display: 'inline-block', width: 22, height: 18, lineHeight: '18px',
                        fontSize: 10, fontWeight: 500, borderRadius: 3,
                        background: isA ? SXA_BG : SXB_BG,
                        color:      isA ? SXA_CLR : SXB_CLR,
                        textAlign: 'center',
                      }}>
                        {isA ? initA : initB}
                      </span>
                    </td>
                  );
                })}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, background: M.totBg, color: statusColor, padding: '2px 4px' }}>
                  {statusInfo ? statusInfo.text : '—'}
                </td>
              </tr>

              {/* Press rows — one per press level from engine output (§7.3) */}
              {pressRows.map((pr, pi) => {
                // Press row lead state: run holeWinFn over holes from press startHole to end of segment
                const prHoles     = seg.holes.filter(h => h >= pr.startHole);
                const prLeadState = buildLeadState(winFn, prHoles);
                const prLastH     = [...prHoles].reverse().find(h => prLeadState[h] !== undefined);
                const prRawInfo   = prLastH != null
                  ? fmtLead(prLeadState[prLastH].lead, prLeadState[prLastH].matchOver, prLeadState[prLastH].holesLeft)
                  : null;
                const prStatusInfo  = prRawInfo ? { ...prRawInfo, text: stripThru(prRawInfo.text) } : null;
                const prStatusColor = prStatusInfo
                  ? (prLeadState[prLastH].lead > 0 ? SXA_LED : prLeadState[prLastH].lead < 0 ? SXB_LED : '#888')
                  : '#aaa';

                return (
                  <tr key={`press_${pi}`} style={{ background: '#f0f8ff' }}>
                    <td style={{ padding: '2px 6px', fontSize: 10, color: '#1a6b9a', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {pr.label}
                    </td>
                    {seg.holes.map(h => {
                      // Holes before press start get a pre-start dot (§7.3 / §7.6)
                      if (h < pr.startHole) return (
                        <td key={h} style={{ textAlign: 'center', color: '#e8e8e8', fontSize: 11 }}>·</td>
                      );
                      const w = winFn(h);
                      if (w === null) return (
                        <td key={h} style={{ textAlign: 'center', color: '#ddd', fontSize: 11 }}>·</td>
                      );
                      if (w === 0 || w === 'half') return (
                        <td key={h} style={{ textAlign: 'center', color: '#bbb', fontSize: 12 }}>–</td>
                      );
                      const isA = w === 'a';
                      return (
                        <td key={h} style={{ textAlign: 'center', padding: '1px' }}>
                          <span style={{
                            display: 'inline-block', width: 22, height: 18, lineHeight: '18px',
                            fontSize: 10, fontWeight: 500, borderRadius: 3,
                            background: isA ? '#c0d8f0' : '#f8dede',
                            color:      isA ? SXA_CLR   : SXB_CLR,
                            textAlign: 'center',
                          }}>
                            {isA ? initA : initB}
                          </span>
                        </td>
                      );
                    })}
                    <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, background: '#cce8f8', color: prStatusColor, padding: '2px 4px' }}>
                      {prStatusInfo ? prStatusInfo.text : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // ── Build chip bar segments (now includes press chips) ────────────────────
  const chipSegments = SEGS.map((seg, si) => {
    const team = segTeams[si];
    if (!team) {
      return {
        mainChip: {
          label: seg.label, winnerName: '—', value: '—',
          color: '#aaa', bg: M.hdrBg, labelColor: M.hdrClr,
          pressable: false, hasChildPress: false, isPress: false,
          onLongPress: () => {},
        },
        pressChips: [],
      };
    }
    const { a, b } = team;
    const teamBIdx  = players.map((_, i) => i).filter(i => i !== a && i !== b);
    const [c, d]    = teamBIdx;
    const foursome  = [players[a], players[b], players[c], players[d]];
    const resolved  = resolveSegmentNames(foursome);
    const nmA = `${resolved[0]}/${resolved[1]}`;
    const nmB = `${resolved[2]}/${resolved[3]}`;
    const winFn = makeSegHoleWinFn(si);
    return buildSegmentChips(si, winFn, nmA, nmB);
  });

  return (
    <GameSection title="Sixes" badge={scoringLabel(mode)} color={M.hdrClr} borderColor={M.border}>

      {/* PressModal — mpKey stored directly in state, no re-derivation (fixes G-3/G-4) */}
      {pressModal && (() => {
        const { mpKey, betHoles, depth, minHole, existingPressHole, label, status, winnerName } = pressModal;
        return (
          <PressModal
            title={label}
            status={status}
            winnerName={winnerName}
            validHoles={betHoles}
            existingPressHole={existingPressHole}
            minHole={minHole}
            onConfirm={h => {
              setManualPresses(prev => {
                const trimmed = (prev[mpKey] || []).slice(0, depth);
                if (trimmed.includes(h)) return prev;
                return { ...prev, [mpKey]: [...trimmed, h].sort((a, b) => a - b) };
              });
              setPressModal(null);
            }}
            onRemove={h => {
              setManualPresses(prev => ({
                ...prev,
                [mpKey]: (prev[mpKey] || []).filter(x => x < h),
              }));
              setPressModal(null);
            }}
            onClose={() => setPressModal(null)}
          />
        );
      })()}

      {/* Three segment blocks */}
      {SEGS.map((_, si) => renderSegment(si))}

      {/* Chip bar */}
      <TableDivider/>
      <SegmentChipColumns segments={chipSegments}/>

    </GameSection>
  );
}
