// ─── tables/MatchNassauTable.jsx ──────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js
//
// Display spec: Nassau_Match_Contract.md v2.4 §13 (hole winner cell format)

import { useState } from 'react';
import { scoreForMode, xGrossScore } from '../../engine/handicap.js';
import { isNassauMatch, runMatchNassau } from '../../engine/games.js';
import {
  M, MP, FRONT_H, BACK_H, ALL18_H, COL_W, TOT_W, NAME_MIN,
  fmtLead, buildLeadState, lastScoredInHoles, scoringLabel,
} from '../scorecard/scorecardUtils.js';
import { GameSection, HalfLabel, TableDivider } from '../scorecard/GameSection.jsx';
import { PressModal, SegmentChipColumns } from '../scorecard/PressModal.jsx';
import { G, RED } from '../../components/ui.jsx';

// ── Team color tokens — colorblind-safe blue/red, matching SixesTable ─────────
const TMA_BG  = '#dbeeff';   // Team A chip background  (blue)
const TMA_CLR = '#0c447c';   // Team A chip text        (blue)
const TMA_LED = '#185fa5';   // Team A header / status  (blue)
const TMB_BG  = '#fde8e8';   // Team B chip background  (red)
const TMB_CLR = '#791f1f';   // Team B chip text        (red)
const TMB_LED = '#a32d2d';   // Team B header / status  (red)

// ── §13.2 Individual format: first + last initial, concatenated (unchanged) ───
const initials = name => {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  return parts.length >= 2 ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase() : name.slice(0, 2).toUpperCase();
};

// ── §13.3 Team format: collision-aware name resolution + single first initials ─
// All players across both teams are resolved together for cross-match collision
// detection. Chip label = first char of each resolved name joined by '/'.
// Mirrors resolveSegmentNames + initialsFromResolved in SixesTable.jsx exactly.
function resolveMatchTeamNames(teamAIdxs, teamBIdxs, players) {
  const allIdxs    = [...teamAIdxs, ...teamBIdxs];
  const allPlayers = allIdxs.map(i => players[i]);

  const firstNames = allPlayers.map(p => (p?.name || '?').trim().split(/\s+/)[0]);
  const lastInits  = allPlayers.map(p => {
    const parts = (p?.name || '').trim().split(/\s+/);
    return parts.length >= 2 ? parts[parts.length - 1][0].toUpperCase() : '';
  });

  const resolved = firstNames.map((fn, i) => {
    const collision = firstNames.some((other, j) => j !== i && other === fn);
    if (!collision) return fn;
    return lastInits[i] ? `${fn} ${lastInits[i]}` : fn;
  });

  const resolvedA = resolved.slice(0, teamAIdxs.length);
  const resolvedB = resolved.slice(teamAIdxs.length);

  return {
    chipA: resolvedA.map(n => n[0].toUpperCase()).join('/'),   // e.g. "C/D"
    chipB: resolvedB.map(n => n[0].toUpperCase()).join('/'),   // e.g. "J/M"
    nmA:   resolvedA.join('/'),                                // e.g. "Chris/Danny"
    nmB:   resolvedB.join('/'),                                // e.g. "Dave/Cody"
  };
}

export function MatchNassauTable({ players, scores, hcps, matches, courseHcps, minCourseHcp, manualPresses, setManualPresses, isLandscape }) {

  if (!matches?.length) return (
    <GameSection title="Match / Nassau" color={M.hdrClr} borderColor={M.border}>
      <div style={{ color: '#aaa', fontSize: 12, padding: '8px 10px 10px' }}>No matches configured — go to Setup.</div>
    </GameSection>
  );

  const indivHoleWinner = (pi1, pi2, h, mode) => {
    const r1 = scores[h]?.[pi1];
    const r2 = scores[h]?.[pi2];
    if (r1 === '' || r1 == null || r2 === '' || r2 == null) return null;
    const p1X = r1 === 'X', p2X = r2 === 'X';
    if (p1X && p2X) return 0; // both X → halved
    if (p1X) return 2;        // X loses to any real score
    if (p2X) return 1;
    const g1 = parseInt(r1), g2 = parseInt(r2);
    if (!g1 || !g2) return null;
    const v1 = scoreForMode(g1, courseHcps[pi1], hcps[h], minCourseHcp, mode);
    const v2 = scoreForMode(g2, courseHcps[pi2], hcps[h], minCourseHcp, mode);
    if (v1 < v2) return 1; if (v2 < v1) return 2; return 0;
  };

  const teamHoleWinner = (teamA, teamB, h, mode, tiebreak) => {
    const rawsA = teamA.map(pi => scores[h]?.[pi]);
    const rawsB = teamB.map(pi => scores[h]?.[pi]);
    if (rawsA.some(r => r === '' || r == null) || rawsB.some(r => r === '' || r == null)) return null;
    // X → Infinity so it can never be the best-ball (min)
    const valsA = rawsA.map((raw, ii) => {
      if (raw === 'X') return Infinity;
      const g = parseInt(raw);
      return g ? scoreForMode(g, courseHcps[teamA[ii]], hcps[h], minCourseHcp, mode) : Infinity;
    });
    const valsB = rawsB.map((raw, ii) => {
      if (raw === 'X') return Infinity;
      const g = parseInt(raw);
      return g ? scoreForMode(g, courseHcps[teamB[ii]], hcps[h], minCourseHcp, mode) : Infinity;
    });
    const bestA = Math.min(...valsA), bestB = Math.min(...valsB);
    if (!isFinite(bestA) && !isFinite(bestB)) return 0; // both teams all-X → halved
    if (bestA < bestB) return 'a';
    if (bestB < bestA) return 'b';
    if (tiebreak === 'second' && teamA.length >= 2 && teamB.length >= 2) {
      const s2A = Math.max(...valsA.filter(isFinite)), s2B = Math.max(...valsB.filter(isFinite));
      if (s2A < s2B) return 'a';
      if (s2B < s2A) return 'b';
    } else if (tiebreak === 'cumulative' && teamA.length >= 2 && teamB.length >= 2) {
      const sumA = valsA.map(v => isFinite(v) ? v : 0).reduce((s, v) => s + v, 0);
      const sumB = valsB.map(v => isFinite(v) ? v : 0).reduce((s, v) => s + v, 0);
      if (sumA < sumB) return 'a';
      if (sumB < sumA) return 'b';
    }
    return tiebreak === 'half' ? 'half' : 0;
  };

  // ── renderHalf — portrait 9-hole table ────────────────────────────────────
  const renderHalf = (hs, betsForHalf, holeWinFn, nm1, nm2, lbl1, lbl2, isTeam) => {
    return (
      <div style={{ padding: '0 8px 4px' }}>
        <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%', minWidth: NAME_MIN + 9 * COL_W + TOT_W }}>
          <colgroup>
            <col/>
            {hs.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
          </colgroup>
          <thead>
            <tr>
              <th style={{ padding: '3px 6px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'left' }}></th>
              {hs.map(h => <th key={h} style={{ padding: '2px 1px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              <th style={{ padding: '2px 4px', background: M.totBg, color: M.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {betsForHalf.map((bet, bi) => {
              const isOverall = bet.isOverall;
              const isPress   = bet.isPress;
              const rowBg     = isOverall ? '#fffef5' : isPress ? '#f0f8ff' : '#f5fbf5';
              const labelClr  = isOverall ? MP.clr : isPress ? '#1a6b9a' : '#888';
              const tBg       = isOverall ? MP.totBg : isPress ? '#cce8f8' : M.totBg;
              const lastH     = [...hs].reverse().find(h => bet.leadState?.[h] !== undefined);
              const leadInfo  = lastH != null ? fmtLead(bet.leadState[lastH].lead, bet.leadState[lastH].matchOver, bet.leadState[lastH].holesLeft) : null;
              // Status color: team uses blue/red; individual uses G/RED from fmtLead
              const statusClr = isTeam && leadInfo
                ? (bet.leadState[lastH].lead > 0 ? TMA_LED : bet.leadState[lastH].lead < 0 ? TMB_LED : '#3a3abd')
                : (leadInfo ? leadInfo.color : '#aaa');
              return (
                <tr key={bi} style={{ background: rowBg }}>
                  <td style={{ padding: '2px 6px', fontSize: 10, color: labelClr, fontWeight: (isOverall || isPress) ? 600 : 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{bet.label}</td>
                  {hs.map(h => {
                    if (h < (bet.startHole ?? 0)) return <td key={h} style={{ textAlign: 'center', color: '#e8e8e8', fontSize: 11 }}>·</td>;
                    const w = holeWinFn(h);
                    if (w === null) return <td key={h} style={{ textAlign: 'center', color: '#ddd', fontSize: 11 }}>·</td>;
                    if (w === 0 || w === 'half') return <td key={h} style={{ textAlign: 'center', color: '#bbb', fontSize: 12 }}>–</td>;
                    const side1 = (w === 1 || w === 'a');
                    const chipBg  = isTeam ? (side1 ? TMA_BG  : TMB_BG)  : (side1 ? '#d8f0d8' : '#fde8e8');
                    const chipClr = isTeam ? (side1 ? TMA_CLR : TMB_CLR) : (side1 ? G : RED);
                    return (
                      <td key={h} style={{ textAlign: 'center', padding: '1px' }}>
                        <span style={{
                          display: 'inline-block', width: 22, height: 18, lineHeight: '18px',
                          fontSize: 10, fontWeight: 500, borderRadius: 3,
                          background: chipBg, color: chipClr,
                        }}>
                          {side1 ? lbl1 : lbl2}
                        </span>
                      </td>
                    );
                  })}
                  <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, background: tBg, color: statusClr, padding: '2px 4px' }}>
                    {leadInfo ? leadInfo.text : '—'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  // ── renderAll18 — landscape 18-hole table ─────────────────────────────────
  const renderAll18 = (allRows, holeWinFn, nm1, nm2, lbl1, lbl2, isTeam) => {
    const tableMinW = NAME_MIN + 18 * COL_W + 2 * TOT_W + TOT_W;
    return (
      <div style={{ overflowX: 'auto', padding: '0 8px 4px' }}>
        <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%', minWidth: tableMinW }}>
          <colgroup>
            <col style={{ minWidth: NAME_MIN }}/>
            {FRONT_H.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
            {BACK_H.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
            <col style={{ width: TOT_W }}/>
          </colgroup>
          <thead>
            <tr>
              <th style={{ padding: '3px 6px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'left' }}></th>
              {FRONT_H.map(h => <th key={h} style={{ padding: '2px 1px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              <th style={{ padding: '2px 4px', background: M.totBg, color: M.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>Total</th>
              {BACK_H.map(h => <th key={h} style={{ padding: '2px 1px', background: M.hdrBg, color: M.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              <th style={{ padding: '2px 4px', background: M.totBg, color: M.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>Total</th>
              <th style={{ padding: '2px 4px', background: M.totBg, color: M.totClr, fontSize: 10, textAlign: 'center', fontWeight: 800 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {allRows.map((bet, bi) => {
              const isOverall = bet.isOverall;
              const isPress   = bet.isPress;
              const rowBg     = isOverall ? '#fffef5' : isPress ? '#f0f8ff' : '#f5fbf5';
              const labelClr  = isOverall ? MP.clr : isPress ? '#1a6b9a' : '#888';
              const tBg       = isOverall ? MP.totBg : isPress ? '#cce8f8' : M.totBg;

              const lastF  = [...FRONT_H].reverse().find(h => bet.leadStateFront?.[h] !== undefined);
              const f9Lead = lastF != null ? bet.leadStateFront[lastF] : null;
              const f9Info = f9Lead ? fmtLead(f9Lead.lead, f9Lead.matchOver, f9Lead.holesLeft) : null;
              const f9Clr  = isTeam && f9Lead ? (f9Lead.lead > 0 ? TMA_LED : f9Lead.lead < 0 ? TMB_LED : '#3a3abd') : (f9Info ? f9Info.color : '#aaa');

              const lastB  = [...BACK_H].reverse().find(h => bet.leadStateBack?.[h] !== undefined);
              const b9Lead = lastB != null ? bet.leadStateBack[lastB] : null;
              const b9Info = b9Lead ? fmtLead(b9Lead.lead, b9Lead.matchOver, b9Lead.holesLeft) : null;
              const b9Clr  = isTeam && b9Lead ? (b9Lead.lead > 0 ? TMA_LED : b9Lead.lead < 0 ? TMB_LED : '#3a3abd') : (b9Info ? b9Info.color : '#aaa');

              const lastAll  = [...ALL18_H].reverse().find(h => bet.leadState?.[h] !== undefined);
              const allLead  = lastAll != null ? bet.leadState[lastAll] : null;
              const allInfo  = allLead ? fmtLead(allLead.lead, allLead.matchOver, allLead.holesLeft) : null;
              const allClr   = isTeam && allLead ? (allLead.lead > 0 ? TMA_LED : allLead.lead < 0 ? TMB_LED : '#3a3abd') : (allInfo ? allInfo.color : '#aaa');

              const holeTd = (h) => {
                if (h < (bet.startHole ?? 0)) return <td key={h} style={{ textAlign: 'center', color: '#e8e8e8', fontSize: 11 }}>·</td>;
                const w = holeWinFn(h);
                if (w === null) return <td key={h} style={{ textAlign: 'center', color: '#ddd', fontSize: 11 }}>·</td>;
                if (w === 0 || w === 'half') return <td key={h} style={{ textAlign: 'center', color: '#bbb', fontSize: 12 }}>–</td>;
                const side1   = (w === 1 || w === 'a');
                const chipBg  = isTeam ? (side1 ? TMA_BG  : TMB_BG)  : (side1 ? '#d8f0d8' : '#fde8e8');
                const chipClr = isTeam ? (side1 ? TMA_CLR : TMB_CLR) : (side1 ? G : RED);
                return (
                  <td key={h} style={{ textAlign: 'center', padding: '1px' }}>
                    <span style={{
                      display: 'inline-block', width: 22, height: 18, lineHeight: '18px',
                      fontSize: 10, fontWeight: 500, borderRadius: 3,
                      background: chipBg, color: chipClr,
                    }}>
                      {side1 ? lbl1 : lbl2}
                    </span>
                  </td>
                );
              };

              return (
                <tr key={bi} style={{ background: rowBg }}>
                  <td style={{ padding: '2px 6px', fontSize: 10, color: labelClr, fontWeight: (isOverall || isPress) ? 600 : 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{bet.label}</td>
                  {FRONT_H.map(h => holeTd(h))}
                  <td style={{ textAlign: 'center', fontSize: 10, fontWeight: 700, background: tBg, color: f9Clr, padding: '2px 3px' }}>{f9Info ? f9Info.text : '—'}</td>
                  {BACK_H.map(h => holeTd(h))}
                  <td style={{ textAlign: 'center', fontSize: 10, fontWeight: 700, background: tBg, color: b9Clr, padding: '2px 3px' }}>{b9Info ? b9Info.text : '—'}</td>
                  <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, background: tBg, color: allClr, padding: '2px 4px' }}>{allInfo ? allInfo.text : '—'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  const [pressModal, setPressModal] = useState(null);

  return (
    <>
      {pressModal && (() => {
        const { betHoles, mpKey, depth, minHole, existingPressHole, label, status, winnerName } = pressModal;
        return (
          <PressModal
            title={`Press: ${label}`}
            status={status}
            winnerName={winnerName}
            validHoles={betHoles}
            existingPressHole={existingPressHole}
            minHole={minHole}
            onConfirm={h => {
              setManualPresses(prev => {
                const ex = prev[mpKey] || [];
                const trimmed = ex.slice(0, depth);
                if (trimmed.includes(h)) return prev;
                return { ...prev, [mpKey]: [...trimmed, h].sort((a,b) => a-b) };
              });
              setPressModal(null);
            }}
            onRemove={h => {
              setManualPresses(prev => ({
                ...prev,
                [mpKey]: (prev[mpKey] || []).filter(x => x < h),
              }));
              setPressModal(null);
            }}
            onClose={() => setPressModal(null)}
          />
        );
      })()}

      {matches.map((matchDef, mi) => {
        const matchId  = matchDef.id || `match_${mi}`;
        const isTeam   = matchDef.format === 'team';
        const nassau   = isNassauMatch(matchDef);
        const mode     = matchDef.grossNetNOL ?? matchDef.scoring ?? 'net';
        const tiebreak = matchDef.scoring ?? matchDef.tiebreak ?? 'none';
        // Section header: "Match A", "Match B", … — index-derived per Nassau_Match_Contract §5.6
        const matchLetter = String.fromCharCode(65 + mi);
        const title    = `Match ${matchLetter}`;

        const legacyN = (matchDef.autoPress && matchDef.autoPress !== 'none') ? parseInt(matchDef.autoPress) : 0;
        const toN = (v) => (v && v !== 'none') ? parseInt(v) : legacyN;
        const apF = toN(matchDef.autoPressF);
        const apB = toN(matchDef.autoPressB);
        const apO = toN(matchDef.autoPressO);
        const apParts = [];
        if (apF > 0) apParts.push(`F${apF}`);
        if (apB > 0) apParts.push(`B${apB}`);
        if (apO > 0) apParts.push(`O${apO}`);
        const badge = `${scoringLabel(mode)}${apParts.length ? ` · AP ${apParts.join('/')}dn` : ''}`;

        // ── Name / chip label resolution ──────────────────────────────────────
        let nm1, nm2, lbl1, lbl2;
        if (isTeam) {
          const r = resolveMatchTeamNames(matchDef.teamA || [], matchDef.teamB || [], players);
          nm1 = r.nmA; nm2 = r.nmB; lbl1 = r.chipA; lbl2 = r.chipB;
        } else {
          nm1 = players[matchDef.p1]?.name || '?';
          nm2 = players[matchDef.p2]?.name || '?';
          lbl1 = initials(nm1);
          lbl2 = initials(nm2);
        }

        const valid = isTeam
          ? (matchDef.teamA?.length > 0 && matchDef.teamB?.length > 0 && [...(matchDef.teamA||[]), ...(matchDef.teamB||[])].every(i => players[i]))
          : (players[matchDef.p1] && players[matchDef.p2]);

        if (!valid) return (
          <GameSection key={matchId} title={title} badge={badge} color={M.hdrClr} borderColor={M.border}>
            <div style={{ color: '#aaa', fontSize: 12, padding: '8px 10px 10px' }}>Incomplete match setup — go to Setup.</div>
          </GameSection>
        );

        const holeWinFn = isTeam
          ? (h) => teamHoleWinner(matchDef.teamA, matchDef.teamB, h, mode, tiebreak)
          : (h) => indivHoleWinner(matchDef.p1, matchDef.p2, h, mode);

        const mpFront   = (manualPresses || {})[`Match:${matchId}:Front`]   || [];
        const mpBack    = (manualPresses || {})[`Match:${matchId}:Back`]    || [];
        const mpOverall = (manualPresses || {})[`Match:${matchId}:Overall`] || [];

        const { front: frontBets, back: backBets, overall: overallBets } = runMatchNassau(
          scores, players, hcps, matchDef, courseHcps, minCourseHcp,
          { front: mpFront, back: mpBack, overall: mpOverall }
        );

        // leadState scoped to segment's own holes — correct closure detection (§13.4)
        const buildDisplayBets = (engineBets, hs, isOverallRow) => {
          return engineBets
            .filter(b => (b.startHole ?? 0) <= hs[hs.length - 1])
            .map((b, i) => {
              const startH    = b.startHole ?? hs[0];
              const runHoles  = hs.filter(h => h >= startH);
              const leadState = buildLeadState(holeWinFn, runHoles);
              return { label: b.label, startHole: startH, isOverall: isOverallRow, isPress: i > 0, leadState };
            });
        };

        const frontDisplayBets = nassau ? buildDisplayBets(frontBets,   FRONT_H, false) : [];
        const backDisplayBets  = nassau ? buildDisplayBets(backBets,    BACK_H,  false) : [];
        const overallFront     = buildDisplayBets(overallBets, FRONT_H, nassau).map(b => ({ ...b, isPress: false }));
        const overallBack      = buildDisplayBets(overallBets, BACK_H,  nassau).map(b => ({ ...b, isPress: false }));

        const frontRows = nassau ? [...frontDisplayBets, ...overallFront] : buildDisplayBets(overallBets, FRONT_H, false);
        const backRows  = nassau ? [...backDisplayBets,  ...overallBack]  : buildDisplayBets(overallBets, BACK_H,  false);

        // Landscape rows: three leadState scopes per row
        const allRows18 = (() => {
          const makeBet18 = (engineBets, isOverallRow) => engineBets.map((b, i) => {
            const startH = b.startHole ?? 0;
            return {
              label:          b.label,
              startHole:      startH,
              isOverall:      isOverallRow,
              isPress:        i > 0,
              leadState:      buildLeadState(holeWinFn, ALL18_H.filter(h => h >= startH)),
              leadStateFront: buildLeadState(holeWinFn, FRONT_H.filter(h => h >= startH)),
              leadStateBack:  buildLeadState(holeWinFn, BACK_H.filter(h => h >= startH)),
            };
          });
          if (!nassau) return makeBet18(overallBets, false);
          return [
            ...makeBet18(frontBets,   false),
            ...makeBet18(backBets,    false),
            ...makeBet18(overallBets, true).map(b => ({ ...b, isPress: false })),
          ];
        })();

        const makeBetChip = (bet, segHoles, segLabel, depth, totalDepths, mpKey, mpArr) => {
          const betHoles  = segHoles.filter(h => h >= (bet.startHole ?? segHoles[0]));
          const leadState = buildLeadState(holeWinFn, betHoles);
          const lastH     = [...betHoles].reverse().find(h => leadState[h] !== undefined);
          const info      = lastH != null ? fmtLead(leadState[lastH].lead, leadState[lastH].matchOver, leadState[lastH].holesLeft) : null;
          const winnerName = info ? (leadState[lastH].lead > 0 ? nm1 : leadState[lastH].lead < 0 ? nm2 : 'All Square') : '—';

          const pressDepthBg  = depth === 0 ? null : depth === 1 ? '#e8f4fb' : '#dceef8';
          const pressDepthLbl = depth === 0 ? M.hdrClr : '#1a6b9a';
          const chipBg = info
            ? (leadState[lastH].lead > 0
                ? (depth > 0 ? '#c0d8f0' : TMA_BG)
                : leadState[lastH].lead < 0
                  ? (depth > 0 ? '#f8dede' : TMB_BG)
                  : (depth > 0 ? '#e0e0f8' : '#eaeaff'))
            : (pressDepthBg || M.hdrBg);
          const chipColor = info
            ? (leadState[lastH].lead > 0 ? TMA_LED : leadState[lastH].lead < 0 ? TMB_LED : '#aaa')
            : '#aaa';

          const existingPressHole = mpArr[depth] ?? null;
          const minHole       = bet.startHole ?? segHoles[0];
          const label         = depth === 0 ? segLabel : bet.label;
          const hasChildPress = existingPressHole !== null;
          const isLastInChain = depth === totalDepths - 1;
          const lastScored    = lastScoredInHoles(holeWinFn, betHoles);
          const canAddPress   = isLastInChain && lastScored !== null && lastScored < betHoles[betHoles.length - 1];
          const pressable     = hasChildPress || canAddPress;

          return {
            label, winnerName, value: info ? info.text : '—',
            color: chipColor,
            bg: chipBg, labelColor: pressDepthLbl,
            pressable, hasChildPress, isPress: depth > 0,
            onLongPress: () => setPressModal({
              matchId, segment: segLabel, betHoles, mpKey, mpArr, depth,
              minHole, existingPressHole,
              label: `${nm1} vs ${nm2} · ${label}`,
              status: info ? info.text : '—',
              winnerName,
            }),
          };
        };

        const buildSegment = (engineBets, segHoles, segLabel) => {
          const mpKey = `Match:${matchId}:${segLabel}`;
          const mpArr = (manualPresses || {})[mpKey] || [];
          const total = engineBets.length || 1;
          const [main, ...presses] = engineBets;
          if (!main) return {
            mainChip: makeBetChip({ startHole: segHoles[0], label: segLabel }, segHoles, segLabel, 0, 1, mpKey, mpArr),
            pressChips: [],
          };
          return {
            mainChip:   makeBetChip(main, segHoles, segLabel, 0, total, mpKey, mpArr),
            pressChips: presses.map((pb, pi) => makeBetChip(pb, segHoles, segLabel, pi + 1, total, mpKey, mpArr)),
          };
        };

        const segments = nassau ? [
          buildSegment(frontBets,   FRONT_H, 'Front'),
          buildSegment(backBets,    BACK_H,  'Back'),
          buildSegment(overallBets, ALL18_H, 'Overall'),
        ] : [
          buildSegment(overallBets, ALL18_H, 'Overall'),
        ];

        return (
          <GameSection key={matchId} title={title} badge={badge} color={M.hdrClr} borderColor={M.border}>
            {/* Team: blue/red color-coded names matching SixesTable convention */}
            <div style={{ fontSize: 11, fontWeight: 700, color: M.hdrClr, padding: '5px 10px 2px' }}>
              {isTeam ? (
                <>
                  <span style={{ color: TMA_LED }}>{nm1}</span>
                  <span style={{ color: '#aaa', fontWeight: 400, margin: '0 4px' }}>vs</span>
                  <span style={{ color: TMB_LED }}>{nm2}</span>
                </>
              ) : (
                `${nm1} vs ${nm2}`
              )}
            </div>
            {isLandscape ? (
              renderAll18(allRows18, holeWinFn, nm1, nm2, lbl1, lbl2, isTeam)
            ) : (
              <>
                <HalfLabel>Front 9</HalfLabel>
                {renderHalf(FRONT_H, frontRows, holeWinFn, nm1, nm2, lbl1, lbl2, isTeam)}
                <TableDivider/>
                <HalfLabel>Back 9</HalfLabel>
                {renderHalf(BACK_H, backRows, holeWinFn, nm1, nm2, lbl1, lbl2, isTeam)}
              </>
            )}
            <TableDivider/>
            <SegmentChipColumns segments={segments}/>
          </GameSection>
        );
      })}
    </>
  );
}
