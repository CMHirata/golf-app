// ─── tables/NinesTable.jsx ────────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js

import { scoreForMode, xGrossScore } from '../../engine/handicap.js';
import { ninesPts } from '../../engine/games.js';
import { N, nameTd, scoringLabel } from '../scorecard/scorecardUtils.js';
import { GameSection, GameTable, HalfLabel, TableDivider, ColNote, PlayerChips } from '../scorecard/GameSection.jsx';
import { RED } from '../../components/ui.jsx';

const FRONT = [0,1,2,3,4,5,6,7,8];
const BACK  = [9,10,11,12,13,14,15,16,17];

export function NinesTable({ players, scores, pars, hcps, opts, courseHcps, minCourseHcp, ninesPlayers, isLandscape }) {
  const mode  = opts?.grossNetNOL ?? opts?.scoring ?? 'net';
  const blitz = opts?.blitz   || false;

  if (!ninesPlayers || ninesPlayers.length !== 3) return null;
  const activeIdxs = ninesPlayers;
  const activePlayers = activeIdxs.map(i => players[i]).filter(Boolean);
  if (activePlayers.length !== 3) return null;

  const holeData = (hs) => hs.map(h => {
    const raws = activeIdxs.map(pi => scores[h]?.[pi]);
    // Stop if any player unscored (empty/null). 'X' counts as scored.
    if (raws.some(r => r === '' || r == null)) return null;

    const xFlags = raws.map(r => r === 'X');
    const allX   = xFlags.every(Boolean);
    if (allX) return new Array(activeIdxs.length).fill(3);

    // Compute numeric values; X players get null (replaced with worst+1 below)
    const numericVals = raws.map((raw, k) => {
      if (xFlags[k]) return null;
      const pi = activeIdxs[k];
      const g  = parseInt(raw);
      return mode === 'gross' ? g : scoreForMode(g, courseHcps[pi], hcps[h], minCourseHcp, mode);
    });
    const maxReal  = Math.max(...numericVals.filter(v => v !== null));
    const normVals = numericVals.map(v => v === null ? maxReal + 1 : v);
    return ninesPts(normVals, blitz);
  });

  const vColor = v => v === null ? '#ccc' : v === 9 ? '#7b1fa2' : v === 5 ? '#27ae60' : v === 0 ? RED : '#333';

  const renderHalf = (hs, label) => {
    const data   = holeData(hs);
    const halves = activePlayers.map((_, k) => data.reduce((s, pts) => s + (pts ? pts[k] : 0), 0));
    return (
      <>
        <HalfLabel>{label}</HalfLabel>
        <div style={{ padding: '0 8px 4px' }}>
          <GameTable hs={hs} colHeader="Total" headerBg={N.hdrBg} headerColor={N.hdrClr} totBg={N.totBg} totColor={N.totClr}>
            {activePlayers.map((p, k) => (
              <tr key={activeIdxs[k]} style={{ background: N.row[k % 2] }}>
                <td style={{ ...nameTd, color: N.hdrClr }}>{p.name}</td>
                {data.map((pts, i) => { const v = pts ? pts[k] : null; return <td key={i} style={{ textAlign: 'center', fontSize: 11, color: vColor(v), fontWeight: v === 9 ? 700 : 400 }}>{v === null ? '·' : v}</td>; })}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: N.totClr, background: N.totBg, padding: '2px 4px' }}>{halves[k]}</td>
              </tr>
            ))}
          </GameTable>
        </div>
      </>
    );
  };

  const renderAll18 = () => {
    const frontData = holeData(FRONT);
    const backData  = holeData(BACK);
    const frontTots = activePlayers.map((_, k) => frontData.reduce((s, pts) => s + (pts ? pts[k] : 0), 0));
    const backTots  = activePlayers.map((_, k) => backData.reduce((s, pts) => s + (pts ? pts[k] : 0), 0));
    return (
      <div style={{ padding: '0 8px 4px' }}>
        <GameTable landscape headerBg={N.hdrBg} headerColor={N.hdrClr} totBg={N.totBg} totColor={N.totClr}>
          {activePlayers.map((p, k) => (
            <tr key={activeIdxs[k]} style={{ background: N.row[k % 2] }}>
              <td style={{ ...nameTd, color: N.hdrClr }}>{p.name}</td>
              {frontData.map((pts, i) => { const v = pts ? pts[k] : null; return <td key={i} style={{ textAlign: 'center', fontSize: 11, color: vColor(v), fontWeight: v === 9 ? 700 : 400 }}>{v === null ? '·' : v}</td>; })}
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: N.totClr, background: N.totBg, padding: '2px 3px' }}>{frontTots[k]}</td>
              {backData.map((pts, i) => { const v = pts ? pts[k] : null; return <td key={i+9} style={{ textAlign: 'center', fontSize: 11, color: vColor(v), fontWeight: v === 9 ? 700 : 400 }}>{v === null ? '·' : v}</td>; })}
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: N.totClr, background: N.totBg, padding: '2px 3px' }}>{backTots[k]}</td>
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, color: N.totClr, background: N.totBg, padding: '2px 3px' }}>{frontTots[k] + backTots[k]}</td>
            </tr>
          ))}
        </GameTable>
      </div>
    );
  };

  const allData = holeData([...Array(18).keys()]);
  const totals = activePlayers.map((_, k) => allData.reduce((s, pts) => s + (pts ? pts[k] : 0), 0));

  return (
    <GameSection title="Nines" badge={`${scoringLabel(mode)}${blitz ? ' · Blitz' : ''}`} color={N.hdrClr} borderColor={N.border}>
      {isLandscape ? (
        renderAll18()
      ) : (
        <>
          {renderHalf(FRONT, 'Front 9')}
          <TableDivider/>
          {renderHalf(BACK, 'Back 9')}
        </>
      )}
      <TableDivider/>
      <PlayerChips players={activePlayers} values={totals} chipBg={N.hdrBg} chipColor={N.hdrClr} leaderBg={N.totBg} leaderColor={N.totClr} fmtVal={v => v} subLabel=""/>
      <ColNote>9 = blitz · 5/3/1 = positions · 0 = lost hole</ColNote>
    </GameSection>
  );
}
