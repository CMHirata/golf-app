// ─── payouts.js ───────────────────────────────────────────────────────────────
// Computes final dollar payouts for every active game.
// Pure function — no React, no DOM. Returns { bank, breakdown }.
//
// NOL + SUBSET RULE (Handicap Contract §5):
//   When a game operates on a player subset and scoring mode is 'netofflow',
//   minCourseHcp passed to the engine must be the minimum course handicap of
//   the participating subset only — never from a superset of players.
//   All per-game blocks below use subsetMin() to enforce this invariant.

import { scoreForMode } from './handicap.js';
import {
  calcSkins,
  calcNines, ninesPts,
  runMatchNassau, isNassauMatch, matchLabel,
  getSixesTeam, calcSixesSegment, runSixesSegment,
  calcStablefordTotal, calcTeamStablefordTotal,
  calcStrokePlay,
  getDotsPartner, getMatchTeamPartner, sixesSegForHole,
} from './games.js';

const ALL18 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17];
const FRONT  = [0,1,2,3,4,5,6,7,8];
const BACK   = [9,10,11,12,13,14,15,16,17];

function initBank(players) {
  const bank = {};
  players.forEach(p => (bank[p.name] = 0));
  return bank;
}

/** Pay the winner of a segment vs all other players in the subset */
function payWinner(winner, players, bet, gb) {
  players.forEach(p => {
    if (p.name !== winner) { gb[p.name] -= bet; gb[winner] += bet; }
  });
}

/**
 * Compute the minimum course handicap for a subset of player indices.
 * When mode is 'netofflow' and idxs is a non-empty subset, returns the
 * minimum of cHcps[i] for i in idxs only.
 * When mode is not 'netofflow', or idxs is empty, returns globalMin.
 * This enforces the NOL + subset invariant (Handicap Contract §5).
 */
function subsetMin(cHcps, idxs, globalMin, mode) {
  if (mode !== 'netofflow' || !idxs?.length) return globalMin;
  return Math.min(...idxs.map(i => cHcps[i]));
}

export function computePayouts({
  players, pars, hcps, scores,
  activeGames, gameOpts,
  matches = [],             // unified Match/Nassau instances
  strokePlayPlayers = [],   // player index subset for Stroke Play ([] = all)
  skinsPlayers = [],        // player index subset for Skins ([] = all)
  stablefordPlayers = [],   // player index subset for Stableford ([] = all)
  ninesPlayers = [],        // 3 player indices for Nines
  sixesTeams,
  sixesPlayers = [],        // 4 player indices for Sixes ([] = all; deferred 5-player support)
  dotsPlayers = [],         // player index subset for Dots ([] = all)
  dots, dotEntries,
  courseHcps,
  minCourseHcp,
  manualPresses = {},
  // 13-C.2: Round length — accepted for forward compatibility, not yet used
  // for range trimming (that is 13-C.3 scope per PartialGameContract §1.3).
  // Engine firewall (§11.1, invariant #13) guarantees these are a complete
  // no-op when roundStartHole=0 and roundNumHoles=18.
  // eslint-disable-next-line no-unused-vars
  roundStartHole = 0,
  // eslint-disable-next-line no-unused-vars
  roundNumHoles  = 18,
}) {
  const bank      = initBank(players);
  const breakdown = [];
  const cHcps    = courseHcps || players.map(p => Math.round(parseFloat(p.ghin) || 0));
  const minCHcp  = minCourseHcp ?? Math.min(...cHcps);
  const parTot   = pars.reduce((a, b) => a + b, 0);

  // ── Stroke Play ────────────────────────────────────────────────────────────
  if (activeGames.includes('Stroke Play')) {
    const bet        = gameOpts['Stroke Play']?.bet  || 0;
    const mode       = gameOpts['Stroke Play']?.grossNetNOL ?? gameOpts['Stroke Play']?.scoring ?? 'net';
    const strokeMode = gameOpts['Stroke Play']?.betMode ?? gameOpts['Stroke Play']?.strokeMode ?? 'total';
    const spBetF     = gameOpts['Stroke Play']?.betF  ?? bet;
    const spBetB     = gameOpts['Stroke Play']?.betB  ?? bet;
    const spBet18    = gameOpts['Stroke Play']?.bet18 ?? bet;

    const spIdxs = strokePlayPlayers?.length ? strokePlayPlayers : players.map((_, i) => i);
    const spMin  = subsetMin(cHcps, spIdxs, minCHcp, mode);
    const gb     = initBank(players);

    // payWinnerStroke: lowest nd wins the segment; ties = no payout
    const payWinnerStroke = (segRows, segBet) => {
      if (segBet <= 0 || !segRows.length) return;
      const low = segRows[0].nd;
      const winners = segRows.filter(r => r.nd === low);
      const losers  = segRows.filter(r => r.nd !== low);
      if (losers.length > 0 && winners.length === 1) {
        const pot   = losers.length * segBet;
        winners.forEach(w => { gb[w.name] += pot; });
        losers.forEach(l  => { gb[l.name] -= segBet; });
      }
    };

    if (strokeMode === 'nassau' || strokeMode === 'segments') {
      // Compute net-to-par per segment for each player in subset
      const segScore = (holes) => {
        return spIdxs.map(pi => {
          const p = players[pi];
          let nd = 0;
          for (const h of holes) {
            const g = parseInt(scores[h]?.[pi]);
            if (!g) continue;
            const net = scoreForMode(g, cHcps[pi], hcps[h], spMin, mode);
            nd += net - pars[h];
          }
          return { name: p.name, nd };
        }).sort((a, b) => a.nd - b.nd);
      };
      payWinnerStroke(segScore(FRONT), spBetF);
      payWinnerStroke(segScore(BACK),  spBetB);
      const rows18 = calcStrokePlay(scores, players, hcps, pars, mode, cHcps, spMin, spIdxs);
      payWinnerStroke(rows18, spBet18);
      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏌️ Stroke Play (Nassau)',
        rows: rows18.map(r => ({ name: r.name, detail: `${r.nd > 0 ? '+' : ''}${r.nd}`, net: gb[r.name] || 0 })),
      });
    } else {
      const rows = calcStrokePlay(scores, players, hcps, pars, mode, cHcps, spMin, spIdxs);
      if (bet > 0 && rows.length > 0) {
        const lowNd   = rows[0].nd;
        const winners = rows.filter(r => r.nd === lowNd);
        const losers  = rows.filter(r => r.nd !== lowNd);
        if (losers.length > 0) {
          const pot   = losers.length * bet;
          const split = pot / winners.length;
          winners.forEach(w => { gb[w.name] += split; });
          losers.forEach(l  => { gb[l.name] -= bet;   });
        }
      }
      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏌️ Stroke Play',
        rows: rows.map(r => ({
          name:   r.name,
          detail: `${r.gt} gross / ${r.nt} net (${r.nd > 0 ? '+' : ''}${r.nd})`,
          net:    gb[r.name] || 0,
        })),
      });
    }
  }

  // ── Skins ──────────────────────────────────────────────────────────────────
  if (activeGames.includes('Skins')) {
    const bet          = gameOpts.Skins?.bet || 0;
    const payoutMode   = gameOpts.Skins?.mode || 'perSkin'; // backward compat: absent → 'perSkin'
    const scoringMode  = gameOpts.Skins?.grossNetNOL ?? gameOpts.Skins?.scoring ?? 'net';
    const carryover    = gameOpts.Skins?.carryover === false ? false : true;
    const idxs         = skinsPlayers?.length ? skinsPlayers : players.map((_, i) => i);
    const skinPs       = idxs.map(i => players[i]).filter(Boolean);
    const subsetSize   = skinPs.length;

    // NOL + subset: use subset minimum when mode is netofflow (Handicap Contract §5.2)
    const skinsMin = subsetMin(cHcps, idxs, minCHcp, scoringMode);

    const { rows, totals } = calcSkins(scores, players, hcps, scoringMode, carryover, cHcps, skinsMin, idxs);
    const gb           = initBank(players);

    // Sum awarded skins across subset players only (invariant: non-subset totals[name] === 0)
    const totalAwardedSkins = skinPs.reduce((sum, p) => sum + (totals[p.name] || 0), 0);

    if (bet > 0) {
      if (payoutMode === 'perSkin') {
        // bet = per-player contribution per skin; each skin is worth bet × subsetSize.
        // gross[p] = totals[p] × bet × subsetSize
        // pp       = totalAwardedSkins × bet  (each player's total contribution)
        // net[p]   = gross[p] - pp
        if (totalAwardedSkins > 0) {
          const skinValue = bet * subsetSize;
          const pp        = totalAwardedSkins * bet;
          skinPs.forEach(p => { gb[p.name] += (totals[p.name] || 0) * skinValue - pp; });
        }
      } else {
        // pot mode: each player buys in for `bet`; pot split by awarded skins.
        // If no skins awarded, pot is returned (all net = 0).
        if (totalAwardedSkins > 0) {
          const pot          = bet * subsetSize;
          const skinUnitValue = pot / totalAwardedSkins;
          skinPs.forEach(p => { gb[p.name] += (totals[p.name] || 0) * skinUnitValue - bet; });
        }
      }
    }

    Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
    breakdown.push({
      game: '💰 Skins',
      rows: skinPs.map(p => ({
        name:   p.name,
        detail: `${totals[p.name]} skins`,
        net:    gb[p.name] || 0,
      })).sort((a, b) => b.net - a.net),
    });
  }

  // ── Match / Nassau ─────────────────────────────────────────────────────────
  if (activeGames.includes('Match / Nassau') && matches.length > 0) {
    const gb            = initBank(players);
    const playerDetails = {};
    players.forEach(p => (playerDetails[p.name] = []));

    matches.forEach((matchDef, mi) => {
      const matchKey = matchDef.id || `match_${mi}`;
      const manuPresses = {
        front:   manualPresses[`Match:${matchKey}:Front`]   || [],
        back:    manualPresses[`Match:${matchKey}:Back`]    || [],
        overall: manualPresses[`Match:${matchKey}:Overall`] || [],
      };

      // NOL + match subset: derive minCourseHcp from match participants only
      // (Handicap Contract §5.4). Individual matches involve 2 players;
      // team matches involve 4. Full-field minCHcp is wrong here.
      const isTeam = matchDef.format === 'team';
      const sideA  = isTeam ? (matchDef.teamA || []) : [matchDef.p1];
      const sideB  = isTeam ? (matchDef.teamB || []) : [matchDef.p2];
      const involved = [...sideA, ...sideB].filter(i => players[i]);
      const matchMode = matchDef.grossNetNOL ?? matchDef.scoring ?? 'net';
      const matchMin  = subsetMin(cHcps, involved, minCHcp, matchMode);

      const { front, back, overall } = runMatchNassau(
        scores, players, hcps, matchDef, cHcps, matchMin, manuPresses
      );

      const betF = matchDef.betFront   || 0;
      const betB = matchDef.betBack    || 0;
      const betO = matchDef.betOverall || 0;
      const lbl  = matchLabel(matchDef, players);

      const segments = [
        { bets: front,   betAmt: betF, seg: 'Front' },
        { bets: back,    betAmt: betB, seg: 'Back'  },
        { bets: overall, betAmt: betO, seg: isNassauMatch(matchDef) ? 'Overall' : 'Main' },
      ];

      segments.forEach(({ bets, betAmt, seg }) => {
        bets.forEach(m => {
          if (m.thru > 0) {
            involved.forEach(pi => {
              if (players[pi]) {
                const tag = `${lbl} ${seg}${bets.length > 1 ? ` (${m.label})` : ''}`;
                playerDetails[players[pi].name].push(`${tag}: ${m.status}`);
              }
            });
          }
          if (betAmt > 0 && m.thru > 0) {
            // Individual match
            if (!isTeam && m.lead !== 0) {
              const wi = m.lead > 0 ? matchDef.p1 : matchDef.p2;
              const li = m.lead > 0 ? matchDef.p2 : matchDef.p1;
              if (players[wi] && players[li]) {
                gb[players[wi].name] += betAmt;
                gb[players[li].name] -= betAmt;
              }
            }
            // Team match — each player on winning side wins betAmt from each player on losing side
            if (isTeam && m.lead !== 0) {
              const winSide = m.lead > 0 ? sideA : sideB;
              const losSide = m.lead > 0 ? sideB : sideA;
              winSide.forEach(wi => {
                if (players[wi]) gb[players[wi].name] += betAmt;
              });
              losSide.forEach(li => {
                if (players[li]) gb[players[li].name] -= betAmt;
              });
            }
          }
        });
      });
    });

    Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
    breakdown.push({
      game: '🥊 Match / Nassau',
      rows: players.map(p => ({
        name:   p.name,
        detail: playerDetails[p.name]?.join(' · ') || '—',
        net:    gb[p.name] || 0,
      })).sort((a, b) => b.net - a.net),
    });
  }

  // ── Stableford ─────────────────────────────────────────────────────────────
  if (activeGames.includes('Stableford')) {
    const bet         = gameOpts.Stableford?.bet || 0;
    const mode        = gameOpts.Stableford?.grossNetNOL ?? 'net';
    const stabBetMode = gameOpts.Stableford?.betMode ?? gameOpts.Stableford?.stabBetMode ?? 'perpoint';
    const stabTable   = gameOpts.Stableford?.stabTable ?? null;
    const format      = gameOpts.Stableford?.format ?? 'individual';
    const teamA       = gameOpts.Stableford?.teamA ?? [];
    const teamB       = gameOpts.Stableford?.teamB ?? [];
    const scoring     = gameOpts.Stableford?.scoring ?? 'cumulative';
    const gb          = initBank(players);

    // Per-segment bet overrides
    const stabBetF  = gameOpts.Stableford?.betF  || bet;
    const stabBetB  = gameOpts.Stableford?.betB  || bet;
    const stabBet18 = gameOpts.Stableford?.bet18 || bet;

    if (format === 'team' && teamA.length === 2 && teamB.length === 2) {
      // ── Team mode ──────────────────────────────────────────────────────────
      // NOL+subset: use team union as participant set
      const teamIdxs = [...teamA, ...teamB];
      const stabMin  = subsetMin(cHcps, teamIdxs, minCHcp, mode);

      const teamTots = (idxs, holes) =>
        calcTeamStablefordTotal(scores, pars, hcps, cHcps, stabMin, mode, stabTable, idxs, scoring, holes);

      // Helper: settle one team pair for a segment — each player pays/receives full segBet
      const payTeamSeg = (totA, totB, segBet) => {
        if (segBet <= 0 || totA === totB) return; // push on tie
        const [winners, losers] = totA > totB ? [teamA, teamB] : [teamB, teamA];
        winners.forEach(pi => { gb[players[pi].name] += segBet; });
        losers.forEach(pi  => { gb[players[pi].name] -= segBet; });
      };

      if (stabBetMode === 'perpoint') {
        const rA = teamTots(teamA, ALL18);
        const rB = teamTots(teamB, ALL18);
        const diff = Math.abs(rA.pts - rB.pts);
        if (bet > 0 && diff > 0) {
          const perPlayer = diff * bet;
          const [winners, losers] = rA.pts > rB.pts ? [teamA, teamB] : [teamB, teamA];
          winners.forEach(pi => { gb[players[pi].name] += perPlayer; });
          losers.forEach(pi  => { gb[players[pi].name] -= perPlayer; });
        }
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        const allTeamPis = [...teamA, ...teamB];
        breakdown.push({
          game: 'Stableford',
          rows: allTeamPis
            .map(pi => ({ name: players[pi].name, detail: `${teamA.includes(pi) ? rA.pts : rB.pts} pts`, net: gb[players[pi].name] || 0 }))
            .sort((a, b) => b.net - a.net),
        });
      } else if (stabBetMode === 'segments') {
        const rA = teamTots(teamA, ALL18);
        const rB = teamTots(teamB, ALL18);
        // payTeamSeg already writes correct per-player amounts to gb
        payTeamSeg(rA.ptsF, rB.ptsF, stabBetF);
        payTeamSeg(rA.ptsB, rB.ptsB, stabBetB);
        payTeamSeg(rA.pts,  rB.pts,  stabBet18);
        const nmA = teamA.map(pi => players[pi].name).join(' & ');
        const nmB = teamB.map(pi => players[pi].name).join(' & ');
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        const allTeamPis = [...teamA, ...teamB];
        breakdown.push({
          game: 'Stableford',
          rows: [
            { name: 'F9',  detail: `${nmA} ${rA.ptsF} / ${nmB} ${rB.ptsF}`, net: null, isHeader: true },
            { name: 'B9',  detail: `${nmA} ${rA.ptsB} / ${nmB} ${rB.ptsB}`, net: null, isHeader: true },
            { name: '18h', detail: `${nmA} ${rA.pts}  / ${nmB} ${rB.pts}`,  net: null, isHeader: true },
            ...allTeamPis
              .map(pi => ({ name: players[pi].name, detail: '', net: gb[players[pi].name] || 0 }))
              .sort((a, b) => b.net - a.net),
          ],
        });
      } else {
        // 'total' mode: each player on winning team receives bet; each on losing team pays bet
        const rA = teamTots(teamA, ALL18);
        const rB = teamTots(teamB, ALL18);
        if (bet > 0) payTeamSeg(rA.pts, rB.pts, bet);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        const allTeamPis = [...teamA, ...teamB];
        breakdown.push({
          game: 'Stableford',
          rows: allTeamPis
            .map(pi => ({ name: players[pi].name, detail: `${teamA.includes(pi) ? rA.pts : rB.pts} pts`, net: gb[players[pi].name] || 0 }))
            .sort((a, b) => b.net - a.net),
        });
      }
    } else {
      // ── Individual mode ────────────────────────────────────────────────────
      const stabIdxs = stablefordPlayers?.length ? stablefordPlayers : players.map((_, i) => i);
      const stabPs   = stabIdxs.map(i => players[i]).filter(Boolean);

      // NOL+subset: use subset minimum
      const stabMin = subsetMin(cHcps, stabIdxs, minCHcp, mode);

      const stabScore = (pi, holes) =>
        calcStablefordTotal(scores, pi, pars, hcps, cHcps[pi], stabMin, mode, stabTable, holes);

      // Split-pot helper: finds co-winners (tied high), losers pay segBet, pot split among winners
      const paySegStab = (arr, field, segBet) => {
        if (segBet <= 0) return;
        const maxVal  = Math.max(...arr.map(r => r[field]));
        const winners = arr.filter(r => r[field] === maxVal);
        const losers  = arr.filter(r => r[field] < maxVal);
        if (losers.length === 0) return; // all tied — push
        const share = (losers.length * segBet) / winners.length;
        losers.forEach(r  => { gb[r.name] -= segBet; });
        winners.forEach(r => { gb[r.name] += share; });
      };

      if (stabBetMode === 'perpoint' && bet > 0) {
        const ranked = stabIdxs
          .map(pi => ({ name: players[pi].name, pts: stabScore(pi, ALL18) }))
          .sort((a, b) => b.pts - a.pts);
        for (let i = 0; i < ranked.length; i++)
          for (let j = i + 1; j < ranked.length; j++) {
            const diff = ranked[i].pts - ranked[j].pts;
            if (diff > 0) { gb[ranked[i].name] += diff * bet; gb[ranked[j].name] -= diff * bet; }
          }
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: 'Stableford',
          rows: ranked.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      } else if (stabBetMode === 'nassau' || stabBetMode === 'segments') {
        const pts18 = stabIdxs.map(pi => ({
          name: players[pi].name,
          pts:  stabScore(pi, ALL18),
          ptsF: stabScore(pi, FRONT),
          ptsB: stabScore(pi, BACK),
        }));
        paySegStab(pts18, 'ptsF', stabBetF);
        paySegStab(pts18, 'ptsB', stabBetB);
        paySegStab(pts18, 'pts',  stabBet18);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: 'Stableford',
          rows: pts18.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      } else {
        // 'total' mode (and any unrecognised value): split-pot among tied winners
        const pts18 = stabIdxs
          .map(pi => ({ name: players[pi].name, pts: stabScore(pi, ALL18) }))
          .sort((a, b) => b.pts - a.pts);
        if (bet > 0) {
          const maxPts  = pts18[0]?.pts ?? 0;
          const winners = pts18.filter(r => r.pts === maxPts);
          const losers  = pts18.filter(r => r.pts < maxPts);
          if (losers.length > 0) {
            const share = (losers.length * bet) / winners.length;
            losers.forEach(r  => { gb[r.name] -= bet; });
            winners.forEach(r => { gb[r.name] += share; });
          }
        }
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: 'Stableford',
          rows: pts18.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      }
    }
  }

  // ── Nines ──────────────────────────────────────────────────────────────────
  if (activeGames.includes('Nines')) {
    const bet       = gameOpts.Nines?.bet || 0;
    const mode      = gameOpts.Nines?.grossNetNOL ?? gameOpts.Nines?.scoring ?? 'net';
    const ninesMode = gameOpts.Nines?.betMode ?? gameOpts.Nines?.ninesMode ?? 'perpoint';
    const blitz     = gameOpts.Nines?.blitz || false;

    // Per-segment bets (nassau mode)
    const ninesBetF  = gameOpts.Nines?.betF  ?? bet;
    const ninesBetB  = gameOpts.Nines?.betB  ?? bet;
    const ninesBet18 = gameOpts.Nines?.bet18 ?? bet;

    // ninesPlayers resolution chain (Nines Contract §2.2):
    //   Step 1: top-level ninesPlayers param (from buildPayoutArgs) — length must be exactly 3
    //   Step 2: gameOpts.Nines.ninesPlayers legacy field — length must be exactly 3
    //   Step 3: [0,1,2] fallback ONLY for 3-player rounds (safe because all 3 players participate).
    //           In 4+ player rounds with no valid subset, skip the block entirely (G-4 fix).
    const nPlayerIdx = ninesPlayers?.length === 3
      ? ninesPlayers
      : (gameOpts.Nines?.ninesPlayers?.length === 3
          ? gameOpts.Nines.ninesPlayers
          : players.length === 3
              ? [0, 1, 2]
              : null);   // null → skip block for 4+ player rounds with no subset set

    const nPlayers = nPlayerIdx ? nPlayerIdx.map(i => players[i]).filter(Boolean) : [];

    if (nPlayers.length >= 3) {
      const gb = initBank(players);

      // NOL + subset: Nines always operates on exactly 3 players (Handicap Contract §5.2)
      const ninesMin = subsetMin(cHcps, nPlayerIdx, minCHcp, mode);

      const calcTots = (holes) => {
        const { totals } = calcNines(scores, players, nPlayerIdx, hcps, mode, blitz, holes, cHcps, ninesMin);
        return nPlayers.map((p, i) => ({ name: p.name, pts: totals[i] }));
      };

      const payRanked = (ranked, rate) => {
        // Pairwise over unordered pairs (i < j) — each pair evaluated exactly once.
        for (let i = 0; i < ranked.length; i++)
          for (let j = i + 1; j < ranked.length; j++) {
            const diff = ranked[i].pts - ranked[j].pts;
            if (diff > 0 && rate > 0) {
              gb[ranked[i].name] += diff * rate;
              gb[ranked[j].name] -= diff * rate;
            }
          }
      };

      const payNassauSeg = (ranked, segBet) => {
        if (segBet <= 0) return;
        for (let i = 0; i < ranked.length; i++)
          for (let j = i + 1; j < ranked.length; j++)
            if (ranked[i].pts > ranked[j].pts) {
              gb[ranked[i].name] += segBet;
              gb[ranked[j].name] -= segBet;
            }
      };

      if (ninesMode === 'perpoint') {
        const ranked = calcTots(ALL18).sort((a, b) => b.pts - a.pts);
        if (bet > 0) payRanked(ranked, bet);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: '🔢 Nines',
          rows: ranked.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      } else {
        const f9 = calcTots(FRONT).sort((a, b) => b.pts - a.pts);
        const b9 = calcTots(BACK).sort((a, b) => b.pts - a.pts);
        const ov = calcTots(ALL18).sort((a, b) => b.pts - a.pts);
        payNassauSeg(f9, ninesBetF);
        payNassauSeg(b9, ninesBetB);
        payNassauSeg(ov, ninesBet18);
        const seg = s => s.map(r => `${r.name} ${r.pts}pts`).join(' / ');
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: '🔢 Nines (Nassau)',
          rows: [
            { name: 'F9', detail: seg(f9), net: null, isHeader: true },
            { name: 'B9', detail: seg(b9), net: null, isHeader: true },
            { name: '18', detail: seg(ov), net: null, isHeader: true },
            ...nPlayers.map(p => ({ name: p.name, detail: 'net', net: gb[p.name] || 0 }))
              .sort((a, b) => b.net - a.net),
          ],
        });
      }
    }
  }

  // ── Sixes ──────────────────────────────────────────────────────────────────
  if (activeGames.includes('Sixes') && sixesTeams?.[0]?.a != null && sixesTeams?.[1]?.a != null) {
    const bet      = gameOpts.Sixes?.bet || 0;
    const mode     = gameOpts.Sixes?.grossNetNOL ?? gameOpts.Sixes?.scoring ?? 'net';
    const tiebreak = gameOpts.Sixes?.scoring ?? gameOpts.Sixes?.tiebreak ?? 'none';
    const gb       = initBank(players);

    // Derive auto-press threshold (0 = off)
    const autoN = (gameOpts.Sixes?.autoPress && gameOpts.Sixes?.autoPress !== 'none')
      ? parseInt(gameOpts.Sixes?.autoPress)
      : 0;

    const SEG_HOLES = [
      [0, 1, 2, 3, 4, 5],
      [6, 7, 8, 9, 10, 11],
      [12, 13, 14, 15, 16, 17],
    ];
    const SEG_KEYS = ['Sixes:seg0', 'Sixes:seg1', 'Sixes:seg2'];

    SEG_HOLES.forEach((holes, si) => {
      const team = getSixesTeam(si, sixesTeams, players);
      if (!team) return; // null → invalid segment per §2.3

      const mpHoles = manualPresses[SEG_KEYS[si]] || [];

      // NOL + subset (Sixes Contract §14.2 / Handicap Contract §5.2):
      // When sixesPlayers is non-empty, compute minCourseHcp from the 4 participating
      // player indices for this segment only. When sixesPlayers is empty (all-player
      // 4-player rounds), full-field minCHcp is correct and subsetMin returns it unchanged.
      const { a, b } = team;
      const others = players.map((_, i) => i).filter(i => i !== a && i !== b);
      const segIdxs = sixesPlayers.length
        ? sixesPlayers
        : [a, b, ...others.slice(0, 2)];
      const segMin = subsetMin(cHcps, segIdxs, minCHcp, mode);

      const matchLevels = runSixesSegment(
        holes, scores, players, hcps,
        team, mode, tiebreak,
        cHcps, segMin,
        autoN, mpHoles
      );
      if (!matchLevels) return; // null → < 4 players guard

      const [c, d] = others;

      // Pay each match level independently at bet $ per player (§4.2)
      matchLevels.forEach(m => {
        if (bet > 0 && m.winTeam && m.thru > 0) {
          const ws = m.winTeam === 'ab' ? [a, b] : [c, d];
          const ls = m.winTeam === 'ab' ? [c, d] : [a, b];
          ws.forEach(wi => { gb[players[wi].name] += bet; });
          ls.forEach(li => { gb[players[li].name] -= bet; });
        }
      });
    });

    Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
    breakdown.push({
      game: '🔄 Sixes',
      rows: players.map(p => ({ name: p.name, detail: '', net: gb[p.name] || 0 }))
        .sort((a, b) => b.net - a.net),
    });
  }

  // ── Dots ───────────────────────────────────────────────────────────────────
  // Formerly "Specials" — renamed in v2.0.
  // Backward compat: also fires for old rounds where activeGames still has 'Specials'.
  // Team-aware payout: Dots_Contract.md §7.6 — partners do not settle against
  // each other. Sixes: per-segment exclusion. Match: fixed exclusion all 18 holes.
  const dotsGameActive = activeGames.includes('Dots') || activeGames.includes('Specials');
  if (dotsGameActive) {
    const dotsOpts = gameOpts.Dots || gameOpts.Specials || {};
    const dolPt    = dotsOpts.bet || 0;
    const ens      = (dots || []).filter(s => s.enabled);
    const gb       = initBank(players);

    // Numeric entry count — backward compatible with legacy boolean true values.
    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);

    // teamMode migration: old rounds stored teamScoring:bool; new rounds store teamMode:string.
    const rawTeamMode = dotsOpts.teamMode;
    const legacyTeam  = dotsOpts.teamScoring;
    const isTeamMode  = rawTeamMode ? rawTeamMode !== 'none' : !!legacyTeam;
    const teamSource  = rawTeamMode && rawTeamMode !== 'none'
      ? rawTeamMode
      : (legacyTeam ? 'Sixes' : 'none');

    // Determine participating players (subset or all)
    const dtIdxs    = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    const dtPlayers = dtIdxs.map(i => players[i]).filter(Boolean);

    // ── indivDots accumulation — used for individual mode and Match display ────
    // Counts own dots including own 'team' dot type (h_pi_team, 3 parts).
    // Excludes companion entries (h_partner_team_dot_for_earner, 6 parts).
    const indivDots = players.map(() => 0);
    Object.entries(dotEntries || {}).forEach(([key, v]) => {
      const cnt = entryCount(v);
      if (!cnt) return;
      const parts = key.split('_');
      if (parts[2] === 'team' && parts.length > 3) return; // skip companions only
      const pi    = parseInt(parts[1]);
      const id    = parts[2];
      const sp    = ens.find(s => s.id === id);
      if (sp && players[pi]) indivDots[pi] += (sp.value ?? sp.pts ?? 1) * cnt;
    });

    // ── Pairwise settlement — team-aware (§7.6) ──────────────────────────────
    if (isTeamMode && teamSource === 'Sixes') {
      // Sixes: per-segment team settlement. For each segment, compute total
      // value-weighted dots for Team A and Team B. The team with more dots
      // wins diff*bet per player (each winner gets +diff*bet, each loser pays
      // -diff*bet). This mirrors the Sixes game payout model exactly.

      // Build segDots[pi][seg] — value-weighted OWN dots per player per segment.
      // Companion entries (h_partner_team_dot_for_earner, 6 parts) are excluded.
      // Own team dot entries (h_pi_team, 3 parts) ARE counted.
      const segDots = players.map(() => [0, 0, 0]);
      Object.entries(dotEntries || {}).forEach(([key, v]) => {
        const cnt = entryCount(v); if (!cnt) return;
        const parts = key.split('_');
        // Skip companion entries only (parts[2]==='team' AND parts.length > 3)
        if (parts[2] === 'team' && parts.length > 3) return;
        const pi    = parseInt(parts[1]);
        const sp    = ens.find(s => s.id === parts[2]);
        if (!sp || !players[pi]) return;
        const seg = sixesSegForHole(parseInt(parts[0]));
        segDots[pi][seg] += (sp.value ?? sp.pts ?? 1) * cnt;
      });

      const gbSeg = [initBank(players), initBank(players), initBank(players)];

      if (dolPt > 0) {
        for (let seg = 0; seg < 3; seg++) {
          // Identify Team A and Team B for this segment via getDotsPartner
          // Team A = [p0, p0's partner]; Team B = remaining dtIdxs players
          const p0 = dtIdxs[0];
          const p0partner = getDotsPartner(p0, seg, sixesTeams, players);
          if (p0partner < 0) continue;
          const teamA = [p0, p0partner].filter(pi => dtIdxs.includes(pi));
          const teamB = dtIdxs.filter(pi => !teamA.includes(pi));
          if (!teamA.length || !teamB.length) continue;

          // Team totals for this segment
          const totA = teamA.reduce((s, pi) => s + segDots[pi][seg], 0);
          const totB = teamB.reduce((s, pi) => s + segDots[pi][seg], 0);
          const diff = totA - totB;

          if (diff > 0) {
            // Team A wins
            teamA.forEach(pi => {
              gb[players[pi].name]         += diff * dolPt;
              gbSeg[seg][players[pi].name] += diff * dolPt;
            });
            teamB.forEach(pi => {
              gb[players[pi].name]         -= diff * dolPt;
              gbSeg[seg][players[pi].name] -= diff * dolPt;
            });
          } else if (diff < 0) {
            // Team B wins
            teamB.forEach(pi => {
              gb[players[pi].name]         += (-diff) * dolPt;
              gbSeg[seg][players[pi].name] += (-diff) * dolPt;
            });
            teamA.forEach(pi => {
              gb[players[pi].name]         -= (-diff) * dolPt;
              gbSeg[seg][players[pi].name] -= (-diff) * dolPt;
            });
          }
        }
      }

      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏅 Dots',
        colHeaders: ['Match A', 'Match B', 'Match C', 'Total'],
        rows: dtPlayers.map((p, ii) => {
          const pi = dtIdxs[ii];
          return {
            name:      p.name,
            detail:    '',
            net:       gb[p.name] || 0,
            matchCols: [
              gbSeg[0][p.name] || 0,
              gbSeg[1][p.name] || 0,
              gbSeg[2][p.name] || 0,
              gb[p.name] || 0,
            ],
          };
        }).sort((a, b) => b.net - a.net),
      });

    } else if (isTeamMode && teamSource.startsWith('Match:')) {
      // Match: fixed teams all 18 holes. Compute team A vs team B using OWN
      // dots only (exclude companion team entries — they mirror partner's dots
      // and would double-count the team total).
      const matchId   = teamSource.slice(6);
      const teamMatch = matches.find(m => m.id === matchId) || matches.find(m => m.format === 'team');
      const tA = (teamMatch?.teamA || []).filter(pi => dtIdxs.includes(pi));
      const tB = (teamMatch?.teamB || []).filter(pi => dtIdxs.includes(pi));

      if (dolPt > 0 && tA.length && tB.length) {
        // ownDots: value-weighted dots per player — includes own 'team' dot type
        // entries (key format: h_pi_team, 3 parts) but excludes companion entries
        // (key format: h_partner_team_dot_for_earner, 6 parts).
        const ownDots = players.map(() => 0);
        Object.entries(dotEntries || {}).forEach(([key, v]) => {
          const cnt = entryCount(v); if (!cnt) return;
          const parts = key.split('_');
          // Skip companion entries (parts[2]==='team' AND parts.length > 3)
          if (parts[2] === 'team' && parts.length > 3) return;
          const pi = parseInt(parts[1]);
          const sp = ens.find(s => s.id === parts[2]);
          if (sp && players[pi]) ownDots[pi] += (sp.value ?? sp.pts ?? 1) * cnt;
        });

        const totA = tA.reduce((s, pi) => s + ownDots[pi], 0);
        const totB = tB.reduce((s, pi) => s + ownDots[pi], 0);
        const diff = totA - totB;
        if (diff > 0) {
          tA.forEach(pi => { gb[players[pi].name] += diff * dolPt; });
          tB.forEach(pi => { gb[players[pi].name] -= diff * dolPt; });
        } else if (diff < 0) {
          tB.forEach(pi => { gb[players[pi].name] += (-diff) * dolPt; });
          tA.forEach(pi => { gb[players[pi].name] -= (-diff) * dolPt; });
        }
      }

      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏅 Dots',
        colHeaders: ['Match', 'Total'],
        rows: dtPlayers.map((p, ii) => {
          const net = gb[p.name] || 0;
          return {
            name:      p.name,
            detail:    '',
            net,
            matchCols: [net, net],
          };
        }).sort((a, b) => b.net - a.net),
      });

    } else {
      // Individual mode — unchanged pairwise loop (§7.6.3)
      if (dolPt > 0) {
        for (let ii = 0; ii < dtIdxs.length; ii++) {
          for (let jj = ii + 1; jj < dtIdxs.length; jj++) {
            const ei = dtIdxs[ii], ej = dtIdxs[jj];
            if (!players[ei] || !players[ej]) continue;
            const diff = indivDots[ei] - indivDots[ej];
            if (diff > 0) {
              gb[players[ei].name] += diff * dolPt;
              gb[players[ej].name] -= diff * dolPt;
            } else if (diff < 0) {
              gb[players[ej].name] += (-diff) * dolPt;
              gb[players[ei].name] -= (-diff) * dolPt;
            }
          }
        }
      }

      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏅 Dots',
        rows: dtPlayers.map((p, ii) => ({
          name:   p.name,
          detail: '',
          net:    gb[p.name] || 0,
        })).sort((a, b) => b.net - a.net),
      });
    }
  }

  // ── Zero-sum invariant check ───────────────────────────────────────────────
  // All games are zero-sum: money only moves between players, never created
  // or destroyed. This check fires in development to catch double-counting,
  // subset misapplication, or rounding bugs. See Payout Contract §6.
  if (process.env.NODE_ENV !== 'production') {
    const total = Object.values(bank).reduce((a, b) => a + b, 0);
    if (Math.abs(total) > 0.01) {
      console.error('[payouts] Zero-sum violation — total net:', total, bank);
    }
  }

  return { bank, breakdown };
}
