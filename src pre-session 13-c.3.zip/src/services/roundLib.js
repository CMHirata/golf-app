// ─── services/roundLib.js ─────────────────────────────────────────────────────
// Round history library: save, list, update, delete completed rounds.
//
// Schema conversions:
//   fromActiveRound(ar)  — activeRound blob  → history record (for saving)
//   toActiveRound(r)     — history record    → activeRound blob (for reloading to scorecard)
//   toSetupState(r)      — history record    → NewRoundPage init state (for pre-filling setup)
//
// Round record schema (stored in SK.rounds):
//   id, date, course_name, course_snapshot, front_nine, back_nine, selected_tee,
//   pars, hcps, players[{id,name,gender,ghin,courseHcpVal,selectedTee}],
//   course_hcps[], min_course_hcp, active_games[], game_opts{},
//   matches[],
//   skins_players[], stroke_play_players[], stableford_players[], nines_players[],
//   sixes_teams[], sixes_players[],
//   dots_players[], dots[], dot_entries{},   ← renamed from specials_players/specials/spec_entries in v2.0
//   scores[][], breakdown[], bank{}
//
// Legacy fields still read for backward compat:
//   match_pairs, nassau_pairs (match migration)
//   specials_players, specials, spec_entries (Dots rename migration v2.0)
//   active_games entry 'Specials' → 'Dots' (v2.0)
//   game_opts.Specials → game_opts.Dots (v2.0)
//   DotDef.pts → DotDef.value (v2.0)
//
// DATA INTEGRITY RULE (Session 1-B):
//   toActiveRound and toSetupState must NEVER read from the live player or course
//   libraries. All data must come exclusively from the stored history record.

import { ls, SK, makeId } from './storage.js';
import { buildLayout, DEF_PARS, DEF_HCP } from '../engine/handicap.js';

// ─── Migration shim ────────────────────────────────────────────────────────────
function migrateRecord(r) {
  let rec = r;

  // ── Match migration (legacy match_pairs / nassau_pairs) ────────────────────
  if (rec.matches === undefined) {
    const matches = [];
    const mp = rec.match_pairs || [];
    const mpOpts = rec.game_opts?.['Match Play'] || {};
    mp.forEach(key => {
      const [i, j] = key.split('-').map(Number);
      matches.push({
        id: `mp_${key}`, format: 'individual', p1: i, p2: j,
        grossNetNOL: mpOpts.scoring || 'net', autoPress: mpOpts.autoPress || 'none',
        autoPressN: mpOpts.autoPressN || '2', betFront: 0, betBack: 0,
        betOverall: mpOpts.bet || 0,
      });
    });
    const np = rec.nassau_pairs || [];
    const nOpts = rec.game_opts?.['Nassau'] || {};
    np.forEach(key => {
      const [i, j] = key.split('-').map(Number);
      matches.push({
        id: `nau_${key}`, format: 'individual', p1: i, p2: j,
        grossNetNOL: nOpts.scoring || 'net', autoPress: nOpts.autoPress || 'none',
        autoPressN: nOpts.autoPressN || '2',
        betFront: nOpts.betFront ?? nOpts.bet ?? 0,
        betBack: nOpts.betBack ?? nOpts.bet ?? 0,
        betOverall: nOpts.betOverall ?? nOpts.bet ?? 0,
      });
    });
    let activeGames = rec.active_games || [];
    if (activeGames.includes('Match Play') || activeGames.includes('Nassau')) {
      activeGames = activeGames.filter(g => g !== 'Match Play' && g !== 'Nassau');
      if (!activeGames.includes('Match / Nassau') && matches.length > 0) {
        activeGames = ['Match / Nassau', ...activeGames];
      }
    }
    rec = { ...rec, matches, active_games: activeGames };
  }

  // ── Dots rename migration (v2.0) ───────────────────────────────────────────
  // activeGames: 'Specials' → 'Dots'
  if (rec.active_games?.includes('Specials') && !rec.active_games.includes('Dots')) {
    rec = {
      ...rec,
      active_games: rec.active_games.map(g => g === 'Specials' ? 'Dots' : g),
    };
  }

  // game_opts: Specials → Dots
  if (rec.game_opts?.Specials && !rec.game_opts?.Dots) {
    const { Specials, ...restOpts } = rec.game_opts;
    rec = { ...rec, game_opts: { ...restOpts, Dots: Specials } };
  }

  // Field renames: specials_players → dots_players, specials → dots, spec_entries → dot_entries
  if (rec.specials_players !== undefined && rec.dots_players === undefined) {
    rec = { ...rec, dots_players: rec.specials_players };
  }
  if (rec.specials !== undefined && rec.dots === undefined) {
    rec = { ...rec, dots: rec.specials };
  }
  if (rec.spec_entries !== undefined && rec.dot_entries === undefined) {
    rec = { ...rec, dot_entries: rec.spec_entries };
  }

  // Companion key segment: team_special_for → team_dot_for
  if (rec.dot_entries) {
    const entries = rec.dot_entries;
    const hasLegacy = Object.keys(entries).some(k => k.includes('team_special_for'));
    if (hasLegacy) {
      const migrated = {};
      Object.entries(entries).forEach(([key, v]) => {
        migrated[key.replace('team_special_for', 'team_dot_for')] = v;
      });
      rec = { ...rec, dot_entries: migrated };
    }
  }

  // DotDef.pts → DotDef.value (non-destructive; restoreDotDefs handles at read time,
  // but we normalise here for permanence when the record is re-saved)
  if (rec.dots?.length) {
    const needsMigration = rec.dots.some(d => d.value === undefined && d.pts !== undefined);
    if (needsMigration) {
      rec = {
        ...rec,
        dots: rec.dots.map(d =>
          d.value === undefined && d.pts !== undefined
            ? { ...d, value: d.pts }
            : d
        ),
      };
    }
  }

  // DotDef name fix: 'KP (par 3s)' → 'KP' (v2.0 label cleanup)
  if (rec.dots?.some(d => d.id === 'kp' && d.name === 'KP (par 3s)')) {
    rec = {
      ...rec,
      dots: rec.dots.map(d =>
        d.id === 'kp' && d.name === 'KP (par 3s)' ? { ...d, name: 'KP' } : d
      ),
    };
  }

  // ── betMode field renames (v2.7) ───────────────────────────────────────────
  // Stroke Play: strokeMode → betMode; 'single' → 'total'; 'nassau' → 'segments'
  const spOpts = rec.game_opts?.['Stroke Play'];
  if (spOpts && spOpts.betMode === undefined && spOpts.strokeMode !== undefined) {
    const val = spOpts.strokeMode === 'nassau' ? 'segments'
              : spOpts.strokeMode === 'single'  ? 'total'
              : 'total';
    rec = { ...rec, game_opts: { ...rec.game_opts, 'Stroke Play': { ...spOpts, betMode: val } } };
  }

  // Stableford: stabBetMode → betMode; 'nassau' → 'segments'; 'single' → 'perpoint'
  const stabOpts = rec.game_opts?.Stableford;
  if (stabOpts && stabOpts.betMode === undefined && stabOpts.stabBetMode !== undefined) {
    const val = stabOpts.stabBetMode === 'nassau' ? 'segments'
              : stabOpts.stabBetMode === 'single'  ? 'perpoint'
              : 'perpoint';
    rec = { ...rec, game_opts: { ...rec.game_opts, Stableford: { ...stabOpts, betMode: val } } };
  }

  // Nines: ninesMode → betMode; 'nassau' → 'segments'; 'single' → 'perpoint'
  const ninesOpts = rec.game_opts?.Nines;
  if (ninesOpts && ninesOpts.betMode === undefined && ninesOpts.ninesMode !== undefined) {
    const val = ninesOpts.ninesMode === 'nassau' ? 'segments'
              : ninesOpts.ninesMode === 'single'  ? 'perpoint'
              : 'perpoint';
    rec = { ...rec, game_opts: { ...rec.game_opts, Nines: { ...ninesOpts, betMode: val } } };
  }

  // Skins: carryover string → boolean ('yes' → true, 'no' → false)
  const skinsOpts = rec.game_opts?.Skins;
  if (skinsOpts && typeof skinsOpts.carryover === 'string') {
    rec = { ...rec, game_opts: { ...rec.game_opts, Skins: { ...skinsOpts, carryover: skinsOpts.carryover !== 'no' } } };
  }

  // ── scoring → grossNetNOL field rename (v2.9) ─────────────────────────────
  // Non-destructive: copy old field to new if new is absent.
  const gnolGames = ['Stroke Play', 'Skins', 'Stableford', 'Nines', 'Sixes', 'Dots'];
  let needsGnolOpts = false;
  const updatedOpts = { ...(rec.game_opts || {}) };
  for (const g of gnolGames) {
    const o = updatedOpts[g];
    if (o && o.grossNetNOL === undefined && o.scoring !== undefined) {
      updatedOpts[g] = { ...o, grossNetNOL: o.scoring };
      needsGnolOpts = true;
    }
  }
  if (needsGnolOpts) rec = { ...rec, game_opts: updatedOpts };

  // matchDef.scoring → matchDef.grossNetNOL (v2.9)
  if (rec.matches?.length) {
    let matchChanged = false;
    const updatedMatches = rec.matches.map(m => {
      const changes = {};
      if (m.grossNetNOL === undefined && m.scoring !== undefined) {
        changes.grossNetNOL = m.scoring;
        matchChanged = true;
      }
      // matchDef.tiebreak → matchDef.scoring (v2.9); 'half' → 'none'
      if (m.scoring === undefined && m.tiebreak !== undefined) {
        changes.scoring = m.tiebreak === 'half' ? 'none' : m.tiebreak;
        matchChanged = true;
      }
      return Object.keys(changes).length ? { ...m, ...changes } : m;
    });
    if (matchChanged) rec = { ...rec, matches: updatedMatches };
  }

  // gameOpts.Sixes.tiebreak → gameOpts.Sixes.scoring (v2.9); 'half' → 'none'
  const sixesO = rec.game_opts?.Sixes;
  if (sixesO && sixesO.scoring === undefined && sixesO.tiebreak !== undefined) {
    rec = {
      ...rec,
      game_opts: {
        ...rec.game_opts,
        Sixes: { ...sixesO, scoring: sixesO.tiebreak === 'half' ? 'none' : sixesO.tiebreak },
      },
    };
  }

  // ── Dots teamMode: 'Match' → 'Match:{matchId}' (v3.0 / 11-J) ─────────────
  // Pre-11-J rounds stored the generic string 'Match' with no ID suffix.
  // Resolve to the first team-format match ID, or 'none' if none exists.
  const dotsO = rec.game_opts?.Dots;
  if (dotsO && dotsO.teamMode === 'Match') {
    const firstTeam = (rec.matches || []).find(m => m.format === 'team');
    const newMode   = firstTeam ? `Match:${firstTeam.id}` : 'none';
    rec = {
      ...rec,
      game_opts: { ...rec.game_opts, Dots: { ...dotsO, teamMode: newMode } },
    };
  }

  return rec;
}

// ─── CRUD ──────────────────────────────────────────────────────────────────────

export const roundLib = {

  list() {
    return (ls.get(SK.rounds) || []).map(migrateRecord);
  },

  saveFromActive(ar) {
    const record = roundLib.fromActiveRound(ar);
    const all = ls.get(SK.rounds) || [];
    if (ar.roundId) {
      const idx = all.findIndex(r => r.id === ar.roundId);
      if (idx !== -1) {
        all[idx] = { ...record, id: ar.roundId };
        ls.set(SK.rounds, all);
        return all[idx];
      }
    }
    ls.set(SK.rounds, [record, ...all]);
    return record;
  },

  save(data) {
    const all = ls.get(SK.rounds) || [];
    const round = { id: makeId('r'), ...data };
    ls.set(SK.rounds, [round, ...all]);
    return round;
  },

  update(id, changes) {
    if (!id) return;
    const all = ls.get(SK.rounds) || [];
    const idx = all.findIndex(r => r.id === id);
    if (idx === -1) return;
    all[idx] = { ...all[idx], ...changes };
    ls.set(SK.rounds, all);
    return all[idx];
  },

  delete(id) {
    if (!id) return;
    const all = ls.get(SK.rounds) || [];
    ls.set(SK.rounds, all.filter(r => r.id !== id));
  },

  // ─── Schema conversions ───────────────────────────────────────────────────

  fromActiveRound(ar) {
    return {
      id:           makeId('r'),
      date:         ar.roundDate,

      course_name:     ar.course?.name  || 'Unknown',
      course_snapshot: ar.course        || null,
      front_nine:      ar.frontNine     || '',
      back_nine:       ar.backNine      || '',
      selected_tee:    ar.selectedTee   || '',

      pars: ar.pars || DEF_PARS,
      hcps: ar.hcps || DEF_HCP,

      players: (ar.activePlayers || []).map(p => ({
        id:           p.id           || p.name,
        name:         p.name,
        gender:       p.gender       || '',
        ghin:         p.ghin         || '',
        courseHcpVal: p.courseHcpVal ?? null,
        selectedTee:  p.selectedTee  || '',
      })),
      course_hcps:    ar.courseHcps   || [],
      min_course_hcp: ar.minCourseHcp ?? null,

      active_games:  ar.activeGames  || [],
      game_opts:     ar.gameOpts     || {},
      matches:       ar.matches      || [],

      // 13-C.2: Round length — stored as-is (undefined if not set). Callers
      // apply ?? 0 and ?? 18 at read time per PartialGameContract §1A.7.
      round_start_hole: ar.roundStartHole,
      round_num_holes:  ar.roundNumHoles,

      stroke_play_players: ar.strokePlayPlayers || [],
      skins_players:       ar.skinsPlayers      || [],
      stableford_players:  ar.stablefordPlayers || [],
      nines_players:       ar.ninesPlayers      || [],
      sixes_teams:         ar.sixesTeams        || [null, null, null],
      sixes_players:       ar.sixesPlayers      || [],
      dots_players:        ar.dotsPlayers       || [],
      dots:                ar.dots              || [],
      dot_entries:         ar.dotEntries        || {},
      manual_presses:      ar.manualPresses     || {},

      scores:    ar.scores    || Array.from({ length: 18 }, () => []),
      breakdown: ar.breakdown || [],
      bank:      ar.bank      || {},
    };
  },

  toActiveRound(r) {
    try {
      const rec = migrateRecord(r);

      const courseSnapshot = rec.course_snapshot || null;
      const nines = courseSnapshot?.nines;
      const layout = (nines?.length && rec.front_nine)
        ? buildLayout(nines, rec.front_nine, rec.back_nine)
        : null;

      const pars = rec.pars || layout?.pars || DEF_PARS;
      const hcps = rec.hcps || layout?.hcps || DEF_HCP;

      const activePlayers = (rec.players || []).map(p => ({
        id:           p.id   || p.name,
        name:         p.name,
        gender:       p.gender || '',
        ghin:         p.ghin   || '',
        courseHcpVal: p.courseHcpVal ?? null,
        selectedTee:  p.selectedTee  || rec.selected_tee || '',
      }));

      const courseHcps   = rec.course_hcps?.length ? rec.course_hcps : [];
      const minCourseHcp = rec.min_course_hcp ?? (courseHcps.length ? Math.min(...courseHcps) : 0);

      return {
        roundId:     rec.id,
        roundDate:   rec.date,
        course:      courseSnapshot,
        frontNine:   rec.front_nine   || '',
        backNine:    rec.back_nine    || '',
        selectedTee: rec.selected_tee || '',
        layout,
        pars,
        hcps,
        activePlayers: activePlayers.map((p, i) => ({
          ...p,
          courseHcpVal: courseHcps[i] ?? p.courseHcpVal ?? null,
        })),
        courseHcps,
        minCourseHcp,
        activeGames:        rec.active_games        || [],
        gameOpts:           rec.game_opts           || {},
        matches:            rec.matches             || [],
        // 13-C.2: Round length — restored as-is (undefined if absent in record).
        // Callers apply ?? 0 and ?? 18 at read time per PartialGameContract §1A.7.
        // Backward compat: legacy records with neither field load as full 18-hole rounds.
        roundStartHole:     rec.round_start_hole,
        roundNumHoles:      rec.round_num_holes,
        strokePlayPlayers:  rec.stroke_play_players || [],
        skinsPlayers:       rec.skins_players       || [],
        stablefordPlayers:  rec.stableford_players  || [],
        ninesPlayers:       rec.nines_players       || [],
        sixesTeams:         rec.sixes_teams         || [null, null, null],
        sixesPlayers:       rec.sixes_players       || [],
        dotsPlayers:        rec.dots_players        || [],
        dots:               rec.dots               || [],
        dotEntries:         rec.dot_entries         || {},
        manualPresses:      rec.manual_presses      || {},
        scores:             rec.scores              || Array.from({ length: 18 }, () => []),
        breakdown:          rec.breakdown           || [],
        bank:               rec.bank                || {},
      };
    } catch(e) {
      console.error('roundLib.toActiveRound failed:', e);
      throw new Error('Failed to reconstruct round: ' + e.message);
    }
  },

  toSetupState(r) {
    const rec = migrateRecord(r);

    const courseSnapshot = rec.course_snapshot || null;
    const playerSnapshots = (rec.players || []).map(p => ({
      id:           p.id   || p.name,
      name:         p.name,
      gender:       p.gender || '',
      ghin:         p.ghin   || '',
      courseHcpVal: p.courseHcpVal ?? null,
      selectedTee:  p.selectedTee  || rec.selected_tee || '',
    }));

    return {
      roundId:           rec.id,
      roundDate:         rec.date,
      selectedCourseId:  courseSnapshot?.id || '',
      frontNine:         rec.front_nine   || '',
      backNine:          rec.back_nine    || '',
      selectedTee:       rec.selected_tee || '',
      selectedPlayerIds: playerSnapshots.map(p => p.id),
      playerSnapshots,
      courseSnapshot,
      activeGames:       rec.active_games      || [],
      gameOpts:          rec.game_opts         || {},
      gameBets: Object.fromEntries(
        Object.entries(rec.game_opts || {}).map(([g, o]) => [g, o.bet || 0])
      ),
      matches:             rec.matches              || [],
      strokePlayPlayers:   rec.stroke_play_players  || [],
      skinsPlayers:        rec.skins_players        || [],
      stablefordPlayers:   rec.stableford_players   || [],
      ninesPlayers:        rec.nines_players        || [],
      sixesTeams:          rec.sixes_teams          || [null, null, null],
      sixesPlayers:        rec.sixes_players        || [],
      dotsPlayers:         rec.dots_players         || [],
      dots:                rec.dots                 || [],
      isReload:            true,
      reloadedScores:      rec.scores               || [],
      dot_entries:         rec.dot_entries          || {},
      // J1 fix (13-C.2 fix pass): manual_presses was not restored here, causing
      // saved presses to be lost on round reload. The `handleStart` path reads
      // `initSrc?.manual_presses` which was always undefined without this field.
      // Pre-existing bug surfaced during 13-C.2 testing.
      manual_presses:      rec.manual_presses       || {},
      // 13-C.2: Round length — restored as-is (undefined if absent). NewRoundPage
      // applies ?? 0 and ?? 18 at read time via initSrc. Without this, a reload
      // of a saved partial round would silently reset to 0/18 in the picker.
      roundStartHole:      rec.round_start_hole,
      roundNumHoles:       rec.round_num_holes,
    };
  },
};
