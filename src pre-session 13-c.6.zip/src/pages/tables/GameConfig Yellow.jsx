// ─── GameConfig.jsx ───────────────────────────────────────────────────────────
// Per-game bet/scoring configuration panel rendered inside NewRoundPage
// when a game toggle is active.
//
// Named exports (shared across files):
//   GameTile             — unified morph tile (header + body share one container)
//   BetSection           — universal bet layout
//   TeamPickerPair       — shared team A/B picker (Match team format + Sixes segments)
//   PlayerSubsetDropdown — inline dropdown subset picker with C-2 chip closed state
//   InlineRow            — label + control row (kept for future use, no current callers)
//   PlayerSubsetChips    — existing chip picker (used inside PlayerSubsetDropdown panel)
//   PRESS_OPTS           — shared press-dropdown option list
//
// Default export: GameConfig panel body for a single game (except Match, which is
// rendered directly by NewRoundPage as one <GameTile> per match instance).

import { useState, useRef, useEffect } from 'react';
import { ls, SK } from '../../services/storage.js';
import { DEFAULT_STAB } from '../../engine/handicap.js';
import { Btn, Tog, BetInput, G, GA, GB, RED, AMB, AMBBG } from '../../components/ui.jsx';
import { PlayerDropdown, ReadOnlyBubble, StyledSel } from '../PlayerDropdown.jsx';

// ─── InlineRow — shared export (kept for future use; no internal callers) ─────
export function InlineRow({ label, children }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, marginBottom:6 }}>
      <span style={{ fontSize:11, fontWeight:700, color:'#666', flexShrink:0 }}>{label}</span>
      <div style={{ flexShrink:0 }}>{children}</div>
    </div>
  );
}

// ─── PlayerSubsetChips — shared export (used inside PlayerSubsetDropdown panel) ──
export function PlayerSubsetChips({ players, selectedIdxs, onChange, label, note, maxSelect }) {
  const n = players.length;
  const cols = n <= 3 ? n : n === 4 ? 2 : 3;
  return (
    <div style={{ marginBottom:8 }}>
      {label && <div style={{ fontSize:11, fontWeight:700, color:'#666', marginBottom:4 }}>{label}</div>}
      {note && <div style={{ fontSize:10, color:'#888', marginBottom:5 }}>{note}</div>}
      <div style={{ display:'grid', gridTemplateColumns:`repeat(${cols}, 1fr)`, gap:5 }}>
        {players.map((p, i) => {
          const allIn = selectedIdxs.length === 0;
          const on = allIn || selectedIdxs.includes(i);
          const atMax = maxSelect != null && selectedIdxs.length >= maxSelect && !selectedIdxs.includes(i);
          const toggle = () => {
            if (atMax) return;
            if (allIn) { onChange(players.map((_,j)=>j).filter(j=>j!==i)); return; }
            const next = on ? selectedIdxs.filter(x=>x!==i) : [...selectedIdxs,i];
            onChange(next.length === players.length ? [] : next);
          };
          const parts = (p?.name || '').trim().split(/\s+/);
          const first = parts[0] || '?';
          const last  = parts.length >= 2 ? parts[parts.length-1] : '';
          return (
            <div key={i} onClick={toggle}
              style={{ border:`1.5px solid ${on?G:atMax?'#eee':'#ddd'}`, background:on?GA:'#fff', borderRadius:20, padding:'5px 8px', cursor:atMax?'not-allowed':'pointer', textAlign:'center', minWidth:0, opacity:atMax?0.5:1 }}>
              <div style={{ fontSize:12, fontWeight:600, color:on?G:'#aaa', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', lineHeight:1.2 }}>{first}</div>
              {last && <div style={{ fontSize:10, fontWeight:400, color:on?G:'#aaa', opacity:0.7, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', lineHeight:1.2 }}>{last}</div>}
            </div>
          );
        })}
      </div>
      {selectedIdxs.length > 0 && selectedIdxs.length < players.length && (
        <div style={{ fontSize:10, color:'#888', marginTop:4 }}>
          {selectedIdxs.length}{maxSelect ? `/${maxSelect}` : ` of ${players.length}`} players · tap to toggle
        </div>
      )}
    </div>
  );
}

// ─── PlayerSubsetDropdown — shared export ─────────────────────────────────────
// Closed-state bubble: C-2 chip layout (handoff §2.5).
//   - "All Players" state → single plain text label
//   - Subset state → row of small green-tinted chips (first name only)
// Open panel: unchanged 2-per-row grid from 11-I.1.
export function PlayerSubsetDropdown({ players, selectedIdxs, onChange, required = null }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return;
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    document.addEventListener('touchstart', h);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('touchstart', h); };
  }, [open]);

  const allIn = selectedIdxs.length === 0;
  const isValid = required === null || selectedIdxs.length === required || (required > 0 && players.length <= required);
  const borderColor = required !== null && !isValid ? RED : '#c8e0c8';
  const borderWidth = required !== null && !isValid ? '1.5px' : '1px';
  const bg = required !== null && !isValid ? '#fff5f5' : '#fff';

  const chipData = allIn ? [] : selectedIdxs.map(i => {
    const p = players[i];
    const first = (p?.name || '').trim().split(/\s+/)[0] || '?';
    return { i, first };
  });

  return (
    <div ref={ref} style={{ position:'relative', marginBottom:7 }}>
      <div onClick={() => setOpen(o => !o)}
        style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                 border:`${borderWidth} solid ${borderColor}`,
                 background: bg,
                 borderRadius:8, padding:'7px 10px', cursor:'pointer',
                 minWidth:0, width:'100%', boxSizing:'border-box' }}>
        <div style={{ display:'flex', alignItems:'center', gap:4, flex:1, minWidth:0, overflow:'hidden', whiteSpace:'nowrap' }}>
          {allIn ? (
            <span style={{ fontSize:12, fontWeight:500, color: (required !== null && !isValid) ? RED : G }}>
              All Players
            </span>
          ) : (
            chipData.map(({ i, first }) => (
              <span key={i}
                style={{ display:'inline-block', fontSize:11, fontWeight:700, color:G,
                         background:GA, border:'1px solid #c8e0c8', borderRadius:10,
                         padding:'3px 8px', flexShrink:0 }}>
                {first}
              </span>
            ))
          )}
        </div>
        <span style={{ fontSize:9, color:'#aaa', flexShrink:0, marginLeft:4 }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && (
        <div style={{ position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:50,
                      background:'#fff', border:`1.5px solid ${G}`, borderRadius:12,
                      padding:'10px', boxShadow:'0 4px 16px rgba(0,0,0,.13)' }}>
          {required && (
            <div style={{ fontSize:11, color:'#666', fontWeight:600, marginBottom:8 }}>
              Select {required} players
              {selectedIdxs.length > 0 && (
                <span style={{ color: isValid ? G : RED, marginLeft:6 }}>
                  ({selectedIdxs.length} of {required})
                </span>
              )}
            </div>
          )}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
            {players.map((p, i) => {
              const on = allIn || selectedIdxs.includes(i);
              const toggle = () => {
                if (allIn) { onChange(players.map((_, j) => j).filter(j => j !== i)); return; }
                const next = on ? selectedIdxs.filter(x => x !== i) : [...selectedIdxs, i];
                onChange(next.length === players.length ? [] : next);
              };
              const parts = (p?.name || '').trim().split(/\s+/);
              const first = parts[0] || '?';
              const last  = parts.length >= 2 ? parts.slice(1).join(' ') : '';
              return (
                <div key={i} onClick={toggle}
                  style={{ border:`1.5px solid ${on?G:'#ddd'}`, background:on?GA:'#fff',
                           borderRadius:10, padding:'6px 10px', cursor:'pointer', minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:600, color:on?G:'#aaa', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{first}</div>
                  {last && <div style={{ fontSize:11, color:on?G:'#bbb', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{last}</div>}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Press options (shared — used by BetSection and MatchCard) ────────────────
export const PRESS_OPTS = [
  { value:'none', label:'Press' },
  { value:'1',    label:'1 Down' },
  { value:'2',    label:'2 Down' },
  { value:'3',    label:'3 Down' },
  { value:'4',    label:'4 Down' },
  { value:'5',    label:'5 Down' },
];

// ─── GameTile — shared export ─────────────────────────────────────────────────
// Unified morph tile: header row + (optional) body, all in one container.
// Collapsed: header row only, white background.
// Expanded: header row + hairline separator + body, light-green background (GA).
// Tap anywhere on the header toggles the tile. Dropdowns on the right stop
// propagation so taps on them don't fire onToggle.
//
// Props:
//   title                — display name (e.g. "Stroke Play", "Match A")
//   subtitle             — optional small suffix next to title (e.g. Dots's "Specials, Junk")
//   on                   — boolean; expanded when true
//   onToggle             — tile click + checkbox click handler
//   secondaryDropdown    — JSX rendered between title and scoring dropdown (optional)
//   scoring              — scoring value (if showScoring)
//   onScoringChange      — setter
//   includeNOL           — default true; Dots passes false
//   showScoring          — default true; Match per-instance tiles pass true (scoring
//                          lives on each MatchCard's header); a Match placeholder tile
//                          (when the game is off) has no scoring dropdown — use the
//                          default `on=false` collapsed state and it won't render.
//   children             — body rendered below header when expanded
export function GameTile({
  title,
  subtitle = null,
  on, onToggle,
  secondaryDropdown = null,
  scoring, onScoringChange,
  includeNOL = true,
  showScoring = true,
  children,
}) {
  const scoringOpts = [
    { value:'gross',     label:'Gross' },
    { value:'net',       label:'Net' },
    ...(includeNOL ? [{ value:'netofflow', label:'Net Off Low' }] : []),
  ];

  return (
    <div
      style={{
        width:'100%', boxSizing:'border-box',
        borderRadius:12,
        border:`1.5px solid ${on?G:'#eee'}`,
        background:on?AMBBG:'#fff',
      }}>
      {/* Header row */}
      <div
        onClick={onToggle}
        style={{
          display:'flex', alignItems:'center', gap:8,
          padding:'8px 12px',
          cursor:'pointer',
        }}>
        <input type="checkbox" checked={on} readOnly
          style={{ accentColor:G, width:13, height:13, flexShrink:0, pointerEvents:'none' }}/>
        <span style={{ flex:1, fontWeight:600, fontSize:13, color:on?G:'#333', minWidth:0 }}>
          {title}
          {subtitle && (
            <span style={{ fontSize:11, color:'#888', fontWeight:400, marginLeft:5 }}>{subtitle}</span>
          )}
        </span>
        {on && (
          <div
            onClick={e => e.stopPropagation()}
            style={{ display:'flex', alignItems:'center', gap:6, flexShrink:0 }}>
            {secondaryDropdown}
            {showScoring && (
              <StyledSel
                value={scoring || (includeNOL ? 'net' : 'gross')}
                onChange={onScoringChange}
                options={scoringOpts}
                width={includeNOL ? 130 : 90}
              />
            )}
          </div>
        )}
      </div>
      {/* Body — inside the same container, below a hairline separator */}
      {on && (
        <>
          <div style={{ height:1, background:'#f0d98a', margin:'0 12px' }}/>
          <div style={{ padding:'10px 12px 12px' }}>
            {children}
          </div>
        </>
      )}
    </div>
  );
}

// ─── BetSection — shared export ───────────────────────────────────────────────
// Row 1 ("Bet" label row): "Bet" label left (13/700/G), mode dropdown right.
// Row 2 ("Field row"): depends on mode.
//   Single-field modes: [$field] | [$field][Press] | [$field][extraField]
//   F/B/T modes: external column labels + [$F][$B][$T] + (optional) [P][P][P]
export function BetSection({
  modes = [],
  mode,
  onModeChange,
  values = {},
  onValueChange,
  pressable = false,
  pressValues = {},
  onPressChange,
  extraField = null,
}) {
  const isFBT = mode === 'nassau' || mode === 'segments';
  const hasModes = modes && modes.length > 0;

  // "Bet" label — 13/700/G to balance against the mode dropdown's active text.
  const labelRow = (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                  width:'100%', marginBottom:6, gap:8 }}>
      <span style={{ fontSize:13, fontWeight:700, color:G, flexShrink:0 }}>Bet</span>
      {hasModes && (
        <div style={{ flexShrink:0 }}>
          <StyledSel value={mode} onChange={onModeChange} options={modes} width={120} />
        </div>
      )}
    </div>
  );

  if (isFBT) {
    const labelStyle = { fontSize:11, fontWeight:600, color:'#666', textAlign:'center' };
    const fieldStyle = { width:'100%', boxSizing:'border-box', textAlign:'center' };
    return (
      <div style={{ width:'100%', boxSizing:'border-box', minWidth:0 }}>
        {labelRow}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:4 }}>
          <div style={labelStyle}>Front</div>
          <div style={labelStyle}>Back</div>
          <div style={labelStyle}>Total</div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
          <BetInput value={values.front ?? 0} onChange={v => onValueChange('front', v)} placeholder="$" style={fieldStyle}/>
          <BetInput value={values.back  ?? 0} onChange={v => onValueChange('back',  v)} placeholder="$" style={fieldStyle}/>
          <BetInput value={values.total ?? 0} onChange={v => onValueChange('total', v)} placeholder="$" style={fieldStyle}/>
        </div>
        {pressable && (
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginTop:6 }}>
            <StyledSel value={pressValues.front || 'none'} onChange={v => onPressChange('front', v)} options={PRESS_OPTS} width="100%"/>
            <StyledSel value={pressValues.back  || 'none'} onChange={v => onPressChange('back',  v)} options={PRESS_OPTS} width="100%"/>
            <StyledSel value={pressValues.total || 'none'} onChange={v => onPressChange('total', v)} options={PRESS_OPTS} width="100%"/>
          </div>
        )}
      </div>
    );
  }

  const fieldStyle = { width:'100%', boxSizing:'border-box', textAlign:'center' };
  const bet = (
    <BetInput value={values.single ?? 0} onChange={v => onValueChange('single', v)} style={fieldStyle}/>
  );

  let fieldRow;
  if (pressable) {
    fieldRow = (
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
        {bet}
        <StyledSel value={pressValues.single || 'none'} onChange={v => onPressChange('single', v)} options={PRESS_OPTS} width="100%"/>
      </div>
    );
  } else if (extraField) {
    fieldRow = (
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
        {bet}
        <div style={{ minWidth:0 }}>{extraField}</div>
      </div>
    );
  } else {
    fieldRow = <div style={{ width:'100%' }}>{bet}</div>;
  }

  return (
    <div style={{ width:'100%', boxSizing:'border-box', minWidth:0 }}>
      {labelRow}
      {fieldRow}
    </div>
  );
}

// ─── TeamPickerPair — shared export ───────────────────────────────────────────
export function TeamPickerPair({
  players, teamA = [], onTeamAChange,
  excludeIdxs = [],
  labels = ['Player 1','Player 2'],
  teamBPlayers = [],
  separator = 'vs',
  panelLabelPrefix = '',
}) {
  const slot0 = teamA[0] ?? null;
  const slot1 = teamA[1] ?? null;
  const teamAFull = slot0 != null && slot1 != null;

  const setSlot = (slot, pi) => {
    const other = slot === 0 ? slot1 : slot0;
    const newA = slot === 0
      ? [pi, other].filter(x => x != null)
      : [other, pi].filter(x => x != null);
    const cleanA = pi != null && newA[0] === newA[1] ? [pi] : newA;
    onTeamAChange(cleanA);
  };

  const exclude0 = [slot1, ...excludeIdxs].filter(x => x != null);
  const exclude1 = [slot0, ...excludeIdxs].filter(x => x != null);

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      <div>
        <div style={{ fontSize:10, fontWeight:700, color:'#888', marginBottom:4, textTransform:'uppercase', letterSpacing:'0.04em' }}>Team A</div>
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <div style={{ flex:1, minWidth:0 }}>
            <PlayerDropdown players={players} value={slot0}
              onChange={v => setSlot(0, v)} label={labels[0]}
              excludeIdxs={exclude0}
              panelLabel={panelLabelPrefix ? `${panelLabelPrefix} — ${labels[0]}` : undefined}/>
          </div>
          <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>{separator}</span>
          <div style={{ flex:1, minWidth:0 }}>
            <PlayerDropdown players={players} value={slot1}
              onChange={v => setSlot(1, v)} label={labels[1]}
              excludeIdxs={exclude1}
              panelLabel={panelLabelPrefix ? `${panelLabelPrefix} — ${labels[1]}` : undefined}/>
          </div>
        </div>
      </div>
      {teamAFull && teamBPlayers.length >= 2 && (
        <div>
          <div style={{ fontSize:10, fontWeight:700, color:'#888', marginBottom:4, textTransform:'uppercase', letterSpacing:'0.04em' }}>Team B</div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[teamBPlayers[0]]??null}/></div>
            <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>{separator}</span>
            <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[teamBPlayers[1]]??null}/></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Custom dot adder ──────────────────────────────────────────────────────────
function CustomDotAdder({ onAdd }) {
  const [name,  setName]  = useState('');
  const [value, setValue] = useState(1);
  const [multi, setMulti] = useState(true);
  return (
    <div style={{ marginTop:8, display:'flex', flexDirection:'column', gap:6 }}>
      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Custom dot…"
          style={{ flex:1, fontSize:12, padding:'5px 9px', border:'1px solid #ddd', borderRadius:7, fontFamily:'inherit' }}/>
        <span style={{ fontSize:11, color:'#888', flexShrink:0 }}>×</span>
        <input type="text" inputMode="numeric" value={value}
          onChange={e => { const v=parseInt(e.target.value); setValue(isNaN(v)||v<1?1:v); }}
          onFocus={e => e.target.select()}
          style={{ width:34, border:'1px solid #ddd', borderRadius:7, padding:'5px 4px', fontSize:12, textAlign:'center' }}/>
        <Btn small disabled={!name.trim()} onClick={() => {
          if (name.trim()) {
            onAdd({ id:`c_${Date.now()}`, name:name.trim(), value, enabled:true, auto:false, multi });
            setName(''); setValue(1); setMulti(true);
          }
        }}>+ Add</Btn>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:6, paddingLeft:2 }}>
        <Tog small checked={multi} onChange={setMulti}/>
        <span style={{ fontSize:11, color:'#888' }}>Allow multiples per hole</span>
      </div>
    </div>
  );
}

// ─── DotRow ────────────────────────────────────────────────────────────────────
function DotRow({ sp, isEditing, editName, editValue, setEditName, setEditValue,
                  commitEdit, setEditingId, setDots, startEdit, deleteCustom }) {
  const isCustom = sp.id.startsWith('c_');
  const spValue  = sp.value ?? sp.pts ?? 1;
  const [swipeX,  setSwipeX]  = useState(0);
  const [swiping, setSwiping] = useState(false);
  const touchStartX = useRef(0);
  const REVEAL = 88;
  const onTouchStart = e => { touchStartX.current = e.touches[0].clientX; setSwiping(false); };
  const onTouchMove  = e => { const dx = e.touches[0].clientX - touchStartX.current; if (dx < 0) { setSwiping(true); setSwipeX(Math.max(dx, -REVEAL)); } };
  const onTouchEnd   = () => { if (swipeX < -REVEAL/2) setSwipeX(-REVEAL); else { setSwipeX(0); setSwiping(false); } };
  const closeSwipe   = () => { setSwipeX(0); setSwiping(false); };
  return (
    <div style={{ position:'relative', overflow:'hidden', borderRadius:8 }}>
      {isCustom && (
        <div style={{ position:'absolute', right:0, top:0, bottom:0, display:'flex', alignItems:'stretch', zIndex:0 }}>
          <button onClick={() => { closeSwipe(); startEdit(sp); }}
            style={{ width:44, background:'#fff9e6', border:'none', cursor:'pointer', fontSize:11, fontWeight:700, color:'#7a6000', fontFamily:'inherit' }}>Edit</button>
          <button onClick={() => { closeSwipe(); deleteCustom(sp.id); }}
            style={{ width:44, background:'#c0392b', border:'none', cursor:'pointer', fontSize:11, fontWeight:700, color:'#fff', fontFamily:'inherit' }}>Del</button>
        </div>
      )}
      <div
        onTouchStart={isCustom ? onTouchStart : undefined}
        onTouchMove={isCustom ? onTouchMove : undefined}
        onTouchEnd={isCustom ? onTouchEnd : undefined}
        style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 9px', borderRadius:8,
                 background: sp.enabled ? '#f0f8f0' : '#fafafa',
                 border: `1px solid ${sp.enabled ? '#c0dcc0' : '#eee'}`,
                 position:'relative', zIndex:1,
                 transform:`translateX(${swipeX}px)`,
                 transition: swiping ? 'none' : 'transform 0.2s ease' }}>
        <Tog small checked={sp.enabled}
          onChange={v => setDots(p => p.map(s => s.id === sp.id ? { ...s, enabled:v } : s))}/>
        {isEditing ? (
          <>
            <input autoFocus value={editName} onChange={e => setEditName(e.target.value)}
              onBlur={() => commitEdit(sp.id)}
              onKeyDown={e => { if (e.key==='Enter') commitEdit(sp.id); if (e.key==='Escape') setEditingId(null); }}
              style={{ flex:1, fontSize:12, border:'1px solid #aaddaa', borderRadius:5, padding:'2px 5px' }}/>
            <span style={{ fontSize:11, color:'#888', flexShrink:0 }}>×</span>
            <input type="text" inputMode="numeric" value={editValue}
              onChange={e => { const v=parseInt(e.target.value); setEditValue(isNaN(v)||v<1?1:v>10?10:v); }}
              onFocus={e => e.target.select()} onBlur={() => commitEdit(sp.id)}
              style={{ width:34, border:'1px solid #ddd', borderRadius:6, padding:'2px 3px', fontSize:12, textAlign:'center' }}/>
          </>
        ) : (
          <>
            <span style={{ flex:1, fontSize:13, color: sp.enabled ? '#222' : '#aaa' }}>
              {sp.name}{sp.auto && <span style={{ fontSize:10, color:G, marginLeft:4 }}>auto</span>}
            </span>
            <span style={{ fontSize:11, color:'#888', flexShrink:0 }}>×</span>
            <input type="text" inputMode="numeric"
              value={spValue === 0 ? '' : String(spValue)}
              onChange={e => { const v=parseInt(e.target.value); setDots(p=>p.map(s=>s.id===sp.id?{...s,value:isNaN(v)||v<1?1:v>10?10:v}:s)); }}
              onFocus={e => e.target.select()}
              style={{ width:34, border:'1px solid #ddd', borderRadius:6, padding:'2px 3px', fontSize:12, textAlign:'center' }}/>
          </>
        )}
      </div>
    </div>
  );
}

// ─── GameConfig Panel (default export) ────────────────────────────────────────
// Renders the body of a non-Match game tile. Invoked as <GameTile>'s children.
// Match bodies are rendered directly by NewRoundPage.jsx — this component does
// not handle 'Match / Nassau'.
export default function GameConfig({ game, opts, setOpt, bet, setBet, players,
                                     sixesTeams, setSixesTeams,
                                     strokePlayPlayers, setStrokePlayPlayers,
                                     skinsPlayers, setSkinsPlayers,
                                     ninesPlayers, setNinesPlayers, stablefordPlayers, setStablefordPlayers,
                                     dotsPlayers, setDotsPlayers, dots, setDots }) {

  const [editingId, setEditingId] = useState(null);
  const [editName,  setEditName]  = useState('');
  const [editValue, setEditValue] = useState(1);
  const startEdit  = sp => { setEditingId(sp.id); setEditName(sp.name); setEditValue(sp.value ?? sp.pts ?? 1); };
  const commitEdit = id => {
    if (!editName.trim()) { setEditingId(null); return; }
    setDots(p => p.map(s => s.id === id ? { ...s, name: editName.trim(), value: Math.max(1, Math.min(10, editValue)) } : s));
    setEditingId(null);
  };
  const deleteCustom = id => {
    const updatedDots = dots.filter(s => s.id !== id);
    setDots(updatedDots);
    const ar = ls.get(SK.activeRound);
    if (!ar?.dotEntries) return;
    const ens = updatedDots.filter(s => s.enabled);
    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);
    const entries = { ...ar.dotEntries };
    let changed = false;
    Object.keys(entries).forEach(key => {
      const parts = key.split('_');
      if (parts[2] !== 'team') return;
      const hole = parseInt(parts[0]), earnerIdx = parseInt(parts[parts.length-1]);
      if (isNaN(earnerIdx)) return;
      let total = 0;
      Object.entries(entries).forEach(([k, v]) => {
        const cnt = entryCount(v); if (!cnt) return;
        const p = k.split('_');
        if (parseInt(p[0]) !== hole || parseInt(p[1]) !== earnerIdx || p[2] === 'team') return;
        const sp = ens.find(s => s.id === p[2]);
        if (sp) total += cnt;
      });
      const current = entryCount(entries[key]);
      if (total === 0) { delete entries[key]; changed = true; }
      else if (total !== current) { entries[key] = total; changed = true; }
    });
    if (changed) ls.set(SK.activeRound, { ...ar, dotEntries: entries });
  };

  const currentTeamMode = opts.teamMode ?? (opts.teamScoring ? 'Sixes' : 'none');
  const isTeamMode = currentTeamMode !== 'none';

  return (
    <>
      {/* ── Stroke Play ── */}
      {game === 'Stroke Play' && (
        <>
          {players.length > 2 && (
            <PlayerSubsetDropdown players={players} selectedIdxs={strokePlayPlayers} onChange={setStrokePlayPlayers}/>
          )}
          <BetSection
            modes={[{ value:'total', label:'Total' }, { value:'segments', label:'F/B/T' }]}
            mode={opts.betMode || 'total'}
            onModeChange={v => setOpt('betMode', v)}
            values={{ single: bet, front: opts.betF ?? bet, back: opts.betB ?? bet, total: opts.bet18 ?? bet }}
            onValueChange={(field, v) => {
              if (field === 'single')      setBet(v);
              else if (field === 'front')  setOpt('betF',  v);
              else if (field === 'back')   setOpt('betB',  v);
              else if (field === 'total')  setOpt('bet18', v);
            }}
          />
        </>
      )}

      {/* ── Skins ── */}
      {game === 'Skins' && (
        <>
          {players.length > 2 && (
            <PlayerSubsetDropdown players={players} selectedIdxs={skinsPlayers} onChange={setSkinsPlayers}/>
          )}
          <BetSection
            modes={[{ value:'perSkin', label:'Per Skin' }, { value:'pot', label:'Pot' }]}
            mode={opts.mode || 'perSkin'}
            onModeChange={v => setOpt('mode', v)}
            values={{ single: bet }}
            onValueChange={(_, v) => setBet(v)}
            extraField={
              <StyledSel
                value={opts.carryover === false ? false : true}
                onChange={v => setOpt('carryover', v)}
                options={[{ value:true, label:'Carryover' }, { value:false, label:'No Carryover' }]}
                width="100%"
              />
            }
          />
        </>
      )}

      {/* ── Stableford ── */}
      {game === 'Stableford' && (
        <>
          {players.length > 2 && (
            <PlayerSubsetDropdown players={players} selectedIdxs={stablefordPlayers} onChange={setStablefordPlayers}/>
          )}
          <BetSection
            modes={[{ value:'perpoint', label:'Per Point' }, { value:'segments', label:'F/B/T' }]}
            mode={opts.betMode || 'perpoint'}
            onModeChange={v => setOpt('betMode', v)}
            values={{ single: bet, front: opts.betF ?? bet, back: opts.betB ?? bet, total: opts.bet18 ?? bet }}
            onValueChange={(field, v) => {
              if (field === 'single')      setBet(v);
              else if (field === 'front')  setOpt('betF',  v);
              else if (field === 'back')   setOpt('betB',  v);
              else if (field === 'total')  setOpt('bet18', v);
            }}
          />
          <div style={{ marginTop:10 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#666', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.04em' }}>Points</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4 }}>
              {[['+3','-3'],['Eagle','-2'],['Bird','-1'],['Par','0'],['Bog','1'],['Dbl','2'],['Worse','3']].map(([lbl,key]) => {
                const t = opts.stabTable || DEFAULT_STAB;
                return (
                  <div key={key} style={{ textAlign:'center' }}>
                    <div style={{ fontSize:9, color:'#888', marginBottom:2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{lbl}</div>
                    <input type="text" inputMode="numeric" value={t[key]??0}
                      onChange={e => { const v=parseInt(e.target.value); if(!isNaN(v)&&v>=0) setOpt('stabTable',{...(opts.stabTable||DEFAULT_STAB),[key]:v}); }}
                      style={{ width:'100%', boxSizing:'border-box', border:'1px solid #ddd', borderRadius:6, padding:'4px 2px', fontSize:12, textAlign:'center', fontFamily:'inherit' }}/>
                  </div>
                );
              })}
            </div>
            <button onClick={() => setOpt('stabTable',{...DEFAULT_STAB})}
              style={{ marginTop:4, fontSize:11, color:G, background:'none', border:'none', cursor:'pointer', padding:0 }}>Reset</button>
          </div>
        </>
      )}

      {/* ── Nines ── */}
      {game === 'Nines' && (
        <>
          {players.length < 3 && (
            <div style={{ background:'#fce8e8', color:RED, borderRadius:8, padding:'8px 11px', fontSize:12, marginBottom:8 }}>
              Nines requires at least 3 players.
            </div>
          )}
          {players.length > 3 && (
            <PlayerSubsetDropdown players={players} selectedIdxs={ninesPlayers||[]} onChange={setNinesPlayers} required={3}/>
          )}
          <BetSection
            modes={[{ value:'perpoint', label:'Per Point' }, { value:'segments', label:'F/B/T' }]}
            mode={opts.betMode || 'perpoint'}
            onModeChange={v => setOpt('betMode', v)}
            values={{ single: bet, front: opts.betF ?? bet, back: opts.betB ?? bet, total: opts.bet18 ?? bet }}
            onValueChange={(field, v) => {
              if (field === 'single')      setBet(v);
              else if (field === 'front')  setOpt('betF',  v);
              else if (field === 'back')   setOpt('betB',  v);
              else if (field === 'total')  setOpt('bet18', v);
            }}
          />
          <div style={{ marginTop:8 }}>
            <StyledSel
              value={opts.blitz === true}
              onChange={v => setOpt('blitz', v === true)}
              options={[
                { value:false, label:'No Niner' },
                { value:true,  label:'Niner (Win by Net 2)' },
              ]}
              width="100%"
            />
          </div>
        </>
      )}

      {/* ── Sixes ── */}
      {game === 'Sixes' && (
        <>
          {players.length < 4 && (
            <div style={{ background:'#fce8e8', color:RED, borderRadius:8, padding:'8px 11px', fontSize:12, marginBottom:8 }}>
              Sixes requires 4 players.
            </div>
          )}
          {players.length >= 4 && (() => {
            const usedPairs = [];
            [0, 1].forEach(s => {
              const st = sixesTeams[s];
              const a = st?.a ?? null, b = st?.b ?? null;
              if (a != null && b != null) {
                usedPairs.push([a, b]);
                const teamB = players.map((_,i)=>i).filter(i => i!==a && i!==b);
                if (teamB.length === 2) usedPairs.push([teamB[0], teamB[1]]);
              }
            });

            const all4 = players.map((_,i)=>i);
            const allPairs2 = [];
            for (let i=0;i<all4.length;i++) for (let j=i+1;j<all4.length;j++) allPairs2.push([all4[i],all4[j]]);
            const remaining = allPairs2.filter(([x,y]) =>
              !usedPairs.some(([a,b]) => (a===x&&b===y)||(a===y&&b===x))
            );
            const m3A = remaining[0] || null;
            const m3B = m3A ? all4.filter(i => i!==m3A[0] && i!==m3A[1]) : [];

            return (
              <div style={{ marginBottom:8 }}>
                {[0, 1].map(seg => {
                  const t = sixesTeams[seg];
                  const slot0 = t?.a ?? null;
                  const slot1 = t?.b ?? null;
                  const teamAArr = [slot0, slot1].filter(x => x != null);

                  const priorTeammates = anchor => {
                    if (anchor == null) return [];
                    const otherSeg = seg === 0 ? 1 : 0;
                    const os = sixesTeams[otherSeg];
                    if (!os || os.a == null || os.b == null) return [];
                    const pairs = [[os.a, os.b]];
                    const otherTeamB = players.map((_,i)=>i).filter(i => i!==os.a && i!==os.b);
                    if (otherTeamB.length === 2) pairs.push([otherTeamB[0], otherTeamB[1]]);
                    return pairs
                      .filter(([x,y]) => x===anchor || y===anchor)
                      .map(([x,y]) => x===anchor ? y : x);
                  };

                  const extraExcludes = [
                    ...priorTeammates(slot0),
                    ...priorTeammates(slot1),
                  ].filter(x => x != null);

                  const teamB = teamAArr.length === 2
                    ? players.map((_,i)=>i).filter(i => i!==slot0 && i!==slot1)
                    : [];

                  return (
                    <div key={seg} style={{ marginBottom:10 }}>
                      <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:5, textTransform:'uppercase', letterSpacing:'0.05em' }}>
                        Match {seg + 1}
                      </div>
                      <TeamPickerPair
                        players={players}
                        teamA={teamAArr}
                        onTeamAChange={newA => setSixesTeams(prev => {
                          const n = [...prev];
                          n[seg] = { a: newA[0] ?? null, b: newA[1] ?? null };
                          return n;
                        })}
                        excludeIdxs={extraExcludes}
                        labels={['Player 1','Player 2']}
                        teamBPlayers={teamB}
                        separator="+"
                        panelLabelPrefix={`Match ${seg + 1}`}
                      />
                    </div>
                  );
                })}
                {m3A && m3B.length === 2 && (
                  <div style={{ marginBottom:10 }}>
                    <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:5, textTransform:'uppercase', letterSpacing:'0.05em' }}>
                      Match 3 <span style={{ fontSize:9, fontWeight:400, color:'#aaa', textTransform:'none', letterSpacing:0 }}>auto-assigned</span>
                    </div>
                    <div style={{ fontSize:10, fontWeight:700, color:'#888', marginBottom:4, textTransform:'uppercase', letterSpacing:'0.04em' }}>Team A</div>
                    <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:8 }}>
                      <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[m3A[0]]??null}/></div>
                      <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>+</span>
                      <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[m3A[1]]??null}/></div>
                    </div>
                    <div style={{ fontSize:10, fontWeight:700, color:'#888', marginBottom:4, textTransform:'uppercase', letterSpacing:'0.04em' }}>Team B</div>
                    <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                      <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[m3B[0]]??null}/></div>
                      <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>+</span>
                      <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[m3B[1]]??null}/></div>
                    </div>
                  </div>
                )}
              </div>
            );
          })()}
          <BetSection
            modes={[]}
            values={{ single: bet }}
            onValueChange={(_, v) => setBet(v)}
            pressable
            pressValues={{ single: opts.autoPress || 'none' }}
            onPressChange={(_, v) => setOpt('autoPress', v)}
          />
          <div style={{ marginTop:8 }}>
            <StyledSel
              value={opts.tiebreak || 'none'}
              onChange={v => setOpt('tiebreak', v)}
              options={[
                { value:'none',       label:'Best Ball' },
                { value:'second',     label:'2nd Ball Breaks Tie' },
                { value:'cumulative', label:'Cumulative Score' },
              ]}
              width="100%"
            />
          </div>
        </>
      )}

      {/* ── Dots ── */}
      {game === 'Dots' && (
        <>
          {!isTeamMode && players.length > 2 && (
            <PlayerSubsetDropdown players={players} selectedIdxs={dotsPlayers} onChange={setDotsPlayers}/>
          )}
          <BetSection
            modes={[{ value:'spread', label:'Spread' }, { value:'total', label:'Total' }]}
            mode={opts.dotsMode || 'spread'}
            onModeChange={v => setOpt('dotsMode', v)}
            values={{ single: bet }}
            onValueChange={(_, v) => setBet(v)}
          />
          <div style={{ marginTop:10 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#666', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.04em' }}>Dots to Track</div>
            <div style={{ display:'grid', gap:'5px' }}>
              {dots.filter(sp => sp.id !== 'team').map(sp => (
                <DotRow key={sp.id} sp={sp}
                  isEditing={editingId === sp.id}
                  editName={editName} editValue={editValue}
                  setEditName={setEditName} setEditValue={setEditValue}
                  commitEdit={commitEdit} setEditingId={setEditingId}
                  setDots={setDots} startEdit={startEdit} deleteCustom={deleteCustom}
                />
              ))}
            </div>
            <CustomDotAdder onAdd={sp => setDots(p => [...p, sp])}/>
          </div>
        </>
      )}
    </>
  );
}
