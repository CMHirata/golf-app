// ─── tables/SkinsTable.jsx ────────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js
//
// ✅ Self-checked (13-C.3): Accepts startHole/endHole props (default 0/17 for
// backward compat). The per-hole loop uses the range; half sections show only
// columns in range. Portrait half labels changed "Front 9 / Back 9" → "Front /
// Back" per owner decision Q4c. Landscape: if the range sits entirely on one
// half, a single 9-column table is rendered (per Q5). When the range spans
// both halves, landscape shows Front + Back + Total exactly as before but with
// only in-range columns. PartialGameContract §2.4, invariant #11.

import { calcSkinsHole } from '../../engine/games.js';
import { K, nameTd, scoringLabel } from '../scorecard/scorecardUtils.js';
import { GameSection, GameTable, HalfLabel, TableDivider, ColNote, PlayerChips } from '../scorecard/GameSection.jsx';

export function SkinsTable({
  players, scores, hcps, opts, courseHcps, minCourseHcp, skinsPlayerIdxs, isLandscape,
  startHole = 0, endHole = 17,
}) {
  const mode  = opts?.grossNetNOL ?? opts?.scoring ?? 'net';
  const carry = opts?.carryover !== false;

  const displayIdxs = skinsPlayerIdxs?.length ? skinsPlayerIdxs : players.map((_, i) => i);

  // 13-C.3: Range-derived hole arrays (for full round these equal FRONT/BACK/ALL18).
  const rangeHoles = [];
  for (let h = startHole; h <= endHole; h++) rangeHoles.push(h);
  const frontHoles = rangeHoles.filter(h => h < 9);
  const backHoles  = rangeHoles.filter(h => h >= 9);
  const hasFront = frontHoles.length > 0;
  const hasBack  = backHoles.length  > 0;

  // Compute hole-by-hole skin results across the effective range. Carryover
  // counter only advances across holes inside the range — out-of-range holes
  // never contribute.
  const rows = []; let carryCount = 0;
  for (const h of rangeHoles) {
    const result = calcSkinsHole(h, scores, players, hcps, mode, courseHcps, minCourseHcp, displayIdxs);
    if (!result) break;
    if (result.tied) { carryCount++; rows.push({ h, tied: true }); }
    else { rows.push({ h, wi: result.wiIdx, value: carry ? 1 + carryCount : 1 }); carryCount = 0; }
  }

  const totals = displayIdxs.map(pi => rows.reduce((s, r) => s + (r.wi === pi ? r.value : 0), 0));

  const cellVal = (displayPos, h) => {
    const pi = displayIdxs[displayPos];
    const r  = rows.find(r => r.h === h);
    if (!r) return null;
    if (r.tied) return 'tie';
    return r.wi === pi ? r.value : 0;
  };

  const skinTd = (v, h) => {
    if (v === null)  return <td key={h} style={{ textAlign: 'center', color: '#ddd', fontSize: 11 }}>·</td>;
    if (v === 'tie') return <td key={h} style={{ textAlign: 'center', color: '#bbb', fontSize: 11 }}>–</td>;
    if (v === 0)     return <td key={h} style={{ textAlign: 'center', color: '#ececec', fontSize: 11 }}>·</td>;
    return (
      <td key={h} style={{ textAlign: 'center', padding: '1px' }}>
        <span style={{ display: 'inline-block', width: 20, height: 18, lineHeight: '18px', fontSize: 10, fontWeight: 700, color: K.hdrClr, background: v > 1 ? '#c4aaf0' : K.totBg, borderRadius: 3 }}>{v}</span>
      </td>
    );
  };

  const renderHalf = (hs, label) => {
    if (!hs.length) return null;
    const halfTotals = displayIdxs.map((pi) =>
      rows.filter(r => hs.includes(r.h) && r.wi === pi).reduce((s, r) => s + r.value, 0)
    );
    const displayPlayers = displayIdxs.map(i => players[i]).filter(Boolean);
    return (
      <>
        <HalfLabel>{label}</HalfLabel>
        <div style={{ padding: '0 8px 4px' }}>
          <GameTable hs={hs} colHeader="Skins" headerBg={K.hdrBg} headerColor={K.hdrClr} totBg={K.totBg} totColor={K.totClr}>
            {displayPlayers.map((p, pos) => (
              <tr key={displayIdxs[pos]} style={{ background: K.row[pos % 2] }}>
                <td style={{ ...nameTd, color: K.hdrClr }}>{p.name}</td>
                {hs.map(h => skinTd(cellVal(pos, h), h))}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: K.totClr, background: K.totBg, padding: '2px 4px' }}>{halfTotals[pos] || '·'}</td>
              </tr>
            ))}
          </GameTable>
        </div>
      </>
    );
  };

  const renderAll18 = () => {
    const displayPlayers = displayIdxs.map(i => players[i]).filter(Boolean);
    const frontTots = displayIdxs.map((pi) => rows.filter(r => frontHoles.includes(r.h) && r.wi === pi).reduce((s, r) => s + r.value, 0));
    const backTots  = displayIdxs.map((pi) => rows.filter(r => backHoles.includes(r.h)  && r.wi === pi).reduce((s, r) => s + r.value, 0));

    // 13-C.3 Q5: Single-half range → render just that half as a 9-hole table
    // (no Front+Back split, no F/B total columns — matches ScoreGrid layout).
    if (!hasFront || !hasBack) {
      const hs = hasFront ? frontHoles : backHoles;
      return (
        <div style={{ padding: '0 8px 4px' }}>
          <GameTable hs={hs} colHeader="Skins" headerBg={K.hdrBg} headerColor={K.hdrClr} totBg={K.totBg} totColor={K.totClr}>
            {displayPlayers.map((p, pos) => (
              <tr key={displayIdxs[pos]} style={{ background: K.row[pos % 2] }}>
                <td style={{ ...nameTd, color: K.hdrClr }}>{p.name}</td>
                {hs.map(h => skinTd(cellVal(pos, h), h))}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{totals[pos] || '·'}</td>
              </tr>
            ))}
          </GameTable>
        </div>
      );
    }

    return (
      <div style={{ padding: '0 8px 4px' }}>
        <GameTable landscape headerBg={K.hdrBg} headerColor={K.hdrClr} totBg={K.totBg} totColor={K.totClr}>
          {displayPlayers.map((p, pos) => (
            <tr key={displayIdxs[pos]} style={{ background: K.row[pos % 2] }}>
              <td style={{ ...nameTd, color: K.hdrClr }}>{p.name}</td>
              {frontHoles.map(h => skinTd(cellVal(pos, h), h))}
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{frontTots[pos] || '·'}</td>
              {backHoles.map(h => skinTd(cellVal(pos, h), h))}
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{backTots[pos] || '·'}</td>
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{totals[pos] || '·'}</td>
            </tr>
          ))}
        </GameTable>
      </div>
    );
  };

  if (!rows.length) return null;
  const displayPlayers = displayIdxs.map(i => players[i]).filter(Boolean);

  return (
    <GameSection title="Skins" badge={`${scoringLabel(mode)} · Carry ${carry ? 'on' : 'off'}`} color={K.hdrClr} borderColor={K.border}>
      {isLandscape ? (
        renderAll18()
      ) : (
        <>
          {hasFront && renderHalf(frontHoles, 'Front')}
          {hasFront && hasBack && <TableDivider/>}
          {hasBack  && renderHalf(backHoles,  'Back')}
        </>
      )}
      <TableDivider/>
      <PlayerChips players={displayPlayers} values={totals} chipBg={K.hdrBg} chipColor={K.hdrClr} leaderBg={K.totBg} leaderColor={K.totClr} fmtVal={v => v} subLabel="skins"/>
      <ColNote>Number = skins on that hole · darker = carryover · – = tied</ColNote>
    </GameSection>
  );
}
