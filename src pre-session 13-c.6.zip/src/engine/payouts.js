// ─── payouts.js ───────────────────────────────────────────────────────────────
// Computes final dollar payouts for every active game.
// Pure function — no React, no DOM. Returns { bank, breakdown }.
//
// NOL + SUBSET RULE (Handicap Contract §5):
//   When a game operates on a player subset and scoring mode is 'netofflow',
//   minCourseHcp passed to the engine must be the minimum course handicap of
//   the participating subset only — never from a superset of players.
//   All per-game blocks below use subsetMin() to enforce this invariant.
//
// 13-C.3 — PartialGameContract §3.6, §11.1, invariant #13:
//   - `splitRangeByMidpoint(startHole, endHole)` is the single authoritative
//     implementation of the universal F/B/T midpoint split. Back gets the
//     extra hole on odd-length ranges. For the default full round [0, 17]
//     this returns Front=[0..8], Back=[9..17], All=[0..17] — byte-identical
//     to the pre-13-C.3 hardcoded arrays.
//   - `rangeFor(gameKey)` resolves a game's effective range from
//     `gameRanges[gameKey]`, defaulting to [roundStartHole, roundEndHole].
//   - Match and Stableford-team pass the range to the engine via the new
//     optional `range` argument on `runMatchNassau` and
//     `calcTeamStablefordTotal`. All other games are trimmed at the
//     pre-processing layer before the engine is called — engine firewall
//     preserved for every function other than the two excepted above.

import { scoreForMode } from './handicap.js';
import {
  calcSkins, calcSkinsHole,
  calcNines, ninesPts,
  runMatchNassau, isNassauMatch, matchLabel,
  getSixesTeam, calcSixesSegment, runSixesSegment,
  calcStablefordTotal, calcTeamStablefordTotal,
  calcStrokePlay,
  getDotsPartner, getMatchTeamPartner, sixesSegForHole,
} from './games.js';

function initBank(players) {
  const bank = {};
  players.forEach(p => (bank[p.name] = 0));
  return bank;
}

/** Pay the winner of a segment vs all other players in the subset */
function payWinner(winner, players, bet, gb) {
  players.forEach(p => {
    if (p.name !== winner) { gb[p.name] -= bet; gb[winner] += bet; }
  });
}

/**
 * Compute the minimum course handicap for a subset of player indices.
 * When mode is 'netofflow' and idxs is a non-empty subset, returns the
 * minimum of cHcps[i] for i in idxs only.
 * When mode is not 'netofflow', or idxs is empty, returns globalMin.
 * This enforces the NOL + subset invariant (Handicap Contract §5).
 */
function subsetMin(cHcps, idxs, globalMin, mode) {
  if (mode !== 'netofflow' || !idxs?.length) return globalMin;
  return Math.min(...idxs.map(i => cHcps[i]));
}

/**
 * 13-C.3 — PartialGameContract §3.6.
 * Universal F/B/T midpoint split for any game with segment structure.
 *
 *   totalHoles = endHole - startHole + 1
 *   midHole    = startHole + floor(totalHoles / 2)
 *   Front      = [startHole .. midHole - 1]
 *   Back       = [midHole   .. endHole    ]
 *   All        = [startHole .. endHole    ]
 *
 * Odd-length ranges: Back receives the extra hole.
 * For the default full round [0, 17]: midHole=9, Front=[0..8],
 * Back=[9..17], All=[0..17] — byte-identical to pre-13-C.3 behavior.
 *
 * @returns {{ front: number[], back: number[], all: number[] }}
 */
function splitRangeByMidpoint(startHole, endHole) {
  const total = endHole - startHole + 1;
  const mid   = startHole + Math.floor(total / 2);
  const front = [];
  const back  = [];
  const all   = [];
  for (let h = startHole; h < mid;      h++) front.push(h);
  for (let h = mid;       h <= endHole; h++) back.push(h);
  for (let h = startHole; h <= endHole; h++) all.push(h);
  return { front, back, all };
}

/**
 * 13-C.3 — resolve a game's effective hole range.
 * Returns { startHole, endHole } for the given game key, defaulting to the
 * round range when no explicit per-game override is set.
 *
 * `key` matches a key in `gameRanges`:
 *   - Game name for Stroke Play, Skins, Stableford, Nines, Sixes, Dots
 *   - `matchDef.id` for individual Match instances
 */
function rangeFor(key, gameRanges, roundStartHole, roundEndHole) {
  const entry = gameRanges?.[key];
  if (entry
      && Number.isInteger(entry.startHole)
      && Number.isInteger(entry.endHole)
      && entry.startHole >= roundStartHole
      && entry.endHole   <= roundEndHole
      && entry.startHole <  entry.endHole) {
    return { startHole: entry.startHole, endHole: entry.endHole };
  }
  return { startHole: roundStartHole, endHole: roundEndHole };
}

/**
 * 13-C.3 — trim a scores array to a hole range.
 * Returns a new 18-row array where rows outside [startHole, endHole] are
 * replaced with empty-slot rows (each slot `''`). Rows inside the range
 * are passed through by reference (not deep-copied — scores are read-only
 * in payout computation). Used for games (e.g. Stroke Play) whose engine
 * iterates all 18 holes internally; replacing out-of-range rows with
 * empty strings makes `parseInt('')` → NaN → the engine contributes 0.
 */
function trimScoresToRange(scores, startHole, endHole, playerCount) {
  const empty = Array(playerCount).fill('');
  const out = [];
  for (let h = 0; h < 18; h++) {
    if (h >= startHole && h <= endHole) out.push(scores[h] || empty);
    else out.push(empty);
  }
  return out;
}

export function computePayouts({
  players, pars, hcps, scores,
  activeGames, gameOpts,
  matches = [],             // unified Match/Nassau instances
  strokePlayPlayers = [],   // player index subset for Stroke Play ([] = all)
  skinsPlayers = [],        // player index subset for Skins ([] = all)
  stablefordPlayers = [],   // player index subset for Stableford ([] = all)
  ninesPlayers = [],        // 3 player indices for Nines
  sixesTeams,
  sixesPlayers = [],        // 4 player indices for Sixes ([] = all; deferred 5-player support)
  dotsPlayers = [],         // player index subset for Dots ([] = all)
  dots, dotEntries,
  courseHcps,
  minCourseHcp,
  manualPresses = {},
  // 13-C.2 / 13-C.3: Round length + per-game ranges.
  // `roundStartHole` + `roundNumHoles` establish the round boundary; `gameRanges`
  // holds per-game overrides within that boundary (keyed by game name or
  // `matchDef.id` per PartialGameContract §4.3). Defaults preserve full-round
  // no-op behavior (invariant #13).
  roundStartHole = 0,
  roundNumHoles  = 18,
  gameRanges     = {},
}) {
  const bank      = initBank(players);
  const breakdown = [];
  const cHcps    = courseHcps || players.map(p => Math.round(parseFloat(p.ghin) || 0));
  const minCHcp  = minCourseHcp ?? Math.min(...cHcps);
  const parTot   = pars.reduce((a, b) => a + b, 0);
  const playerCount = players.length;

  // 13-C.2: Derived round-end hole. `roundEndHole` is NEVER stored per
  // PartialGameContract §1A.3 / invariant #17 — always recomputed here.
  const roundEndHole = roundStartHole + roundNumHoles - 1;

  // Convenience closure: fetch a game's effective range using the round
  // boundary as the default fallback.
  const gameRange = (key) => rangeFor(key, gameRanges, roundStartHole, roundEndHole);

  // ── Stroke Play ────────────────────────────────────────────────────────────
  if (activeGames.includes('Stroke Play')) {
    const bet        = gameOpts['Stroke Play']?.bet  || 0;
    const mode       = gameOpts['Stroke Play']?.grossNetNOL ?? gameOpts['Stroke Play']?.scoring ?? 'net';
    const strokeMode = gameOpts['Stroke Play']?.betMode ?? gameOpts['Stroke Play']?.strokeMode ?? 'total';
    const spBetF     = gameOpts['Stroke Play']?.betF  ?? bet;
    const spBetB     = gameOpts['Stroke Play']?.betB  ?? bet;
    const spBet18    = gameOpts['Stroke Play']?.bet18 ?? bet;

    const spIdxs = strokePlayPlayers?.length ? strokePlayPlayers : players.map((_, i) => i);
    const spMin  = subsetMin(cHcps, spIdxs, minCHcp, mode);
    const gb     = initBank(players);

    // 13-C.3: Stroke Play effective range + §3.6 midpoint split.
    const { startHole: spStart, endHole: spEnd } = gameRange('Stroke Play');
    const { front: spFront, back: spBack } = splitRangeByMidpoint(spStart, spEnd);

    // Pre-trim scores to Stroke Play's range so `calcStrokePlay` (which
    // iterates all 18 holes) only sums in-range scores. Out-of-range slots
    // become `''`; `parseInt('')` → NaN → contributes 0.
    const spScores = trimScoresToRange(scores, spStart, spEnd, playerCount);

    // payWinnerStroke: lowest nd wins the segment.
    // 13-C.3: Ties for low SPLIT the pot equally among co-winners (matches
    // 'total'-mode behavior in this file and standard stroke-play etiquette).
    // Pre-13-C.3 this guard was `winners.length === 1` which silently zeroed
    // the segment on a tie — fixed in Phase 2A finalization.
    //
    // Phase 2A finalization (Test B-2): also returns a per-name delta map so
    // callers can attribute payouts to a specific segment (used by the
    // Stroke Play Nassau breakdown to emit F/B/O column values on Results).
    const payWinnerStroke = (segRows, segBet) => {
      const segDelta = {};
      players.forEach(p => (segDelta[p.name] = 0));
      if (segBet <= 0 || !segRows.length) return segDelta;
      const low = segRows[0].nd;
      const winners = segRows.filter(r => r.nd === low);
      const losers  = segRows.filter(r => r.nd !== low);
      if (losers.length > 0) {
        const pot   = losers.length * segBet;
        const split = pot / winners.length;
        winners.forEach(w => { gb[w.name] += split; segDelta[w.name] += split; });
        losers.forEach(l  => { gb[l.name] -= segBet; segDelta[l.name] -= segBet; });
      }
      return segDelta;
    };

    if (strokeMode === 'nassau' || strokeMode === 'segments') {
      // Compute net-to-par per segment for each player in subset.
      // 13-C.3: Front / Back arrays derived from §3.6 midpoint — default
      // (full round) gives Front=[0..8] Back=[9..17].
      const segScore = (holes) => {
        return spIdxs.map(pi => {
          const p = players[pi];
          let nd = 0;
          for (const h of holes) {
            const g = parseInt(scores[h]?.[pi]);
            if (!g) continue;
            const net = scoreForMode(g, cHcps[pi], hcps[h], spMin, mode);
            nd += net - pars[h];
          }
          return { name: p.name, nd };
        }).sort((a, b) => a.nd - b.nd);
      };
      const fDelta = payWinnerStroke(segScore(spFront), spBetF);
      const bDelta = payWinnerStroke(segScore(spBack),  spBetB);
      // rows18: "overall" segment for the game — uses pre-trimmed scores so
      // calcStrokePlay's internal 18-hole iteration only counts in-range holes.
      const rows18 = calcStrokePlay(spScores, players, hcps, pars, mode, cHcps, spMin, spIdxs);
      const oDelta = payWinnerStroke(rows18, spBet18);
      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      // Phase 2A finalization (Test B-2): emit a colHeaders breakdown entry
      // so Results page renders F / B / O / Total columns (one row per player,
      // single-line layout). Detected by ResultsPage.DotsColTable via
      // `entry.colHeaders`. Last column is the per-player total.
      breakdown.push({
        game: '🏌️ Stroke Play (Nassau)',
        colHeaders: ['Front', 'Back', 'Total', 'Game Total'],
        rows: rows18.map(r => {
          const f = fDelta[r.name] || 0;
          const b = bDelta[r.name] || 0;
          const o = oDelta[r.name] || 0;
          return {
            name:      r.name,
            matchCols: [f, b, o, f + b + o],
            net:       gb[r.name] || 0,
          };
        }),
      });
    } else {
      const rows = calcStrokePlay(spScores, players, hcps, pars, mode, cHcps, spMin, spIdxs);
      if (bet > 0 && rows.length > 0) {
        const lowNd   = rows[0].nd;
        const winners = rows.filter(r => r.nd === lowNd);
        const losers  = rows.filter(r => r.nd !== lowNd);
        if (losers.length > 0) {
          const pot   = losers.length * bet;
          const split = pot / winners.length;
          winners.forEach(w => { gb[w.name] += split; });
          losers.forEach(l  => { gb[l.name] -= bet;   });
        }
      }
      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏌️ Stroke Play',
        rows: rows.map(r => ({
          name:   r.name,
          detail: `${r.gt} gross / ${r.nt} net (${r.nd > 0 ? '+' : ''}${r.nd})`,
          net:    gb[r.name] || 0,
        })),
      });
    }
  }

  // ── Skins ──────────────────────────────────────────────────────────────────
  if (activeGames.includes('Skins')) {
    const bet          = gameOpts.Skins?.bet || 0;
    const payoutMode   = gameOpts.Skins?.mode || 'perSkin'; // backward compat: absent → 'perSkin'
    const scoringMode  = gameOpts.Skins?.grossNetNOL ?? gameOpts.Skins?.scoring ?? 'net';
    const carryover    = gameOpts.Skins?.carryover === false ? false : true;
    const idxs         = skinsPlayers?.length ? skinsPlayers : players.map((_, i) => i);
    const skinPs       = idxs.map(i => players[i]).filter(Boolean);
    const subsetSize   = skinPs.length;

    // NOL + subset: use subset minimum when mode is netofflow (Handicap Contract §5.2)
    const skinsMin = subsetMin(cHcps, idxs, minCHcp, scoringMode);

    // 13-C.3: Skins effective range. Skins is hole-by-hole family (§7.3) —
    // payouts iterate only over the range. `calcSkins` from games.js iterates
    // 0..17 and breaks on the first empty hole, so for a non-default range
    // we inline a range-aware skins iteration using `calcSkinsHole` directly
    // (engine function, hole-agnostic — takes a single hole index).
    const { startHole: skStart, endHole: skEnd } = gameRange('Skins');

    // Compute hole-by-hole skin results over the effective range.
    // Carryover counter only advances across holes inside the range.
    const totals = {};
    players.forEach(p => (totals[p.name] = 0));
    let carryCount = 0;
    for (let h = skStart; h <= skEnd; h++) {
      const result = calcSkinsHole(h, scores, players, hcps, scoringMode, cHcps, skinsMin, idxs);
      if (!result) break;
      if (result.tied) {
        carryCount++;
      } else {
        const value = carryover ? 1 + carryCount : 1;
        totals[players[result.wiIdx].name] = (totals[players[result.wiIdx].name] || 0) + value;
        carryCount = 0;
      }
    }

    const gb           = initBank(players);

    // Sum awarded skins across subset players only (invariant: non-subset totals[name] === 0)
    const totalAwardedSkins = skinPs.reduce((sum, p) => sum + (totals[p.name] || 0), 0);

    if (bet > 0) {
      if (payoutMode === 'perSkin') {
        // bet = per-player contribution per skin; each skin is worth bet × subsetSize.
        // gross[p] = totals[p] × bet × subsetSize
        // pp       = totalAwardedSkins × bet  (each player's total contribution)
        // net[p]   = gross[p] - pp
        if (totalAwardedSkins > 0) {
          const skinValue = bet * subsetSize;
          const pp        = totalAwardedSkins * bet;
          skinPs.forEach(p => { gb[p.name] += (totals[p.name] || 0) * skinValue - pp; });
        }
      } else {
        // pot mode: each player buys in for `bet`; pot split by awarded skins.
        // If no skins awarded, pot is returned (all net = 0).
        if (totalAwardedSkins > 0) {
          const pot          = bet * subsetSize;
          const skinUnitValue = pot / totalAwardedSkins;
          skinPs.forEach(p => { gb[p.name] += (totals[p.name] || 0) * skinUnitValue - bet; });
        }
      }
    }

    Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
    breakdown.push({
      game: '💰 Skins',
      rows: skinPs.map(p => ({
        name:   p.name,
        detail: `${totals[p.name]} skins`,
        net:    gb[p.name] || 0,
      })).sort((a, b) => b.net - a.net),
    });
  }

  // ── Match / Nassau ─────────────────────────────────────────────────────────
  if (activeGames.includes('Match / Nassau') && matches.length > 0) {
    const gb            = initBank(players);
    const playerDetails = {};
    players.forEach(p => (playerDetails[p.name] = []));

    matches.forEach((matchDef, mi) => {
      const matchKey = matchDef.id || `match_${mi}`;
      const manuPresses = {
        front:   manualPresses[`Match:${matchKey}:Front`]   || [],
        back:    manualPresses[`Match:${matchKey}:Back`]    || [],
        overall: manualPresses[`Match:${matchKey}:Overall`] || [],
      };

      // NOL + match subset: derive minCourseHcp from match participants only
      // (Handicap Contract §5.4). Individual matches involve 2 players;
      // team matches involve 4. Full-field minCHcp is wrong here.
      const isTeam = matchDef.format === 'team';
      const sideA  = isTeam ? (matchDef.teamA || []) : [matchDef.p1];
      const sideB  = isTeam ? (matchDef.teamB || []) : [matchDef.p2];
      const involved = [...sideA, ...sideB].filter(i => players[i]);
      const matchMode = matchDef.grossNetNOL ?? matchDef.scoring ?? 'net';
      const matchMin  = subsetMin(cHcps, involved, minCHcp, matchMode);

      // 13-C.3: per-match effective range (keyed by matchDef.id).
      // Passed to runMatchNassau as the 8th argument. Engine derives
      // FRONT/BACK/ALL18 internally via §3.6 midpoint. For default
      // [0, 17] the output is byte-identical to pre-13-C.3.
      const matchRange = gameRange(matchKey);

      const { front, back, overall } = runMatchNassau(
        scores, players, hcps, matchDef, cHcps, matchMin, manuPresses,
        matchRange
      );

      const betF = matchDef.betFront   || 0;
      const betB = matchDef.betBack    || 0;
      const betO = matchDef.betOverall || 0;
      const lbl  = matchLabel(matchDef, players);

      const segments = [
        { bets: front,   betAmt: betF, seg: 'Front' },
        { bets: back,    betAmt: betB, seg: 'Back'  },
        { bets: overall, betAmt: betO, seg: isNassauMatch(matchDef) ? 'Overall' : 'Main' },
      ];

      segments.forEach(({ bets, betAmt, seg }) => {
        bets.forEach(m => {
          if (m.thru > 0) {
            involved.forEach(pi => {
              if (players[pi]) {
                const tag = `${lbl} ${seg}${bets.length > 1 ? ` (${m.label})` : ''}`;
                playerDetails[players[pi].name].push(`${tag}: ${m.status}`);
              }
            });
          }
          if (betAmt > 0 && m.thru > 0) {
            // Individual match
            if (!isTeam && m.lead !== 0) {
              const wi = m.lead > 0 ? matchDef.p1 : matchDef.p2;
              const li = m.lead > 0 ? matchDef.p2 : matchDef.p1;
              if (players[wi] && players[li]) {
                gb[players[wi].name] += betAmt;
                gb[players[li].name] -= betAmt;
              }
            }
            // Team match — each player on winning side wins betAmt from each player on losing side
            if (isTeam && m.lead !== 0) {
              const winSide = m.lead > 0 ? sideA : sideB;
              const losSide = m.lead > 0 ? sideB : sideA;
              winSide.forEach(wi => {
                if (players[wi]) gb[players[wi].name] += betAmt;
              });
              losSide.forEach(li => {
                if (players[li]) gb[players[li].name] -= betAmt;
              });
            }
          }
        });
      });
    });

    Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
    breakdown.push({
      game: '🥊 Match / Nassau',
      rows: players.map(p => ({
        name:   p.name,
        detail: playerDetails[p.name]?.join(' · ') || '—',
        net:    gb[p.name] || 0,
      })).sort((a, b) => b.net - a.net),
    });
  }

  // ── Stableford ─────────────────────────────────────────────────────────────
  if (activeGames.includes('Stableford')) {
    const bet         = gameOpts.Stableford?.bet || 0;
    const mode        = gameOpts.Stableford?.grossNetNOL ?? 'net';
    const stabBetMode = gameOpts.Stableford?.betMode ?? gameOpts.Stableford?.stabBetMode ?? 'perpoint';
    const stabTable   = gameOpts.Stableford?.stabTable ?? null;
    const format      = gameOpts.Stableford?.format ?? 'individual';
    const teamA       = gameOpts.Stableford?.teamA ?? [];
    const teamB       = gameOpts.Stableford?.teamB ?? [];
    const scoring     = gameOpts.Stableford?.scoring ?? 'cumulative';
    const gb          = initBank(players);

    // Per-segment bet overrides
    const stabBetF  = gameOpts.Stableford?.betF  || bet;
    const stabBetB  = gameOpts.Stableford?.betB  || bet;
    const stabBet18 = gameOpts.Stableford?.bet18 || bet;

    // 13-C.3: Stableford effective range + §3.6 midpoint split.
    const { startHole: stabStart, endHole: stabEnd } = gameRange('Stableford');
    const { front: stabFront, back: stabBack, all: stabAll } = splitRangeByMidpoint(stabStart, stabEnd);
    const stabRange = { startHole: stabStart, endHole: stabEnd };

    if (format === 'team' && teamA.length === 2 && teamB.length === 2) {
      // ── Team mode ──────────────────────────────────────────────────────────
      // NOL+subset: use team union as participant set
      const teamIdxs = [...teamA, ...teamB];
      const stabMin  = subsetMin(cHcps, teamIdxs, minCHcp, mode);

      // 13-C.3: pass `range` to engine for §3.6 midpoint split.
      // `holes` arg is the effective range's all-holes array; engine
      // splits it into ptsF/ptsB internally via the range midpoint.
      const teamTots = (idxs) =>
        calcTeamStablefordTotal(scores, pars, hcps, cHcps, stabMin, mode, stabTable, idxs, scoring, stabAll, stabRange);

      // Helper: settle one team pair for a segment — each player pays/receives full segBet.
      // Returns per-name delta map for column display.
      const payTeamSeg = (totA, totB, segBet) => {
        const segDelta = {};
        [...teamA, ...teamB].forEach(pi => (segDelta[players[pi].name] = 0));
        if (segBet <= 0 || totA === totB) return segDelta; // push on tie
        const [winners, losers] = totA > totB ? [teamA, teamB] : [teamB, teamA];
        winners.forEach(pi => { gb[players[pi].name] += segBet; segDelta[players[pi].name] += segBet; });
        losers.forEach(pi  => { gb[players[pi].name] -= segBet; segDelta[players[pi].name] -= segBet; });
        return segDelta;
      };

      if (stabBetMode === 'perpoint') {
        const rA = teamTots(teamA);
        const rB = teamTots(teamB);
        const diff = Math.abs(rA.pts - rB.pts);
        if (bet > 0 && diff > 0) {
          const perPlayer = diff * bet;
          const [winners, losers] = rA.pts > rB.pts ? [teamA, teamB] : [teamB, teamA];
          winners.forEach(pi => { gb[players[pi].name] += perPlayer; });
          losers.forEach(pi  => { gb[players[pi].name] -= perPlayer; });
        }
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        const allTeamPis = [...teamA, ...teamB];
        breakdown.push({
          game: 'Stableford',
          rows: allTeamPis
            .map(pi => ({ name: players[pi].name, detail: `${teamA.includes(pi) ? rA.pts : rB.pts} pts`, net: gb[players[pi].name] || 0 }))
            .sort((a, b) => b.net - a.net),
        });
      } else if (stabBetMode === 'segments') {
        const rA = teamTots(teamA);
        const rB = teamTots(teamB);
        const fDelta = payTeamSeg(rA.ptsF, rB.ptsF, stabBetF);
        const bDelta = payTeamSeg(rA.ptsB, rB.ptsB, stabBetB);
        const oDelta = payTeamSeg(rA.pts,  rB.pts,  stabBet18);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        const allTeamPis = [...teamA, ...teamB];
        // Phase 2A finalization: emit colHeaders for team Stableford segments.
        // Each player's row shows F/B/O contribution from their team's results.
        breakdown.push({
          game: 'Stableford',
          colHeaders: ['Front', 'Back', 'Total', 'Game Total'],
          rows: allTeamPis.map(pi => {
            const nm = players[pi].name;
            const f  = fDelta[nm] || 0;
            const b  = bDelta[nm] || 0;
            const o  = oDelta[nm] || 0;
            return {
              name:      nm,
              matchCols: [f, b, o, f + b + o],
              net:       gb[nm] || 0,
            };
          }),
        });
      } else {
        // 'total' mode: each player on winning team receives bet; each on losing team pays bet
        const rA = teamTots(teamA);
        const rB = teamTots(teamB);
        if (bet > 0) payTeamSeg(rA.pts, rB.pts, bet);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        const allTeamPis = [...teamA, ...teamB];
        breakdown.push({
          game: 'Stableford',
          rows: allTeamPis
            .map(pi => ({ name: players[pi].name, detail: `${teamA.includes(pi) ? rA.pts : rB.pts} pts`, net: gb[players[pi].name] || 0 }))
            .sort((a, b) => b.net - a.net),
        });
      }
    } else {
      // ── Individual mode ────────────────────────────────────────────────────
      const stabIdxs = stablefordPlayers?.length ? stablefordPlayers : players.map((_, i) => i);
      const stabPs   = stabIdxs.map(i => players[i]).filter(Boolean);

      // NOL+subset: use subset minimum
      const stabMin = subsetMin(cHcps, stabIdxs, minCHcp, mode);

      // 13-C.3: `stabScore` accepts a holes array; call sites pass
      // splitRangeByMidpoint-derived front/back/all arrays.
      const stabScore = (pi, holes) =>
        calcStablefordTotal(scores, pi, pars, hcps, cHcps[pi], stabMin, mode, stabTable, holes);

      // Split-pot helper: finds co-winners (tied high), losers pay segBet,
      // pot split among winners. Returns per-name delta map for column display.
      const paySegStab = (arr, field, segBet) => {
        const segDelta = {};
        arr.forEach(r => (segDelta[r.name] = 0));
        if (segBet <= 0) return segDelta;
        const maxVal  = Math.max(...arr.map(r => r[field]));
        const winners = arr.filter(r => r[field] === maxVal);
        const losers  = arr.filter(r => r[field] < maxVal);
        if (losers.length === 0) return segDelta; // all tied — push
        const share = (losers.length * segBet) / winners.length;
        losers.forEach(r  => { gb[r.name] -= segBet; segDelta[r.name] -= segBet; });
        winners.forEach(r => { gb[r.name] += share;  segDelta[r.name] += share; });
        return segDelta;
      };

      if (stabBetMode === 'perpoint' && bet > 0) {
        const ranked = stabIdxs
          .map(pi => ({ name: players[pi].name, pts: stabScore(pi, stabAll) }))
          .sort((a, b) => b.pts - a.pts);
        for (let i = 0; i < ranked.length; i++)
          for (let j = i + 1; j < ranked.length; j++) {
            const diff = ranked[i].pts - ranked[j].pts;
            if (diff > 0) { gb[ranked[i].name] += diff * bet; gb[ranked[j].name] -= diff * bet; }
          }
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: 'Stableford',
          rows: ranked.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      } else if (stabBetMode === 'nassau' || stabBetMode === 'segments') {
        // 13-C.3: F/B/T derived via §3.6 midpoint — default range yields
        // stabFront=[0..8] stabBack=[9..17] stabAll=[0..17].
        const pts18 = stabIdxs.map(pi => ({
          name: players[pi].name,
          pts:  stabScore(pi, stabAll),
          ptsF: stabScore(pi, stabFront),
          ptsB: stabScore(pi, stabBack),
        }));
        const fDelta = paySegStab(pts18, 'ptsF', stabBetF);
        const bDelta = paySegStab(pts18, 'ptsB', stabBetB);
        const oDelta = paySegStab(pts18, 'pts',  stabBet18);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        // Phase 2A finalization: emit colHeaders so Results renders F/B/O/Total
        // columns (single-line layout). Detected by ResultsPage.DotsColTable
        // via `entry.colHeaders`. Last column = per-player total.
        breakdown.push({
          game: 'Stableford',
          colHeaders: ['Front', 'Back', 'Total', 'Game Total'],
          rows: pts18.map(r => {
            const f = fDelta[r.name] || 0;
            const b = bDelta[r.name] || 0;
            const o = oDelta[r.name] || 0;
            return {
              name:      r.name,
              matchCols: [f, b, o, f + b + o],
              net:       gb[r.name] || 0,
            };
          }),
        });
      } else {
        // 'total' mode (and any unrecognised value): split-pot among tied winners
        const pts18 = stabIdxs
          .map(pi => ({ name: players[pi].name, pts: stabScore(pi, stabAll) }))
          .sort((a, b) => b.pts - a.pts);
        if (bet > 0) {
          const maxPts  = pts18[0]?.pts ?? 0;
          const winners = pts18.filter(r => r.pts === maxPts);
          const losers  = pts18.filter(r => r.pts < maxPts);
          if (losers.length > 0) {
            const share = (losers.length * bet) / winners.length;
            losers.forEach(r  => { gb[r.name] -= bet; });
            winners.forEach(r => { gb[r.name] += share; });
          }
        }
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: 'Stableford',
          rows: pts18.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      }
    }
  }

  // ── Nines ──────────────────────────────────────────────────────────────────
  if (activeGames.includes('Nines')) {
    const bet       = gameOpts.Nines?.bet || 0;
    const mode      = gameOpts.Nines?.grossNetNOL ?? gameOpts.Nines?.scoring ?? 'net';
    const ninesMode = gameOpts.Nines?.betMode ?? gameOpts.Nines?.ninesMode ?? 'perpoint';
    const blitz     = gameOpts.Nines?.blitz || false;

    // Per-segment bets (nassau mode)
    const ninesBetF  = gameOpts.Nines?.betF  ?? bet;
    const ninesBetB  = gameOpts.Nines?.betB  ?? bet;
    const ninesBet18 = gameOpts.Nines?.bet18 ?? bet;

    // ninesPlayers resolution chain (Nines Contract §2.2):
    //   Step 1: top-level ninesPlayers param (from buildPayoutArgs) — length must be exactly 3
    //   Step 2: gameOpts.Nines.ninesPlayers legacy field — length must be exactly 3
    //   Step 3: [0,1,2] fallback ONLY for 3-player rounds (safe because all 3 players participate).
    //           In 4+ player rounds with no valid subset, skip the block entirely (G-4 fix).
    const nPlayerIdx = ninesPlayers?.length === 3
      ? ninesPlayers
      : (gameOpts.Nines?.ninesPlayers?.length === 3
          ? gameOpts.Nines.ninesPlayers
          : players.length === 3
              ? [0, 1, 2]
              : null);   // null → skip block for 4+ player rounds with no subset set

    const nPlayers = nPlayerIdx ? nPlayerIdx.map(i => players[i]).filter(Boolean) : [];

    if (nPlayers.length >= 3) {
      const gb = initBank(players);

      // NOL + subset: Nines always operates on exactly 3 players (Handicap Contract §5.2)
      const ninesMin = subsetMin(cHcps, nPlayerIdx, minCHcp, mode);

      // 13-C.3: Nines effective range + §3.6 midpoint split.
      const { startHole: ninesStart, endHole: ninesEnd } = gameRange('Nines');
      const { front: ninesFront, back: ninesBack, all: ninesAll } = splitRangeByMidpoint(ninesStart, ninesEnd);

      const calcTots = (holes) => {
        const { totals } = calcNines(scores, players, nPlayerIdx, hcps, mode, blitz, holes, cHcps, ninesMin);
        return nPlayers.map((p, i) => ({ name: p.name, pts: totals[i] }));
      };

      const payRanked = (ranked, rate) => {
        // Pairwise over unordered pairs (i < j) — each pair evaluated exactly once.
        for (let i = 0; i < ranked.length; i++)
          for (let j = i + 1; j < ranked.length; j++) {
            const diff = ranked[i].pts - ranked[j].pts;
            if (diff > 0 && rate > 0) {
              gb[ranked[i].name] += diff * rate;
              gb[ranked[j].name] -= diff * rate;
            }
          }
      };

      // 13-C.3 / Phase 2A finalization: payNassauSeg now returns a per-name
      // delta map so the caller can render F/B/O columns on Results. Pairwise
      // settlement (i < j) — each pair pays segBet; ties between two players
      // skip (no third party to share with).
      const payNassauSeg = (ranked, segBet) => {
        const segDelta = {};
        ranked.forEach(r => (segDelta[r.name] = 0));
        if (segBet <= 0) return segDelta;
        for (let i = 0; i < ranked.length; i++)
          for (let j = i + 1; j < ranked.length; j++)
            if (ranked[i].pts > ranked[j].pts) {
              gb[ranked[i].name] += segBet; segDelta[ranked[i].name] += segBet;
              gb[ranked[j].name] -= segBet; segDelta[ranked[j].name] -= segBet;
            }
        return segDelta;
      };

      if (ninesMode === 'perpoint') {
        const ranked = calcTots(ninesAll).sort((a, b) => b.pts - a.pts);
        if (bet > 0) payRanked(ranked, bet);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        breakdown.push({
          game: '🔢 Nines',
          rows: ranked.map(r => ({ name: r.name, detail: `${r.pts} pts`, net: gb[r.name] || 0 })),
        });
      } else {
        const f9 = calcTots(ninesFront).sort((a, b) => b.pts - a.pts);
        const b9 = calcTots(ninesBack).sort((a, b) => b.pts - a.pts);
        const ov = calcTots(ninesAll).sort((a, b) => b.pts - a.pts);
        const fDelta = payNassauSeg(f9, ninesBetF);
        const bDelta = payNassauSeg(b9, ninesBetB);
        const oDelta = payNassauSeg(ov, ninesBet18);
        Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
        // Phase 2A finalization: emit colHeaders for Nines (Nassau).
        // Single line per player with F / B / O / Total columns.
        breakdown.push({
          game: '🔢 Nines (Nassau)',
          colHeaders: ['Front', 'Back', 'Total', 'Game Total'],
          rows: nPlayers.map(p => {
            const f = fDelta[p.name] || 0;
            const b = bDelta[p.name] || 0;
            const o = oDelta[p.name] || 0;
            return {
              name:      p.name,
              matchCols: [f, b, o, f + b + o],
              net:       gb[p.name] || 0,
            };
          }),
        });
      }
    }
  }

  // ── Sixes ──────────────────────────────────────────────────────────────────
  if (activeGames.includes('Sixes') && sixesTeams?.[0]?.a != null && sixesTeams?.[1]?.a != null) {
    const bet      = gameOpts.Sixes?.bet || 0;
    const mode     = gameOpts.Sixes?.grossNetNOL ?? gameOpts.Sixes?.scoring ?? 'net';
    const tiebreak = gameOpts.Sixes?.scoring ?? gameOpts.Sixes?.tiebreak ?? 'none';
    const gb       = initBank(players);

    // Derive auto-press threshold (0 = off)
    const autoN = (gameOpts.Sixes?.autoPress && gameOpts.Sixes?.autoPress !== 'none')
      ? parseInt(gameOpts.Sixes?.autoPress)
      : 0;

    // 13-C.3: Sixes effective range → 3 equal segments.
    // PartialGameContract §3.5: segLength = rangeLength / 3 (validator ensures
    // the range is divisible by 3). For the default full round this yields
    // SEG_HOLES = [[0..5], [6..11], [12..17]] — byte-identical to pre-13-C.3.
    // `runSixesSegment` in games.js already takes a `holes` array as its first
    // argument, so no engine change is required.
    const { startHole: sxStart, endHole: sxEnd } = gameRange('Sixes');
    const sxLen    = sxEnd - sxStart + 1;
    const segLen   = Math.floor(sxLen / 3); // validator guarantees divisibility

    const SEG_HOLES = [
      Array.from({ length: segLen }, (_, i) => sxStart + i),
      Array.from({ length: segLen }, (_, i) => sxStart + segLen + i),
      Array.from({ length: segLen }, (_, i) => sxStart + 2 * segLen + i),
    ];
    const SEG_KEYS = ['Sixes:seg0', 'Sixes:seg1', 'Sixes:seg2'];

    SEG_HOLES.forEach((holes, si) => {
      const team = getSixesTeam(si, sixesTeams, players);
      if (!team) return; // null → invalid segment per §2.3

      const mpHoles = manualPresses[SEG_KEYS[si]] || [];

      // NOL + subset (Sixes Contract §14.2 / Handicap Contract §5.2):
      // When sixesPlayers is non-empty, compute minCourseHcp from the 4 participating
      // player indices for this segment only. When sixesPlayers is empty (all-player
      // 4-player rounds), full-field minCHcp is correct and subsetMin returns it unchanged.
      const { a, b } = team;
      const others = players.map((_, i) => i).filter(i => i !== a && i !== b);
      const segIdxs = sixesPlayers.length
        ? sixesPlayers
        : [a, b, ...others.slice(0, 2)];
      const segMin = subsetMin(cHcps, segIdxs, minCHcp, mode);

      const matchLevels = runSixesSegment(
        holes, scores, players, hcps,
        team, mode, tiebreak,
        cHcps, segMin,
        autoN, mpHoles
      );
      if (!matchLevels) return; // null → < 4 players guard

      const [c, d] = others;

      // Pay each match level independently at bet $ per player (§4.2)
      matchLevels.forEach(m => {
        if (bet > 0 && m.winTeam && m.thru > 0) {
          const ws = m.winTeam === 'ab' ? [a, b] : [c, d];
          const ls = m.winTeam === 'ab' ? [c, d] : [a, b];
          ws.forEach(wi => { gb[players[wi].name] += bet; });
          ls.forEach(li => { gb[players[li].name] -= bet; });
        }
      });
    });

    Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
    breakdown.push({
      game: '🔄 Sixes',
      rows: players.map(p => ({ name: p.name, detail: '', net: gb[p.name] || 0 }))
        .sort((a, b) => b.net - a.net),
    });
  }

  // ── Dots ───────────────────────────────────────────────────────────────────
  // Formerly "Specials" — renamed in v2.0.
  // Backward compat: also fires for old rounds where activeGames still has 'Specials'.
  // Team-aware payout: Dots_Contract.md §7.6 — partners do not settle against
  // each other. Sixes: per-segment exclusion. Match: fixed exclusion all 18 holes.
  const dotsGameActive = activeGames.includes('Dots') || activeGames.includes('Specials');
  if (dotsGameActive) {
    const dotsOpts = gameOpts.Dots || gameOpts.Specials || {};
    const dolPt    = dotsOpts.bet || 0;
    const ens      = (dots || []).filter(s => s.enabled);
    const gb       = initBank(players);

    // Numeric entry count — backward compatible with legacy boolean true values.
    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);

    // teamMode migration: old rounds stored teamScoring:bool; new rounds store teamMode:string.
    const rawTeamMode = dotsOpts.teamMode;
    const legacyTeam  = dotsOpts.teamScoring;
    const isTeamMode  = rawTeamMode ? rawTeamMode !== 'none' : !!legacyTeam;
    const teamSource  = rawTeamMode && rawTeamMode !== 'none'
      ? rawTeamMode
      : (legacyTeam ? 'Sixes' : 'none');

    // Determine participating players (subset or all)
    const dtIdxs    = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    const dtPlayers = dtIdxs.map(i => players[i]).filter(Boolean);

    // 13-C.3: Dots effective range. In team mode, Dots is LOCKED to the team
    // source's range per D-3A — this mirrors the GameConfig UI lock. In
    // individual mode, Dots uses its own range from gameRanges['Dots'].
    let dotsStart, dotsEnd;
    if (isTeamMode && teamSource === 'Sixes') {
      ({ startHole: dotsStart, endHole: dotsEnd } = gameRange('Sixes'));
    } else if (isTeamMode && teamSource.startsWith('Match:')) {
      ({ startHole: dotsStart, endHole: dotsEnd } = gameRange(teamSource.slice(6)));
    } else {
      ({ startHole: dotsStart, endHole: dotsEnd } = gameRange('Dots'));
    }

    // Range membership test for dotEntries (keys of the form "h_pi_...").
    const inDotsRange = (h) => h >= dotsStart && h <= dotsEnd;

    // ── indivDots accumulation — used for individual mode and Match display ────
    // Counts own dots including own 'team' dot type (h_pi_team, 3 parts).
    // Excludes companion entries (h_partner_team_dot_for_earner, 6 parts).
    // 13-C.3: filtered to Dots effective range.
    const indivDots = players.map(() => 0);
    Object.entries(dotEntries || {}).forEach(([key, v]) => {
      const cnt = entryCount(v);
      if (!cnt) return;
      const parts = key.split('_');
      if (parts[2] === 'team' && parts.length > 3) return; // skip companions only
      const h     = parseInt(parts[0]);
      if (!inDotsRange(h)) return; // 13-C.3: out-of-range entries ignored
      const pi    = parseInt(parts[1]);
      const id    = parts[2];
      const sp    = ens.find(s => s.id === id);
      if (sp && players[pi]) indivDots[pi] += (sp.value ?? sp.pts ?? 1) * cnt;
    });

    // ── Pairwise settlement — team-aware (§7.6) ──────────────────────────────
    if (isTeamMode && teamSource === 'Sixes') {
      // Sixes: per-segment team settlement. For each segment, compute total
      // value-weighted dots for Team A and Team B. The team with more dots
      // wins diff*bet per player (each winner gets +diff*bet, each loser pays
      // -diff*bet). This mirrors the Sixes game payout model exactly.
      //
      // 13-C.3: Sixes segments follow the effective Sixes range (§3.5):
      // segLength = rangeLength/3; out-of-range dot entries are ignored.

      const sxLen = dotsEnd - dotsStart + 1;
      const segLen = Math.floor(sxLen / 3);
      const SIXES_SEG_HOLES = [
        Array.from({ length: segLen }, (_, i) => dotsStart + i),
        Array.from({ length: segLen }, (_, i) => dotsStart + segLen + i),
        Array.from({ length: segLen }, (_, i) => dotsStart + 2 * segLen + i),
      ];
      // hole → segment index (0/1/2). Returns -1 for out-of-range holes.
      const segForHole = (h) => {
        for (let s = 0; s < 3; s++) if (SIXES_SEG_HOLES[s].includes(h)) return s;
        return -1;
      };

      // Build segDots[pi][seg] — value-weighted OWN dots per player per segment.
      // Companion entries (h_partner_team_dot_for_earner, 6 parts) are excluded.
      // Own team dot entries (h_pi_team, 3 parts) ARE counted.
      const segDots = players.map(() => [0, 0, 0]);
      Object.entries(dotEntries || {}).forEach(([key, v]) => {
        const cnt = entryCount(v); if (!cnt) return;
        const parts = key.split('_');
        // Skip companion entries only (parts[2]==='team' AND parts.length > 3)
        if (parts[2] === 'team' && parts.length > 3) return;
        const h     = parseInt(parts[0]);
        const seg   = segForHole(h);
        if (seg < 0) return; // 13-C.3: out-of-range entries ignored
        const pi    = parseInt(parts[1]);
        const sp    = ens.find(s => s.id === parts[2]);
        if (!sp || !players[pi]) return;
        segDots[pi][seg] += (sp.value ?? sp.pts ?? 1) * cnt;
      });

      const gbSeg = [initBank(players), initBank(players), initBank(players)];

      if (dolPt > 0) {
        for (let seg = 0; seg < 3; seg++) {
          // Identify Team A and Team B for this segment via getDotsPartner
          // Team A = [p0, p0's partner]; Team B = remaining dtIdxs players
          const p0 = dtIdxs[0];
          const p0partner = getDotsPartner(p0, seg, sixesTeams, players);
          if (p0partner < 0) continue;
          const teamA = [p0, p0partner].filter(pi => dtIdxs.includes(pi));
          const teamB = dtIdxs.filter(pi => !teamA.includes(pi));
          if (!teamA.length || !teamB.length) continue;

          // Team totals for this segment
          const totA = teamA.reduce((s, pi) => s + segDots[pi][seg], 0);
          const totB = teamB.reduce((s, pi) => s + segDots[pi][seg], 0);
          const diff = totA - totB;

          if (diff > 0) {
            // Team A wins
            teamA.forEach(pi => {
              gb[players[pi].name]         += diff * dolPt;
              gbSeg[seg][players[pi].name] += diff * dolPt;
            });
            teamB.forEach(pi => {
              gb[players[pi].name]         -= diff * dolPt;
              gbSeg[seg][players[pi].name] -= diff * dolPt;
            });
          } else if (diff < 0) {
            // Team B wins
            teamB.forEach(pi => {
              gb[players[pi].name]         += (-diff) * dolPt;
              gbSeg[seg][players[pi].name] += (-diff) * dolPt;
            });
            teamA.forEach(pi => {
              gb[players[pi].name]         -= (-diff) * dolPt;
              gbSeg[seg][players[pi].name] -= (-diff) * dolPt;
            });
          }
        }
      }

      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏅 Dots',
        colHeaders: ['Match A', 'Match B', 'Match C', 'Total'],
        rows: dtPlayers.map((p, ii) => {
          const pi = dtIdxs[ii];
          return {
            name:      p.name,
            detail:    '',
            net:       gb[p.name] || 0,
            matchCols: [
              gbSeg[0][p.name] || 0,
              gbSeg[1][p.name] || 0,
              gbSeg[2][p.name] || 0,
              gb[p.name] || 0,
            ],
          };
        }).sort((a, b) => b.net - a.net),
      });

    } else if (isTeamMode && teamSource.startsWith('Match:')) {
      // Match: fixed teams all 18 holes (for standard rounds). Compute team A
      // vs team B using OWN dots only (exclude companion team entries — they
      // mirror partner's dots and would double-count the team total).
      //
      // 13-C.3: Dots in Match team mode are locked to the match's range.
      // `inDotsRange(h)` filter (set above via `gameRange(matchId)`) trims
      // entries to in-range holes.
      const matchId   = teamSource.slice(6);
      const teamMatch = matches.find(m => m.id === matchId) || matches.find(m => m.format === 'team');
      const tA = (teamMatch?.teamA || []).filter(pi => dtIdxs.includes(pi));
      const tB = (teamMatch?.teamB || []).filter(pi => dtIdxs.includes(pi));

      if (dolPt > 0 && tA.length && tB.length) {
        // ownDots: value-weighted dots per player — includes own 'team' dot type
        // entries (key format: h_pi_team, 3 parts) but excludes companion entries
        // (key format: h_partner_team_dot_for_earner, 6 parts).
        // 13-C.3: filtered to Dots effective range.
        const ownDots = players.map(() => 0);
        Object.entries(dotEntries || {}).forEach(([key, v]) => {
          const cnt = entryCount(v); if (!cnt) return;
          const parts = key.split('_');
          // Skip companion entries (parts[2]==='team' AND parts.length > 3)
          if (parts[2] === 'team' && parts.length > 3) return;
          const h  = parseInt(parts[0]);
          if (!inDotsRange(h)) return; // 13-C.3
          const pi = parseInt(parts[1]);
          const sp = ens.find(s => s.id === parts[2]);
          if (sp && players[pi]) ownDots[pi] += (sp.value ?? sp.pts ?? 1) * cnt;
        });

        const totA = tA.reduce((s, pi) => s + ownDots[pi], 0);
        const totB = tB.reduce((s, pi) => s + ownDots[pi], 0);
        const diff = totA - totB;
        if (diff > 0) {
          tA.forEach(pi => { gb[players[pi].name] += diff * dolPt; });
          tB.forEach(pi => { gb[players[pi].name] -= diff * dolPt; });
        } else if (diff < 0) {
          tB.forEach(pi => { gb[players[pi].name] += (-diff) * dolPt; });
          tA.forEach(pi => { gb[players[pi].name] -= (-diff) * dolPt; });
        }
      }

      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏅 Dots',
        colHeaders: ['Match', 'Total'],
        rows: dtPlayers.map((p, ii) => {
          const net = gb[p.name] || 0;
          return {
            name:      p.name,
            detail:    '',
            net,
            matchCols: [net, net],
          };
        }).sort((a, b) => b.net - a.net),
      });

    } else {
      // Individual mode — unchanged pairwise loop (§7.6.3)
      // 13-C.3: indivDots was already range-filtered at accumulation time.
      if (dolPt > 0) {
        for (let ii = 0; ii < dtIdxs.length; ii++) {
          for (let jj = ii + 1; jj < dtIdxs.length; jj++) {
            const ei = dtIdxs[ii], ej = dtIdxs[jj];
            if (!players[ei] || !players[ej]) continue;
            const diff = indivDots[ei] - indivDots[ej];
            if (diff > 0) {
              gb[players[ei].name] += diff * dolPt;
              gb[players[ej].name] -= diff * dolPt;
            } else if (diff < 0) {
              gb[players[ej].name] += (-diff) * dolPt;
              gb[players[ei].name] -= (-diff) * dolPt;
            }
          }
        }
      }

      Object.entries(gb).forEach(([n, v]) => (bank[n] += v));
      breakdown.push({
        game: '🏅 Dots',
        rows: dtPlayers.map((p, ii) => ({
          name:   p.name,
          detail: '',
          net:    gb[p.name] || 0,
        })).sort((a, b) => b.net - a.net),
      });
    }
  }

  // ── Zero-sum invariant check ───────────────────────────────────────────────
  // All games are zero-sum: money only moves between players, never created
  // or destroyed. This check fires in development to catch double-counting,
  // subset misapplication, or rounding bugs. See Payout Contract §6.
  if (process.env.NODE_ENV !== 'production') {
    const total = Object.values(bank).reduce((a, b) => a + b, 0);
    if (Math.abs(total) > 0.01) {
      console.error('[payouts] Zero-sum violation — total net:', total, bank);
    }
  }

  return { bank, breakdown };
}
