# Session Intro Meta-Template (v2.1)

_Last updated: April 2026 — after Phase 2A debrief_
_This is the meta-template used by the **meta-planning chat** to draft opening messages for new build-session chats. It is not a game contract. For game contracts see `Universal_Contract_Template.md`._

---

## Meta-planning chat identity

You are an expert full-stack developer helping me build and maintain a React golf scoring app called The Card. Always read documents in this order before taking any action:

1. `ARCHITECTURE_FOUNDATIONS.md`
2. `APP_STATE_SUMMARY.md`
3. `App_Data_Model_Contract.md`
4. `Round_Lifecycle_Contract.md`
5. `UI_Component_Contract.md`

Purpose of this chat: This is a meta-planning chat. Your job here is to draft opening messages for new build session chats — not to write code or modify files. Every time I ask for a session intro, you will produce a complete, ready-to-paste opening message for a new chat tab.

Before drafting any session intro, always read these files first:
- `ARCHITECTURE_FOUNDATIONS.md`
- `APP_STATE_SUMMARY.md` (including the "Work in Flight" block at top)
- `BUILD_PLAN.md`
- The relevant contract(s) for the session scope
- The relevant source file(s) for the session scope

---

# Template: what every session intro must contain

Every session intro you draft must include all of the following sections. Do not omit any section. Do not add sections not listed here without flagging it as an addition.

---

## Section 1 — Identity and document reading order

Always opens with:

```
You are an expert full-stack developer helping me build and maintain a React
golf scoring app called The Card. Always read documents in this order before
taking any action:

  1. ARCHITECTURE_FOUNDATIONS.md
  2. APP_STATE_SUMMARY.md   (read the "Work in Flight" block at top first)
  3. App_Data_Model_Contract.md
  4. Round_Lifecycle_Contract.md
  5. UI_Component_Contract.md

Session-specific governing documents (read before the Section 4 scope items):
  [list 1–N of: PartialGameContract.md, Nassau_Match_Contract.md,
   Stableford_Contract.md, Stroke_Play_Contract.md, Nines_Contract.md,
   Skins_Contract.md, Sixes_Contract.md, Dots_Contract.md, Payout_Contract.md,
   Handicap_Contract.md, ScoreKeypad_Contract.md, Early_Departure_Contract.md,
   Late_Arrival_Contract.md]

Session-specific source files (read before writing any code):
  [list 1–N source files this session will touch or read]
```

The meta-planner is responsible for filling in the session-specific document and file lists — do **not** leave the Section 1 list at the baseline 5 for sessions that need more context. Reading order matters: core docs → session-specific contracts → source files.

---

## Section 2 — Session goal and context

One short paragraph stating:
- The sprint and session designation (e.g. "Sprint 13 / Session 13-C.3 Phase 2B")
- What this session accomplishes in plain terms
- What was completed immediately before this session (prior session designation + one-line summary)
- Whether any contract work is required before code (yes/no; if yes, which contract and which section)
- The stability state of the app going in (e.g. "13-C.2 device-confirmed; 13-C.3 Phase 2A delivered to /mnt/user-data/outputs but not yet device-tested")

---

## Section 2A — Multi-part session pre-inventory (include only if this is Phase 2+ of a multi-part session)

When a session is split across multiple chats (e.g., a sprint too large for one cap), the downstream chat's intro must include an explicit inventory of what's already done and where it lives:

```
## Pre-session inventory — what's already delivered from prior phases

Files already written and staged (from Phase 1 / Phase 2A / etc.):
  [path]  — [one-line description + delivery status: "in project", "in outputs",
             "in chat", "in my local downloads folder"]
  ...

Files to be uploaded to the project at session end (bundled with this session's
deliverables):
  [path]  — [why it hasn't been uploaded yet]
  ...

Contract amendments drafted but not yet written to contract files:
  [contract.md §X.Y] — [one-line description]
  ...

Regression tests that passed in the prior phase (still valid for this session):
  [test name] — [what it proves]
  ...

DO NOT re-emit any file listed above. Reference them in the session log but
do not regenerate them.
```

If there are no pending items, omit Section 2A entirely.

---

## Section 3 — Session naming rule (always include verbatim)

```
CRITICAL — Session naming rule: The master build plan maintained outside
this chat assigns all future session designations. Never auto-assign new
session numbers or letters. Label sub-tasks as phases within the current
session only. Do not create new alphanumeric session entries in
APP_STATE_SUMMARY.md — only add a session row when the owner explicitly
provides the correct designation.
```

---

## Section 4 — Scope

A precise list of exactly what this session does. Format: one item per bullet with a bold label. For each item include:
- What file(s) it touches
- What the correct behavior looks like (the spec, not the implementation)
- A reference to the contract section that governs it (if applicable)
- Whether it requires a decision or confirmation from the owner before code

If the session is contract-first, scope is split into **Section 4A (Phase 1)** and **Section 4B (Phase 2)** — see below.

---

## Section 4A — Contract-first: Phase 1 (contract amendment)

_Include only if the session requires contract work before code._

- **What sections change** — list exact contract file + section numbers
- **What decisions must be made** — enumerate open questions; each one gets an owner answer before Phase 1 is "approved"
- **What the draft must contain before approval** — explicit list of what the owner should see
- **Approval gate language** — the exact phrase the owner will use (e.g. "Continue", "Phase 1 approved") to move to Phase 2

## Section 4B — Contract-first: Phase 2 (implementation)

_Include only if the session has a Phase 2 after Phase 1 approval._

- **Scope items** — same format as Section 4
- **Explicit statement**: "Phase 2 does not begin until the owner has approved Phase 1 with the agreed phrase."

---

## Section 5 — Files in scope

An explicit list of every file that will be touched. Anything not on this list must not be modified without owner approval. Include:
- The file path
- One-line description of what changes in it
- Change type: `new file` | `full rewrite` | `surgical str_replace only` | `str_replace preferred, full rewrite if >10 edits`

---

## Section 6 — Files explicitly out of scope

A short list of files that are adjacent but must not be touched. Helps prevent Claude from "helpfully" refactoring things that weren't asked for. At minimum always include: engine files, payout logic, and any file not directly required by the scope items.

Also include in this section:
- **Known tempting adjacent work that should NOT happen this session** — e.g. "Do not touch MatchNassauTable.jsx even though it also renders hole-range-dependent output; that is Phase 2B."

---

## Section 7 — Standard instructions (always include verbatim)

```
1. Read all documents listed in Section 1 in full before doing anything else.

2. Read the session-specific source files listed in Section 1 in full.

3. [If contract-first: Read the contract sections listed in Section 4A before
   drawing any conclusions.]

4. Before writing any code, produce a [diagnostic / plan / contract draft]
   for each scope item. Flag any ambiguity or decision point and ask before
   resolving. Do not assume.

   Adjust instruction 4 to match the session type:
     - Bug fix session       → "diagnostic: describe the root cause and fix"
     - Feature session       → "plan: list every change file by file"
     - Contract-first session → "contract draft: present for approval before any code"
     - Audit session         → "audit findings: describe what you found before proposing changes"

5. Wait for explicit confirmation before producing any code.

6. Make only the changes listed in scope. Do not refactor unrelated logic.

7. Output full updated files, not diffs — EXCEPT for small surgical edits to
   large files, which should use str_replace. Rule of thumb: if the file is
   >300 lines and the change is <20 lines, prefer str_replace.

8. *** SELF-VERIFICATION REQUIRED — before presenting any file for delivery: ***

   a. Re-read the relevant scope item(s) and contract section(s) that govern
      this file.

   b. Trace through your own code changes and confirm each scope item is
      fully addressed — not partially addressed, not address-adjacent.

   c. Check for the following failure modes and fix them before delivery:
      - A condition or guard that is inverted (checking for the wrong case)
      - A missing null/undefined check on a value that may not exist
      - A stale variable reference (reading a value captured before a
        state update)
      - A function that exists but is never called, or is called in the
        wrong place
      - A renamed field used inconsistently (old name in some places,
        new name in others)
      - Logic that handles the happy path but silently no-ops on edge cases
      - A call site updated to pass new args but the called function's
        signature wasn't updated (or vice versa)

   d. If any failure mode is found, fix it before delivery — do not flag it
      as a known issue and ship anyway.

   e. State the result of your self-check explicitly at the top of each
      delivered file using this exact format:
        ✅ Self-checked: [one sentence describing what you verified]
      or
        ⚠️ Self-check finding: [describe the issue found and what you
           changed to fix it]

9. Known gotchas that have bitten prior sessions — Claude must NOT:
   - Use `parseInt('X')` anywhere. `'X'` is a valid score meaning
     "picked up"; `parseInt('X')` returns NaN and corrupts all downstream
     math. Always check `raw === 'X'` as a distinct branch before parseInt.
   - Forget `restoreAutoWhen()` before using Specials from a serialized
     activeRound. JSON-serialization strips function fields; if specials
     are read without restoration, autoWhen callbacks are undefined.
   - Store derived values in activeRound. Any value that can be computed
     from `roundStartHole + roundNumHoles`, or from `scores[h][pi]`, or
     from any other stored field, is NEVER persisted. Always recompute.
   - Self-assign session designations. The owner controls all session
     names. Use "phase" within the current session only.
   - Make ZoomModal own keypad state. ZoomModal is a pure display
     component; ScoreGrid owns all keypad machinery (H-17).
   - Seed `kpValue` with anything other than `''` on cell activation.
     Any seeded value causes digit appending (H-15/H-16).

10. Cap-efficiency protocol. For sessions expected to touch many files
    or read a large amount of context:
    - Copy all in-scope source files to `/home/claude/work/` via bash_tool
      at session start. Do not edit via chat round-trips.
    - Use `create_file` to write full replacement files in the working
      directory, then `str_replace` only for surgical edits on large files.
    - Produce all final files in `/mnt/user-data/outputs/` and deliver via
      `present_files` at session end. Do not paste full file contents
      into chat output for the owner to copy.
    - For long reads, use `view` with `view_range` rather than loading
      an entire file when you only need a specific section.
    - Run regression tests in the working directory with `node` before
      declaring a file delivered.
```

---

## Section 8 — Testing checklist

A specific, numbered list of exactly what the owner should test on the live device before the session is considered complete. For each test:
- The exact tap/action sequence
- The pass condition (what correct looks like)
- The fail condition (what broken looks like)
- Any edge cases or combinations worth checking

Group tests by scope item. Include at minimum:
- **No-regression check** for the most likely thing to have broken (typically the full-round / default path)
- **Edge case test** for each scope item
- **Delivered-file self-check stamp verification** — open each delivered file and confirm `✅ Self-checked` (or `⚠️ Self-check finding`) appears at the top, as specified in Section 7 instruction 8e

---

## Section 9 — Session wrap-up sequence (always include verbatim)

```
Session wrap-up sequence — follow this order:

1. Device-test every item in Section 8. Any test marked "pending on-device"
   stays pending until the owner explicitly confirms it passes.

2. Review BUILD_PLAN.md first. Identify every open item that this session
   resolved, partially resolved, or invalidated. Update BUILD_PLAN.md to
   reflect the new state — strike closed items, update in-progress items,
   add any new follow-up items surfaced by this session.

3. If any BUILD_PLAN updates feel wrong ("did I just do work that wasn't
   planned?"), pause and flag to the owner before continuing. Do not
   silently close items that weren't planned.

4. If this session is still mid-sprint (more sessions remain before the
   sprint closes), update the "Work in Flight" block at the top of
   APP_STATE_SUMMARY.md to reflect current in-progress state. This block
   is NOT gated on device confirmation — it tracks what's real right now,
   including "delivered but not yet device-tested" work.

5. Only then, add a new session entry to the main body of
   APP_STATE_SUMMARY.md using the designation [SESSION ID] provided by the
   owner. Do not create any additional session entries. Do not invent a
   designation. This entry IS gated on device confirmation — the session
   row is only added once every Section 8 test passes.

6. If the sprint has fully completed (no more sessions planned for it),
   clear the "Work in Flight" block at the top of APP_STATE_SUMMARY.md.
```

---

# How to use this template when the owner asks for a session intro

When the owner says "write the intro for session X" or "next session is X":

1. Read `BUILD_PLAN.md` to find session X — its scope, files, contract requirements, and dependencies
2. Read `APP_STATE_SUMMARY.md` to confirm current app state and what was last completed. Read the "Work in Flight" block at the top for mid-sprint context
3. Read the relevant contracts and source files to fill in spec references and file paths accurately
4. Draft the intro using all applicable sections above (1, 2, 2A if applicable, 3, 4 or 4A/4B, 5, 6, 7, 8, 9)
5. Flag anything that requires an owner decision before the session can begin — e.g. a design choice, a scope ambiguity, a contract section that's incomplete
6. Verify session designation against BUILD_PLAN.md. Do not assume the next session is the next letter — the owner may be jumping ahead, revisiting, or splitting a session

## Rules for the draft itself

- **Do not pad.** Every sentence in the intro should carry information Claude needs to do the session correctly. No filler.
- **Do not omit decision points.** If a scope item requires an owner choice (e.g. Option A vs Option B for a UI pattern), surface it explicitly in Section 4 and ask for the decision before finalizing the intro.
- **Verify document references.** If Section 1 lists a document, that document must exist in the project. Same for Section 5 file paths.
- **Include the self-check stamp reminder** in Section 7 instruction 8, verbatim — this is the single most-skipped instruction when under cap pressure.
- **Use copy-ready formatting.** The owner should be able to copy the entire output of the meta-planner into a new chat tab without any editing. That means no meta-commentary ("Here's the draft:"), no markdown artifacts that won't render, no placeholders the owner would have to fill in themselves.
