# The Card — Master Build Plan

_Last updated: April 2026 — Sprint 13's 13-C.5 (Resolver UI Design — planning, no code) complete. Spec delivered as `Resolver_UI_Spec.md` v1.0; closes Known Gaps G-1 through G-4 in `PartialGameContract.md` §16. **Next session: 13-C.6 — Early Departure Proactive Entry** (build) — implements `DepartureResolverSheet`, `GameResolutionRow`, `BetPillRow` per spec §2 and the long-press X handler in `ScoreGrid.jsx`._
_Maintained in this chat as the authoritative sequence and history of all build sessions._
_The APP_STATE_SUMMARY.md in the project knowledge base is the authoritative record of_
_what is implemented. This file is the authoritative record of what was planned, why,_
_and in what order — including items that shifted, were skipped, reinstated, or renumbered._

---

## Critical Rules for All Future Sessions

1. **Contracts before code.** Any item marked "contract first" below must have a contract
   amendment approved before a single line of implementation code is written.

2. **Session naming is owner-assigned.** Claude must never auto-assign new session
   designations (e.g. creating "11-B" when it doesn't exist in this plan). Sub-tasks within
   a session are labeled as phases (Phase 1, Phase 2). New session rows in APP_STATE_SUMMARY.md
   are only added when the owner explicitly provides the designation.

3. **APP_STATE_SUMMARY.md is not a bug tracker.** Open items live there briefly while
   they wait for closure; once closed, they are removed (not struck through). The
   external spreadsheet is the master bug/feature tracker.

4. **Do not remove an item from ASS Open Items prematurely.** Removal requires
   owner-confirmed on-device closure of the underlying work.

5. **Derived values are never stored.** All derived state is computed from the activeRound blob.

6. **`restoreDotDefs()` is critical.** Must always be called before using dots from any
   serialized state. Was `restoreAutoWhen()` prior to Session 11-A rename.

7. **`betType` is a static config concept only.** It lives in the `GAME_CONFIGS` constant
   and must never be stored in `gameOpts`, `activeRound`, or any persisted state.
   Decision made in 11-G. Do not revisit without owner approval.

8. **Nassau terminology is retired from all user-facing surfaces.** The behavior is exposed
   as Front/Back/Overall segment bet fields. Decision made in 11-G. Do not reintroduce
   "Nassau" as a UI term without explicit owner approval.

---

## Key Architectural Decisions

These decisions should not be revisited without good reason:

1. **Contracts are authoritative over code.** When contract language and implementation
   conflict, contracts win. Code is updated to match.

2. **Write contracts before fixing engines.** The contract defines the spec the engine
   fix must conform to.

3. **Derived values are never stored.** All derived state computed from activeRound blob.

4. **Session naming is owner-assigned.** Claude never invents new session designations.

5. **Generic swipe component** extracted when adding swipe to Players/Courses (12-F),
   not before — avoid premature abstraction.

6. **Dots/Specials shim removal** only after owner confirms all saved rounds have been
   opened and re-exported. Do not rush this.

7. **Per-player tee selection (completed in 11-I.1).** If extended further, treat as
   high-risk and own a full session.

8. **Custom keypad replaces system keyboard (13-B).** `ScoreKeypad.jsx` is the sole
   score entry component throughout the app. The hidden-input / `.focus()` pattern used
   in ZoomModal is retired after 13-B. `'X'` is a valid score value (player picked up);
   it stores as `'X'`, displays as `"NX"` (N = ESC gross), and always loses to any real
   score. Confirmed decision: no system keyboard for score entry post-13-B.

9. **`'X'` score semantics (13-B).** X = player picked up. Gross value = `par + 2 +
   strokes` (full Net, never NOL). Already ESC-capped by definition. "X always loses to
   a real score; X ties X" is the universal invariant across all 7 games.

10. **Early departure via Results gateway (13-C).** There is no "End Round Early" button
    on the scorecard. Departure is declared either via long-press X on the keypad
    (proactive) or via the Results → transition gate (reactive). Contiguous trailing empty
    cells = early departure. Scattered gaps = missing scores (blocked, must enter).

11. **Late arrival: append-only exception to lineup reset (13-D).** Adding a new player
    appended to the end of the lineup, with existing players unchanged, preserves existing
    scores. All other lineup mutations still trigger a full reset (RLC §2.6).

12. **Name display convention:** always show first name (larger/darker) + last name
    (smaller/lighter) unconditionally. No collision detection. `resolveDisplayNames`
    removed from most consumers after this decision.

13. **`PlayerDropdown.jsx`** is the shared component for all player picker UI in New Round
    setup. Do not create parallel picker implementations.

14. **Nassau terminology retired (11-G).** The betting behavior formerly called "Nassau"
    is exposed as Front/Back/Overall segment bet fields. `betType` is a static UI
    dispatch concept in `GAME_CONFIGS` — never stored in round state.

15. **Wolf is the next planned game format.** `GAME_CONFIGS` design in 11-I preserves
    a clean extension point for Wolf's rotating-player and doubling mechanics. Owner has
    confirmed Wolf will not be added until rest of app is considered solid.

16. **NOL dot selector design (11-K).** Unified segmented pill control replaces Net/NOL
    toggle. All segments in a single bordered pill: Net (if mixed round) / NOL / NOL Skins
    / NOL Match A / etc. Games with identical participant sets merged into one button.
    ZoomModal inherits the selection. Center button from setup tab triggers handleStart.

17. **ScoreKeypad nav row removed (13-B).** The ←/✓/→ navigation row was removed from
    `ScoreKeypad` after device testing confirmed it consumed too much screen space. Cell
    advancement is handled entirely by auto-advance timing (700ms for `'1'`, immediate
    for all others). Backspace retreats on second tap on an empty cell. The removed props
    (`onConfirm`, `onNavigate`, `atFirst`, `atLast`) must not be re-added without owner
    approval and a contract amendment.

18. **Round length is stored as `roundStartHole` + `roundNumHoles` — `roundEndHole` is
    always derived (13-C.2).** The UI exposes Start hole + End hole (1-based), converted
    at the form boundary. The scores array is always 18 slots regardless of round length;
    `roundStartHole`/`roundNumHoles` control display and compute scope, not array shape.
    ScoreGrid renders full 9-column Front 9 / Back 9 sections; out-of-round score cells
    are gray and non-interactive. ESC is omitted for partial rounds (GHIN requires 9 or
    18 holes for official posting). `toSetupState` must restore every field that
    `NewRoundPage` reads from `initSrc` — omission causes silent data loss on round
    reload (see App_Data_Model_Contract §9 + invariant #16).

---

## Numbering History & Collision Notes

- **Sessions 1–9** were numbered sequentially as work progressed.
- **Sessions 11-B and 11-C** were auto-created by Claude mid-session during the Dots
  rework, colliding with planned future sessions. Corrected: all three phases collapsed
  into **11-A** in the ASS.
- **11-B** in this plan = Shared GameTable shell (deferred to post-Sprint 12).
- **11-C** in this plan = Match/Nassau team hole display (completed).
- **11-D** in this plan = Fixed-width player name fields + PlayerDropdown (completed,
  scope exceeded plan).
- **11-E** in this plan = Disabled Btn fix + NOL label audit (completed).
- **11-G** was a planning-only session (no code). Downstream sessions renamed
  11-H, 11-I, 11-J, 11-K for cleanliness.
- **11-I split into 11-I.1, 11-I.2, 11-I.3** during execution. 11-I.1 (Players card +
  contracts) shipped on device first; 11-I.2 (game config UI rebuild) followed; 11-I.3
  (semantic field rename: `scoring` → `grossNetNOL`, AND `tiebreak` → `scoring`) was
  added later as a separate atomic rename.
- **11-M.1** is post-11-M follow-on bug fixes (SixesTable `opts`, ReadOnlyScorecard
  handicap dots, etc.) — split from 11-M proper because the bugs surfaced during
  on-device testing of 11-M's main work. Kept as a sub-session for traceability.
- **Sprint 13 restructured (April 2026).** Original 13-A (iCloud export) and 13-C
  (partial round stub) replaced with a focused 4-session sprint: 13-A = planning,
  13-B = custom keypad, 13-C = early departure, 13-D = late arrival. iCloud export
  moved to 14-D. Sprint 13 is entirely dedicated to score entry and partial round
  lifecycle features.
- **13-B split into 13-B, 13-B.1, 13-B.2.** 13-B = main keypad + X score work;
  13-B.1 = ZoomModal stabilization + pre-13 bug fixes (Bugs A/B/C) caught during
  device testing; 13-B.2 = contract-only correction to ScoreKeypad_Contract.md
  §3.4–§3.8 to match the 13-B.1 final implementation.
- **13-C split into 13-C (planning + contract), 13-C.2, 13-C.3 (with sub-phases 1, 2A, 2B), then 13-C.4 onward.**
  The original sequence anticipated 13-C.2 through 13-C.7 as builds; the Phase 1 / Phase 2A / Phase 2B
  sub-numbering inside 13-C.3 emerged because the predetermined-game-ranges feature
  needed contract amendments (Phase 1) → engine + plumbing (Phase 2A) → game-table
  visual range trimming (Phase 2B) and the work spanned multiple chats. There is
  no 13-C.1 — that designation was unused. The 13-C planning session also superseded
  `Early_Departure_Contract.md` (v1.0 DRAFT) and `Late_Arrival_Contract.md` (v1.0 DRAFT)
  in their entirety; both are unified under `PartialGameContract.md`.
- **14-E** is a one-off slotted into Sprint 14 ahead of its planned timing because
  the import conflict / id-less record bugs were blocking real-world use. The rest
  of Sprint 14 (14-A through 14-D) remains in its planned order.

---

## Completed Sessions

| Session | Scope | Original Items | Notes |
|---|---|---|---|
| 1-A | Round lifecycle bugs + safety guards: cancel/delete in-progress round; New Round full reset; score-overwrite warning; history-load conflict check; "Round in Progress" banner; date defaults to today | | Confirmed on device |
| 1-B | History data integrity: static snapshot audit (B-1); loading old rounds restores game data (B-4); edit historical round settings (B-2) | B-1, B-2, B-4 | Confirmed on device |
| 1-C | Score cell shift fix (C-1, `display:block`); Specials popup iOS copy/paste callout fix (C-2, `userSelect:none`) | C-1, C-2 | Confirmed on device |
| 2 | History UX: swipe-left strip; full-swipe delete; RoundSummaryModal; landscape scorecard 18-hole; per-match payouts; Stroke Index gender-aware labeling | | Confirmed on device |
| 3 | ResultsPage redesign (B-5 partial); per-match payout breakdown (B-3); named nine labels on scorecard (C-10); HomePage recent round tap opens modal; player chips in header | B-3, C-10 | Confirmed on device. B-5 results page refinement still desired — open in future session |
| 4 | Back-to-setup fix (B-3 follow-up); share sheet PNG via iOS native share (B-7) | B-7 | Confirmed on device. B-7 subsequently superseded by portrait PDF in 11-M |
| 5 | Visual polish: logo + branding (J-1); mint bg; SVG icons replacing emojis (F-3); swipe strip redesign; headers; player chips moved | F-3, J-1 | Confirmed on device |
| 6 | Navigation overhaul: always-visible nav (F-1); logo super-tab; pinned action bars; scroll-to-top (C-3); divider removed between scorecard and chips (C-6); expand triangles removed (A-11 partial) | F-1, C-3, C-6, A-11 | Confirmed on device |
| 7 | Shared layout constants (`layout.js`); NewRoundPage extractions: `PlayerPickerPopup.jsx`, `MatchCard.jsx`, `GameConfig.jsx`; NewRoundPage 1,360→592 lines | | Confirmed on device |
| 8 | CoursesPage full extraction: 5 components + helpers to courseLib.js | | Confirmed on device |
| 9 | PWA: manifest.json, sw.js, PNG logos, home screen install (I-1) | I-1 | Confirmed on device |
| 10-A | RoundSummaryModal totals row; ESC (Adjusted Gross Score) in TotalsCard; `escTotal()` added to handicap.js; Results F9/B9/Overall zeros bug fixed; auto-export on save (A-8) added; Handicap_Contract.md → v1.5 | A-8 | Confirmed on device. A-8 exact session uncertain — 10-A or 10-B |
| 10-B | Visual regressions: logo heights + header consistency; landscape full-width fix; MatchNassauTable isLandscape; Courses triangles removed (A-11 final); share image complete rework (B-6) | A-11, B-6 | Confirmed on device |
| 11-A | Dots (Specials) full rework: contract v2.0→v2.1; full Specials→Dots rename at all layers; DotsTable, DotsPopup, DotBadge; discrete scoring specials; mutual exclusivity; popup redesign; pivot summary tile; retroactive autoMark; App_Data_Model_Contract v2.5 | E-1 | Confirmed on device — pending bulk round migration before shim removal |
| 11-C | D-1: Match/Nassau team hole winner display: slash-initials (C/D), colorblind-safe blue/red chips; color-coded header; Front 9 closure bug fixed; Match status columns (D-3) — "Status" column with segment results; Nassau_Match_Contract v2.4 | D-1, D-3 | Confirmed on device |
| 11-D | resolveDisplayNames rollout; PlayerDropdown.jsx new file (PlayerDropdown, StyledSel, ReadOnlyBubble); MatchCard and GameConfig/Sixes migrated to custom pickers; fixed-width chips + first-name display (C-4/C-5); Sixes dropdown widths (D-5) | C-4, C-5, D-5 | Confirmed on device. Scope significantly exceeded plan |
| 11-E | Disabled Btn style fix (F-2); NOL label audit — confirmed already consistent (F-4); name display convention unified; Sixes duplicate-team prevention | F-2, F-4 | Confirmed on device |
| 11-F | Zoom score entry modal: ZoomModal.jsx (new), hidden-input keyboard pattern, 3-hole window, stacked player names, active-cell-only border, magnifying glass button, landscape zoom | C-9 | Confirmed on device |
| 11-G | Planning session: NOL dot display design decision; betting model architecture (Nassau retired → segment betting); betType as static config; GAME_CONFIGS pattern; Wolf extension point | | No code produced |
| 11-H | Design-only session: full NewRoundPage setup UI design spec. Output: `NewRoundPage_Design_Spec.md` | | No code produced |
| 11-I.1 | 6 contracts amended (App_Data_Model v2.7, Nassau_Match v2.5, Stableford v1.3, Nines v1.3, Skins v1.5, Stroke_Play v1.4); engine read-site changes; Players card rebuilt; per-player tee selection (A-7, A-13); "Default Tee" buttons removed (A-12); course picker popup built; nine-selection shown only for 3-nine courses; shared BetRow/SimpleBetRow/ScoringDropdown/PlayerSubsetDropdown components built. **Follow-on (same session number, later work):** NinesTable subset filtering — table and payouts show only 3-player subset (D-6, D-7). | A-7, A-12, D-6, D-7 | Confirmed on device |
| 11-I.2 | Game config UI rebuild: all game tiles (Match, Skins, Stableford, Nines, Stroke Play, Sixes, Dots); GameTile morph tile; BetSection; TeamPickerPair; MatchCard rebuilt; Stableford Teams disabled (Option Z); `cumulative` tiebreak branch added in games.js; App_Data_Model v2.8, Sixes v1.8, Nassau_Match v2.6 | D-4 | Confirmed on device |
| 11-I.3 | Semantic field rename: `scoring`→`grossNetNOL`, `tiebreak`→`scoring`; 10 contracts amended; 19 files updated; migration shims added; 3 pre-existing bugs fixed | | Confirmed on device |
| 11-J | Per-match instance labeling; `teamMode` → `'Match:{matchId}'`; migration shim; Dots dropdown enumerates per-instance options; Nassau terminology fully purged from all surfaces; App_Data_Model v3.0, Nassau_Match v2.8 | D-8 | Confirmed on device |
| 11-K | NOL dot selector: unified segmented pill; `computeNolDotOptions`; ZoomModal inheritance; center nav button → `handleStart`; `manualPresses` preservation fix; Handicap_Contract v1.6, Round_Lifecycle_Contract v1.6 | C-11 | Confirmed on device |
| 11-L | Stableford Teams engine support. Phase 1: `Stableford_Contract.md` → v1.5; `App_Data_Model_Contract.md` → v3.1. Phase 2: `handicap.js`, `games.js`, `payouts.js`, `NewRoundPage.jsx`, `GameConfig.jsx`, `StablefordTable.jsx`, `GameSection.jsx`, `ScoreGrid.jsx`, `NinesTable.jsx`, `StrokePlayTable.jsx`, `MatchNassauTable.jsx`, `ResultsPage.jsx`, `App.jsx` | | Confirmed on device |
| 11-M | Team Dots payout fix; DotsTable team layout; portrait/landscape share orientation picker; portrait share as PDF; `deriveShareDotMode`; Dots_Contract v2.3, UI_Component_Contract v1.3, Round_Lifecycle_Contract v1.7 | B-7 superseded | Confirmed on device |
| 11-M.1 | Follow-on bug fixes after 11-M: SixesTable `opts` prop; ReadOnlyScorecard handicap dots; share image dots; Sixes pivot `pivotSegTot`; RLC → v1.8 | | Confirmed on device |
| 11-N | Round totals regression restore: TotalsCard import added to RoundSummaryModal; totalsHtml block added to buildShareHtml | | Confirmed on device |
| 11-O | Audit session: all 7 game tables in RoundSummaryModal and share image confirmed correctly wired; C-10 nine labels confirmed; B-8 lock/unlock in HistoryPage | B-8 | Confirmed on device |
| 13-A | Planning session: custom keypad design, X score type definition, early departure model, late arrival model. Output: `ScoreKeypad_Contract.md` (v1.0 DRAFT), `Early_Departure_Contract.md` (v1.0 DRAFT), `Late_Arrival_Contract.md` (v1.0 DRAFT), `Session_Planning_Keypad_Departure_Arrival.md` | | No code produced |
| 13-B | Custom keypad + X score type. `ScoreKeypad.jsx` (new) — fixed-bottom 4-row overlay (1–9, ⌫/0/X); replaces iOS system keyboard everywhere. `'X'` score type: stores as `'X'`, displays as NX (amber), ESC-capped by definition, always loses to real score, ties another X. ZoomModal rebuilt as pure display component — no hidden input, no keyboard focus logic; keypad floats above it at zIndex 300. `ScoreGrid` owns all keypad state. `NinesTable` and `MatchNassauTable` fixed to handle X in display-layer scoring. Discard bug fixed (isDiscardingRef). `ScoreKeypad_Contract.md` → v2.1 AUTHORITATIVE. All 7 game contracts, `App_Data_Model_Contract.md`, `Round_Lifecycle_Contract.md`, `Handicap_Contract.md`, `Payout_Contract.md` amended with X score behavior. | D-B0 | Confirmed on device |
| 13-B.1 | ZoomModal stabilization + pre-13 bug fixes + touch isolation hardening. **ZoomModal final architecture:** pure display component; `onCellTap` prop → `openKeypadOnCell`; `activeKpCell` prop drives border; `cardRef` exempts card from dismiss handler. **ScoreGrid:** `openZoom` no longer calls `.focus()` (was causing iOS keyboard); `kpVisible` no longer suppressed when ZoomModal open; `zoomCardRef` added to dismiss exemption; `closeZoom` clears keypad state; `useEffect` on `[zoomOpen]` defers first cell activation; `kpAdvanceCell`/`kpRetreatCell` call `setZoomHole` on hole-crossing; `longPressFired` guard on `onCellTap` wrapper; `savedKpCellRef` + `activeKpCellRef` pattern saves/restores keypad across DotsPopup. **DotsPopup:** `touchStartedOnBackdrop` ref prevents auto-close from long-press lift; full touch isolation on backdrop and card. **ZoomModal:** backdrop touch isolation (`stopPropagation`; `e.target === e.currentTarget` close guard); card touch isolation. **Bug A:** `handleBackToSetup` `if (ar)` guard; `playerCHOverrides` restored from snapshots. **Bug B:** Sixes `autoPress !== 'none'` fix in `SixesTable` + `payouts.js`. **Bug C:** Match `legacyN` fix in `MatchNassauTable` + `games.js`. **Other:** tee blank-on-new-course; ZoomModal dot badges column-aware sizing. **Follow-on fixes (same session):** X handling in `SixesTable.holeWinFn`, `NinesTable.allData`, `StablefordTable.scoreHole`; `ScoreGrid.renderCell` cell height formula. Contract amendments: Sixes, Nines, Stableford X Score Behavior sections. Files: `ZoomModal.jsx`, `ScoreGrid.jsx`, `DotsPopup.jsx`, `App.jsx`, `NewRoundPage.jsx`, `SixesTable.jsx`, `NinesTable.jsx`, `StablefordTable.jsx`, `payouts.js`, `games.js`, `MatchNassauTable.jsx`. | | Confirmed on device |
| 13-B.2 | ScoreKeypad_Contract.md §3.4–§3.8 amendment. **No code changes.** §3.4 rewritten: `zoomOpen` removed from ZoomModal prop list; `longPressFired` guard documented; `cardRef`/`zoomCardRef` relationship clarified. §3.5: INPUT exception noted as dead code. §3.6 rewritten: `openZoomOnHole(h)` documented as never implemented; `openZoom` uses `firstEmptyHole()`; cell activation is a separate `useEffect`. §3.8 (new): `savedKpCellRef`, `activeKpCellRef`, `longPressFired` ref patterns documented. `ScoreKeypad_Contract.md` → v2.2 AUTHORITATIVE. | | Contract only — no device test needed |
| 13-C | Partial Rounds — Planning + Contract. No code produced. Full per-game departure/range walkthrough completed across all 7 games. `Early_Departure_Contract.md` (v1.0 DRAFT) and `Late_Arrival_Contract.md` (v1.0 DRAFT) superseded in their entirety. `PartialGameContract.md` → v1.3 AUTHORITATIVE. Three concepts unified under one contract: predetermined ranges, mid-round game start, early departure. Engine firewall confirmed: `games.js` and `handicap.js` never touched; all range/departure logic in `payouts.js` pre-processing layer only. Key decisions confirmed: press independence; `exclude_player` availability rules (3+ players must remain; not valid for Match/Nines/Sixes/Stableford team); Sixes segment length = `rangeLength / 3`; dormie+1 clinch rule; `–` display for unplayed holes (distinct from `X` and blank); `games.js` firewall invariant. | D-C1, D-C2, D-C3 | Planning + contract only — no device test needed |
| 13-C.2 | Round length foundation: Start + End hole pickers in Course card; `roundStartHole`/`roundNumHoles` added to `activeRound` blob, history record, and `toSetupState`; `roundEndHole` always derived; ScoreGrid full 9-column Front/Back layout with gray out-of-round score cells; TotalsCard scoped to in-round holes, ESC hidden on partial rounds; Results → always tappable (save-time gate only); `manual_presses` pre-existing `toSetupState` omission fixed; iOS input baseline-shift fixed with flex-centered wrapper (H-24 pattern); `PartialGameContract.md` → v1.5 AUTHORITATIVE; `App_Data_Model_Contract.md` → v3.2; `Round_Lifecycle_Contract.md` → v1.9. Files: `NewRoundPage.jsx`, `ScoreGrid.jsx`, `ScorecardPage.jsx`, `ZoomModal.jsx`, `TotalsCard.jsx`, `ResultsPage.jsx`, `App.jsx`, `roundUtils.js`, `roundLib.js`, `payouts.js`. | | Confirmed on device |
| 13-C.3 (Phase 1 + Phase 2A) | **Predetermined Game Ranges + Per-Match Ranges + F/B/T Column Display.** Phase 1 — partial-game contract amendments: `PartialGameContract.md` (§3.6 universal F/B/T midpoint rule covering Match, Stroke Play, Stableford ind+team, Nines; §14 invariant #13 relaxed to permit surgical `range` param on `runMatchNassau` + `calcTeamStablefordTotal`; §14 invariant #15 split into #15(a) live ScoreGrid gray cells + #15(b) read-only `–` rendering; §15 D-10 uneven Sixes deferred), `Nassau_Match_Contract.md` (§1.3 partial-range note), `Stableford_Contract.md` (§3.7), `Stroke_Play_Contract.md` (§3.7), `Nines_Contract.md` (§3.7). **Phase 2A — engine, payouts, plumbing.** `games.js`: `runMatchNassau` + `calcTeamStablefordTotal` accept optional `range` param, derive F/B/T via §3.6 midpoint internally; default = byte-identical to pre-13-C.3. `payouts.js`: `splitRangeByMidpoint` / `rangeFor` / `trimScoresToRange` helpers; per-game range resolution for Stroke Play, Skins, Match/Nassau, Stableford (ind+team), Nines, Sixes (segLen dynamic), Dots (team-mode locks to source). `roundUtils.js`: `computePerMatchPayouts` accepts gameRanges + per-match range threading. `ScoreGrid.jsx`/`ScorecardPage.jsx`/`RoundSummaryModal.jsx`: per-game range plumbing to all 7 game tables. `RoundSummaryModal.jsx`: ReadOnlyScorecard renders `–` for out-of-range holes; landscape `xAware` totals respect range. **Phase 2A finalization (this session):** F/B/T payout column display extended to all Nassau-structure games. `payouts.js` Stroke Play `payWinnerStroke` tie split-pot fix (closes Stroke Play §14 G-4 segments-mode variant); per-segment delta-map pattern emits `colHeaders: ['Front', 'Back', 'Total', 'Game Total']` and per-row `matchCols: [f, b, o, f+b+o]` for Stroke Play (segments), Stableford (segments — both ind+team), Nines (Nassau). `roundUtils.js`: `computePerMatchPayouts` emits same columnar shape per match. `ResultsPage.jsx`: match rendering detects `match.colHeaders` and routes through existing `DotsColTable`; legacy fallback preserved for older history records. Additional contracts amended in finalization: `Stroke_Play_Contract.md` (§1.3, §4.1, §4.3, §5.4, §5.8, §5.9 (new), §13 invariant 19, §14 G-4 closed), `Payout_Contract.md` (§3.2 universal flat/columnar shape spec, §7.1, §7.3, §7.4, §7.5), `Stableford_Contract.md` (§5.3, §5.7 — colHeaders emission), `Nines_Contract.md` (§5.4 — colHeaders emission), `Dots_Contract.md` (§7.5 — colHeaders/matchCols generalization note). **Audit pass (end of session):** Cross-cutting spec drift caught and fixed in 4 additional contracts: `App_Data_Model_Contract.md` v3.2→v3.3 (§5.1 `gameRanges` field schema, §10 `buildPayoutArgs` shape), `Round_Lifecycle_Contract.md` v1.9→v2.0 (§7 required field, §12 invariant 22 round-trip preservation), `Sixes_Contract.md` v1.9→v1.10 (§3.6 clarification, §3.7 new partial-range section), `Skins_Contract.md` v1.6→v1.7 (§3.1 new partial-range section). All 11 amended contracts had their version + changelog entries updated. Files: `games.js`, `payouts.js`, `roundUtils.js`, `ScoreGrid.jsx`, `ScorecardPage.jsx`, `RoundSummaryModal.jsx`, `ResultsPage.jsx`. | D-9, D-10 (deferred) | Confirmed on device — full-round byte-identity + partial-round + per-match range + F/B/T column display + Stroke Play tie split-pot all verified |
| 13-C.3 Phase 2B | Game table visual range trimming + ScoreGrid landscape width + X-score totals fix. Full rewrites of `MatchNassauTable.jsx`, `SixesTable.jsx`, `DotsTable.jsx` — each now range-aware via `startHole`/`endHole` (Sixes/Dots) or `gameRanges`/`roundStartHole`/`roundEndHole` (Match, per-match resolution). `splitByMidpoint` derives F/B/T per match; `deriveSegs` derives 3-segment Sixes layout. `runMatchNassau` receives effective range arg (bug fix: without it, engine F/B used hardcoded FRONT/BACK causing Back tile `—` on 9-hole rounds). Segment chip labels "Front"/"Back"/"Total"; internal `'Overall'` press keys unchanged. Single-half landscape when range entirely in one canonical half. ScoreGrid: `maxWidth` constraint extended from TotalsCard-only to entire paddingTop wrapper (game tables now match compact scoregrid width in landscape). ScoreGrid: `grossTotal`/`netTotal` fixed to use `xGrossScore` for `'X'` scores (pre-existing bug — `parseInt('X')` = NaN silently dropped X holes from half-totals). Files: `MatchNassauTable.jsx`, `SixesTable.jsx`, `DotsTable.jsx`, `ScoreGrid.jsx`. | | Confirmed on device |
| 13-C.5 | **Resolver UI Design — planning, no code.** Single new spec document `Resolver_UI_Spec.md` v1.0 (§§1–8) closing all four Known Gaps in `PartialGameContract.md` §16: G-1 (`payouts.js` pre-processing API — primitives `trimScoresToRange` / `trimScoresToHole` / `excludePlayerSubset`, dispatcher, segment status evaluator, post-engine abandon-zeroing, full order of operations), G-2 (`DepartureResolverSheet`, `GameResolutionRow`, `BetPillRow` component prop interfaces with three resolved UX decisions: sheet owns draft state, not-started presses omitted entirely, team Match departure ends the match), G-3 (clinch detection algorithm — three internal states `closed`/`in_progress`/`not_started`, numeric boundary conditions `\|lead\| > holesRemaining`, four worked examples, alignment claim with Nassau §3.2 dormie+1 rule), G-4 (per-game minimum-hole validation: Nines 6 / Sixes 9 with divisibility / other 3, GameConfig-only validator, no engine code change, auto-clear on round-length change). Engine firewall preserved — no new engine arguments proposed beyond invariant #13.b's two existing exceptions. Surgical contract amendment: `PartialGameContract.md` v1.6 → v1.7 (§6.3 / §10.1 / §10.2 / §11.8 corrected — not-started presses are omitted from the resolver sheet entirely, not rendered as auto-Abandoned rows; §16 G-1 through G-4 marked closed with cross-references). Files: `Resolver_UI_Spec.md` (new), `PartialGameContract.md` (surgical edits). | G-1, G-2, G-3, G-4 closed | N/A — planning session, review-only gate |
| 14-E | Import conflict UX overhaul + id-less record fix. Root cause: AI-generated JSON files produce ID collisions (different courses sharing same ID), and `mergeById` silently dropped records with no `id` field. Fixes: (1) `makeId` assigned to id-less courses/players at import time; (2) `diffCourses` now diffs the name field — name mismatch on an ID collision is the primary signal; (3) `likelySameCourse` tightened: stop-words filtered, substring match requires ≥12 chars, word-overlap threshold raised to 80%; (4) `ImportConflictModal` rebuilt with side-by-side `CourseSummaryCard` showing both records, red header for ID conflicts with name mismatch, three actions: Keep Library / Use File / Keep Both; (5) Keep Both prompts for a new name and saves the incoming course as a fresh record with a new ID; (6) `sameId` flag passed from conflict detection through to modal. No contract changes required. | | Confirmed on device |

---

## Open Session Plan

> **Next session: 13-C.6 — Early Departure Proactive Entry** (build). 13-C.5 (Resolver UI Design — planning) complete; spec delivered as `Resolver_UI_Spec.md` v1.0 closing G-1 through G-4. 13-C.4 (Mid-Round Game Start) was deferred — see Deferred / Deprioritized table for full context. Sprint 11 remaining items are
> deferred or low-urgency; Sprint 12 items are medium priority; the active sprint
> is 13. Skip to "Sprint 13 — Score Entry, Partial Rounds, Lifecycle" below.

Sessions are listed in recommended execution order. Items marked "contract first"
require a contract amendment to be written and approved before any code is produced.

---

### Sprint 11 — Remaining

**11-B: Shared GameTable shell** *(DEFERRED to post-Sprint 12)*
- Move GameTable/PlayerChips documentation into UI_Component_Contract.md
- Audit SkinsTable, SixesTable, MatchNassauTable, StrokePlayTable for further shared chrome
- Low urgency — patterns already working; documentation + optional refactor pass
- Files: `GameSection.jsx`, `UI_Component_Contract.md`

---

### Sprint 12 — Medium Priority Features

**12-B: Game table display consistency pass**
- Audit all game tile chip/total labels across all games (e.g. "pts", "$") — decide once whether labels appear, apply uniformly
- Audit player name chip display consistency across all game tables
- D-2: "pts" label on Nines total chips (original item, now part of broader audit)
- Files: `NinesTable.jsx`, `SkinsTable.jsx`, `StablefordTable.jsx`, `SixesTable.jsx`, `MatchNassauTable.jsx`, `StrokePlayTable.jsx`, `DotsTable.jsx`, `ScoreGrid.jsx`
- Priority: Medium

**12-C: Setup UX polish**
- A-5: Save game settings from prior round as defaults for next round
- Files: `NewRoundPage.jsx`, `roundLib.js`
- Priority: Medium
- Note: Course picker popup ✅ done in 11-I.1; nine-selection guard ✅ done in 11-I.1; Default Tee buttons ✅ removed in 11-I.1. Only A-5 remains.

**12-E: Players and leaderboard enhancements**
- G-1: Starred/favorite players float to top
- G-2: Include/exclude from leaderboard — filter one-off players off money list
- Files: `PlayersPage.jsx`, `HomePage.jsx`
- Priority: Medium

**12-F: Players/Courses swipe-left actions**
- Swipe-left Edit/Delete strip matching HistoryPage pattern
- Extract generic swipe component at the same time (avoid third copy of HistoryPage logic)
- Import PALE_YELLOW from ui.jsx for Edit button background (already specified in ASS gotcha)
- Files: `PlayersPage.jsx`, `CoursesPage.jsx` + new generic swipe component
- Priority: Medium

**Results page refinement** *(session to be named by owner)*
- B-5: General results page layout and presentation refinement pass
- Priority: Medium

---

### Sprint 13 — Score Entry, Partial Rounds, Lifecycle

Remaining sessions execute in order per `PartialGameContract.md` §1.3.

**13-C.5: Resolver UI Design** *(planning — no code)* — ✅ **COMPLETE** April 2026. Spec delivered as `Resolver_UI_Spec.md` v1.0; closes Known Gaps G-1, G-2, G-3, G-4 in `PartialGameContract.md` §16. See Completed Sessions table for full scope summary.

**13-C.5 — original scope (now closed, retained for traceability):**
- Specify `DepartureResolverSheet`, `BetPillRow`, `GameResolutionRow` component props
- Clinch detection algorithm for Match/Sixes (close G-3)
- `payouts.js` pre-processing API for segment/press evaluation (close G-1)
- Close all remaining Known Gaps G-1 through G-4
- Output: approved spec before 13-C.6 build begins

**13-C.6: Early Departure — Proactive Entry** *(build)*
- Long-press X flow: save X → confirmation → full resolver
- `DepartureResolverSheet` built per 13-C.5 spec
- `earlyDepartureOpts` written to `activeRound` on confirm
- Locked `–` cells for departed player in `ScoreGrid`; undo tap handler
- Name chip dimming in scorecard header
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`, `DepartureResolverSheet.jsx` (new),
  `roundLib.js`, `roundUtils.js`

**13-C.7: Early Departure — Reactive Entry** *(build)*
- Results → classification relative to `roundEndHole`; block for Missing scores;
  show resolver for Early departure (Scenario A and B)
- Write `lastCompletedHole`, `earlyEndOpts`, `earlyDepartureOpts` on confirm
- Files: `App.jsx`, `DepartureResolverSheet.jsx`

**13-C.8: Engine Departure Handling** *(build)*
- `payouts.js`: `end_at_k`, `continue`, `exclude_player` resolutions
- Per-segment and per-press Pay/Abandon applied to engine output
- `RoundSummaryModal` shows `–` for departed/stopped holes
- Files: `payouts.js`, `RoundSummaryModal.jsx`

---

### Sprint 14 — Low Priority Polish

**14-A: Cleanup** *(sequence after all major feature work complete)*
- F-5: Remove legacy shims (confirm all saved rounds migrated before removing)
- F-6: Hint text review and cleanup
- I-5: Delete hooks.js (confirmed dead code)
- H-1: Sahalee hole numbering 1–9 per nine + yardage total fix
- History date range persistence across sessions
- Files: misc
- Priority: Low — do last

**14-B: Advanced scorecard options** *(contract first)*
- C-7: Birdie/bogey indicators (amend UI_Component_Contract.md)
- C-8: Lock/pin scorecard toggle
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`

**14-C: Security and misc** *(contract first for A-9)*
- I-3: API key / Face ID security gate
- A-9: Handicap multiplier (amend Handicap_Contract.md)
- In-app splash screen on cold load (~1.5s, logo on green)
- Replace PNG logos with SVG when designer provides file
- Files: `CoursesPage.jsx`, `storage.js`, `App.jsx`

**14-D: iCloud Export Naming**
- I-2: Confirm save-to-Files flow on iOS Safari behaves correctly with current
  naming convention (`The Card YYYY-MM-DD HH-MM.json`)
- Files: `App.jsx`
- Priority: Medium
- Risk: Low — verification only; may require minor filename fix

---

### Future — New Game Formats

Each format requires its own contract session before any code.
Recommended order:

1. **Wolf** — rotating Wolf player; highest priority next format. `GAME_CONFIGS` in 11-I preserves extension point for Wolf's doubling mechanic. Owner confirmed Wolf not until rest of app is solid.
2. **High/Low** — low ball + high ball per hole
3. **Banker (Quota)**, **Scotch/Greensomes**, **Chapman/Pinehurst**
4. **Bingo Bango Bongo**, **Vegas**, **Round Robin**, **Snake**, **Rabbit/Flags/String**
5. **Uneven team matches (1v2)**

---

## Items Requiring Contract Work Before Code

Active contract-work needs only. Completed contract work is captured in the
Completed Sessions table above and in the Decision Log below.

| Item | Contract | Status | Session |
|---|---|---|---|
| 14-B: Birdie/bogey indicators | Amend `UI_Component_Contract.md` | Not started | 14-B |
| 14-C: Handicap multiplier | Amend `Handicap_Contract.md` | Not started | 14-C |
| Future: Wolf | New `Wolf_Contract.md` | Not started | Future |
| Future: Other formats | New contract per format | Not started | Future |

---

## Decision Log

### Pending decisions

The following decisions must be confirmed by the owner before the named session
begins (or revisited at the start of it). Once confirmed, decisions move to the
Confirmed Decisions table below and may also be promoted to the Key Architectural
Decisions section if they have lasting cross-cutting impact.

| ID | Session | Question | Recommendation | Notes |
|---|---|---|---|---|
| ~~D-D1~~ | ~~13-C.4~~ | ~~NOL retroactivity when late-joining player has lower courseHcp~~ | ~~Retroactive (Option A)~~ | **Withdrawn** — parent session 13-C.4 deferred. If late-arrival engine work is reinstated, this question must be re-confirmed at that time. Recommendation (retroactive Option A, required by Handicap §5 invariant) is preserved in Deferred entry below for future reference. |

### Confirmed decisions

Recorded for traceability. Items with cross-cutting architectural impact are also
captured in the Key Architectural Decisions section above.

| ID | Session | Question | Decision |
|---|---|---|---|
| D-4 | 13-D | "Starts on hole" picker visibility | In-progress only |
| D-5 | 13-D | Nines rotation at non-zero start | Fresh start |
| D-B0 | 13-B | Keypad layout | 4 rows, 56px height, nav row removed |
| D-C1 | 13-C | Nines `'exclude_player'`: pay through departure hole? | Yes — `end_at_k` through departure hole; no Nines for remaining holes |
| D-C2 | 13-C | Nassau partial segment with `'payout'`: leader wins partial? | Yes — partial segment pays to leader (Option A); user may override via pill |
| D-C3 | 13-C | Departed player chip visual treatment in scorecard header | Dimmed chip — gray tint / reduced opacity |
| D-9 | 13-C.2 | Wrap-around rounds (e.g. start hole 15 → hole 5) | Deferred — see Deferred / Deprioritized table |
| D-10 | 13-C.3 | Uneven Sixes segments | Deferred — PartialGameContract §15 D-10 |

---

## Deferred / Deprioritized

| Item | Reason deferred |
|---|---|
| 11-B: Shared GameTable shell | Pattern already working; documentation value only; post-Sprint 12 |
| Dark mode | Token structure ready in ui.jsx; low demand |
| Undo delete toast | Low impact |
| Match scorecard rows collapse by default | Low priority |
| CoursesPage GHIN/USGA API import | External dependency; low priority |
| ResultsPage share as graphic email | Done as share sheet PDF; email redesign deprioritized |
| Portrait PDF revert → PNG | If jsPDF causes issues or PDF UX not preferred, revert portrait to PNG. Full revert instructions in ASS. ~5 min to implement. |
| Scorecard options menu (gear icon) | Deferred pending dot display mode design decision |
| Press modal UX: show live match status | Low priority UX enhancement |
| MatchNassauTable column headers for non-zero-start matches | Polish — deferred to post-13-D |
| "Computed over holes 1–k" notes in game table footers | Polish — deferred to post-13-D |
| Game range indicator in game table headers | Polish — deferred to post-13-D |
| **ScoreGrid legacy keyboard dead code cleanup** | `advanceRef`, `handleKeyDown`, `handleScore`, `scheduleAdvance`, `cancelAdvance`, `pendingAdvance`, `refs.current[...]` lookups — all dead code since 13-B removed hidden-input pattern. `refs.current[key]` is never populated; every advance path is a silent no-op. ~60 lines. Safe to remove in a dedicated cleanup pass after 13-C series stabilizes. Intentionally untouched in 13-C.2 per scope discipline. |
| **Dots auto-mark loops iterate 0..17 instead of round bounds** | Two `useEffect` hooks in `ScoreGrid` at the autoMark call sites iterate `for (let h = 0; h < 18; h++)`. Functionally correct for partial rounds (out-of-round holes are empty → no-op) but architecturally inconsistent with the round-bounds pattern established in 13-C.2. Small cleanup — update loop bounds when legacy dead code is removed. |
| **Round Length inputs use iOS system keyboard** | Start Hole and End Hole pickers in `NewRoundPage` open the iOS system keyboard. Inconsistent with `ScoreKeypad` used for all score entry. Future option: replace with a numeric stepper component (tap +/−) — eliminates keyboard entirely, appropriate for the tiny 1–18 range. Would also resolve residual iOS input rendering edge cases. Candidate for a polish session after 13-C series. |
| **Wrap-around rounds** | Starting on hole 15 and playing through to hole 5. Considered and explicitly deferred during 13-C.2. Owner determined the use case is rare enough to not justify cross-layer complexity: new "round sequence" concept in PartialGameContract §1A, sequence-based cell navigation, `payouts.js` pre-processing for wrapped score arrays, Sixes/Nassau segment boundary handling across the wrap. Also documented as D-9 in PartialGameContract §15. Revisit if real-world demand emerges. |
| **`buildShareImage` range-awareness** | Surfaced during 13-C.3 Phase 2A device test: tapping Share on the Results page goes through `buildShareImage` in `roundUtils.js`, which uses module-level `FRONT = [0..8]` / `BACK = [9..17]` constants and ignores `roundStartHole`/`roundEndHole`/`gameRanges`. Result: shared image of a partial round shows all 18 holes, no `–` for out-of-range. ~30-50 line edit to mirror ReadOnlyScorecard's invariant #15(b) treatment. Deferred per owner direction ("leave round summary functionality as is for now") — revisit alongside 14-D iCloud Export polish. |
| **Mid-round Round Summary access gating** | `RoundSummaryModal` is currently reachable from ResultsPage Share even mid-round. Owner instinct: summary should be locked until round completion; opening mid-round shows misleading state. Deferred per owner direction this session — "leave round summary functionality as is for now - too much going on." Revisit when the partial-round UX is fully complete (post-Phase-2B) and we have a clean baseline. Three implementation options surveyed: (A) hide Share button mid-round, (B) two display modes for the same modal, (C) separate "in-progress snapshot" modal. Owner has not chosen. |
| **Stroke Play §14 G-2 — `effMin` not received from `subsetMin()`** | `calcStrokePlay` derives `effMin` internally instead of receiving it from the payout block's `subsetMin()`. Architectural inconsistency only — results are correct. Listed in Stroke Play §14 G-2 as Medium severity, non-blocking. Pre-existing; unchanged by 13-C.3. |
| **"Overall" → "Total" full internal rename** | Phase 2B did display-label only. A future session would rename the internal `overall` field across `runMatchNassau` return value, `matchDef.betOverall` persisted field, the press-key string format `'Match:{matchId}:Overall'`, and all internal variables (`mpO`, `betO`, `overallBets`, `mpOverall`). Requires a `roundLib` migration shim for legacy history records. Pattern matches the prior `scoring`/`grossNetNOL` and `tiebreak`/`scoring` rename sessions. Touches `games.js`, `payouts.js`, `roundUtils.js`, `MatchNassauTable.jsx`, `Nassau_Match_Contract.md` §1.3 internal vocabulary, App_Data_Model_Contract.md §5.5 (`betOverall` field), and possibly Payout_Contract.md. Surfaced during 13-C.3 Phase 2A finalization. |
| **Multi-instance for non-Match games** | Forward-looking question raised during Phase 2B Q1 discussion: should Skins/Stableford/Stroke Play/Sixes/Nines/Dots adopt Match-style multi-instance (one game can have 2+ instances per round, each with its own range/subset/bets)? Per current 13-C contract, departure cases are handled by the **resolver** (`'continue'` / `'end_at_k'` / `'exclude_player'`) within a single-instance model — no multi-instance needed for the documented departure cases. But if a future use case needs **completely different bet/format on different segments of one round** (e.g., front-9 stroke play / back-9 best ball), multi-instance becomes the natural model. Decision deferred to a Sprint 14+ contract-first planning session. Substantial scope: schema changes, all 7 game contracts, NewRoundPage UI, payouts.js iteration patterns, migration shim. |
| **Gray cells for out-of-range columns in Phase 2B tables** | Phase 2B currently omits out-of-range columns entirely (D3). Owner reserved option to add gray cells back later as visual reference. If implemented, would parallel ScoreGrid's invariant #15(a) gray-cell pattern. Estimated 1–2 lines per table — small reversible change. |
| **13-C.4 Mid-Round Game Start (full scope)** | Deferred April 2026 after a planning discussion that walked the late-arrival problem game by game. Owner's read of real-world play patterns: late arrivals are infrequent enough that building dedicated engine support for them is not worth the cost. The group's actual workflow when a 4th player shows up mid-round is to start a *separate game* with the new lineup (e.g., the on-time players play Match → switch to Nines when the 3rd arrives → switch to Skins when the 4th arrives) rather than merge the late joiner into the existing games. **What was specified, what's preserved, and the open decisions if this is revisited:**<br><br>**Scope as originally planned.** `playerJoinHoles: { [playerIdx]: number }` field added to `activeRound`, round-tripped through `roundLib.fromActiveRound` / `toActiveRound` / `toSetupState` (snake-case `player_join_holes` in history records). `buildPayoutArgs` passes `playerJoinHoles ?? {}`. `payouts.js` adds a per-game eligibility pre-processing layer above the engine call sites: `playerGameStart = max(game.startHole, player.joinHole ?? roundStartHole)`, score-trim helper for pre-joinHole rows, eligible-subset filter for NOL `subsetMin` participant sets. `NewRoundPage` shows a "Starts on hole N" label when a player is added with `inProgress === true`. Files: `roundLib.js`, `roundUtils.js`, `payouts.js`, `NewRoundPage.jsx` (engine firewall absolute — no `games.js` / `handicap.js` changes per PartialGameContract §11.1).<br><br>**Game-by-game thinking from the deferral discussion.** Match: already solved via existing `gameRanges` mechanism (multi-instance support exists; user spawns a new match with a custom range starting at the join hole). Nines (3 players exact) and Sixes (4 players exact): structural mismatch — late arrival breaks the fixed group size; user manually trims `gameRanges['Nines'].endHole` (or `gameRanges['Sixes'].endHole`) to end the game at the join hole, no engine work required. Stableford and Stroke Play: late joiner could in principle be handled by a per-leg subset split (early leg = original players, late leg = full subset), but the "total" mode in each game has no clean semantic for a player with only partial holes (exclude joiner from total bet vs. auto-degrade total → segments — both have UX downsides). Owner judged the engineering cost too high relative to use-case frequency. Skins and Dots: the simplest cases — both iterate hole-by-hole, both naturally accept a per-hole eligibility filter. A narrowed scope was discussed (engine work for *only* Skins + Dots, leaving Stableford/Stroke deferred) but ultimately deferred in full.<br><br>**Owner-confirmed decisions from the discussion** (preserved in case of revival): (1) Skins per-skin mode — late joiner has zero exposure on missed holes (not a candidate winner, owes nothing). (2) Skins pot mode — late joiner pays *full buy-in* despite reduced opportunity; pot fixed at `bet × allSubsetPlayers`, divided by total skins awarded over the full game range. Owner rejected pro-rated buy-in and two-pot split alternatives. (3) Skins carryover behavior at the join boundary — Option 1 (reset at join hole). The user mental model is "Skins paused when the new player arrived and restarted fresh at hole `joinHole + 1`." Carryover counter resets to 0 at the lowest non-zero `joinHole`. (4) No score sentinel for late arrival — explicitly rejected the "type 0 to mean skipped" approach because it conflicts with `'X'` semantics, is destructive on data-entry mistakes, and introduces a third invalid-but-meaningful score state.<br><br>**Open decisions if this is revived.** D-D1 (NOL retroactivity): recommendation was Option A (retroactive recompute of `minCourseHcp` from the eligible subset including the late joiner) per Handicap §5 invariant, which requires `Math.min(...courseHcps_of_participants) === minCourseHcp` for any single engine call. Per-hole subset min is the natural mechanism (each `calcSkinsHole` / Dots call gets its own subset min computed from players present on that hole). Stableford/Stroke total-mode handling was never resolved (exclude vs. auto-degrade — punted). Documentation / contract change required: amend `PartialGameContract.md` §3 to clarify which games consume `playerJoinHoles` vs. which use the `gameRanges` workaround; update invariant #12 footnote with engine-consumption scope. UI override range bound: discussed `[roundStartHole + 1, currentHole + 1]` 1-based — backdate allowed (user forgot to add the player), future-date blocked. Confirmed but never implemented.<br><br>**Why the contract still references `playerJoinHoles`.** `PartialGameContract.md` §3 / §4.1 / §13 already specify the field as a future-facing data-model element. We deliberately left those sections intact when deferring this session, because the contract's role is to describe the eventual model whenever we revisit it. Only the *implementation* is deferred — not the spec.<br><br>**Rough estimate if reinstated.** ~4–6 hour build session for the data model + UI label + Skins/Dots engine work. ~12+ hour session if Stableford/Stroke late-arrival support is also wanted (because of the total-mode UX questions and the breakdown-display work to show per-leg subtotals on Results / RoundSummaryModal). Recommend revisiting only if real-world demand emerges, or as part of a broader Sprint 14+ planning session that bundles other small partial-round polish items. |
