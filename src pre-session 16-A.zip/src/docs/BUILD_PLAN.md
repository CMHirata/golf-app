# The Card — Master Build Plan

_Last updated: June 2026 — 15-Bugs.6 complete and confirmed on device. ScoreKeypad overlap fix in ManualCourseModal. Next session: **16-A — Wolf (contract first)**._
_Maintained in this chat as the authoritative sequence and history of all build sessions._
_The APP_STATE_SUMMARY.md in the project knowledge base is the authoritative record of_
_what is implemented. This file is the authoritative record of what was planned, why,_
_and in what order — including items that shifted, were skipped, reinstated, or renumbered._

---

## Critical Rules

1. **Every session starts with a full read of `APP_STATE_SUMMARY.md`.** Do not write code before reading the current state.
2. **Contracts are authoritative over code.** If implementation conflicts with a contract, the contract wins.
3. **Session designations are owner-assigned.** Do not invent session numbers.
4. **No session is "closed" until it is confirmed on device.** "Delivered" ≠ "Closed."
5. **One question at a time.** Never stack multiple open decisions in a single message.
6. **No stream-of-consciousness.** Diagnostic first, code second, confirmation last.
7. **Always use the canonical app URL: `https://the-card-1qm.pages.dev`** — not the hash deployment URLs (e.g. `941b83c0.the-card-1qm.pages.dev`). Hash URLs are frozen deployment snapshots and never update.

---

## Numbering History

- **11-I** split into **11-I.1** (Players card + contracts + shared components) and **11-I.2** (game config UI rebuild) — sub-session dot notation; both treated as separate BP rows.
- **14-E** (Import conflict UX overhaul) completed out of order during Sprint 13. Logged under Sprint 13 in Completed Sessions.
- **14-A** scope vastly exceeded original plan (simple API swap → full OCR infrastructure build). Split into **14-A** (closed May 2026) and **14-A.2** (Mistral OCR continuation, requires real WiFi). See 14-A.2 open session entry.
- **14-B** scope significantly exceeded plan — originally "CourseImportReviewModal new component"; became full ManualCourseModal redesign + import flow wiring + extensive iOS keypad debugging.
- **14-C.bugs** (Open Session Plan designation) → corrected to **14-bugs.1** at session start per owner. Non-sequential designation; logged here for traceability.
- **15-E** scope significantly exceeded original plan — original spec covered swipe-to-delete, star toggle, money toggle on Players page only. Expanded to include: shared `SwipeableRow` component (refactoring CoursesPage swipe at the same time), Money List moved from History to Home page, YTD Leader removed, cumulative winnings removed from History page, starred avatar treatment in PlayerPickerPopup, `new-round/CourseCard.jsx` renamed to `NewRoundCourseCard.jsx` to resolve naming collision.
- **15-J** scope significantly exceeded original plan — original spec was payStyle toggle + file move + condor default. Expanded to include: `dotsMode` contract gap discovered and filled, Dots `'total'` engine branch implemented, `MatchCard.jsx` renamed `GameConfigMatch.jsx`, multiple engine bugs found and fixed during testing (Stroke Play Pay Up tie check; Stableford and Nines perpoint missing payStyle fork), payout sort by game added.
- **15-Bugs.1** non-sequential designation per owner. Bug-fix session for female course handicap on 3-nine courses.
- **15-Bugs.3** → corrected to **15-I** at owner direction. Non-sequential designation; logged here for traceability. Nines 'total' bet mode: contract amendment + engine + config UI. Payout logic corrected mid-session from pool to pairwise flat-bet.
- **15-L** scope significantly exceeded original plan — original spec was player photo upload/crop + `PlayerAvatar` shared component rollout. Extensive iOS Safari debugging required: `overflow:hidden` on ancestor elements kills `<img>` rendering; `background-image` with large data URIs fails on circular elements; foreignObject canvas render does not wait for image decode. Multiple approaches tested via Safari Web Inspector console before root causes identified.
- **15-Bugs.3** non-sequential designation per owner (note: an earlier entry using this label was corrected to 15-I at owner direction; this is a separate later use of the same designation). Bug-fix session for iOS ScoreKeypad overlap on Players page Edit Player modal.
- **15-Bugs.4** non-sequential designation per owner. Bug-fix + color scheme overhaul session for `MatchNassauTable.jsx` and `SixesTable.jsx`.
- **15-Bugs.5** non-sequential designation per owner. Bug-fix session for SI dropdown options in `ManualCourseModal.jsx` — even-front 2-nine courses.
- **15-Bugs.6** non-sequential designation per owner. Bug-fix session for ScoreKeypad overlap in `ManualCourseModal.jsx` — Rating/Slope & Yardage tab.

---

## Completed Sessions

| Session | Summary | Items Closed | Status |
|---|---|---|---|
| 1 | Initial scaffold — React/Vite setup, localStorage, basic score grid | — | Confirmed on device |
| 2 | Handicap engine — `scoreForMode`, stroke allocation, ESC | — | Confirmed on device |
| 3 | Skins engine + SkinsTable live display | — | Confirmed on device |
| 4 | Match/Nassau engine + MatchNassauTable | — | Confirmed on device |
| 5 | Stableford + Nines engines + tables | — | Confirmed on device |
| 6 | Sixes engine + SixesTable | — | Confirmed on device |
| 7 | Dots/Specials engine, DotsTable, DotsPopup | — | Confirmed on device |
| 8 | Stroke Play engine + StrokePlayTable | — | Confirmed on device |
| 9 | Payout aggregation, ResultsPage, share sheet | — | Confirmed on device |
| 11-A | Dots rework (auto-mark, mutual exclusivity, team mode), player name display convention | A-1, A-2, A-3 | Confirmed on device |
| 11-C | Match/Nassau team hole display | B-1 | Confirmed on device |
| 11-D | Fixed-width player name fields + PlayerDropdown shared component | A-4, B-2 | Confirmed on device |
| 11-E | Disabled Btn fix + NOL label audit | C-1, C-2 | Confirmed on device |
| 11-F | HistoryPage swipe-delete + RoundSummaryModal | E-1, E-2 | Confirmed on device |
| 11-G | Planning session — `betType` static decision, Wolf deferral, Nassau terminology retirement | — | Planning + contract only — no device test needed |
| 11-H | NewRoundPage full redesign (3-card layout) | D-1 | Confirmed on device |
| 11-I.1 | Players card redesign + per-player tee selection + Handicap Contract | D-3, D-4 | Confirmed on device |
| 11-I.2 | Game config UI rebuild — all 7 game tiles redesigned | D-2 | Confirmed on device |
| 11-I.3 | Semantic field rename: `scoring` → `grossNetNOL`, `tiebreak` → `scoring` | — | Confirmed on device |
| 11-J | Course library + ManualCourseModal + CourseSearchModal (AI-powered) | — | Confirmed on device |
| 11-K | HistoryPage + history record schema + ResultsPage refinement | — | Confirmed on device |
| 11-L | Stroke Play engine + StrokePlayTable redesign | — | Confirmed on device |
| 11-M | Sixes engine rewrite + SixesTable redesign | — | Confirmed on device |
| 11-M.1 | Post-11-M bug fixes: SixesTable `opts`, ReadOnlyScorecard handicap dots | — | Confirmed on device |
| 13-A | Planning session — sprint restructure, contract audit, session sequencing | — | Planning + contract only — no device test needed |
| 13-B | Custom keypad (`ScoreKeypad.jsx`) + X score type + ZoomModal | — | Confirmed on device |
| 13-B.1 | ZoomModal stabilization + pre-13 bug fixes (Bugs A/B/C) | — | Confirmed on device |
| 13-B.2 | ScoreKeypad_Contract.md §3.4–§3.8 correction to match 13-B.1 implementation | — | Contract only — no device test needed |
| 13-C | Planning + contract session — PartialGameContract v1.0, departure model design | — | Planning + contract only — no device test needed |
| 13-C.2 | Round length fields (`roundStartHole` + `roundNumHoles`), NewRoundPage length UI, Results save-gate fix | — | Confirmed on device |
| 13-C.3 | Predetermined game ranges: Phase 1 contract amendments + Phase 2A engine + plumbing + Phase 2B game-table visual range trimming | — | Confirmed on device |
| 13-C.4 | Deferred — mid-round game start (late arrival) confirmed too rare to justify cost | — | Deferred |
| 13-C.5 | Departure resolver UI Phase 1: `DepartureResolverSheet`, per-game option matrix, clinch detection | — | Confirmed on device |
| 13-C.6 | Departure resolver UI Phase 2: undo gesture, format detection, departure semantics | — | Confirmed on device |
| 13-C.7 | Departure resolver Phase 3 + PartialGameContract v2.0 (sequenced-event model, Reorder Departures) + v2.1 amendment + cleanup | — | Confirmed on device |
| 13-C.8 | Match/Nassau per-instance breakdown (Option A) + Sixes columnar shape + departure decoration strings | — | Confirmed on device |
| 13-C.bugs | Post-13-C.8 bug-fix consolidation session | — | Confirmed on device |
| 13-D | Planning session — backlog restructure, sprint reprioritization + `useDepartureResolver.js` extraction bonus | — | Confirmed on device |
| 14-E | Import conflict UX overhaul (completed out of order during Sprint 13) | — | Confirmed on device |
| 13-E | `GameConfig.jsx` (1,292 lines) split into 7-file dispatcher + Shared + 6 panel files. Circular import resolved via `GameConfigShared`. Architectural pattern (dispatcher + Shared) added as Decision #26. Four game contracts amended. | — | Confirmed on device |
| 13-E.2 | `App.jsx` slim-down (530→321 lines). Four extractions: `NavIcons.jsx`, `BottomNav.jsx`, `exportUtils.js`, `useIsLandscape.js`. | — | Confirmed on device |
| 13-E.3 | `HistoryPage.jsx` slim-down (736→482 lines). Two extractions: `SwipeableRoundRow.jsx`, `HistoryIcons.jsx`. | — | Confirmed on device |
| 13-E.4 | `ScoreGrid.jsx` depart-prompt extraction + Skins regression fix + resolver header copy edge case. `PartialGameContract.md` → v2.2, `Resolver_UI_Spec.md` → v1.4. | — | Confirmed on device |
| 13-E.5 | `PayoutDisplay.jsx` shared extraction. | — | Confirmed on device |
| 13-E.6 | `roundUtils.js` → `shareUtils.js` extraction (933 lines). | — | Confirmed on device |
| 13-E.7 | `NewRoundPage.jsx` 3-card extraction (1414→765 lines). Four new files. H-31 added. | — | Confirmed on device |
| 13-E.8 | `RoundSummaryModal.jsx` → `ReadOnlyScorecard.jsx` extraction. Closes 13-E.x series. | — | Confirmed on device |
| 13-F (contract) | Universal keypad expansion + plus-CH indicator — contract-only. Four contracts amended. | — | Contract only — no device test needed |
| 13-F | Universal keypad implementation. Scope significantly exceeded plan — extensive iOS-specific debugging. H-32 through H-35 added. Contracts updated to v2.4/v1.8/v1.5. | — | Confirmed on device |
| 13-G | Female handicap bug fix — gender-aware course handicap + stroke-allocation display. `Handicap_Contract.md` v1.9. H-36 added. | — | Confirmed on device |
| 13-G.2 | Engine gender-blind SI refactor — per-player `siArray`, `hcps` dropped from all 9 engine functions. `Handicap_Contract.md` v2.0, `App_Data_Model_Contract.md` v3.7. H-37 added. | — | Confirmed on device |
| 14-A | Sprint 14 photo import — full OCR infrastructure build. AI Assistant path confirmed on device. Auto Scan functional with known limitations. `courseLib.js` schema gains `nineComboNames`. `CourseCard.jsx` hole numbering + combo yardages. Deploy migrated from Netlify to Cloudflare Pages + Workers. Scope significantly exceeded plan — see detailed 14-A notes below. | — | Confirmed on device — AI Assistant path. Auto Scan in development. |
| 14-B | ManualCourseModal full redesign: compact M/W inline grid for Par & Handicap, table layout for Rating/Slope & Yardage, USGA SI validation (odd/even per nine, duplicate detection, save-block), `KpField` component for system-keyboard-free entry, discard confirmation overlay, tap-outside lock, modal shrinks when keypad open, background scroll lock. `PhotoImportModal.jsx`: `finish()` → Review & Save flow via `ManualCourseModal` with `initialData`, duplicate tee name consolidation. `CourseCard.jsx` + `courseLib.js`: website field removed. Scope significantly exceeded plan. H-39 added. | — | Confirmed on device |
| 14-bugs.1 | Custom dot bugs: `parts[2]` key-split bug caused custom dot IDs (`c_timestamp`) to be silently dropped in payout accumulation and team companion logic across `payouts.js`, `ScoreGrid.jsx`, `DotsTable.jsx`, `DotsPopup.jsx`. Fixed with `parts.slice(2).join('_')` at all 6 id-extraction sites. `pivotSegTot`/`pivotRoundTot` companion-filtering fix. ScoreKeypad double-fire: React 18 passive listeners silently ignored `preventDefault()` in `onTouchEnd`, causing `onClick` to fire ~300ms later on every digit/backspace tap. Fixed with `touchHandledRef` timestamp guard on `onClick`; `onMouseUp` removed. H-40 added. | — | Confirmed on device |
| 15-E | Players page enhancements. Shared `SwipeableRow` component (ported from `SwipeableRoundRow` mechanics — yellow edit strip, red delete, full-swipe overlay). `CoursesPage` refactored to use `SwipeableRow`. Star/favourite toggle on player rows — starred players sort to top of `playerLib.list()` and all player pickers. Per-player `inMoneyLists` toggle. Cumulative Winnings removed from History page. Money List added to Home page (roster-filtered, `inMoneyLists`-filtered). YTD Leader widget removed from Home page. Starred avatar treatment in `PlayerPickerPopup` (pale yellow star watermark behind initial, disappears on selection). `new-round/CourseCard.jsx` renamed `NewRoundCourseCard.jsx` to resolve naming collision with `pages/CourseCard.jsx`. `App_Data_Model_Contract.md` §5.3 amended — `starred` and `inMoneyLists` library-record fields. Scope significantly exceeded plan. | — | Confirmed on device |
| 15-F | Dead import cleanup. Removed dead `Btn` import from `HistoryPage.jsx`; removed dead `GA` import from `HomePage.jsx`. Two surgical `str_replace` edits. | — | Confirmed on device |
| 15-E.1 | Money List visual overhaul (Option D layout: position number + initials avatar + name + amount; left accent bar in app green/red/grey; no winner highlight; no round counters). Custom date wheel picker (iOS-style three-column scroll wheel: month/day/year) replacing native `<input type="date">`. New shared `components/RangePicker.jsx` extracts all range logic — owns two localStorage keys (`moneyListRange` for Home, `historyRange` for History) so the two pages maintain independent filter state. Range options: 7 Days, MTD, YTD, All Time, Custom (equal-width pill grid). Settings persisted through backup/restore via new top-level `settings` field in export payload. Player conflict-detection field-list fix (`starred`, `inMoneyLists` added to `f` field list at both detection and resolution sites in `HistoryPage.applyImport`). `CoursesPage` add-button row updated to match Money List pill style (Search / Scan Card / Manual all filled green). Contracts amended: `App_Data_Model_Contract.md` v3.8 (§1 storage keys, §1.1 range pref shape, §1.2 backup payload settings field), `Round_Lifecycle_Contract.md` v2.3 (§5.2 settings cross-reference), `UI_Component_Contract.md` v1.6 (§10 NEW — `RangePicker.jsx` documented). Scope significantly exceeded plan. | App_Data_Model v3.8, Round_Lifecycle v2.3, UI_Component v1.6 | Confirmed on device |
| 15-G | Birdie/bogey/eagle/double-bogey par-relative indicators on ScoreGrid score cells, ReadOnlyScorecard (round summary modal), and share image (`shareUtils.js`). `parRelative()` helper added to `scorecardUtils.js`. `BIRDIE_COLOR` and `BOGEY_COLOR` tokens added to `ui.jsx`. Indicators: eagle = double circle, birdie = single circle, par = none, bogey = single square, double-bogey-or-worse = double square. Stroke-only outlines, gross score vs par, suppressed on empty/locked/missing-par cells. Share image uses CSS borders (not SVG) due to foreignObject limitation; number centered via absolute `top:53%/left:50%` anchor. ScoreGrid pin feature deferred — see Deferred table. `UI_Component_Contract.md` v1.7 (§3.6 new tokens, §4.11 NEW indicator overlay rules). Scope significantly exceeded plan — extended to 15-G.2 to cover ReadOnlyScorecard and shareUtils. | UI_Component v1.7 | Confirmed on device |
| 15-C | Payouts page redesign. "Results" renamed to "Payouts" throughout (`ResultsPage.jsx` header, `ScorecardPage.jsx` button). Player chips: vertical stack (initial circle / first name / last name / net amount), sorted win-to-loss, all players in one row, first+last initials in circle. Settle Up tile with transfer SVG icon: greedy debt-simplification algorithm (fewest transactions). "Total — All Games" section removed. Per-game sections refreshed as white cards with border/shadow on light-green page background. No contract changes. Scope significantly exceeded original plan. | — | Confirmed on device |
| 15-B | Game table display consistency pass. Removed all per-game legend/help text (`ColNote` lines) from `NinesTable`, `SkinsTable`, `StablefordTable`, `StrokePlayTable`, and the scorecard-level dots hint from `ScoreGrid`. Stripped extra info from game tile upper-right badges — Gross/Net only across all tables; added missing Gross/Net badge to `DotsTable`. Column header standardization: "Skins"→"Total" (`SkinsTable`), "F"/"B"→"Total" (`StablefordTable`), "Status"→"Total" (`SixesTable`, `MatchNassauTable`). "Front 9"/"Back 9"→"Front"/"Back" in `MatchNassauTable`, `DotsTable`, and `ScoreGrid` half labels. Removed Dots pivot winner highlight. Removed dead `frontLabel`/`backLabel` prop from `ScoreGrid` (variables retained in `ScorecardPage` for toolbar display). | — | Confirmed on device |
| 15-Bugs.1 | Female course handicap fix on 3-nine courses. `groupCourseHandicaps` and `computePlayerCH` in `NewRoundPage.jsx` were summing `parsWomen` across all nines in `course.nines` instead of only the two active nines, producing a wildly wrong `womensPar` (e.g. 108 instead of 72 at Sahalee). Fixed by filtering to `activeNines` (front + back only) at both call sites. Two surgical `str_replace` edits to `NewRoundPage.jsx` only. H-43 added. | — | Confirmed on device |
| 15-Bugs.2 | Save-gate exempts post-departure holes for departed players (`ResultsPage.jsx`). Nines Nassau decoration string fixes: unresolved segments default to `'abandon'`, zero-bet segments excluded from label, capitalize "Ended"/"Paid", period separator, trailing period. Changes to `payouts.js`, `roundUtils.js`, `ResultsPage.jsx`. | — | Confirmed on device |
| 15-I | Nines `'total'` bet mode. `Nines_Contract.md` v1.7 + `App_Data_Model_Contract.md` §5.3 amended. `payouts.js` new `'total'` branch (pairwise flat-bet: each lower-ranked player pays each higher-ranked player `bet`). `GameConfigNines.jsx` "Total" pill added between "Per Point" and "F/B/T". Initial pool implementation corrected mid-session to pairwise flat-bet to match owner-specified semantics. | — | Confirmed on device |
| 15-J | Pay Up / Pay Winner toggle + Point Spread rename + GameConfig file move + Dots total mode + condor default fix + payout sort. `payStyle: 'payup' \| 'paywinner'` added to Nines (default payup), Stableford (default paywinner), Stroke Play (default paywinner), Dots (default payup). `dotsMode: 'spread' \| 'total'` contracted and Dots `'total'` engine branch implemented. `'perpoint'`/`'spread'` UI labels renamed "Point Spread" for consistency. `PayStylePill` shared component added to `GameConfigShared.jsx`. All `GameConfig*.jsx` files moved from `src/pages/tables/` to `src/pages/new-round/`. `MatchCard.jsx` renamed to `GameConfigMatch.jsx` and moved to `new-round/`. Condor default changed to `enabled:true` in `DOTS_DEF`; runtime migration shim in `App.jsx` `getActiveRound`. By Game payout sections sorted alphabetically in `PayoutDisplay.jsx`. Five contracts amended: Nines v1.8, Stableford v1.8, Stroke Play v1.8, Dots v2.6, App_Data_Model v3.9. Multiple engine bugs found and fixed during testing (Stroke Play Pay Up tie check; Stableford and Nines perpoint branches missing payStyle fork). Scope significantly exceeded plan. | Nines v1.8, Stableford v1.8, Stroke Play v1.8, Dots v2.6, App_Data_Model v3.9 | Confirmed on device |
| 15-H | Export filename fix. `makeExportFilename()` in `exportUtils.js`: time separator changed from `-` to `.` (e.g. `The Card 2026-05-27 14.35.json`). Colon rejected — iOS converts `:` to `_` in filenames. Single `str_replace` edit. | — | Confirmed on device |
| 15-A | Display polish pass. Player chips moved out of dark green header into `#ddeedd` band beneath it, matching share image style (white card chips, first/last name stacked, HI/CH). Course name smart line-break on ` - ` in `RoundSummaryModal` header. `ReadOnlyScorecard` half-row labels simplified to `'Front'`/`'Back'` (nine names removed). `shareUtils` half-table labels same; `ninesLabel` gated to 27-hole courses only (was firing for all multi-nine courses). History game pills: `'Match / Nassau'` displays as `'Match'` in `SwipeableRoundRow`. No contract changes. | — | Confirmed on device |
| 15-K | Randomize Teams button in Sixes config. `footerSlot` render prop added to `PlayerDropdown` — optional `(close: () => void) => ReactNode` rendered below the player grid in the open panel. `GameConfigSixes.jsx` passes Randomize Teams button as `footerSlot` to Match 1 / Player 1 dropdown only. Randomize logic enumerates all 3 valid pairings from real player indices and picks two distinct ones; Match 3 auto-derives as before. H-45 added. | — | Confirmed on device |
| 15-L | Player photos. New `src/components/PlayerAvatar.jsx` shared component (photo or initial circle, starred badge, `onPress`). New `src/components/ImageCropOverlay.jsx` (pan + pinch-zoom crop UI; touch-only gesture system; direct DOM transform for 60fps; lazy pinch baseline on first touchmove). Photo upload/crop on Players page; avatar tap → full-screen expand with Change/Delete/Cancel. `App_Data_Model_Contract.md` v4.0: `photo?` added to player library record schema. Avatar circles rolled out to all surfaces: Players page, PlayerPickerPopup, HomePage Money List, PlayersCard (New Round), Payouts page, Round Summary modal, TotalsCard (avatars removed in favour of name+scores only). Share image: photos drawn directly onto canvas after foreignObject render (bypasses iOS Safari `<img>`-in-foreignObject limitation). Photos enriched from `playerLib` by name-fallback in `ResultsPage` and `RoundSummaryModal` since `activePlayers` snapshot carries no `photo`. Email/phone fields removed from player edit modal and player schema. Gender kept (handicap) but icon removed from player row. `HistoryPage.applyImport` `f` array updated at both sites (H-42). H-46, H-47 added. Scope significantly exceeded plan — extensive iOS Safari debugging required. | App_Data_Model v4.0 | Confirmed on device |
| 15-M | HomePage Enhanced view. Basic/Enhanced toggle (localStorage-persisted, scroll-to-see text link at bottom). Enhanced view: Standings card with podium (2nd left / 1st center / 3rd right, SVG pennant ribbons, photo avatars, stacked first/last name, equal-width flex cards), ranked list 4+ with collapse chevron, "By Game" slide-in breakdown table (all games normalized/deduplicated, alphabetical columns, sticky avatar+name column, horizontal scroll). 4-tile stat row (individual cards, icon circles matching nav icon style). Insights 2×2 grid: Heater (hot streak count), Cold Streak (loss streak count), Dynamic Duo (team pair win count from all formats), The Lock (win rate, min 3 rounds). Range picker centered in Standings header. No contract changes. Scope significantly exceeded plan. | — | Confirmed on device |
| 15-Bugs.3 | iOS keyboard overlap fix on Players page. ScoreKeypad (position:fixed, bottom:0) physically covered the bottom of the Edit Player modal sheet. Fixed by applying `paddingBottom:300` to the sheet div when `activeFieldId==='ghin'`, pushing the Handicap Index field and Cancel/Save buttons above the keypad. Single `str_replace` edit to `PlayersPage.jsx`. H-48 added. | — | Confirmed on device |
| 15-Bugs.4 | Scorecard table color scheme overhaul. `MatchNassauTable.jsx` and `SixesTable.jsx`: replaced legacy red/pink hole-chip and Total-cell colors with identity-stable two-color scheme — navy/pale-blue (Team A, player 1) and red/pale-yellow (Team B, player 2). Removed `isTeam &&` guards so individual matches use same colors as team matches. Total cells now show leader's full bg+font color (or neutral green for All Square) across all three render paths. Row backgrounds flattened (no press-depth tinting). All bet/press row labels unified to dark green `M.hdrClr` / `fontWeight:600`. Redundant "Front"/"Back" `<HalfLabel>` headers removed — first bet row label is sufficient. Sixes: `isBluePlayer` helper anchored to `sixesTeams[0]` (segment-0 team composition) rather than raw player index, ensuring consistent color identity across all three segments. Segment header now shows team names only; "Holes 1–6" etc. moved into first bet row label cell. H-49 added. | — | Confirmed on device |
| 15-N | RangePicker 6-pill expansion. Added `'30days'` (Month, rolling 30-day) and `'365days'` (Year, rolling 365-day) range options to `RangePicker.jsx`. All pill labels changed to word-based: Week / Month / Year / YTD / All / Custom. MTD removed. Grid updated from `repeat(5,1fr)` to `repeat(6,1fr)`. `UI_Component_Contract.md` §10 amended. | UI_Component_Contract.md §10 | Confirmed on device |
| 15-Bugs.5 | SI dropdown options fix for 2-nine courses with even-front layout. `siValidSet()` in `ManualCourseModal.jsx` previously enforced USGA odd/even per nine index — nine 0 odd-only, nine 1 even-only. Courses with even SI values on the front nine (e.g. Snohomish GC) caused all selects to snap to the first valid option, displaying all 1s and 2s. Fix: 2-nine courses now offer all 18 values in both nines' dropdowns; duplicate detection via `dupIndices` remains the sole correctness gate. Single `str_replace` to `siValidSet` + call site. H-50 added. | — | Confirmed on device |
| 15-O | CoursesPage sort + starred courses. `courseLib.list()` now returns courses sorted starred-first then A→Z within each tier (mirrors `playerLib.list()`). Star toggle button added to each course row in `CoursesPage.jsx` (gold filled ★ when starred, grey outline when not — identical style to Players page). `CoursePickerPopup` in `NewRoundPage.jsx`: sorted same way; tiles simplified to name + location only (tees line removed); gold star shown on right of starred tiles. History-course prepend participates in sort. `App_Data_Model_Contract.md` §5.2 amended — course library record schema added with `starred?: boolean` (library-only, absent = false). | App_Data_Model v4.1 | Confirmed on device |
| 15-Bugs.6 | ScoreKeypad overlap fix in `ManualCourseModal.jsx` — Rating/Slope & Yardage tab. Applied `paddingBottom:300` to the modal card when `setupKp` is active (reverts to 20 when null). Added `useEffect` on `setupKp?.fieldId` to scroll `modalCardRef` to `scrollHeight` on keypad open. `kpWasOpenRef` guards the scroll to fire only on closed→open transition — not on field-to-field switches while keypad is already up (which caused double-scroll / extra whitespace). H-51 added. | — | Confirmed on device |

---

## Known Bugs

| Bug | Severity | Discovered | Notes |
|---|---|---|---|
| — | — | — | No known bugs. |

---

## Open Session Plan

> **Next session: 16-A — Wolf (contract first).** Sprint 15 complete. Sprint 16 (new game formats) is next; all sessions are contract-first.

---

### Sprint 14 — Scorecard Photo Import

_14-A complete. 14-B complete. 14-bugs.1 complete. AI Assistant + Review & Save flow confirmed on device._

**14-A.2: Mistral OCR Continuation** *(requires real WiFi — do not attempt on airplane)*
- Test Mistral OCR table parsing with `page.tables[]` array fix
- Evaluate vs Gemini coordinate approach on Waiehu, Fircrest, Sahalee
- If accurate: integrate as primary Auto Scan path; Gemini handles metadata only
- If inaccurate: document findings, close 14-A.2, rely on AI Assistant + 14-B correction grid
- Files: `worker/worker.js` (swap in `worker_mistral.js`)
- Priority: High (gated on real WiFi)
- Requires: Mistral API key (Christopher has it, prefix `llx-p8`)

**14-C: Photo Guidance + UI Polish** *(fold into next available session)*
- Review photo slot labels and instruction copy.
- Files: `PhotoImportModal.jsx`
- Priority: Low — 14-B already cleaned up labels to "Front" / "Back"

---

### Sprint 15 — Display Polish + Features

_15-A, 15-B, 15-Bugs.1, 15-Bugs.2, 15-Bugs.3, 15-Bugs.4, 15-Bugs.5, 15-Bugs.6, 15-C, 15-E, 15-E.1, 15-F, 15-G, 15-H, 15-I, 15-J, 15-K, 15-L, 15-M, 15-N, 15-O complete and confirmed on device — see Completed Sessions table above. 15-D deferred. **Next session: 16-A — Wolf (contract first).**_

---

### Sprint 16 — New Game Formats

_All Sprint 16 sessions are contract-first._

**16-A: Wolf** *(contract first)* — extension point preserved in `GAME_CONFIGS`.

**16-B+: Other formats** — High/Low, Bingo Bango Bongo, etc.

---

## Items Requiring Contract Work

| Item | Contract | Notes |
|---|---|---|
| Sprint 16: Wolf | New `Wolf_Contract.md` | Full contract session before any code |
| Sprint 16: High/Low | New `HighLow_Contract.md` | Full contract session before any code |
| Sprint 16: other formats | New contracts per format | Full contract session each |

---

## Decision Log

### Pending Decisions

_None._

### Confirmed Decisions

| Decision | Session | Notes |
|---|---|---|
| Contracts are authoritative over code | 11-G | When contract and implementation conflict, contract wins |
| `betType` never stored in round state | 11-G | Static UI dispatch concept in `GAME_CONFIGS` only |
| Nassau terminology retired from UI | 11-G | Exposed as Front/Back/Overall segment bet fields |
| Wolf deferred until app is solid | 11-G | Extension point preserved in `GAME_CONFIGS` |
| Per-player tee selection | 11-I.1 | Completed; treat any extension as high-risk |
| `scoring` → `grossNetNOL` rename | 11-I.3 | Semantic field rename; all contracts updated |
| ScoreKeypad nav row removed | 13-B | Device testing confirmed too much screen space |
| Auto-advance timing: 700ms for `'1'`, immediate for others | 13-B | Cell advancement post-nav-row removal |
| `'X'` score semantics | 13-B | X = picked up; gross = par+2+strokes; always loses to real score |
| Round length stored as `roundStartHole` + `roundNumHoles` | 13-C.2 | `roundEndHole` always derived |
| Early departure via Results gateway only | 13-C | No "End Round Early" button on scorecard |
| Sequenced-event resolver model (v2.0) | 13-C.7 | One sheet per player, never combined; v1.x model REMOVED |
| Match/Nassau breakdown per-instance (Option A) | 13-C.8 | Each match emits its own columnar row; combined header retired |
| GPT-4o for scorecard photo OCR (superseded) | 13-D | Claude vision unreliable. Superseded by Gemini decision. |
| Codebase extraction before feature work | 13-D | 13-E refactor pass before Sprint 14+ |
| Dispatcher + Shared file pattern for multi-game UI splits | 13-E | Canonical pattern for splitting files with shared sub-components |
| Gemini 2.0 Flash for scorecard photo OCR | Sprint 14 planning | Tied with GPT-4o at 100% accuracy on app fields; chosen on cost (~25× cheaper) and latency. |
| API key storage = Option B (localStorage prompt) for build phase | Sprint 14 planning | Zero infrastructure; key never in bundle. Option C proxy deferred to production hardening. |
| On-device OCR (Tesseract.js) rejected | Sprint 14 planning | Not an offline use case; character recognizer not a table parser; WASM too heavy. |
| `PayStylePill` is a shared component in `GameConfigShared.jsx` | 15-J | Identical two-pill toggle across all four game panels — one component, not four copies |
| All `GameConfig*.jsx` files live in `src/pages/new-round/` | 15-J | Moved from `src/pages/tables/` — config panels belong with new-round setup, not with display tables |
| `MatchCard.jsx` renamed `GameConfigMatch.jsx` and moved to `new-round/` | 15-J | Consistent naming with all other GameConfig panel files |
| Pay Up / Pay Winner semantics: flat `bet` per rank-position pair (not per-pot) | 15-J | Pay Up: j pays i `bet` for every pair where i ranked above j. Pay Winner: all losers pay only top scorer `bet`. Applies uniformly across flat-bet and differential modes. |
| iOS double-cell-advance fix: `touchHandledRef` timestamp guard | 13-G | React 18 passive listeners; synthetic click suppressed within 600ms of touchend. |
| `footerSlot` on `PlayerDropdown` is a render prop `(close) => ReactNode` | 15-K | Caller receives `close()` directly; no companion prop needed. Cleaner than a static ReactNode + separate `onFooterAction` callback. |
| `photo` is library-only — never copied to `activePlayers` snapshot | 15-L | Same rule as `starred` and `inMoneyLists`. Surfaces using `activePlayers` must enrich from `playerLib` by id/name lookup when photo display is needed. |
| Player photos drawn directly onto canvas in share image | 15-L | iOS Safari does not render `<img>` inside SVG foreignObject reliably. Photos are omitted from the foreignObject HTML and drawn via canvas 2D API (`ctx.arc` + `ctx.clip` + `ctx.drawImage`) after the foreignObject renders. |
| Sixes color anchor is `sixesTeams[0]` team composition, not raw player index | 15-Bugs.4 | `sixesTeams[0].a` and `sixesTeams[0].b` define the permanent "blue side" regardless of player indices. Raw index (0+1=blue, 2+3=red) fails when segment-0 team pairs index 0 with index 3. |
| Overall back-9 Total cells show back-9 result only (not 18-hole cumulative) | 15-Bugs.4 | Chip bar is the correct place to read the 18-hole summary. Mixing scopes in the split table would be inconsistent and confusing. |

---

## Key Architectural Decisions

| Decision | Session | Notes |
|---|---|---|
| Cloudflare Pages + Workers for scorecard parsing | 14-A | Netlify 10s timeout too short for multi-pass OCR. Cloudflare Worker has no hard wall-clock timeout. |
| Transcription-first CSV for Gemini OCR | 14-A | Stop asking model to structure; ask it to transcribe. JS does all structuring. Key breakthrough. |
| AI Assistant import path as primary reliable path | 14-A | User copies prompt → Gemini chat → paste JSON back. Works flawlessly. Primary until Auto Scan perfected. |
| `nineComboNames` field for 27-hole courses | 14-A | Optional `string[]` on course object. Stores 18-hole combo labels in card order. `CourseCard.jsx` uses for yardage display. |
| Hole numbers display 1-9 per nine (not 1-27) | 14-A | `CourseCard.jsx` uses `h+1` not `ni*9+h+1`. Every nine numbered 1-9 independently. |
| Mistral OCR as next candidate for Auto Scan | 14-A | $0.002/page, native HTML tables, simple REST API. Partially integrated. Follow up in 14-A.2 on real WiFi. |
| Always use canonical Cloudflare URL | 14-A | `https://the-card-1qm.pages.dev` always points to latest deploy. Hash URLs (e.g. `941b83c0.the-card-1qm.pages.dev`) are frozen snapshots — never use them for testing. |
| CourseImportReviewModal replaced by Review & Save via ManualCourseModal | 14-B | Dedicated review grid scrapped — consistent UI, less code. `finish()` in PhotoImportModal opens ManualCourseModal pre-populated via `initialData`. |
| Website field removed from course schema UI | 14-B | Removed from ManualCourseModal, CourseCard, courseLib prompt/merge. Existing localStorage data with `website` field silently ignored. |
| SI validation: 2-nine courses offer all 18 values; duplicate detection is sole gate | 14-B, 15-Bugs.5 | Original: odd/even per nine index (14-B). Amended 15-Bugs.5: courses vary; even-front layouts are valid. Both nines now show 1–18; `dupIndices` blocks duplicates. 1-nine and 3-nine courses unaffected (still 1–9). |
| Tee Boxes card layout preserved as commented code | 14-B | `TeeRow` component kept in `ManualCourseModal.jsx` as commented-out Tees 1 option for potential future settings menu. |
| `SwipeableRow` gesture mechanics port from `SwipeableRoundRow` | 15-E | All swipe gesture tracking in refs (zero setState during gesture). `snapClose` called before action callbacks. Full-swipe threshold = 80% of row width. Edit strip = pale yellow `#fff9e6`, delete = `#c0392b`. |
| Money List on Home page; cumulative winnings removed from History | 15-E | Home page shows roster-filtered, `inMoneyLists`-filtered cumulative winnings. History page shows rounds only. |
| `starred` and `inMoneyLists` are library-only fields — never in `activePlayers` | 15-E | Engines never see these fields. `App_Data_Model_Contract.md` §5.3 amended. |
| `new-round/CourseCard.jsx` renamed to `NewRoundCourseCard.jsx` | 15-E | Resolves naming collision with `pages/CourseCard.jsx` (read-only detail card). Two distinct components, now distinct names. |
| Shared `RangePicker.jsx` is single source of truth for range filters | 15-E.1 | Both Home page Money List and History page round filter import from `components/RangePicker.jsx`. Range options, filter logic, custom date wheel picker live in one file. New range options or filter changes are made once and pick up in both consumers automatically. |
| Home and History maintain independent date filter state | 15-E.1 | Two distinct localStorage keys (`moneyListRange`, `historyRange`) sharing the same shape. `loadRangePref(key)` and `saveRangePref(pref, key)` accept the key as a parameter; consumer pages pass their own. Both keys survive backup/restore via the new `settings` payload field. |
| Backup payload `settings` field for app-level preferences | 15-E.1 | Top-level `settings` field on the export JSON carries app preferences (currently `moneyListRange` and `historyRange`). `HistoryPage.handleImportFile` preserves it through to `applyImport`, which writes each present key to localStorage. Settings overwrite silently — not subject to the player/course conflict prompt. Future preference keys follow the same pattern. |
| App-preference localStorage keys are direct strings, not part of `SK` | 15-E.1 | `SK` is reserved for entity data (players, courses, rounds, active round, setup draft). UI preference keys (`moneyListRange`, `historyRange`) are direct string literals owned by the component that uses them. Documented in `App_Data_Model_Contract.md` §1. |
| iOS-style scroll wheel for custom date picker | 15-E.1 | Three independent scroll columns (month/day/year) using CSS `scroll-snap-type: y mandatory` and `scroll-snap-align: center`. Selection highlight band is semi-transparent with green borders so the centered text is fully readable. Top/bottom fades stop short of the selected row to avoid obscuring it. |
| Money List visual: avatar + name + amount | 15-L | Left accent bar and place number removed (15-L). Avatar circle (30px) + name + amount. Green/red/grey amount coloring retained for win/loss/zero. |
| Player import conflict field-list includes `starred` and `inMoneyLists` | 15-E.1 | `HistoryPage.applyImport` previously rebuilt player records using a fixed five-field list (`name, gender, ghin, email, phone`), silently dropping `starred` and `inMoneyLists` on any conflicting import. Both fields added to the `f` list at conflict-detection (line ~158) and conflict-resolution (line ~199) sites. Brand-new players (no conflict) were already correct. |
| Payouts page: player chips vertical stack, first+last initials, sorted win-to-loss | 15-C | Circle / first name / last name / net amount stacked vertically. All players in one row. Amounts always align because name is always two lines. |
| Payouts page: greedy debt-simplification for Settle Up tile | 15-C | `buildSettlements(bank)` sorts debtors/creditors by magnitude, matches greedily for fewest transactions. |
| "Total — All Games" section removed from Payouts page | 15-C | Redundant with player chips which already show each player's net. |
| ScoreGrid half labels simplified to Front/Back | 15-B | `frontLabel`/`backLabel` props removed from `ScoreGrid` — dead after label simplification. Variables retained in `ScorecardPage` for toolbar nine-name display. |
| Female CH on 3-nine courses: filter to active nines before summing womensPar | 15-Bugs.1 | `course.nines` must be filtered to the active front and back nines before summing parsWomen for the womensPar used in courseHandicap(). Summing all nines produces wildly wrong par (e.g. 108 instead of 72 at Sahalee). Fixed at both call sites in `NewRoundPage.jsx`. Captured as H-43. |
