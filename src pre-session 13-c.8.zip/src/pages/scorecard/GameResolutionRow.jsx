// ─── scorecard/GameResolutionRow.jsx ──────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js
//
// ✅ Self-checked (13-C.7.5 / v2.0): Match-family top-level pills simplified
// per PartialGameContract §6.1 v2.0 — three pills (abandon / end_at_k_closed_only
// / end_at_k_closed_and_open) collapsed to two (abandon / end_at_k). Any
// `end_at_k` selection on a clinch-family game now expands per-segment +
// per-press Pay/Abandon pills, providing the same expressivity as the old
// `closed_and_open` variant. The legacy `topLevelVariant` field is still
// accepted on input (for backward compat with v1.x stored records) — when
// `closed_only` is present in storage, the per-segment defaults that were
// derived from "closed only" (in-progress segments → Abandon) are visible
// via the segment pills, and the user can edit them; the variant field is
// no longer set by user action.
//
// ✅ Self-checked (13-C.6): One row per game in the resolver sheet per
// Resolver_UI_Spec §2.2. Pure presentational: no internal state, no engine
// call. Hole-by-hole never expands. `aria-pressed` on each top-level pill.
// The component does not reset segments/presses when top-level changes —
// that is the parent sheet's responsibility.
//
// ✅ Self-checked (13-C.6 device-test): Pill labels wrap to a second line
// when too long for single-line layout (was `whiteSpace: 'nowrap'` with
// ellipsis truncation). Equal-width pills preserved via `flex: 1 1 0`;
// vertical centering keeps short and long pills aligned in the same row.

import { G } from '../../components/ui.jsx';
import { BetPillRow } from './BetPillRow.jsx';

// Top-level pill style — selected = filled green, unselected = outlined.
// Pills share row width equally (`flex: 1 1 0`) and wrap their text to a
// second line when the label is too long for one row. Vertical centering
// keeps short and long pills visually aligned in the same row.
function pillStyle(selected) {
  return {
    flex: '1 1 0',
    padding: '8px 10px',
    borderRadius: 8,
    border: selected ? `1.5px solid ${G}` : '1.5px solid #ccc',
    background: selected ? G : '#fff',
    color:      selected ? '#fff' : '#444',
    fontSize: 12,
    fontWeight: 700,
    fontFamily: 'inherit',
    cursor: 'pointer',
    transition: 'all .15s',
    WebkitTapHighlightColor: 'transparent',
    // 13-C.6 device-test fix: allow wrap so 4-pill rows (Dots) and long
    // labels ("Continue", "Drop [LongName]") render fully instead of
    // being truncated with an ellipsis.
    whiteSpace: 'normal',
    overflow: 'visible',
    textAlign: 'center',
    lineHeight: 1.2,
    minWidth: 0,
    minHeight: 36,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  };
}

// Maps the `value` from a topLevelOption to the resolver-state shape.
//
// v2.0 (13-C.7.5):
//   'abandon'                  → { topLevel: 'abandon' }
//   'end_at_k'                 → { topLevel: 'end_at_k' }   [all families]
//   'continue'                 → { topLevel: 'continue' }
//   'exclude_player'           → { topLevel: 'exclude_player' }
//
// v1.0 backward compat (still accepted on input):
//   'end_at_k_closed_only'     → { topLevel: 'end_at_k', topLevelVariant: 'closed_only' }
//   'end_at_k_closed_and_open' → { topLevel: 'end_at_k', topLevelVariant: 'closed_and_open' }
function partialFromOption(value) {
  switch (value) {
    case 'abandon':                  return { topLevel: 'abandon',         topLevelVariant: undefined };
    case 'end_at_k':                 return { topLevel: 'end_at_k',        topLevelVariant: undefined };
    case 'continue':                 return { topLevel: 'continue',        topLevelVariant: undefined };
    case 'exclude_player':           return { topLevel: 'exclude_player',  topLevelVariant: undefined };
    // v1.0 legacy variants — still accepted but no longer emitted.
    case 'end_at_k_closed_only':     return { topLevel: 'end_at_k',        topLevelVariant: 'closed_only' };
    case 'end_at_k_closed_and_open': return { topLevel: 'end_at_k',        topLevelVariant: 'closed_and_open' };
    default:                         return { topLevel: value,             topLevelVariant: undefined };
  }
}

// Inverse — used to decide which top-level pill is currently selected.
//
// v2.0: clinch-family `end_at_k` (with or without the legacy variant)
// always maps to the simplified `end_at_k` pill.
function optionValueFromResolution(resolution, family) {
  const tl = resolution?.topLevel;
  if (!tl) return null;
  // v2.0: collapse v1.0 variants to plain 'end_at_k' for pill selection.
  // The variant field still carries its value through onConfirm, so older
  // engine readers (and future 13-C.8) can interpret it if desired.
  if (tl === 'end_at_k') return 'end_at_k';
  return tl;
}

export function GameResolutionRow({ gameRow, resolution, onChange }) {
  if (!gameRow) return null;
  const { gameKey, label, family, topLevelOptions = [], segments = [], presses = [] } = gameRow;
  const selectedValue = optionValueFromResolution(resolution, family);

  // v2.0: any `end_at_k` selection on clinch or completion family expands
  // per-segment pills. (v1.0 only `closed_and_open` expanded clinch.)
  // Hole-by-hole never expands.
  const tl = resolution?.topLevel;
  const isClinchEnd     = family === 'clinch'     && tl === 'end_at_k';
  const isCompletionEnd = family === 'completion' && tl === 'end_at_k';
  const expanded        = isClinchEnd || isCompletionEnd;

  const handleTopLevel = (value) => {
    onChange(gameKey, partialFromOption(value));
  };

  const handleSegment = (segKey, decision) => {
    onChange(gameKey, { segments: { [segKey]: decision } });
  };

  const handlePress = (pressKey, decision) => {
    onChange(gameKey, { presses: { [pressKey]: decision } });
  };

  return (
    <div style={{ padding: '10px 0', borderTop: '1px solid #eee' }}>
      <div style={{ fontWeight: 700, fontSize: 13, color: G, marginBottom: 8 }}>
        {label}
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: expanded ? 8 : 0 }}>
        {topLevelOptions.map(opt => {
          const isSelected = opt.value === selectedValue;
          return (
            <button
              key={opt.value}
              type="button"
              aria-pressed={isSelected}
              onClick={() => handleTopLevel(opt.value)}
              style={pillStyle(isSelected)}
            >
              {opt.label}
            </button>
          );
        })}
      </div>

      {expanded && (
        <div style={{ marginTop: 4 }}>
          {segments.map(seg => (
            <BetPillRow
              key={seg.segKey}
              label={seg.label}
              status={seg.status}
              decision={resolution?.segments?.[seg.segKey] ?? 'pay'}
              onChange={(d) => handleSegment(seg.segKey, d)}
            />
          ))}
          {/* Presses — only shown for clinch family. The completion-family
              expansion shows segments only; presses[] is not populated
              for completion-family games anyway. */}
          {isClinchEnd && presses.map(p => (
            <BetPillRow
              key={p.pressKey}
              label={p.label}
              status={p.status}
              decision={resolution?.presses?.[p.pressKey] ?? 'pay'}
              onChange={(d) => handlePress(p.pressKey, d)}
              indented
            />
          ))}
        </div>
      )}
    </div>
  );
}
