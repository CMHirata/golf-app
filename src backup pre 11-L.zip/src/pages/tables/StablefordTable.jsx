// ─── tables/StablefordTable.jsx ───────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js

import { stabPts } from '../../engine/handicap.js';
import { S, nameTd, scoringLabel } from '../scorecard/scorecardUtils.js';
import { GameSection, GameTable, HalfLabel, TableDivider, ColNote, PlayerChips } from '../scorecard/GameSection.jsx';
import { RED } from '../../components/ui.jsx';

const FRONT = [0,1,2,3,4,5,6,7,8];
const BACK  = [9,10,11,12,13,14,15,16,17];

export function StablefordTable({ players, scores, pars, hcps, opts, courseHcps, minCourseHcp, stablefordPlayers, isLandscape }) {
  const mode = opts?.grossNetNOL ?? opts?.scoring ?? 'net';

  const activeIdxs = stablefordPlayers?.length ? stablefordPlayers : players.map((_, i) => i);

  const displayMin = (mode === 'netofflow' && activeIdxs.length)
    ? Math.min(...activeIdxs.map(i => courseHcps[i]))
    : minCourseHcp;

  const scoreHole = (pi, h) => {
    const g = parseInt(scores[h]?.[pi]);
    if (!g) return null;
    return stabPts(g, pars[h], courseHcps[pi], hcps[h], displayMin, mode, opts?.stabTable);
  };
  const vColor = v => v === null ? '#ccc' : v >= 3 ? '#27ae60' : v === 0 ? RED : '#555';

  const subsetPlayers = activeIdxs.map(pi => ({ p: players[pi], pi })).filter(({ p }) => p);

  const renderHalf = (hs, label) => {
    const halves = players.map((_, pi) => hs.reduce((s, h) => s + (scoreHole(pi, h) ?? 0), 0));
    return (
      <>
        <HalfLabel>{label}</HalfLabel>
        <div style={{ padding: '0 8px 4px' }}>
          <GameTable hs={hs} colHeader={hs[0] === 0 ? 'F9' : 'B9'} headerBg={S.hdrBg} headerColor={S.hdrClr} totBg={S.totBg} totColor={S.totClr}>
            {subsetPlayers.map(({ p, pi }, rowIdx) => {
              const holePts = hs.map(h => scoreHole(pi, h));
              return (
                <tr key={pi} style={{ background: S.row[rowIdx % 2] }}>
                  <td style={{ ...nameTd, color: S.hdrClr }}>{p.name}</td>
                  {holePts.map((v, i) => <td key={i} style={{ textAlign: 'center', fontSize: 11, color: vColor(v), fontWeight: v != null && v >= 3 ? 700 : 400 }}>{v === null ? '·' : v}</td>)}
                  <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: S.totClr, background: S.totBg, padding: '2px 4px' }}>{halves[pi]}</td>
                </tr>
              );
            })}
          </GameTable>
        </div>
      </>
    );
  };

  const renderAll18 = () => {
    const frontHalves = players.map((_, pi) => FRONT.reduce((s, h) => s + (scoreHole(pi, h) ?? 0), 0));
    const backHalves  = players.map((_, pi) => BACK.reduce((s, h)  => s + (scoreHole(pi, h) ?? 0), 0));
    return (
      <div style={{ padding: '0 8px 4px' }}>
        <GameTable landscape headerBg={S.hdrBg} headerColor={S.hdrClr} totBg={S.totBg} totColor={S.totClr}>
          {subsetPlayers.map(({ p, pi }, rowIdx) => {
            const frontPts = FRONT.map(h => scoreHole(pi, h));
            const backPts  = BACK.map(h => scoreHole(pi, h));
            return (
              <tr key={pi} style={{ background: S.row[rowIdx % 2] }}>
                <td style={{ ...nameTd, color: S.hdrClr }}>{p.name}</td>
                {frontPts.map((v, i) => <td key={i} style={{ textAlign: 'center', fontSize: 11, color: vColor(v), fontWeight: v != null && v >= 3 ? 700 : 400 }}>{v === null ? '·' : v}</td>)}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: S.totClr, background: S.totBg, padding: '2px 3px' }}>{frontHalves[pi]}</td>
                {backPts.map((v, i) => <td key={i+9} style={{ textAlign: 'center', fontSize: 11, color: vColor(v), fontWeight: v != null && v >= 3 ? 700 : 400 }}>{v === null ? '·' : v}</td>)}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: S.totClr, background: S.totBg, padding: '2px 3px' }}>{backHalves[pi]}</td>
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, color: S.totClr, background: S.totBg, padding: '2px 3px' }}>{frontHalves[pi] + backHalves[pi]}</td>
              </tr>
            );
          })}
        </GameTable>
      </div>
    );
  };

  const subsetTotals = subsetPlayers.map(({ pi }) =>
    [...Array(18).keys()].reduce((s, h) => s + (scoreHole(pi, h) ?? 0), 0)
  );

  return (
    <GameSection title="Stableford" badge={scoringLabel(mode)} color={S.hdrClr} borderColor={S.border}>
      {isLandscape ? (
        renderAll18()
      ) : (
        <>
          {renderHalf(FRONT, 'Front 9')}
          <TableDivider/>
          {renderHalf(BACK, 'Back 9')}
        </>
      )}
      <TableDivider/>
      <PlayerChips
        players={subsetPlayers.map(({ p }) => p)}
        values={subsetTotals}
        chipBg={S.hdrBg} chipColor={S.hdrClr}
        leaderBg={S.totBg} leaderColor={S.totClr}
        fmtVal={v => v} subLabel="pts"
      />
      <ColNote>3+ = birdie or better · 2 = par · 1 = bogey · 0 = double+</ColNote>
    </GameSection>
  );
}
