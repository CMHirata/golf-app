// ─── tables/StrokePlayTable.jsx ───────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js

import { scoreForMode } from '../../engine/handicap.js';
import { P, nameTd, scoringLabel } from '../scorecard/scorecardUtils.js';
import { GameSection, GameTable, HalfLabel, TableDivider, ColNote } from '../scorecard/GameSection.jsx';
import { RED } from '../../components/ui.jsx';

const FRONT = [0,1,2,3,4,5,6,7,8];
const BACK  = [9,10,11,12,13,14,15,16,17];

export function StrokePlayTable({ players, scores, pars, hcps, opts, courseHcps, minCourseHcp, strokePlayPlayers, isLandscape }) {
  const mode = opts?.grossNetNOL ?? opts?.scoring ?? 'gross';

  const activeIdxs = strokePlayPlayers?.length ? strokePlayPlayers : players.map((_, i) => i);

  const displayMin = (mode === 'netofflow' && activeIdxs.length)
    ? Math.min(...activeIdxs.map(i => courseHcps[i]))
    : minCourseHcp;

  const fmtDiff = v => v === null ? '·' : v === 0 ? 'E' : v > 0 ? `+${v}` : `${v}`;
  const diffClr = v => v === null ? '#ddd' : v < 0 ? '#27ae60' : v > 0 ? RED : '#555';

  const playerStats = players.map((_, pi) => {
    let cum = 0, thru = 0;
    const byHole = [];
    for (let h = 0; h < 18; h++) {
      const g = parseInt(scores[h]?.[pi]);
      if (!g) { byHole.push(null); continue; }
      const net = scoreForMode(g, courseHcps[pi], hcps[h], displayMin, mode);
      cum += net - pars[h];
      thru++;
      byHole.push(net - pars[h]);
    }
    return { byHole, cum, thru };
  });

  const subsetPlayers = activeIdxs.map(pi => ({ p: players[pi], pi })).filter(({ p }) => p);

  const renderHalf = (hs, label) => {
    const halves = players.map((_, pi) => hs.reduce((s, h) => s + (playerStats[pi].byHole[h] ?? 0), 0));
    return (
      <>
        <HalfLabel>{label}</HalfLabel>
        <div style={{ padding: '0 8px 4px' }}>
          <GameTable hs={hs} colHeader={hs[0] === 0 ? 'F9' : 'B9'} headerBg={P.hdrBg} headerColor={P.hdrClr} totBg={P.totBg} totColor={P.totClr}>
            {subsetPlayers.map(({ p, pi }, rowIdx) => {
              const { byHole } = playerStats[pi];
              const anyPlayed  = hs.some(h => byHole[h] !== null);
              return (
                <tr key={pi} style={{ background: P.row[rowIdx % 2] }}>
                  <td style={{ ...nameTd, color: P.hdrClr }}>{p.name}</td>
                  {hs.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 11, color: diffClr(byHole[h]), fontWeight: byHole[h] != null && byHole[h] <= -1 ? 600 : 400 }}>{fmtDiff(byHole[h])}</td>)}
                  <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: P.totClr, background: P.totBg, padding: '2px 4px' }}>{anyPlayed ? fmtDiff(halves[pi]) : '·'}</td>
                </tr>
              );
            })}
          </GameTable>
        </div>
      </>
    );
  };

  const renderAll18 = () => {
    const frontHalves = players.map((_, pi) => FRONT.reduce((s, h) => s + (playerStats[pi].byHole[h] ?? 0), 0));
    const backHalves  = players.map((_, pi) => BACK.reduce((s, h)  => s + (playerStats[pi].byHole[h] ?? 0), 0));
    return (
      <div style={{ padding: '0 8px 4px' }}>
        <GameTable landscape headerBg={P.hdrBg} headerColor={P.hdrClr} totBg={P.totBg} totColor={P.totClr}>
          {subsetPlayers.map(({ p, pi }, rowIdx) => {
            const { byHole } = playerStats[pi];
            const anyF = FRONT.some(h => byHole[h] !== null);
            const anyB = BACK.some(h => byHole[h] !== null);
            return (
              <tr key={pi} style={{ background: P.row[rowIdx % 2] }}>
                <td style={{ ...nameTd, color: P.hdrClr }}>{p.name}</td>
                {FRONT.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 11, color: diffClr(byHole[h]), fontWeight: byHole[h] != null && byHole[h] <= -1 ? 600 : 400 }}>{fmtDiff(byHole[h])}</td>)}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: P.totClr, background: P.totBg, padding: '2px 3px' }}>{anyF ? fmtDiff(frontHalves[pi]) : '·'}</td>
                {BACK.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 11, color: diffClr(byHole[h]), fontWeight: byHole[h] != null && byHole[h] <= -1 ? 600 : 400 }}>{fmtDiff(byHole[h])}</td>)}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: P.totClr, background: P.totBg, padding: '2px 3px' }}>{anyB ? fmtDiff(backHalves[pi]) : '·'}</td>
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, color: P.totClr, background: P.totBg, padding: '2px 3px' }}>{(anyF || anyB) ? fmtDiff(playerStats[pi].cum) : '·'}</td>
              </tr>
            );
          })}
        </GameTable>
      </div>
    );
  };

  const sorted = [...subsetPlayers.map(({ p, pi }) => ({ p, pi, stat: playerStats[pi] }))].sort((a, b) => a.stat.cum - b.stat.cum);
  const n = sorted.length;

  return (
    <GameSection title="Stroke Play" badge={scoringLabel(mode)} color={P.hdrClr} borderColor={P.border}>
      {isLandscape ? (
        renderAll18()
      ) : (
        <>
          {renderHalf(FRONT, 'Front 9')}
          <TableDivider/>
          {renderHalf(BACK, 'Back 9')}
        </>
      )}
      <TableDivider/>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${n}, 1fr)`, gap: 6, padding: '6px 8px 8px' }}>
        {sorted.map(({ p, pi, stat }, rank) => {
          const parts = (p?.name || '').trim().split(/\s+/);
          const first = parts[0] || '?';
          const last  = parts.length >= 2 ? parts[parts.length - 1] : '';
          return (
            <div key={pi} style={{ textAlign: 'center', borderRadius: 8, padding: '5px 4px', background: rank === 0 && stat.thru > 0 ? P.totBg : P.hdrBg, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: P.hdrClr, lineHeight: 1.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{first}</div>
              {last && <div style={{ fontSize: 10, fontWeight: 400, color: P.hdrClr, opacity: 0.65, lineHeight: 1.2, marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{last}</div>}
              <div style={{ fontSize: 15, fontWeight: 700, color: stat.thru > 0 ? diffClr(stat.cum) : '#aaa' }}>{stat.thru > 0 ? fmtDiff(stat.cum) : '—'}</div>
              <div style={{ fontSize: 10, color: '#aaa' }}>{stat.thru > 0 ? `thru ${stat.thru}h` : '—'}</div>
            </div>
          );
        })}
      </div>
      <ColNote>Each hole = score vs par · F9/B9 col = half total vs par</ColNote>
    </GameSection>
  );
}
