// ─── ResultsPage.jsx ──────────────────────────────────────────────────────────
import { useState, useCallback } from 'react';
import { Btn, Card, G, RED, ShareOrientationPicker } from '../components/ui.jsx';
import { computePerMatchPayouts, cleanGameName, triggerRoundShare, buildShareImage } from '../services/roundUtils.js';
import { roundLib } from '../services/roundLib.js';

// Layout constants — must match App.jsx
const NAV_BAR_HEIGHT    = 68;
const ACTION_BAR_HEIGHT = 52;

function fmtMoney(v) {
  return v > 0 ? `+$${Math.abs(v).toFixed(2)}` : v < 0 ? `-$${Math.abs(v).toFixed(2)}` : '$0';
}

// ── DotsColTable ───────────────────────────────────────────────────────────────
// Renders the columnar Dots payout breakdown when team mode is active.
// Detected by presence of entry.colHeaders on the breakdown entry.
function DotsColTable({ entry }) {
  if (!entry?.colHeaders?.length || !entry?.rows?.length) return null;
  const headers   = entry.colHeaders;
  const rows      = entry.rows;
  const colClr    = v => v > 0 ? '#27ae60' : v < 0 ? RED : '#888';
  const isTot     = (i) => i === headers.length - 1;
  const COL_W     = 52;  // px — fixed width for each data column
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11,
                    marginTop: 2, tableLayout: 'fixed' }}>
      <colgroup>
        <col/>  {/* name column — takes all remaining space */}
        {headers.map((_, i) => <col key={i} style={{ width: COL_W }}/>)}
      </colgroup>
      <thead>
        <tr>
          <td style={{ padding: '2px 0', color: '#888', fontSize: 10 }}></td>
          {headers.map((h, i) => (
            <td key={i} style={{ padding: '2px 4px',
                                  textAlign: isTot(i) ? 'right' : 'center',
                                  color: '#888',
                                  fontSize: 10, fontWeight: isTot(i) ? 700 : 500,
                                  borderBottom: '1px solid #e8f0e8',
                                  whiteSpace: 'nowrap' }}>
              {h}
            </td>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, ri) => (
          <tr key={ri} style={{ borderBottom: '1px solid #f8f8f8' }}>
            <td style={{ padding: '2px 0', color: '#555', fontSize: 11,
                         overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {r.name}
            </td>
            {(r.matchCols || []).map((v, ci) => (
              <td key={ci} style={{ padding: '2px 4px',
                                     textAlign: isTot(ci) ? 'right' : 'center',
                                     fontWeight: isTot(ci) ? 700 : 600,
                                     color: colClr(v), fontSize: isTot(ci) ? 12 : 11,
                                     whiteSpace: 'nowrap' }}>
                {fmtMoney(v)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ── SectionLabel ───────────────────────────────────────────────────────────────
function SectionLabel({ children, style }) {
  return (
    <div style={{ fontSize:11, fontWeight:700, color:G, marginBottom:6, marginTop:14,
      textTransform:'uppercase', letterSpacing:'0.5px', ...style }}>
      {children}
    </div>
  );
}

// ── SubHeader ─────────────────────────────────────────────────────────────────
function SubHeader({ children }) {
  return (
    <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:3, paddingBottom:2,
      borderBottom:'1px solid #e8f0e8' }}>
      {children}
    </div>
  );
}

// ── PayRow ────────────────────────────────────────────────────────────────────
function PayRow({ name, net, i }) {
  return (
    <div key={i} style={{ display:'flex', justifyContent:'space-between', fontSize:11,
      padding:'2px 0', borderBottom:'1px solid #f8f8f8' }}>
      <span style={{ color:'#555' }}>{name}</span>
      <span style={{ fontWeight:600, color: net>0?'#27ae60':net<0?RED:'#888' }}>{fmtMoney(net)}</span>
    </div>
  );
}

// ── ResultsDisplay ─────────────────────────────────────────────────────────────
function ResultsDisplay({ breakdown, bank, matchPayouts }) {
  const payoutRows = Object.entries(bank || {}).sort((a, b) => b[1] - a[1]);

  const otherEntries = (breakdown || []).filter(e =>
    e.game !== '🥊 Match / Nassau' && e.game !== 'Match / Nassau'
  );

  return (
    <div>
      <SectionLabel style={{ marginTop:4 }}>Payouts</SectionLabel>

      <div style={{ background:G, borderRadius:14, padding:'12px 16px', marginBottom:4 }}>
        <div style={{ fontWeight:800, fontSize:14, color:'#fff', marginBottom:8 }}>Total — All Games</div>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <tbody>
            {payoutRows.map(([name, amount], i) => (
              <tr key={i}>
                <td style={{ padding:'6px 8px', color:'#fff', fontWeight:600, fontSize:13 }}>{name}</td>
                <td style={{ padding:'6px 8px', textAlign:'right', fontSize:16, fontWeight:800,
                  color: amount>0 ? '#7fff7f' : amount<0 ? '#ffaaaa' : '#fff' }}>
                  {fmtMoney(amount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionLabel>By Game</SectionLabel>

      {matchPayouts.map((match, mi) => {
        const nonZero = match.rows.filter(r => r.net !== 0);
        if (!nonZero.length) return null;
        return (
          <div key={`match_${mi}`} style={{ marginBottom:10 }}>
            <SubHeader>{match.label}</SubHeader>
            {nonZero.map((r, i) => <PayRow key={i} name={r.name} net={r.net} i={i} />)}
          </div>
        );
      })}

      {otherEntries.map((entry, ei) => {
        // Team Dots: always render when colHeaders present — do not suppress on zero-net rows.
        if (entry.colHeaders) {
          return (
            <div key={`game_${ei}`} style={{ marginBottom:10 }}>
              <SubHeader>{cleanGameName(entry.game)}</SubHeader>
              <DotsColTable entry={entry}/>
            </div>
          );
        }
        const rows = (entry.rows || []).filter(r => r.net != null && r.net !== 0);
        if (!rows.length) return null;
        return (
          <div key={`game_${ei}`} style={{ marginBottom:10 }}>
            <SubHeader>{cleanGameName(entry.game)}</SubHeader>
            {rows.map((r, i) => <PayRow key={i} name={r.name} net={r.net} i={i} />)}
          </div>
        );
      })}
    </div>
  );
}

function getMissingScoresError(scores, activePlayers) {
  const numHoles   = 18;
  const numPlayers = (activePlayers || []).length;
  const byPlayer   = {};

  for (let h = 0; h < numHoles; h++) {
    for (let pi = 0; pi < numPlayers; pi++) {
      const val = scores?.[h]?.[pi];
      if (val === '' || val === null || val === undefined) {
        const name = activePlayers[pi]?.name || `Player ${pi + 1}`;
        if (!byPlayer[name]) byPlayer[name] = [];
        byPlayer[name].push(h + 1);
      }
    }
  }

  if (Object.keys(byPlayer).length === 0) return null;

  const lines = Object.entries(byPlayer).map(([name, holes]) => {
    const holeList = holes.length <= 6
      ? `hole${holes.length > 1 ? 's' : ''} ${holes.join(', ')}`
      : `${holes.length} holes`;
    return `${name}: missing ${holeList}`;
  });
  return `Scores incomplete — cannot save.\n${lines.join('\n')}`;
}

export default function ResultsPage({ getActiveRound, onSave, onBack }) {
  const [saveMsg,        setSaveMsg]        = useState('');
  const [shareStatus,    setShareStatus]    = useState('idle');
  const [shareError,     setShareError]     = useState('');
  const [showOrienPick,  setShowOrienPick]  = useState(false);
  const ar = getActiveRound();

  const matchPayouts = (() => {
    if (!ar) return [];
    if (!(ar.activeGames || []).includes('Match / Nassau')) return [];
    try {
      return computePerMatchPayouts(
        ar.matches || [], ar.activePlayers, ar.scores, ar.hcps,
        ar.courseHcps, ar.minCourseHcp, ar.manualPresses || {}
      );
    } catch(e) {
      console.error('ResultsPage: computePerMatchPayouts failed', e);
      return [];
    }
  })();

  const handleShare = useCallback(() => {
    if (!ar) return;
    setShowOrienPick(true);
  }, [ar]);

  const handleShareWithOrientation = useCallback(async (orientation) => {
    if (!ar) return;
    setShowOrienPick(false);
    setShareStatus('building');
    setShareError('');
    try {
      const rShim = { ...roundLib.fromActiveRound(ar), id: ar.roundId || undefined };
      const blob  = await buildShareImage(rShim, ar, ar.bank || {}, ar.breakdown || [], matchPayouts, orientation);
      await triggerRoundShare(rShim, ar, ar.bank || {}, ar.breakdown || [], matchPayouts, blob, orientation);
      setShareStatus('done');
    } catch(err) {
      if (err?.name === 'AbortError') { setShareStatus('idle'); return; }
      console.error('Share failed:', err);
      setShareError('Could not share. Try again.');
      setShareStatus('error');
    }
  }, [ar, matchPayouts]);

  if (!ar) {
    return (
      <div style={{ padding: 40, textAlign:'center', color:'#aaa' }}>
        <div>No active round.</div>
        <Btn onClick={onBack} style={{ marginTop: 16 }}>← Back</Btn>
      </div>
    );
  }

  const { roundDate, course, activePlayers, breakdown, bank, courseHcps, scores, minCourseHcp, manualPresses } = ar;
  const hasScores    = (ar.scores || []).some(r => r.some(s => s !== ''));
  const missingError = getMissingScoresError(ar.scores, activePlayers);
  const canSave      = hasScores && !missingError;

  const handleSave = () => {
    setSaveMsg('');
    if (missingError) { setSaveMsg('Error: ' + missingError); return; }
    try {
      onSave();
      setSaveMsg('Saved! View in History tab.');
      setTimeout(() => setSaveMsg(''), 6000);
    } catch(e) {
      setSaveMsg(`Save failed: ${e.message}`);
    }
  };

  const n = (activePlayers || []).length;

  // Total bottom clearance: action bar height + nav bar + button protrusion + gap
  const bottomClearance = NAV_BAR_HEIGHT + ACTION_BAR_HEIGHT + 30;
  // Action bar sits flush on top of nav bar; paddingBottom absorbs button protrusion
  const actionBarBottom = NAV_BAR_HEIGHT;

  return (
    <div style={{ minHeight:'100vh', background:'#eef4ee' }}>

      {/* Sticky header */}
      <div style={{ background:G, padding:'8px 16px 7px', position:'sticky', top:0, zIndex:10, boxShadow:'0 2px 12px rgba(0,0,0,.2)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <img src="/logo_lockup.png" alt="The Card" style={{ height:58, width:'auto', display:'block' }} />
        <div style={{ color:'#fff', fontWeight:800, fontSize:16, letterSpacing:'0.12em', textTransform:'uppercase', fontFamily:'inherit' }}>Results</div>
      </div>

      {/* Scrollable content — paddingBottom clears pinned bar + nav */}
      <div style={{ padding:'14px 14px', maxWidth:520, margin:'0 auto', paddingBottom:`calc(${bottomClearance}px + env(safe-area-inset-bottom))` }}>

        {/* R-5: Player chips */}
        {n > 0 && (
          <div style={{ display:'grid', gridTemplateColumns:`repeat(${n}, 1fr)`, gap:6, marginBottom:12 }}>
            {(activePlayers || []).map((p, i) => {
              const hi  = p.ghin != null && p.ghin !== '' ? p.ghin : null;
              const ch  = (courseHcps || [])[i] != null ? (courseHcps || [])[i] : (p.courseHcpVal ?? null);
              const tee = p.selectedTee || '';
              const hasHiCh = hi != null || ch != null;
              return (
                <div key={i} style={{ background:'#fff', borderRadius:12, padding:'8px 10px', minWidth:0, boxShadow:'0 1px 4px rgba(0,0,0,.06)', border:'1.5px solid #e0ece0' }}>
                  <div style={{ fontWeight:700, color:G, fontSize:12, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{p.name}</div>
                  {hasHiCh && (
                    <div style={{ fontSize:10, marginTop:2, color:'#888' }}>
                      {hi != null && <span>HI {hi}</span>}
                      {hi != null && ch != null && <span> · </span>}
                      {ch != null && <span>CH {ch}</span>}
                    </div>
                  )}
                  {tee && <div style={{ fontSize:10, color:'#aaa', marginTop:1 }}>{tee}</div>}
                </div>
              );
            })}
          </div>
        )}

        {!hasScores && (
          <Card><div style={{ textAlign:'center', color:'#aaa', padding:36 }}>Enter scores to see results.</div></Card>
        )}
        {hasScores && <ResultsDisplay breakdown={breakdown} bank={bank} matchPayouts={matchPayouts} />}

        {hasScores && missingError && (
          <div style={{ padding:'10px 12px', borderRadius:8, margin:'10px 0', background:'#fff8e1', border:'1.5px solid #f0c040', color:'#7a5800', fontSize:13, whiteSpace:'pre-line' }}>
            {missingError}
          </div>
        )}

        {saveMsg && (
          <div style={{ padding:'8px 12px', borderRadius:8, margin:'10px 0',
            background: saveMsg.startsWith('Saved') ? '#e8f5e8' : '#fce8e8',
            color:      saveMsg.startsWith('Saved') ? '#27ae60' : RED,
            fontSize:13, whiteSpace:'pre-line' }}>
            {saveMsg}
          </div>
        )}

        {shareStatus === 'error' && (
          <div style={{ fontSize:12, color:RED, marginTop:6 }}>{shareError}</div>
        )}
      </div>

      {showOrienPick && (
        <ShareOrientationPicker
          onPick={handleShareWithOrientation}
          onDismiss={() => setShowOrienPick(false)}
        />
      )}

      {/* ── Pinned action bar: ← Scorecard | Save Round | Share ── */}
      {/* Flush on nav bar top. paddingBottom: 13px clears 5px button protrusion. */}
      <div style={{
        position: 'fixed',
        bottom: `calc(${actionBarBottom}px + env(safe-area-inset-bottom))`,
        left: 0, right: 0,
        zIndex: 20,
        background: '#eef4ee',
        borderTop: '1px solid #d4e8d4',
        padding: '8px 12px 16px',
      }}>
        <div style={{ display:'flex', gap:8, maxWidth:520, margin:'0 auto' }}>
          <Btn variant="outline" onClick={onBack} style={{ flex:1 }}>← Scorecard</Btn>
          <Btn
            onClick={handleSave}
            style={{ flex:1, opacity:canSave?1:0.5, cursor:canSave?'pointer':'not-allowed' }}
          >
            Save Round
          </Btn>
          <Btn
            variant="ghost"
            onClick={handleShare}
            disabled={shareStatus==='building'}
            style={{ flex:1 }}
          >
            {shareStatus==='building' ? 'Building…' : shareStatus==='done' ? 'Shared ✓' : 'Share'}
          </Btn>
        </div>
      </div>

    </div>
  );
}
