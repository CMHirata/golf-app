# Stableford Contract

_Version 1.4 — April 2026_
_Supersedes: Stableford Contract v1.3._
_Changes in v1.4: `gameOpts.Stableford.scoring` renamed to `gameOpts.Stableford.grossNetNOL` throughout. §3.1, §4.2, §8.1, §9.2 schema updated._
_Changes in v1.3: §1.3 — `betMode` field replaces `stabBetMode`; values `'nassau'` and `'single'` retired from UI; new values `'perpoint'` (default) and `'segments'`. Default changed from `'nassau'` to `'perpoint'`. Engine fallback chain documented. §4.1 — bet mode semantics updated. §8.1 — schema updated._
_Status: AUTHORITATIVE_
_All implementation must conform to this contract._
_If code conflicts with this contract, the contract wins._

---

**Engine file(s):** `engine/games.js`, `engine/payouts.js`, `engine/handicap.js`
**Table component:** `pages/tables/StablefordTable.jsx`
**Payout logic location:** `payouts.js` — Stableford block (search `activeGames.includes('Stableford')`)
**Cross-references:**
- `Handicap_Contract.md` §6 — `stabPts`, `DEFAULT_STAB`, scoring modes
- `Handicap_Contract.md` §5 — NOL+subset invariant; `subsetMin()` pattern
- `Payout_Contract.md` §4.3 — `subsetMin()` universal implementation rule
- `Payout_Contract.md` §7.4 — Stableford payout block spec
- `App_Data_Model_Contract.md` §5.5 — `gameOpts.Stableford` schema (v2.0, `nassauMode` removed)
- `App_Data_Model_Contract.md` §5.8 — `stablefordPlayers` field
- `App_Data_Model_Contract.md` §10 — `buildPayoutArgs` synchronization rule

---

## §1. Overview and Game Identity

### §1.1 Plain-language description

Stableford is a points-based individual scoring format. Each player earns
points on every hole based on how their score compares to par (after
handicap adjustment). Higher points are better. The game accumulates points
across 18 holes and settles at the end of the round according to the
configured payout mode. Two payout modes are available in the current UI:
per-point (pairwise point-differential payouts, default) and F/B/T
(three independent segment bets). Unlike Match Play, no hole-by-hole
settlement occurs — only end-of-round payout.

### §1.2 Game key (activeGames entry)

The string identifier in `activeGames[]` for this game is: `'Stableford'`

This must match exactly what is stored in `activeRound.activeGames`, used
in the `computePayouts()` conditional block, and displayed in game config
UI. A mismatch causes silent non-payout.

### §1.3 Format variants

| Variant | UI label | Stored `betMode` | Description | Configured by |
|---|---|---|---|---|
| `'perpoint'` | Per Point | `'perpoint'` | Pairwise point-differential payouts; `bet` moves per point of differential across all unordered player pairs. **Default.** | `gameOpts.Stableford.betMode` |
| `'segments'` | F/B/T | `'segments'` | Three independent segments (F9, B9, 18-hole); highest points per segment wins `bet` (or per-segment `betF`/`betB`/`bet18`) from each other participant; sole winner only (tied = no payout) | `gameOpts.Stableford.betMode` |

Default variant: **`'perpoint'`** (changed from `'nassau'` in v1.3).

> **Legacy values retired from UI:** `'nassau'` and `'single'` are no longer
> written by the setup UI. Engine fallback chain:
> `opts.betMode ?? opts.stabBetMode ?? 'perpoint'`
> Migration shim (`roundLib.migrateRecord`): `'nassau'` → `'segments'`;
> `'single'` → `'perpoint'`. Any value other than `'perpoint'` or `'segments'`
> falls to the single-winner else-branch in the payout engine.

---

## §2. Eligibility and Players

### §2.1 Valid player counts

| Player count | Valid? | Notes |
|---|---|---|
| 2 | Yes | All three modes work; `perpoint` produces one pairwise comparison |
| 3 | Yes | Subset picker shown (`players.length > 2`) |
| 4+ | Yes | Subset picker shown |

Minimum required: 2 players in the subset.
Maximum allowed: no hard maximum (practical limit is active players in round).

> **Subset picker trigger:** The `PlayerSubsetChips` picker in `NewRoundPage`
> is rendered only when `players.length > 2`. With exactly 2 players there is
> no picker and both always participate. This is a UI guard, not an engine constraint.

### §2.2 Subset support

Yes — Stableford supports a player subset.

- **State field:** `activeRound.stablefordPlayers` — type: `number[]` (player
  indices); `[]` = all players participate
- **History record field:** `stableford_players` — mapped by `roundLib.fromActiveRound`
- **`buildPayoutArgs` key:** `stablefordPlayers` — passed as top-level field
- **Engine parameter name:** `stabIdxs` (derived inside `computePayouts()` from
  `stablefordPlayers`; not a direct engine function parameter)
- **Selection UI:** `PlayerSubsetChips` in `NewRoundPage`, shown only when
  `players.length > 2`
- **Subset is fixed at:** Round creation (setup screen)
- **Changing subset mid-round:** Undefined behavior. The engine derives
  `stabMin` (NOL baseline) from the subset at payout time; changing the subset
  mid-round would silently recalculate with a different baseline.

**Subset resolution in engine:**
```js
const stabIdxs = stablefordPlayers?.length
  ? stablefordPlayers
  : players.map((_, i) => i);
```
Empty array (`[]`) means all players participate.

### §2.3 Multi-instance support

No. There is exactly one Stableford game per round. The `activeGames` array
may contain `'Stableford'` at most once. The payout block fires once.

### §2.4 Team structure

N/A — Stableford is an individual scoring game. No teams.

---

## §3. Scoring

### §3.1 Scoring modes

Three modes are supported, configured per round via `gameOpts.Stableford.grossNetNOL`:

| Mode | Description |
|---|---|
| `'net'` | Each player's gross score is reduced by their per-hole stroke allocation. Default. |
| `'gross'` | Raw scores used with no handicap adjustment. |
| `'netofflow'` | Strokes received are relative to the lowest course handicap in the Stableford subset (not the full-field minimum — see §3.4). |

Default: `'net'`.

### §3.2 Score comparison unit

Points per hole, accumulated across holes. Comparison is always by total
point accumulation — never by hole-by-hole result or direct score comparison.

### §3.3 Team scoring rule

N/A — individual game; no team scoring.

### §3.4 Handicap application

Per-hole net score is computed by `scoreForMode(gross, courseHcp, rank, minCourseHcp, mode)` inside `stabPts`. See Handicap Contract §6.

**NOL+subset rule:** When `mode === 'netofflow'`, the `minCourseHcp` reference
value must be the minimum course handicap among the Stableford subset
participants only — not the full-field minimum. This is implemented via:

```js
const stabMin = subsetMin(cHcps, stabIdxs, minCHcp, mode);
```

See Payout Contract §4.3 and Handicap Contract §5. ✅ Implemented in payout engine.
✅ Implemented in display component (`displayMin` via subset-min logic in `StablefordTable`).

### §3.5 Points table

Points per hole are determined by `stabPts(gross, par, courseHcp, rank, minCourseHcp, mode, stabTable)` in `handicap.js`.

The lookup key is `d = clamp(par − net, −3, 3)` where positive `d` = under par (good).

**Sign convention (counterintuitive — read carefully):**
Because `d = par − net`, a _positive_ key means under par and a _negative_
key means over par. Key `'3'` = albatross (3 under par) = 5 points.
Key `'-3'` = triple bogey or worse = 0 points.

**`DEFAULT_STAB`** (from `handicap.js`):

| Key (`d = par − net`) | Score relative to par | Points |
|---|---|---|
| `'3'` | Albatross / 3 under | 5 |
| `'2'` | Eagle / 2 under | 4 |
| `'1'` | Birdie / 1 under | 3 |
| `'0'` | Par | 2 |
| `'-1'` | Bogey | 1 |
| `'-2'` | Double bogey | 0 |
| `'-3'` | Triple bogey or worse | 0 |

```js
export const DEFAULT_STAB = { '-3':0, '-2':0, '-1':1, '0':2, '1':3, '2':4, '3':5 };
```

> **Warning — storage direction:** More-negative keys represent _worse_ scores.
> Key `'-3'` = triple bogey = 0 pts. Key `'3'` = albatross = 5 pts. This is the
> reverse of a descending-key points scale. The implementation is correct. Do not
> reorder or invert keys.

**Custom table:** `gameOpts.Stableford.stabTable` — an object with any subset
of string keys `'-3'` through `'3'`. `null` means use `DEFAULT_STAB`. Missing
keys in a custom table return 0. Configurable per-round in `NewRoundPage`.

Keys outside the range `'-3'` to `'3'` are silently ignored — `d` is always
clamped to `[-3, 3]` before the lookup, so out-of-range keys can never be
reached and should not be stored.

```js
const t = stabTable || DEFAULT_STAB;
return t[String(d)] ?? 0;
```

### §3.6 Missing score behavior

If `gross` is falsy (0, null, undefined, empty string), `stabPts` returns
`null`. `calcStablefordTotal` treats `null` as 0 via the `?? 0` guard:

```js
return sum + (g ? stabPts(...) ?? 0 : 0);
```

A missing score on any hole contributes 0 points. An unscored hole is treated
as a worst-case result (no points), not excluded from scoring.

### §3.7 Segment relevance

| Segment | Holes (0-based indices) | Used in |
|---|---|---|
| Front 9 | 0–8 | `'segments'` mode F9 bet; display sub-table |
| Back 9 | 9–17 | `'segments'` mode B9 bet; display sub-table |
| Full 18 | 0–17 | All payout modes; display chip bar totals |

---

## §4. Betting and Payout Structure

### §4.1 Bet type

One `bet` amount, whose meaning varies by payout mode:

- **`'segments'` mode:** `bet` = default dollars paid by each loser to the winner of each segment. Per-segment overrides `betF` (F9), `betB` (B9), `bet18` (18-hole) take precedence when set; each falls back to `bet` if `0` or absent. Maximum exposure per player = `betF + betB + bet18`.
- **`'perpoint'` mode:** `bet` = dollars per point of differential paid between each unordered pair. Exposure is proportional to point spread.
- **Single-winner else-branch:** `bet` = dollars paid by each non-winner to the sole winner. Maximum exposure for losers = `(n − 1) × bet`. Triggered by any stored value other than `'perpoint'` or `'segments'`.

### §4.2 Bet config fields

All stored in `gameOpts.Stableford`:

| Field | Type | Default | Description |
|---|---|---|---|
| `bet` | `number` | `0` | Dollar unit per the active payout mode; also the segments per-segment fallback |
| `grossNetNOL` | `'net'`\|`'gross'`\|`'netofflow'` | `'net'` | Scoring mode for point calculation |
| `betMode` | `'perpoint'`\|`'segments'` | `'perpoint'` | Payout mode. Canonical field as of v1.3. Engine reads: `betMode ?? stabBetMode ?? 'perpoint'` |
| `stabTable` | `object\|null` | `null` | Custom points table; null = use DEFAULT_STAB |
| `betF` | `number` | `0` | Segments mode: F9 bet override; falls back to `bet` if `0` or absent |
| `betB` | `number` | `0` | Segments mode: B9 bet override; falls back to `bet` if `0` or absent |
| `bet18` | `number` | `0` | Segments mode: 18-hole bet override; falls back to `bet` if `0` or absent |

> `betF`, `betB`, `bet18` are only meaningful in `'segments'` mode. In other modes they are ignored by the engine.

### §4.3 Press support

N/A — Stableford does not support presses. No `PressModal` involvement.
No `manualPresses` keys are created or read for Stableford.

### §4.4 Tiebreak rules

**`'segments'` mode:** Tied segment (two or more players share the highest
point total for that segment) = no payout for that segment. The sole-winner
guard `sorted[0]?.[field] > (sorted[1]?.[field] ?? -Infinity)` enforces this:
if the top two values are equal (regardless of how many players share that
value), the condition is false and no money moves for that segment.

**`'perpoint'` mode:** Zero point differential between two players = no
movement. No tie penalty.

**Single-winner else-branch:** If two or more players share the highest 18-hole total,
no payout occurs:
```js
pts18[0]?.pts > (pts18[1]?.pts ?? -Infinity)
```

### §4.5 Carryover

N/A — no carryover mechanism in Stableford.

---

## §5. Payout Formulas

### §5.1 Payout structure type

- `'segments'` mode: per-player, per-segment, winner-takes-all (three segments)
- `'perpoint'` mode: per-player-pair, proportional to point differential
- Single-winner else-branch: per-player, sole-winner-takes-all (one settlement)

### §5.2 Zero-sum proof

**`'segments'` mode** (N players, sole winner per segment):
Winner: `+(N − 1) × bet`. Each loser: `−bet`. Sum = 0. ✓ (Per segment; three independent.)

**`'perpoint'` mode:**
Every dollar credited to player i is debited from player j: net per pair = 0.
Sum over all pairs = 0. ✓

**Single-winner else-branch:**
Winner: `+(N − 1) × bet`. Each loser: `−bet`. Sum = 0. ✓

### §5.3 `'segments'` mode payout formula

Three segments evaluated independently: F9 (`ptsF`), B9 (`ptsB`), 18-hole (`pts`).

Per-segment bet amounts: `stabBetF = betF ?? bet`, `stabBetB = betB ?? bet`, `stabBet18 = bet18 ?? bet`. Each falls back to the base `bet` when the override is `0` or absent.

For each segment:
1. Sort all subset players descending by that segment's point field.
2. Sole-winner check: `sorted[0][field] > sorted[1][field]` (using the
   **segment-specific field**, not always `'pts'`).
3. If sole winner: each non-winner pays `segBet` to winner.
4. If tied at the top: no money moves for this segment.

```js
const payNassauStab = (arr, field, segBet) => {
  if (segBet <= 0) return;
  const sorted = [...arr].sort((a, b) => b[field] - a[field]);
  stabPs.forEach(p => {
    if (p.name !== sorted[0]?.name &&
        sorted[0]?.[field] > (sorted[1]?.[field] ?? -Infinity)) {
      gb[p.name] -= segBet;
      gb[sorted[0].name] += segBet;
    }
  });
};
payNassauStab(pts18, 'ptsF', stabBetF);
payNassauStab(pts18, 'ptsB', stabBetB);
payNassauStab(pts18, 'pts',  stabBet18);
```

**Previously fixed bug:** The guard formerly used `sorted[0].pts > sorted[1].pts`
(always the 18-hole field) for all three segments — incorrect when the F9 or B9
winner differed from the 18-hole leader. Fixed to use `sorted[0]?.[field]`.
**Do not revert to the `.pts` form.**

### §5.4 `'perpoint'` mode payout formula

Evaluate all unordered pairs `(i, j)` where `i < j`:

```js
const diff = ranked[i].pts - ranked[j].pts;
if (diff > 0) {
  gb[ranked[i].name] += diff * bet;
  gb[ranked[j].name] -= diff * bet;
}
```

Zero differential = no movement.

### §5.5 Single-winner else-branch payout formula

```js
if (bet > 0 && pts18[0]?.pts > (pts18[1]?.pts ?? -Infinity))
  payWinner(pts18[0].name, stabPs, bet, gb);
```

### §5.6 Incomplete round behavior

There is no segment-completeness guard in any payout mode. Payout is always
based on accumulated points through whatever holes have been scored. An
unplayed hole contributes 0 points (per §3.6) — it is not excluded from the
segment's evaluation.

**`'segments'` mode specifically:** F9 and B9 bets are evaluated on whatever
subset of holes 0–8 and 9–17 have been scored. A player who has only played
4 holes of the front 9 accumulates points from those 4 holes (the other 5
contribute 0). The segment winner is whoever has the most points from their
scored holes. There is no requirement that all 9 holes in a segment be scored
before the segment pays out. This matches the general "pay on accumulated
results" policy applied across all games in this app (see Payout Contract §9).

All participating players are evaluated over the same fixed hole sets (0–8
for F9, 9–17 for B9, 0–17 for 18-hole). Missing scores are 0 for all players
equally, preserving fairness of comparison.

---

## §6. Engine API

### §6.1 Engine function signatures

**Per-hole points — `handicap.js`:**
```js
stabPts(gross, par, courseHcp, rank, minCourseHcp, mode, stabTable)
  → number | null
```

**Segment / 18-hole total — `games.js`:**
```js
calcStablefordTotal(scores, pi, pars, hcps, courseHcp, minCourseHcp, mode, stabTable, holes)
  → number
```

| Param | Type | Description |
|---|---|---|
| `scores` | `number[][]` | `scores[hole][playerIndex]` |
| `pi` | `number` | Player index |
| `pars` | `number[18]` | Par per hole |
| `hcps` | `number[18]` | Stroke index per hole |
| `courseHcp` | `number` | Player's signed course handicap |
| `minCourseHcp` | `number` | Subset minimum course handicap |
| `mode` | `string` | Scoring mode |
| `stabTable` | `object\|null` | Point table |
| `holes` | `number[]` | 0-based hole indices to sum |

Returns: `number` — total points across specified holes (missing scores = 0).

### §6.2 Caller responsibilities

- Caller must pass `minCourseHcp` as the subset minimum (`subsetMin()` result),
  not the full-field minimum, when mode is `'netofflow'`.
- Caller must pass a valid `stabTable` object or `null`.
- Engine does not validate inputs.

### §6.3 Return value shape

`calcStablefordTotal` returns a plain `number`, never null.
`stabPts` returns `number | null` — null only when `gross` is falsy.

### §6.4 Calling convention

| Caller | Layer | Function called | Purpose |
|---|---|---|---|
| `payouts.js` (Stableford block) | Engine | `calcStablefordTotal` | Compute totals for payout |
| `StablefordTable.jsx` | UI (permitted direct call) | `stabPts` | Per-hole display only |

`StablefordTable.jsx` calling `stabPts` directly is a **permitted direct engine
call** per App Data Model Contract §4.

---

## §7. Display Component

### §7.1 Table component

`pages/tables/StablefordTable.jsx`

Begins with the standard render-only header:
```js
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js
```

### §7.2 Props received

| Prop | Type | Description |
|---|---|---|
| `players` | `Player[]` | All active players (not pre-filtered to subset) |
| `scores` | `number[][]` | `scores[hole][playerIndex]` |
| `pars` | `number[18]` | Par per hole |
| `hcps` | `number[18]` | Stroke index per hole |
| `opts` | `object` | `gameOpts.Stableford` — includes `grossNetNOL`, `stabTable` |
| `courseHcps` | `number[]` | Course handicap per player (full array) |
| `minCourseHcp` | `number` | Full-field minimum (component derives its own `displayMin`) |
| `stablefordPlayers` | `number[]` | Subset indices; `[]` = all players |

### §7.3 Display layout

```
GameSection "Stableford" [badge: scoringLabel(mode)]
  HalfLabel "Front 9"
  GameTable  (holes 0–8, colHeader "F9", subset rows only)
  TableDivider
  HalfLabel "Back 9"
  GameTable  (holes 9–17, colHeader "B9", subset rows only)
  TableDivider
  PlayerChips (subset players, 18-hole totals)
  ColNote "3+ = birdie or better · 2 = par · 1 = bogey · 0 = double+"
```

### §7.4 Cell rendering

Each cell shows the points value for that player on that hole:
- Missing score (null from `stabPts`): renders as `'·'` (center dot)
- Integer points: renders as the number

### §7.5 Color tokens

| Condition | Color | Meaning |
|---|---|---|
| `v === null` | `'#ccc'` | No score entered |
| `v >= 3` | `'#27ae60'` (green) | Birdie or better |
| `v === 0` | `RED` from `ui.jsx` | Double bogey or worse |
| `v === 1` or `v === 2` | `'#555'` (grey) | Bogey or par |

Font weight: bold (`700`) when `v >= 3`; otherwise `400`.

### §7.6 Totals display

`PlayerChips` footer shows 18-hole point totals for subset players only.
Player with highest total receives `leaderBg/leaderColor` styling. Sub-label: `"pts"`.

### §7.7 NOL display baseline

`displayMin` is computed inside `StablefordTable` from the `stablefordPlayers`
subset (not from `minCourseHcp` prop):

```js
const displayMin = (mode === 'netofflow' && activeIdxs.length)
  ? Math.min(...activeIdxs.map(i => courseHcps[i]))
  : minCourseHcp;
```

This mirrors the `stabMin` computation in `payouts.js`, ensuring the scorecard
display agrees with payout calculations for NOL+subset rounds.

### §7.8 scorecardUtils helpers

`scoringLabel(mode)` — called for the `GameSection` badge text.

---

## §8. Configuration Schema

### §8.1 `gameOpts.Stableford` shape

```js
gameOpts.Stableford = {
  bet:         number,                           // default 0; segments per-segment fallback
  grossNetNOL: 'net' | 'gross' | 'netofflow',  // default 'net'
  betMode:     'perpoint' | 'segments',         // default 'perpoint'; canonical field as of v1.3
                                                // engine reads: betMode ?? stabBetMode ?? 'perpoint'
  stabTable:   object | null,                   // default null (= DEFAULT_STAB)
  betF:        number,                          // segments F9 override; 0/absent → falls back to bet
  betB:        number,                          // segments B9 override; 0/absent → falls back to bet
  bet18:       number,                          // segments 18-hole override; 0/absent → falls back to bet
}
```

### §8.2 `activeRound` fields

| Field | Type | Location | Notes |
|---|---|---|---|
| `gameOpts.Stableford` | object | `activeRound.gameOpts` | See §8.1 |
| `stablefordPlayers` | `number[]` | `activeRound` top-level | `[]` = all players |

### §8.3 `buildPayoutArgs` fields consumed by Stableford block

```js
{
  players,             // activePlayers array
  pars,                // number[18]
  hcps,                // number[18]
  scores,              // number[][]
  activeGames,         // must include 'Stableford'
  gameOpts,            // .Stableford sub-object consumed
  stablefordPlayers,   // subset indices; [] = all
  courseHcps,          // number[] — full array; stabMin derived internally
  minCourseHcp,        // full-field min; subsetMin() applied internally
}
```

### §8.4 History record fields

| History field | `activeRound` source | `roundLib` function |
|---|---|---|
| `stableford_players` | `stablefordPlayers` | `fromActiveRound`, `toActiveRound`, `toSetupState` |
| `game_opts` blob | `gameOpts` | all three — via full `gameOpts` blob |

All three `roundLib` schema-conversion functions handle `stableford_players`. ✅

---

## §9. Validation Rules (NewRoundPage)

| Guard | Where | Behavior |
|---|---|---|
| Subset picker shown only when `players.length > 2` | `NewRoundPage` | `PlayerSubsetDropdown` not rendered for 2-player rounds |
| `betMode` default | `NewRoundPage` | Falls back to `'perpoint'` if not set |
| Custom `stabTable` inputs | `NewRoundPage` | `parseInt` + `!isNaN` + `>= 0` validation per key; non-integers rejected |
| "Reset defaults" button | `NewRoundPage` | Restores `DEFAULT_STAB` spread |

The engine does not validate `betMode`, `stabTable`, `stablefordPlayers`, or `bet`.
All validation is the UI layer's responsibility.

---

## §10. Press UI Contract

N/A — Stableford does not support presses. No `PressModal` involvement.
No `manualPresses` keys are created or read for Stableford.

---

## §11. Derived Values — Must Not Be Stored

| Value | Computed by |
|---|---|
| Per-hole Stableford points | `stabPts()` in `handicap.js` |
| Segment point totals (F9, B9, 18) | `calcStablefordTotal()` in `games.js` |
| Payout amounts (`gb` → `bank`) | `computePayouts()` in `payouts.js` |
| `stabMin` (payout NOL baseline) | `subsetMin()` inside `computePayouts()` |
| `displayMin` (display NOL baseline) | inline computation inside `StablefordTable` |

None of the above may be written to `activeRound` or history records.

---

## §12. Architecture Boundary

| Layer | Files | Role |
|---|---|---|
| Engine | `handicap.js`, `games.js`, `payouts.js` | All point and payout computation. Source of truth. |
| Display logic | `scorecardUtils.js` | `scoringLabel()` for badge text only. |
| UI | `StablefordTable.jsx`, `ScoreGrid.jsx` | Renders data; `stabPts` direct call permitted. |

### §12.1 Layer rules

- All Stableford point values originate from `stabPts()` in `handicap.js`.
- `calcStablefordTotal()` accumulates points by calling `stabPts` per hole.
- `computePayouts()` is the payout engine — calls `calcStablefordTotal` per player/segment.
- `StablefordTable.jsx` may call `stabPts` directly for per-hole display. This is the
  only permitted direct engine call from the UI layer for this game.
- Payout math must not appear in any UI component.

---

## §13. Invariants

1. **Zero-sum:** Payout net values across all Stableford subset players sum to zero for each mode. (Proof in §5.2.)
2. **Pure functions:** `stabPts`, `calcStablefordTotal`, and the Stableford block in `computePayouts` are pure and deterministic.
3. **Missing score = 0 points:** A falsy gross score produces `null` from `stabPts`, treated as 0 by all callers.
4. **`d` clamped to `[−3, 3]`:** Scores better than albatross or worse than triple bogey are clamped.
5. **Subset indices stable:** `stablefordPlayers` indices must not change during an active round.
6. **`stabMin` ≤ every participant's `courseHcp`:** By construction of `subsetMin()`.
7. **`stabTable` keys are strings:** Lookup uses `String(d)`. Numeric keys will not match. Custom tables must use string keys `'-3'`–`'3'`.
8. **`bet === 0` suppresses payout:** All three mode blocks guard on `bet > 0`.
9. **Nassau sole-winner guard uses segment field:** `sorted[0]?.[field]` with the segment-specific `field` argument. Using `'.pts'` for F9 or B9 is the previously fixed bug. Do not revert.
10. **`stablefordPlayers` persisted correctly:** All three `roundLib` functions handle `stableford_players`. ✅
11. **Non-participants appear in `bank` at 0:** Players not in `stabIdxs` are never charged or credited.
12. **`computePayouts()` is called from `App.jsx` only.**
13. **Single instance only:** `'Stableford'` appears at most once in `activeGames[]`.
14. **`displayMin` matches `stabMin`:** `StablefordTable` uses the same subset-min logic as `payouts.js`, so scorecard display and payout always agree on NOL baselines.
15. **Engine assumes subset immutability:** `calcStablefordTotal` and the payout block in `computePayouts` assume `stablefordPlayers` is constant for the duration of the round. The engine performs no validation of this assumption. The state layer (`ScorecardPage`) is solely responsible for ensuring the subset does not change mid-round. Violation produces silent incorrect NOL baselines.
16. **Display layer must not compute totals or rankings independently:** `StablefordTable` may call `stabPts` for per-hole display values only. It must not accumulate totals for the purpose of ranking players or determining winners. All ranking logic must originate from the engine (`computePayouts`). Totals shown in the `PlayerChips` footer are display-only and carry no payout authority.

---

## §14. Known Gaps and Open Items

| # | Severity | Description | Status |
|---|---|---|---|
| ~~G-1~~ | ~~Medium~~ | ~~`nassauMode` field — read but never used; purpose unresolved~~ | ✅ **CLOSED** |
| ~~G-2~~ | ~~Low~~ | ~~`StablefordTable` display uses full-field `minCourseHcp`, not subset-adjusted `stabMin`~~ | ✅ **CLOSED** |

### ~~G-1 — `nassauMode` field~~ ✅ CLOSED

`gameOpts.Stableford.nassauMode` was confirmed dead code — read in `payouts.js`
but never used in any conditional branch. Not present in any display component,
engine caller, `NewRoundPage`, or any contract. Removed from `payouts.js` and
`App_Data_Model_Contract.md` §5.5 (v2.0). Old records containing this field are
harmless (engine ignores unknown fields). No migration needed.

### ~~G-2 — `StablefordTable` display NOL baseline~~ ✅ CLOSED

`StablefordTable.jsx` now accepts a `stablefordPlayers` prop and computes
`displayMin` using the same subset-min logic as `payouts.js`. The scorecard
display and payout engine now agree on the NOL baseline for all combinations
of scoring mode and subset.

Prop threading added:
- `ScorecardPage`: destructures `stablefordPlayers` from `ar`; passes to `ScoreGrid`
- `ScoreGrid`: added `stablefordPlayers` to props destructure; passes to `StablefordTable`
- `StablefordTable`: accepts `stablefordPlayers`; derives `activeIdxs` and `displayMin`

---

## §15. Examples

### §15.1 Nassau mode — 4 players, F9 sole winner, B9 tie, 18-hole tie

```
Setup: Alice, Bob, Carol, Dave (all in subset)
  bet = $5, betMode = 'segments', grossNetNOL = 'net'

Segment totals:   F9    B9   18
  Alice:          19    16   35
  Bob:            17    18   35
  Carol:          17    18   35
  Dave:           15    14   29

F9 (field='ptsF'): Alice(19) > Bob(17) → sole winner → Alice +$15, others −$5 each
B9 (field='ptsB'): Bob(18) = Carol(18) → tie → no payout
18 (field='pts'):  Alice(35) = Bob(35) = Carol(35) → tie → no payout

Final: Alice +$15, Bob −$5, Carol −$5, Dave −$5  |  Sum = $0 ✓
```

### §15.2 Per-point mode — 3 players

```
Setup: Alice(38 pts), Bob(33 pts), Carol(30 pts)
  bet = $2, betMode = 'perpoint'

Alice vs Bob:  diff=5 → Alice +$10, Bob −$10
Alice vs Carol: diff=8 → Alice +$16, Carol −$16
Bob vs Carol:  diff=3 → Bob +$6, Carol −$6

Final: Alice +$26, Bob −$4, Carol −$22  |  Sum = $0 ✓
```

### §15.3 Single mode — sole winner and tie

```
Case A: Alice(34), Bob(30) — sole winner → payWinner('Alice', ..., $10, gb)
  Alice +$10, Bob −$10  |  Sum = $0 ✓

Case B: Alice(32), Bob(32) — tie → no payout
  Alice $0, Bob $0  |  Sum = $0 ✓
```

### §15.4 Per-hole points — stabPts

```
Hole: par 4, mode='net', courseHcp=12, hcp rank=5 → player gets a stroke → net = gross−1

gross=3 (eagle):  net=2 → d=4−2=2  → 4 pts
gross=4 (birdie): net=3 → d=4−3=1  → 3 pts
gross=5 (par):    net=4 → d=4−4=0  → 2 pts
gross=6 (bogey):  net=5 → d=4−5=−1 → 1 pt
gross=7 (double): net=6 → d=4−6=−2 → 0 pts
gross=9:          net=8 → d=−4 → clamped to −3 → 0 pts
gross=0 (missing):        → stabPts returns null → treated as 0
```

---

## §16. Final Rule

If implementation behavior conflicts with this contract, call out the
conflict. The implementation must be corrected. This document defines the truth.

---

## Template Validation Checklist

- [x] Every placeholder filled or N/A'd
- [x] §2.2 documents both state field name and engine parameter name
- [x] §3.4 specifies `subsetMin()` requirement — both payout and display
- [x] §4.2 documents `bet` meaning per mode
- [x] §4.3 explicitly N/A (no press support)
- [x] §5.2 zero-sum proof for all three modes
- [x] §6.1 engine function signatures match actual code
- [x] §6.4 specifies callers and layers
- [x] §8.3 lists all `buildPayoutArgs` fields consumed
- [x] §9 documents all UI guards
- [x] §13 invariants include universal invariants
- [x] §14 Known Gaps — both G-1 and G-2 closed ✅
- [x] §15 examples arithmetically verified
- [x] Cross-references accurate
- [x] Added to Document Index in `APP_STATE_SUMMARY.md` ✅
