# The Card — Master Build Plan

_Last updated: April 2026 — Session 11-M complete + Portrait Share Report + Portrait PDF + Post-11-M bug fixes (all confirmed on device)_
_Maintained in this chat as the authoritative sequence and history of all build sessions._
_The APP_STATE_SUMMARY.md in the project knowledge base is the authoritative record of_
_what is implemented. This file is the authoritative record of what was planned, why,_
_and in what order — including items that shifted, were skipped, reinstated, or renumbered._

---

## Critical Rules for All Future Sessions

1. **Contracts before code.** Any item marked "contract first" below must have a contract
   amendment approved before a single line of implementation code is written.

2. **Session naming is owner-assigned.** Claude must never auto-assign new session
   designations (e.g. creating "11-B" when it doesn't exist in this plan). Sub-tasks within
   a session are labeled as phases (Phase 1, Phase 2). New session rows in APP_STATE_SUMMARY.md
   are only added when the owner explicitly provides the designation.

3. **APP_STATE_SUMMARY.md is not a bug tracker.** Open items live there; closed items are
   struck through. The external spreadsheet is the master bug/feature tracker.

4. **Do not remove open items from ASS** without confirmed on-device testing by owner.

5. **Derived values are never stored.** All derived state is computed from the activeRound blob.

6. **`restoreDotDefs()` is critical.** Must always be called before using dots from any
   serialized state. Was `restoreAutoWhen()` prior to Session 11-A rename.

7. **`betType` is a static config concept only.** It lives in the `GAME_CONFIGS` constant
   and must never be stored in `gameOpts`, `activeRound`, or any persisted state.
   Decision made in 11-G-1. Do not revisit without owner approval.

8. **Nassau terminology is retired from all user-facing surfaces.** The behavior is exposed
   as Front/Back/Overall segment bet fields. Decision made in 11-G-1. Do not reintroduce
   "Nassau" as a UI term without explicit owner approval.

---

## Numbering History & Collision Notes

The session numbering in this project has a complex history. Key facts:

- **Sessions 1–9** were numbered sequentially as work progressed, not always matching
  the original sprint plan (which used Sprint 1/2/3 with lettered sub-sessions).
- **Sessions 11-B and 11-C** were auto-created by Claude mid-session during the Dots
  rework, colliding with planned future sessions. This was corrected: all three phases
  of the Dots rework were collapsed into **11-A** in the ASS.
- **11-B** in this plan = Shared GameTable shell (deferred to post-Sprint 12).
- **11-C** in this plan = Match/Nassau team hole display (completed).
- **11-D** in this plan = Fixed-width player name fields + PlayerDropdown component system (completed but scope exceeded plan; not audited until 11-E — see Completed Sessions for full detail).
- **11-E** in this plan = Disabled Btn fix + NOL label consistency + 11-D audit (completed; confirmed on device).
- **11-G** was originally planned as a single session (NOL subset display). It was
  expanded in planning session **11-G** (formerly 11-G-1) into five sessions after
  architectural debt was identified. The downstream sessions were initially named
  11-G-2/3/4 then renumbered to **11-H, 11-I, 11-J, 11-K** for cleanliness.
  **11-G is a planning-only session** (no code). 11-H is the UX design spec session.
  11-I is the betting model refactor. 11-J is per-match labeling. 11-K is NOL dots.
- **13-C** was discussed but deferred back (early-end / partial round) — still planned.

---

## Key Architectural Decisions Made in Planning Sessions

These are decisions made during planning that should not be revisited without good reason:

1. **Contracts are authoritative over code.** When contract language and implementation
   conflict, contracts win. Code is updated to match.

2. **Write contracts before fixing engines.** The contract defines the spec the engine
   fix must conform to.

3. **Derived values are never stored.** All derived state computed from activeRound blob.

4. **Session naming is owner-assigned.** Claude never invents new session designations.

5. **Generic swipe component** extracted when adding swipe to Players/Courses (12-F),
   not before — avoid premature abstraction.

6. **Dots/Specials shim removal** only after owner confirms all saved rounds have been
   opened and re-exported. Do not rush this.

7. **Per-player tee selection (13-B)** is its own full session — high risk, do not bundle.

8. **Late player join (14-D)** is complex enough to require its own contract and should
   not be attempted until owner explicitly schedules it.

9. **The `resolveDisplayNames` approach** was tried in 11-D then superseded by a post-session
   patch: the final convention is to always show first name (larger/darker) + last name
   (smaller/lighter) unconditionally, without collision detection. Simpler, more readable,
   no edge cases. `resolveDisplayNames` was removed from most consumers after this decision.

10. **`PlayerDropdown.jsx`** is a new shared component created in 11-D housing `PlayerDropdown`,
    `StyledSel`, and `ReadOnlyBubble`. All player picker UI in New Round setup should use
    these components. Do not create parallel picker implementations.

11. **Scope creep in 11-D is documented, not penalized.** The PlayerDropdown work was
    valuable and the results are good. The lesson is: when a session's scope expands
    significantly mid-session, the ASS must be updated to reflect what actually happened —
    not what was planned.

12. **Nassau terminology retired (11-G).** The betting behavior formerly called "Nassau"
    is exposed as Front/Back/Overall (segment) bet fields applied selectively per game.
    `betType` is a static UI dispatch concept in `GAME_CONFIGS` — never stored in round state.
    Shared bet config components (`<SegmentBetConfig>`, `<RateBetConfig>`, `<PotBetConfig>`)
    are written once and reused across all games that share the same betting model.

13. **Wolf is the next planned game format.** `GAME_CONFIGS` design in 11-I must preserve
    a clean extension point for Wolf's rotating-player and doubling mechanics. Owner has
    confirmed Wolf will not be added until rest of app is considered solid.

14. **NOL dot selector design (11-K).** When NOL is the active dot mode and a subset/match
    game excludes the round's low-handicap player, a unified segmented pill control appears
    (replacing the Net/NOL toggle). All segments are in a single bordered pill: Net (if mixed
    round) / NOL / NOL Skins / NOL Match A / etc. Games with identical participant sets are
    merged into one button (e.g. "NOL Skins / Match A"). Switching to Net resets to NOL field
    view. ZoomModal inherits the selection. Match instances use persistent labels from 11-J.
    Hint text row removed from scorecard. Center button from setup tab now triggers
    handleStart (same as Start Scoring) to commit config changes before navigating.

---

## Completed Sessions

| Session | Scope | Notes |
|---|---|---|
| 1-A | Round lifecycle bugs + safety guards: cancel/delete in-progress round; New Round full reset; score-overwrite warning; history-load conflict check; "Round in Progress" banner suppressed on new round; date defaults to today | All confirmed |
| 1-B | History data integrity: static snapshot audit; loading old rounds restores game data; edit historical round settings load correctly | All confirmed |
| 1-C | Scorecard input bugs: score cell shift fix (`display:block`); Specials popup iOS copy/paste callout fix (`userSelect:none`) | All confirmed. E-1 (Specials totals) deferred to 11-A |
| 2 | History UX: swipe-left strip with real-time tracking; full-swipe delete; RoundSummaryModal; landscape scorecard 18-hole; per-match payouts; Stroke Index gender-aware labeling | All confirmed |
| 3 | ResultsPage redesign; RoundSummaryModal polish; per-match payout breakdown; named nine labels on scorecard; HomePage recent round tap opens modal; player chips in header | All confirmed |
| 4 | Back-to-setup fix (B-3); share sheet PNG via iOS native share; share from modal, ResultsPage, History swipe | All confirmed |
| 5 | Visual polish: logo, mint bg, SVG icons, swipe strip redesign, headers, player chips moved out of Results header | Confirmed (pending on-device) |
| 6 | Navigation overhaul: always-visible nav; logo super-tab; pinned action bars; scroll-to-top; divider removed between scorecard and chips | Confirmed (pending on-device) |
| 7 | Shared layout constants (`layout.js`); NewRoundPage extractions: `PlayerPickerPopup.jsx`, `MatchCard.jsx`, `GameConfig.jsx`; NewRoundPage reduced from 1,360→592 lines | Confirmed on device |
| 8 | CoursesPage full extraction: 5 components + helpers to courseLib.js | Confirmed on device |
| 9 | PWA: manifest.json, sw.js, PNG logos, home screen install | Confirmed on device |
| 10-A | RoundSummaryModal totals row; ESC (Adjusted Gross Score) in TotalsCard; `escTotal()` added to handicap.js; Handicap_Contract.md → v1.5 | Confirmed |
| 10-B | Visual regressions: logo heights + header consistency; landscape full-width fix (App.jsx maxWidth); MatchNassauTable isLandscape; Courses triangles removed; share image complete rework | All confirmed on device |
| 11-A | Dots (Specials) full rework: contract v2.0→v2.1; full Specials→Dots rename at all layers; DotsTable, DotsPopup, DotBadge; discrete scoring specials; mutual exclusivity; popup redesign; pivot summary tile; retroactive autoMark; App_Data_Model_Contract v2.5 | Complete — pending bulk round migration before shim removal |
| 11-C | D-1: Match/Nassau team hole winner display: slash-initials (C/D), colorblind-safe blue/red chips matching Sixes; color-coded header; Front 9 closure bug fixed (buildLeadState scoped to segment holes); Nassau_Match_Contract v2.4 | Confirmed on device |
| 11-D | Scope exceeded plan significantly. Planned: resolveDisplayNames + PlayerChips migration. Actually built: (1) `resolveDisplayNames` added to scorecardUtils.js; (2) `PlayerChips` added to GameSection.jsx; (3) TotalsCard, StrokePlayTable, PlayerSubsetChips migrated to first-name display; (4) **`PlayerDropdown.jsx` — entirely new file** with `PlayerDropdown`, `StyledSel`, `ReadOnlyBubble` components; (5) GameConfig.jsx Sixes team picker fully redesigned using PlayerDropdown; (6) MatchCard.jsx individual and team pickers rebuilt using PlayerDropdown/StyledSel; (7) All scoring/option selects across setup replaced with StyledSel. Post-session patch: name display convention changed from collision-aware first-name-only to unconditional first+last. | Confirmed on device |
| 11-E | Btn disabled style fix; NOL label audit (confirmed clean); name display convention unified; Sixes duplicate-team prevention | Confirmed on device |
| 11-F | Zoom score entry modal: ZoomModal.jsx (new), hidden-input keyboard pattern, 3-hole window, stacked player names, active-cell-only border, magnifying glass button, landscape zoom via zoomTriggerRef, DotsPopup position + focus coordination | Confirmed on device |
| 11-G | Planning session: NOL dot display design decision; betting model architecture (Nassau retired → segment betting); betType as static config; GAME_CONFIGS pattern; Wolf extension point; downstream sessions renamed 11-H/I/J/K | Complete — no code produced |
| 11-H | Design-only session: full NewRoundPage setup UI design spec. Game-by-game field inventory; all Phase 2 design decisions owner-confirmed; unified betting row pattern (`[Mode▼][field(s)]`); shared components identified (`<BetRow>`, `<SimpleBetRow>`, `<ScoringPills>`, `<PlayerSubsetDropdown>`); Players card redesign; pinned Start button; `GAME_CONFIGS` shape specified; section header decision deferred to on-device review. Output: `NewRoundPage_Design_Spec.md` | Complete — no code produced |
| 11-I.1 | Phase 0: full-page mockup produced and owner-approved. Phase 1: 6 contracts amended (App_Data_Model v2.7, Nassau_Match v2.5, Stableford v1.3, Nines v1.3, Skins v1.5, Stroke_Play v1.4) — `betMode` replaces game-specific field names, `carryover` boolean. Phase 2: engine read-site changes in payouts.js; SkinsTable carryover fix; roundLib migration shim; NewRoundPage Players card rebuilt and confirmed on device (two-row tiles, HIField, CHField with manual override, TeeDropdown, pinned Start button, GAME_CONFIGS constant, HI saves on blur); PlayerDropdown.jsx controls normalized; BetRow/SimpleBetRow/ScoringDropdown/PlayerSubsetDropdown shared components built; GameConfig.jsx and MatchCard.jsx partially rebuilt but games config UI not confirmed. Handoff doc: `handoff_11I1.md` | Players card confirmed on device ✅. Games config intentionally incomplete — full rebuild in 11-I.2 |
| 11-I.2 | Game config UI rebuild: component-first design from owner-provided mockups; all game config blocks rebuilt (Match, Skins, Stableford, Nines, Stroke Play, Sixes, Dots); MatchCard final state; full 11-I testing checklist on device. **Prep work completed in handoff session: engine `cumulative` tiebreak branch added in `games.js` (`runTeamMatch`, `calcSixesSegment`, `runSixesSegment`); `'half'` retained for back-compat, not offered in UI; contracts bumped (App_Data_Model v2.8, Sixes v1.8, Nassau_Match v2.6); Stableford Teams option grey/disabled in UI (Option Z — engine work pending 11-L).** **Implementation: `GameTile` unified morph tile (single container, hairline separator, pale-green fill, dark-green border); `BetSection` universal bet layout; `TeamPickerPair` shared team picker; `PlayerSubsetDropdown` C-2 chip closed state; `MatchCard` rebuilt as body-only (header owned by GameTile); Match A/B/C ephemeral labels from array index; Match placeholder tile (collapsed when off, per-match tiles when on); alphabetical game sort in display (stored order unchanged); "Match / Nassau" display-renamed to "Match"; games/player tiles sizing disciplined to 1fr/1fr/1fr grid; Sixes + Match team stacked left/right layout with vs separator; `firstNameOnly` prop on PlayerDropdown + ReadOnlyBubble; Stableford "Bogey"/"Double" labels; Dots subtitle collapsed-only; no contracts changed (pure UI session).** | ✅ Confirmed on device |
| 11-I.3 | **Semantic field rename** — pure cleanup, no behavior changes. Renamed `gameOpts.*.scoring` (`'gross'|'net'|'netofflow'`) → `grossNetNOL` across all games. Renamed `gameOpts.Sixes.tiebreak` and `matchDef.tiebreak` (team hole-scoring rule) → `scoring`. Phase 1: 10 contracts amended (App_Data_Model v2.9, Nassau_Match v2.7, Sixes v1.9, Skins v1.6, Stableford v1.4, Nines v1.4, Stroke_Play v1.6, Dots v2.2 + renamed to `Dots_Contract.md`, Payout v1.10, NewRoundPage_Design_Spec). Phase 2: 19 implementation files updated with backward-compat fallback chains throughout. Migration shims added to `roundLib.migrateRecord` (4 shims: grossNetNOL from old scoring, Sixes.scoring from tiebreak, matchDef.grossNetNOL from scoring, matchDef.scoring from tiebreak; 'half' remapped to 'none'). `App.jsx` `getActiveRound` applies live migration for in-progress rounds. `NewRoundPage` `allOpts` always writes `grossNetNOL` explicitly with correct per-game defaults. **Three pre-existing bugs fixed during testing:** (1) `StrokePlayTable` default fallback corrected `'net'` → `'gross'` — closes Stroke_Play_Contract G-1; (2) `SixesTable.holeWinFn` missing `cumulative` branch added; (3) `MatchNassauTable.teamHoleWinner` missing `cumulative` branch added. Function names `scoreForMode`/`strokesForMode` in `handicap.js` not renamed (deferred). | ✅ Confirmed on device |
| 11-J | Per-match instance labeling. Labels derived from current array index at render time — not stored; renumber on delete. `teamMode` changed from generic `'Match'` to `'Match:{matchId}'` (ID-based, stable). Migration shim in `roundLib.migrateRecord` converts legacy `'Match'` → `'Match:{firstTeamMatchId}'` or `'none'`. Dots dropdown enumerates per-instance "Match A Teams" / "Match B Teams" options. Match delete resets Dots `teamMode` when it references the deleted match. `MatchNassauTable` section headers show "Match A" / "Match B" (was "Nassau"/"Match"). Results payout sub-headers show "Match A" / "Match B" — "Match / Nassau" prefix fully purged from `ResultsPage`, `RoundSummaryModal`, and share image. Contracts: `App_Data_Model_Contract.md` → v3.0; `Nassau_Match_Contract.md` → v2.8. Files changed: `roundLib.js`, `roundUtils.js`, `MatchNassauTable.jsx`, `NewRoundPage.jsx`, `ScoreGrid.jsx`, `RoundSummaryModal.jsx`, `ResultsPage.jsx`. | ✅ Confirmed on device |
| 11-N | Round totals regression restore. `TotalsCard` was missing from `RoundSummaryModal` (never imported after 11-I/11-J rebuilds) and from the share image (`buildShareHtml` had no totals block). Fix: (1) added `import { TotalsCard } from './scorecard/TotalsCard.jsx'` to `RoundSummaryModal.jsx` and rendered it between `<ReadOnlyScorecard>` and the Game Results section with all five required props (`players`, `pars`, `scores`, `courseHcps`, `hcps`); (2) added `totalsHtml` IIFE in `roundUtils.buildShareHtml` after `scorecardHtml` and before the game results block — matching TotalsCard layout (green header "Round Totals" / "Par N" badge, per-player gross + ESC columns, alternating row bg). No contract changes. Files changed: `RoundSummaryModal.jsx`, `roundUtils.js`. | ✅ Confirmed on device |
| 11-M | Team Dots payout fix + Team Dots game table + Share image game tables + Portrait share report. **Contract:** `Dots_Contract.md` → v2.3 (team payout exclusion §7.6, per-segment breakdown §7.7, DotsTable team layout §10.5–§10.6, worked examples §15.6–§15.7). **DotsTable.jsx** rebuilt team-aware: Sixes = three 6-hole grids + A/B/C sub-column pivot; Match = F9/B9 grids + Team A/Team B pivot. Team dots hidden from by-hole grid cells (shown only in pivot Team row). Total row removed from grids. Column labels renamed (A/B/C → Total, Dots sum row → Total). `getMatchTeams`/`getMatchPairing` look up by matchId. **ScoreGrid.jsx** `autoMark` stale companion cleanup — deletes all `h_*_team_dot_for_pi` entries for the earner+hole before writing new companion, eliminating cross-contamination when teamMode switches between Sixes and Match. **DotsPopup.jsx** `writeCompanion` same stale-companion cleanup + `getPartner()` fixed to `startsWith('Match:')`. **payouts.js** Match team block: looks up team match by `matchId` from `teamSource` (not just `format==='team'`). **roundUtils.js** share image: (1) Dots pivot hand-built HTML updated with Match team A/B column groups and `allDotCnt` totals; (2) `deriveShareDotMode(ar)` — derives handicap dot display mode from active game `grossNetNOL` values (net > NOL-full > NOL-subset > gross); (3) portrait orientation support (`FO_WIDTH_PORTRAIT = 480`); handicap stroke dots now shown in share scorecard for all modes; `buildShareImage`/`triggerRoundShare` accept `orientation` param. **Portrait share report (out of scope, added same session):** `ShareOrientationPicker` bottom-sheet component added to `ui.jsx`; all three share surfaces (`ResultsPage`, `HistoryPage`, `RoundSummaryModal`) updated to show picker before building image; portrait scorecard splits into F9/B9 stacked tables. **Contracts:** `UI_Component_Contract.md` → v1.3 (§4.9 `ShareOrientationPicker`); `Round_Lifecycle_Contract.md` → v1.7 (§6.5 orientation picker, portrait layout spec, `deriveShareDotMode` rules). Files changed: `Dots_Contract.md`, `payouts.js`, `DotsPopup.jsx`, `DotsTable.jsx`, `ScoreGrid.jsx`, `roundUtils.js`, `ResultsPage.jsx`, `HistoryPage.jsx`, `RoundSummaryModal.jsx`, `ui.jsx`, `UI_Component_Contract.md`, `Round_Lifecycle_Contract.md`. | ✅ Confirmed on device |
| 11-K | NOL dot selector. Contract-first session. **Phase 1:** `Handicap_Contract.md` → v1.6 — unified segmented pill spec (§5.6–§5.14); qualifying game rule (active + NOL mode + subsetMin > minCourseHcp); subset grouping by fingerprint (merged labels e.g. "NOL Skins / Match A"); state ownership (`nolDotGame`); ZoomModal inheritance; architecture note. `Round_Lifecycle_Contract.md` → v1.6 — center button behavior updated (triggers `handleStart` when on setup tab); `manualPresses` preservation confirmed implemented (§2.6 gap closed, G-11 added). **Phase 2:** `scorecardUtils.js` — `computeNolDotOptions` helper (two-phase: qualify then group by fingerprint). `ScorecardPage.jsx` — `nolDotGame` state; two reset effects (dotMode change + validity check); `nolDotOptions`/`effectiveMinCourseHcp`/`nonParticipantIdxs` memos; unified pill render (right-justified, `flex-wrap`); hint text row removed. `ScoreGrid.jsx` — new props; all four `PopDots` call sites updated with `effectiveMinCourseHcp` + `nonParticipantIdxs` guard. `ZoomModal.jsx` — new props; pill moved below header (same size/style as scorecard); hint footer removed. **Bugs fixed during session:** (1) `manualPresses` not preserved on `handleStart` re-entry when lineup unchanged — fixed in `NewRoundPage.jsx`. (2) Center nav button from setup tab bypassed game config commit — fixed in `App.jsx` via `startTriggerRef` pattern (`handleCenterTap` calls `handleStart` when `tab === 'new-round' && inProgress`). (3) Qualifying condition was inverted (`<` → `>`). (4) `isNOL` guard missing — games in Net mode generated NOL pills. (5) `nolDotOptions` referenced before declaration (TDZ). Files changed: `Handicap_Contract.md`, `Round_Lifecycle_Contract.md`, `scorecardUtils.js`, `ScorecardPage.jsx`, `ScoreGrid.jsx`, `ZoomModal.jsx`, `NewRoundPage.jsx`, `App.jsx`. | ✅ Confirmed on device |

---

## Items Completed Out-of-Order or Under Different Session Names

| Original Plan Item | Completed In | Notes |
|---|---|---|
| B-3: Match display redesign | Session 3 | Per-match payout breakdown |
| B-5: Results page redesign | Session 3 | |
| B-7: Native share sheet | Session 4 | PNG via iOS share API |
| B-6: Graphic scorecard for share | Session 10-B | Complete rework; original was inadequate |
| C-3: Scroll-to-top on scorecard navigate | Session 6 | |
| C-6: Remove line between scorecard and chips | Session 6 | |
| C-10: Named nine labels on scorecard | Session 3 | |
| F-1: Bottom navigation on all pages | Session 6 | |
| F-3: Remove emojis / SVG icons | Session 5 | |
| J-1: App name + logo branding | Session 5 | |
| I-1: PWA / service worker | Session 9 | |
| A-11: Remove expand triangles | Sessions 6+10-B | Session 6 did most; Courses triangles fixed in 10-B |
| B-1: Static snapshot on save | Session 1-B | |
| B-2: Edit historical round settings | Session 1-B | |
| B-4: Loading old rounds restores game data | Session 1-B | |
| E-1: Specials totals rework | Session 11-A | Became full Dots rework |
| D-1: Match team hole winner display | Session 11-C | |
| C-1: Score field shift | Session 1-C | |
| C-2: Long-press iOS accidental input | Session 1-C | |
| C-4/C-5: Fixed-width chips + first-name display | Session 11-D | Exceeded scope — also produced PlayerDropdown.jsx, StyledSel, ReadOnlyBubble; full Sixes and MatchCard picker redesign |
| D-5: Sixes dropdown widths | Session 11-D | Absorbed into full Sixes picker redesign |
| F-2: UI G-5 disabled Btn | Session 11-E | Also included 11-D audit |
| F-4: NOL label consistency | Session 11-E | Audit confirmed already consistent — no code changes needed |
| D-4: Stableford F/B/O bet fields | 11-I | Absorbed into betting model refactor — do not implement in 12-A |
| D-8: Match numbering on cards | 11-J | Absorbed into per-match instance labeling session |
| C-11: NOL subset display per-game | 11-K | ✅ Complete — unified segmented pill with subset grouping; ZoomModal inheritance; center button fix |

---

## Items Skipped / Not Yet Done From Original Sprint Plan

| Item | Original Sprint | Current Status |
|---|---|---|
| A-5: Save game settings from prior round as defaults | Sprint 2-D | Open — Session 12-C |
| A-7: Per-player tee selection | Sprint 4-B | Open — Session 13-B (contract first) |
| A-8: Auto-export on save with correct naming | Sprint 4-A | Open — Session 13-A |
| A-9: Handicap multiplier | Sprint 5-E | Open — Session 14-C (contract first) |
| A-12: Remove "Default Tee" buttons from Setup | Sprint 2-D | Open — Session 12-C |
| B-8: Edit any history round (not just most recent) | Sprint 5-D | Open — Session 14-A |
| C-7: Birdie/bogey indicators on scorecard | Sprint 5-C | Open — Session 14-B (contract first) |
| C-8: Lock/pin scorecard toggle | Sprint 5-E | Open — Session 14-C |
| C-9: Zoomed score entry | Sprint 5-E | Completed in 11-F |
| D-2: "pts" label on Nines total chips | Sprint 3-B | Open — Session 12-B |
| D-3: Match status columns decision | Sprint 3-C | Open — Session 12-D |
| D-6: NinesTable renders only 3-player subset | Sprint 3-B | Open — Session 12-B |
| D-7: NinesTable breakdown rows filter | Sprint 3-B | Open — Session 12-B |
| F-5: Remove legacy shims | Sprint 5-A | Open — Session 14-A |
| F-6: Hint text review | Sprint 5-A | Open — Session 14-A |
| G-1: Starred players | Sprint 5-B | Open — Session 12-E |
| G-2: Leaderboard exclude/include | Sprint 5-B | Open — Session 12-E |
| H-1: Sahalee hole numbering + yardage | Sprint 5-A | Open — Session 14-A |
| I-2: iCloud-friendly export naming | Sprint 4-A | Open — Session 13-A |
| I-3: API key / Face ID security | Sprint 5-E | Open — Session 14-C |
| I-5: Delete hooks.js (dead code) | Sprint 5-A | Open — Session 14-A |

---

## New Items Added Post-Original-Plan (from owner spreadsheet + discoveries)

| Item | Priority | Session |
|---|---|---|
| Results F9/B9/Overall zeros bug | High | Completed in 10-A |
| Summary popup missing round totals | High | Completed in 10-A |
| Partial round / early end (player leaves) | High | Session 13-C (contract first) |
| Specials rework → became full Dots rework | High | Completed in 11-A |
| Setup continuity between games (shared bet fields) | Medium | Absorbed into 11-I |
| Course selection as popup (like player picker) | Medium | Session 12-C |
| Only show nine-selection for 3-nine courses | Medium | Session 12-C |
| Players/Courses swipe-left actions | Medium | Session 12-F |
| Late player join / missed early holes | Low | Session 14-D (contract first — complex) |
| PlayerDropdown / custom picker component | Done | Completed in 11-D |
| Shared GameTable shell documentation | Deferred | Session 11-B (deferred to post-Sprint 12) |
| ~~**Round totals tiles regression** — `TotalsCard` (per-player gross/net/ESC totals row) is missing from both `RoundSummaryModal` scorecard and the share image. Was working after 10-A; regressed during 11-I/11-J work. No contract changes expected — audit and restore only.~~ | ~~**High**~~ | ~~Session 11-N~~ ✅ Complete |
| ~~**Team Dots payout fix (Match team mode)**~~ | ~~**High**~~ | ~~Session 11-M~~ ✅ Complete |
| Portrait / Landscape share image orientation picker | Medium | Completed in 11-M (out of scope) |
| Portrait share as PDF (single tall page, no breaks) — `jsPDF` dependency added | Medium | Post-11-M incremental ✅ confirmed on device. Revert instructions in ASS. |
| Post-11-M bug fixes — SixesTable `opts` prop; `ReadOnlyScorecard` handicap dots; share image dots; Sixes pivot `pivotSegTot`; RLC → v1.8 | High | Post-11-M ✅ confirmed on device |

---

## Open Session Plan

Sessions are listed in recommended execution order. Items marked "contract first"
require a contract amendment to be written and approved before any code is produced.

---

### Sprint 11 — Remaining Sessions

**11-B: Shared GameTable shell** *(DEFERRED to post-Sprint 12)*
- Move GameTable/PlayerChips documentation into UI_Component_Contract.md
- Audit SkinsTable, SixesTable, MatchNassauTable, StrokePlayTable for further shared chrome
- Low urgency — patterns already working; this is a documentation + optional refactor pass
- Files: `GameSection.jsx`, `UI_Component_Contract.md`

**11-H: NewRoundPage UX/UI design spec** ✅ *Completed — April 2026 (no code produced)*
- Output: `NewRoundPage_Design_Spec.md` — authoritative reference for all 11-I sessions. Game-by-game field inventory; unified betting row pattern; shared component spec; GAME_CONFIGS shape; Players card redesign; section header decision made on-device in 11-I.1.

**11-I: Betting model refactor** ✅ *Completed across sessions 11-I.1, 11-I.2, 11-I.3 — April 2026*
- 11-I.1: 6 contracts amended; Players card rebuilt; shared components built.
- 11-I.2: Full game config UI rebuilt; all game tiles confirmed on device.
- 11-I.3: Semantic field rename (`scoring`→`grossNetNOL`, `tiebreak`→`scoring`); 10 contracts; 19 files; 3 bugs fixed.
- See Completed Sessions table for full detail on each sub-session.

**11-I.3: Semantic field rename** ✅ *Completed and confirmed on device — April 2026*
- Renamed `gameOpts.*.scoring` (`'gross'|'net'|'netofflow'`) → `grossNetNOL` across all games and MatchDef.
- Renamed `gameOpts.Sixes.tiebreak` and `matchDef.tiebreak` (team hole-scoring rule) → `scoring`.
- Final name `grossNetNOL` chosen (encodes all three values in the name) rather than `handicap` as originally planned.
- `scoreForMode`/`strokesForMode` function names in `handicap.js` not renamed — deferred to future cleanup session if desired.
- See completed sessions table for full detail.

**11-J: Per-match instance labeling** ✅ *Completed and confirmed on device — April 2026*
- Labels derive from current array index at render time (not stored); renumber on delete.
- `teamMode` changed from generic `'Match'` to `'Match:{matchId}'` (ID-based, stable).
- Migration shim in `roundLib.migrateRecord`: `'Match'` → `'Match:{firstTeamMatchId}'` or `'none'`.
- Match delete in `NewRoundPage` resets `teamMode` to `'none'` if it referenced the deleted match.
- Dots dropdown now enumerates per-instance options: "Match A Teams", "Match B Teams", etc.
- `MatchNassauTable` section header: "Match A", "Match B" (was "Nassau"/"Match").
- Results payout sub-headers: "Match A", "Match B" — Nassau terminology fully purged from `ResultsPage` and `RoundSummaryModal`.
- Share image payout section: same fix in `roundUtils.buildShareHtml`.
- Contracts: `App_Data_Model_Contract.md` → v3.0; `Nassau_Match_Contract.md` → v2.8.
- Files changed: `roundLib.js`, `roundUtils.js`, `MatchNassauTable.jsx`, `NewRoundPage.jsx`, `ScoreGrid.jsx`, `RoundSummaryModal.jsx`, `ResultsPage.jsx`.

**11-N: Round totals tiles regression** ✅ *Completed and confirmed on device — April 2026*
- `TotalsCard` import added to `RoundSummaryModal.jsx` (`'./scorecard/TotalsCard.jsx'`); rendered between `<ReadOnlyScorecard>` and Game Results section with all five props.
- `totalsHtml` block added to `roundUtils.buildShareHtml` after scorecard, before game tables — matching TotalsCard layout.
- No contract changes. Files changed: `RoundSummaryModal.jsx`, `roundUtils.js`.

**11-K: NOL dot selector** ✅ *Completed — pending on-device confirmation — April 2026*
- Contract: `Handicap_Contract.md` → v1.6; `Round_Lifecycle_Contract.md` → v1.6
- Unified segmented pill (Net / NOL / NOL Skins / NOL Match A / …) replaces old Net/NOL toggle
- Games with identical participant subsets merged into one button ("NOL Skins / Match A")
- ZoomModal inherits selection; pill rendered below header (not in green bar); hint footer removed
- Hint text row removed from scorecard control area
- Center nav button from setup tab now triggers `handleStart` — commits game config changes
- `manualPresses` preservation on lineup-unchanged re-entry fixed (pre-existing gap, RLC G-11)
- Files changed: `Handicap_Contract.md`, `Round_Lifecycle_Contract.md`, `scorecardUtils.js`,
  `ScorecardPage.jsx`, `ScoreGrid.jsx`, `ZoomModal.jsx`, `NewRoundPage.jsx`, `App.jsx`

**11-L: Stableford Teams engine support** *(contract first — unblocks UI)*
- **Purpose.** Enable the `Teams` format option on the Stableford game (UI built and disabled in 11-I.2 per Option Z). Engine currently scores Stableford as individual-only.
- **Engine work:** extend `calcStableford` in `games.js` (or add `calcTeamStableford`) to support team scoring. Team scoring rules to be defined in contract amendment — candidate approaches: (1) best-ball Stableford points per hole between two 2-player teams; (2) cumulative Stableford points per team per hole with tie-break rules matching Nassau team options. Owner to specify at contract-draft time.
- **Data model:** Stableford `gameOpts` gains optional `format: 'individual' | 'team'`, `teamA: number[]`, `teamB: number[]`, `tiebreak` (with the 11-I.2 scoring-rule semantics — **or** `scoring` if 11-I.3 has shipped first).
- **UI work:** enable the `Teams` option in the Stableford format dropdown. Wire up team-selection UI (already designed in 11-I.2 — reuse `<TeamPickerPair>`).
- **Contract:** `Stableford_Contract.md` → v1.5 (currently v1.4 after 11-I.3 rename). Add §N "Team Stableford" section with full scoring rules, team selection rules, scoring-rule semantics (use `scoring` field per 11-I.3 naming), payout formula.
- **Payouts:** `payouts.js` — extend Stableford payout calculation for team mode.
- **Migration:** not required (new fields; old rounds have no team fields → default to individual).
- **Priority:** Medium (feature work, not blocking)
- **Risk:** Medium — engine changes always require thorough testing; team-scoring rules are a design decision that needs owner input at contract-draft time.
- **Prerequisite:** 11-I.2 shipped. Ideally after 11-I.3 so field naming is final when team fields are added.

**11-M: Team Dots payout fix + Team Dots game table** ✅ *Completed and confirmed on device — April 2026*
- Contract: `Dots_Contract.md` → v2.3; `UI_Component_Contract.md` → v1.3; `Round_Lifecycle_Contract.md` → v1.7
- Match team settlement fixed (`matchId` lookup, stale companion cleanup in `autoMark` + `DotsPopup`)
- DotsTable team-aware layout; portrait share report added out of scope
- See Completed Sessions table for full detail

---

### Sprint 12 — Medium Priority Features

**12-A: Stableford front/back/overall bet fields** *(ABSORBED INTO 11-I — retire this session)*

**12-B: Nines table fixes**
- D-6: NinesTable renders only 3-player subset (contracted, not implemented)
- D-7: NinesTable breakdown rows filter to subset
- D-2: "pts" label on Nines total chips
- Files: `NinesTable.jsx`, `ScoreGrid.jsx`
- Priority: Medium

**12-C: Setup UX polish**
- A-5: Save game settings from prior round as defaults for next round
- Course selection as popup (like player picker)
- Only show nine-selection when course has 3 nines
- A-12: Remove "Default Tee" buttons from course selection
- Files: `NewRoundPage.jsx`, `GameConfig.jsx`, `PlayerPickerPopup.jsx`
- Priority: Medium

**12-D: Match status columns**
- D-3: Match status columns — decide and implement
- Note: D-8 (match numbering) absorbed into 11-J; do not re-implement here
- Files: `MatchNassauTable.jsx`
- Priority: Medium

**12-E: Players and leaderboard enhancements**
- G-1: Starred/favorite players float to top
- G-2: Include/exclude from leaderboard — filter one-off players off money list
- Files: `PlayersPage.jsx`, `HomePage.jsx`
- Priority: Medium

**12-F: Players/Courses swipe-left actions**
- Swipe-left Edit/Delete strip matching HistoryPage pattern
- Extract generic swipe component at the same time (avoid third copy of HistoryPage logic)
- Import PALE_YELLOW from ui.jsx for Edit button background (already specified in ASS gotcha)
- Files: `PlayersPage.jsx`, `CoursesPage.jsx` + new generic swipe component
- Priority: Medium

---

### Sprint 13 — Infrastructure

**13-A: Auto-export + iCloud naming**
- A-8: Auto-export on save with `The Card YYYY-MM-DD HH-MM.json` naming (RLC §5.2 already specifies)
- I-2: Confirm save-to-Files flow on iOS Safari
- Files: `App.jsx`
- Priority: Medium

**13-B: Per-player tee selection** *(contract first — large, high risk)*
- A-7: Per-player tee dropdown with smart defaults; retain per-course preference
- Contract: amend Round_Lifecycle_Contract.md §2.3, §2.4, §7 + Handicap_Contract.md §3
- Files: `NewRoundPage.jsx`, `handicap.js`, `roundLib.js`, `App.jsx`
- Priority: Medium
- Risk: High — own full session, do not bundle with anything else

**13-C: Partial round / early end** *(contract first)*
- Player leaves early: lastCompletedHole + earlyEndOpts
- Game starts on hole X: configurable starting hole per game
- Contract: amend Round_Lifecycle_Contract.md §4.5–4.7 (already written but not implemented)
- Known open gaps: RLC G-6, Stroke_Play_Contract G-4/G-5/G-6
- Files: `App.jsx`, `ScorecardPage.jsx`, `payouts.js`, `games.js`, `roundLib.js`
- Priority: High (real-life need)
- Risk: High — touches engine and lifecycle; own full session

---

### Sprint 14 — Low Priority Polish

**14-A: Cleanup**
- F-5: Remove legacy shims (all data is test data — confirm before removing)
- F-6: Hint text review and cleanup
- I-5: Delete hooks.js (confirmed dead code)
- H-1: Sahalee hole numbering 1–9 per nine + yardage total fix
- B-8: Edit any history round (not just most recent)
- History date range persistence across sessions
- Files: misc

**14-B: Advanced scorecard options**
- C-7: Birdie/bogey indicators (contract first — amend UI_Component_Contract.md)
- C-8: Lock/pin scorecard toggle
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`

**14-C: Security and misc**
- I-3: API key / Face ID security gate for Anthropic API
- A-9: Handicap multiplier (contract first — amend Handicap_Contract.md)
- In-app splash screen on cold load (~1.5s, logo on green)
- Replace PNG logos with SVG when designer provides file
- Files: `CoursesPage.jsx`, `storage.js`, `App.jsx`

**14-D: Late player join / missed early holes** *(contract first — complex)*
- Player joins after round starts; "X" scores for missed holes
- Affects: handicap calculations, game eligibility, Skins carryover, Nassau match validity,
  Nines subset requirements
- Contract: amend Round_Lifecycle_Contract.md (new section)
- Priority: Low — earmarked but not scheduled until owner confirms need
- Risk: High — do not underestimate complexity

---

### Future — New Game Formats

Each format requires its own contract session before any code.
Recommended order:

1. **Wolf** — rotating Wolf player; highest priority next format. `GAME_CONFIGS` in 11-I
   must preserve extension point for Wolf's doubling mechanic. Owner has confirmed Wolf
   will not be added until rest of app is considered solid.
2. **High/Low** — low ball + high ball per hole
3. **Banker (Quota)**, **Scotch/Greensomes**, **Chapman/Pinehurst**
4. **Bingo Bango Bongo**, **Vegas**, **Round Robin**, **Snake**, **Rabbit/Flags/String**
5. **Uneven team matches (1v2)**

---

## Items Requiring Contract Work Before Code

| Item | Contract Action | Session |
|---|---|---|
| ~~11-H: NewRoundPage UX/UI design spec~~ | ~~No contracts — design only; output is NewRoundPage_Design_Spec.md~~ | ✅ Complete |
| ~~11-I: Betting model refactor~~ | ~~Amend Nassau_Match_Contract.md, Stableford_Contract.md, Nines_Contract.md, Skins_Contract.md, Stroke_Play_Contract.md, App_Data_Model_Contract.md~~ | ✅ Complete (11-I.1–11-I.3) |
| ~~11-J: Per-match instance labeling~~ | ~~Amend Nassau_Match_Contract.md + App_Data_Model_Contract.md~~ | ✅ Complete |
| ~~11-K: NOL dot selector~~ | ~~Amend Handicap_Contract.md §5 → v1.6~~ | ✅ Complete — also amended Round_Lifecycle_Contract.md → v1.6 |
| ~~11-M: Team Dots payout fix + game table~~ | ~~Amend Dots_Contract.md → v2.3~~ | ✅ Complete — also amended UI_Component_Contract.md → v1.3, Round_Lifecycle_Contract.md → v1.7 |
| 13-B: Per-player tee | Amend Round_Lifecycle_Contract.md §2.3/§2.4/§7 + Handicap_Contract.md §3 | 13-B |
| 13-C: Partial round/early end | RLC §4.5–4.7 already written; engine gaps G-4/G-5/G-6 in Stroke_Play_Contract | 13-C |
| 14-B: Birdie/bogey indicators | Amend UI_Component_Contract.md | 14-B |
| 14-C: Handicap multiplier | Amend Handicap_Contract.md | 14-C |
| 14-D: Late player join | New section in Round_Lifecycle_Contract.md | 14-D |
| Future: Wolf | New Wolf_Contract.md | Future |
| Future: Other formats | New contract per format | Future |

---

## Deferred / Deprioritized Items (not abandoned, just not sequenced)

| Item | Reason deferred |
|---|---|
| 11-B: Shared GameTable shell | Pattern already working; documentation value only; post-Sprint 12 |
| Dark mode | Token structure ready in ui.jsx; low demand |
| Undo delete toast | Low impact |
| Match scorecard rows collapse by default | Low priority |
| CoursesPage GHIN/USGA API import | External dependency; low priority |
| ResultsPage share as graphic email | Done as share sheet PNG; email redesign deprioritized |
| Portrait PDF revert → PNG | If jsPDF causes issues or PDF UX is not preferred, revert portrait to PNG output. Full revert instructions in ASS top entry. ~5 min to implement. |
| Scorecard options menu (gear icon) | Deferred pending dot display mode design decision |
| Press modal UX: show live match status | Low priority UX enhancement |
