// ─── scorecard/scorecardUtils.js ──────────────────────────────────────────────
// Display logic layer — bridges engine output and UI components.
//
// TWO CATEGORIES ONLY:
//   Category 1 — Pure formatters: no engine dependency, no side effects.
//   Category 2 — Derived state builders: call engine functions, interpret output.
//
// PROHIBITED: scoring math, reimplementing engine logic, localStorage access.
// TEST: if changing engine rules would change a function's output → move to engine.

import { DOTS_DEF } from '../../engine/games.js';
import { strokesForMode } from '../../engine/handicap.js';
import { G, RED } from '../../components/ui.jsx';

// ── Layout constants (shared across all game tables) ──────────────────────────
export const COL_W    = 26;
export const TOT_W    = 36;
export const NAME_MIN = 80;

// ── Design token objects (shared style palettes per game) ─────────────────────
export const M  = { hdrBg: '#e8f4e8', hdrClr: '#1f4d1f', totBg: '#c8e0c8', totClr: '#1f4d1f', border: '#c8e0c8' };
export const MP = { bg: '#fffbe8', totBg: '#f5e099', clr: '#8a6000' };
export const N  = { hdrBg: '#e8f0fc', hdrClr: '#1a3a5c', totBg: '#c8d8f8', totClr: '#1a3a5c', row: ['#f0f5ff','#e8f0fc'], border: '#c8d8f8' };
export const S  = { hdrBg: '#fef3e8', hdrClr: '#7b3f00', totBg: '#fce4c4', totClr: '#7b3f00', row: ['#fffdf8','#fef9f0'], border: '#fce4c4' };
export const K  = { hdrBg: '#f2eafa', hdrClr: '#4a1580', totBg: '#dac8f5', totClr: '#4a1580', row: ['#f9f5ff','#f2eafa'], border: '#dac8f5' };
export const P  = { hdrBg: '#edf7ed', hdrClr: '#1a5c1a', totBg: '#c8e8c8', totClr: '#1a5c1a', row: ['#f5fbf5','#edf7ed'], border: '#c8e8c8' };
export const SX     = { hdrBg: '#e8f5e9', hdrClr: '#2e7d32', totBg: '#c8e6c9', totClr: '#2e7d32', border: '#c8e6c9' };
export const SX_A   = '#d0ebd0';
export const SX_B   = '#ffe8cc';
export const SX_AC  = '#27ae60';
export const SX_BC  = '#e07020';
export const SP_CLR = '#7b3fa0';
export const SP_BG  = '#f5eefa';
export const SP_HDR = '#f0e4f8';

// Hole range constants
export const FRONT_H = [0,1,2,3,4,5,6,7,8];
export const BACK_H  = [9,10,11,12,13,14,15,16,17];
export const ALL18_H = [...FRONT_H, ...BACK_H];

// Shared name cell style for game tables
export const nameTd = { padding: '2px 6px', fontSize: 11, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' };

/**
 * resolveDisplayNames(players) → string[]
 * Category 1 — Pure formatter. No engine dependency.
 *
 * Given an array of player objects, returns a parallel array of display-name
 * strings for use in chips and headers throughout the UI.
 *
 * Rules:
 *   1. Default label = first name only.
 *   2. First-name collision → append last initial (e.g. "Chris H").
 *   3. First-name + last-initial collision (e.g. Chris Hirata vs Chris Hightower)
 *      → flag with `stacked: true` so the caller can render first/last on two lines.
 *      The `name` property in this case is still the first name; the caller reads
 *      `lastName` to render the second line.
 *
 * Returns array of objects: { name: string, lastName: string|null, stacked: boolean }
 * Callers that only need a flat string can use the `name` property directly when
 * `stacked` is false, or `name + ' ' + lastName` when stacked is true.
 */
export function resolveDisplayNames(players) {
  const firstNames = players.map(p => (p?.name || '?').trim().split(/\s+/)[0]);
  const lastNames  = players.map(p => {
    const parts = (p?.name || '').trim().split(/\s+/);
    return parts.length >= 2 ? parts[parts.length - 1] : '';
  });
  const lastInits = lastNames.map(ln => ln ? ln[0].toUpperCase() : '');

  // Pass 1: detect first-name collisions
  const withInit = firstNames.map((fn, i) => {
    const collision = firstNames.some((other, j) => j !== i && other === fn);
    if (!collision) return { label: fn, hasInit: false };
    return { label: lastInits[i] ? `${fn} ${lastInits[i]}` : fn, hasInit: !!lastInits[i] };
  });

  // Pass 2: detect label collisions after adding initials (e.g. Chris H vs Chris H)
  return withInit.map((entry, i) => {
    if (!entry.hasInit) return { name: entry.label, lastName: null, stacked: false };
    const labelCollision = withInit.some((other, j) => j !== i && other.label === entry.label);
    if (!labelCollision) return { name: entry.label, lastName: null, stacked: false };
    // Still colliding after initial — go stacked (first name + full last name)
    return { name: firstNames[i], lastName: lastNames[i] || null, stacked: true };
  });
}

// ── Category 1 — Pure formatters ──────────────────────────────────────────────

/**
 * Format a match lead state into a display string and color.
 * Returns { text, color }.
 *   "AS"      — All Square (lead === 0)
 *   "{n}UP"   — leading, match open
 *   "{n}&{h}" — leading, match closed
 *   "—"       — no holes played yet
 */
export function fmtLead(lead, matchOver, holesLeft) {
  if (lead === 0) return { text: 'AS', color: '#3a3abd' };
  const n = Math.abs(lead);
  const t = matchOver ? `${n}&${holesLeft}` : `${n}UP`;
  return lead > 0 ? { text: t, color: G } : { text: t, color: RED };
}

/**
 * Scoring mode label for game card badges.
 * 'gross' → 'Gross', 'netofflow' → 'NOL', anything else → 'Net'
 */
export const scoringLabel = m => m === 'gross' ? 'Gross' : m === 'netofflow' ? 'NOL' : 'Net';

/**
 * Returns true if the matchDef is a Nassau (has Front or Back bet).
 * Single authoritative display-layer test for Nassau vs. straight Match Play.
 * Note: engine also exports isNassauMatch — use that in engine code, this in display code.
 */
export function isNassauMatchDisplay(matchDef) {
  return (matchDef?.betFront > 0) || (matchDef?.betBack > 0);
}

/**
 * Restore dot definitions after JSON serialization (Dots Contract §12).
 * Renamed from restoreAutoWhen in v2.0.
 *
 * Handles three restoration tasks:
 * 1. Re-attaches autoWhen functions (stripped by JSON) for auto dots (ace/eagle/birdie).
 * 2. Restores multi field from DOTS_DEF for built-ins if absent (old rounds predate the field).
 * 3. Migrates pts → value for rounds saved before v2.0.
 *
 * MUST be called before using dots from any state that passed through localStorage.
 * Source of truth is always DOTS_DEF in games.js.
 *
 * Custom dots (id starts with 'c_'): no autoWhen (always auto:false);
 * multi defaults to true if absent; value migrated from pts if absent.
 */
export function restoreDotDefs(dots) {
  if (!dots?.length) return dots;
  return dots.map(sp => {
    const def = DOTS_DEF.find(d => d.id === sp.id);
    let restored = sp;
    // 1. Re-attach autoWhen for auto dots
    if (def?.autoWhen && !sp.autoWhen)
      restored = { ...restored, autoWhen: def.autoWhen };
    // 2. Restore multi if absent
    if (restored.multi === undefined)
      restored = { ...restored, multi: def ? (def.multi ?? false) : true };
    // 3. v2.0 migration: pts → value
    if (restored.value === undefined) {
      const fallback = restored.pts ?? (def ? def.value : 1);
      restored = { ...restored, value: fallback };
    }
    return restored;
  });
}

// Backward-compatibility alias — components updated in Sprint 11 but
// any lingering references will still resolve correctly.
export const restoreAutoWhen = restoreDotDefs;

// ── Category 2 — Derived state builders ──────────────────────────────────────

/**
 * Build per-hole lead state for a match bet.
 * holeWinFn: (holeIndex) → 1 | 2 | 'a' | 'b' | 'half' | 0 | null
 * runHoles: array of 0-based hole indices this bet covers.
 * Returns: object keyed by hole index → { lead, matchOver, holesLeft }
 */
export function buildLeadState(holeWinFn, runHoles) {
  let lead = 0, matchOver = false;
  const state = {};
  let played = 0;
  for (const h of runHoles) {
    const w = holeWinFn(h);
    if (w === null) break;
    if (!matchOver) {
      const wVal = (w === 1 || w === 'a') ? 1 : (w === 2 || w === 'b') ? -1 : 0;
      lead += wVal;
      played++;
      const holesLeft = runHoles.length - played;
      if (Math.abs(lead) > holesLeft) matchOver = true;
    }
    state[h] = { lead, matchOver, holesLeft: runHoles.length - played };
  }
  return state;
}

/**
 * Returns the last hole index in `holes` for which holeWinFn returns non-null.
 */
export function lastScoredInHoles(holeWinFn, holes) {
  let last = null;
  for (const h of holes) {
    if (holeWinFn(h) !== null) last = h; else break;
  }
  return last;
}

/**
 * Returns the number of handicap stroke dots for a score cell.
 */
export function getStrokeDotCount(courseHcp, hcpRank, minCourseHcp, mode) {
  return strokesForMode(courseHcp, hcpRank, minCourseHcp, mode || 'net');
}
