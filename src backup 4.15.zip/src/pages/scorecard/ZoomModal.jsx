// ─── scorecard/ZoomModal.jsx ──────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// Zoom score entry modal — magnified 3-hole scorecard popup.
//
// iOS SCROLL FIX:
//   iOS Safari scrolls the viewport to bring focused inputs into view, even
//   inside position:fixed overlays. All attempts to suppress this via CSS or
//   JS scroll locks failed.
//
//   Solution: use a SINGLE HIDDEN INPUT positioned at top:-100px (above the
//   viewport). All score cells are rendered as <div> elements — not inputs.
//   Tapping a cell sets it as activeCell and focuses the hidden input.
//   iOS focuses the hidden input which is already above the viewport top —
//   there is nowhere to scroll to, so no scroll occurs.
//
//   The hidden input handles all keystroke logic (digits, backspace, Enter/Tab).
//   Score values, borders, and dot badges are rendered on the cell divs.

import { useRef, useCallback, useEffect, useState } from 'react';
import { G } from '../../components/ui.jsx';
import { strokesForMode } from '../../engine/handicap.js';

function splitName(fullName = '') {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) return { first: parts[0], last: '' };
  return { first: parts.slice(0, -1).join(' '), last: parts[parts.length - 1] };
}

function ZoomPopDots({ courseHcp, hcpRank, minCourseHcp, mode }) {
  if (!mode) return null;
  const n = strokesForMode(courseHcp, hcpRank, minCourseHcp, mode);
  if (n <= 0) return null;
  return (
    <div style={{ position: 'absolute', bottom: 3, right: 3, display: 'flex', gap: 2, pointerEvents: 'none' }}>
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} style={{ width: 5, height: 5, borderRadius: '50%', background: G }} />
      ))}
    </div>
  );
}

function ZoomDotBadge({ count }) {
  if (!count) return null;
  return (
    <div style={{
      position: 'absolute', top: -3, right: -3,
      width: 15, height: 15, borderRadius: '50%',
      background: G, color: '#fff',
      fontSize: 7, fontWeight: 800, lineHeight: 1,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      pointerEvents: 'none', zIndex: 2,
    }}>{count}</div>
  );
}

export function ZoomModal({
  players, pars, hcps, courseHcps, minCourseHcp,
  scores,
  dotMode, isMixed, setDotModeOverride,
  handleScore,
  startLongPress, cancelLongPress,
  dotsGameActive, sc,
  zoomHole, setZoomHole, setZoomOpen,
  setPopup,
  hiddenInputRef: hiddenInputRefProp,
  focusRef,
}) {
  const hiddenInputRefInternal = useRef(null);
  // hiddenInputRefProp is ScoreGrid's ref — used only for blur/refocus coordination.
  // ZoomModal's own hidden input always uses the internal ref.
  const hiddenInputRef = hiddenInputRefInternal;
  // When true, the zoomHole useEffect should not override activeCell
  // (used by retreat to land on last player instead of first empty)
  const preserveActiveCell = useRef(false);

  // activeCell tracks which cell is "focused" — drives green border and keystroke routing
  const [activeCell, setActiveCell] = useState({ h: zoomHole, pi: 0 });

  // Focus the hidden input synchronously — iOS only shows the keyboard
  // when .focus() is called directly inside a user gesture handler (touchend).
  // Any async wrapper (requestAnimationFrame, setTimeout, useEffect) breaks this.
  const focusHidden = useCallback(() => {
    const el = hiddenInputRef.current;
    if (el) el.focus();
  }, []);

  // Expose focusHidden to ScoreGrid for DotsPopup close refocus
  useEffect(() => {
    if (focusRef) focusRef.current = focusHidden;
  }, [focusRef, focusHidden]);

  // When zoomHole changes, move active cell to first empty on new hole
  // unless preserveActiveCell is set (retreat sets it to land on last player)
  useEffect(() => {
    if (preserveActiveCell.current) {
      preserveActiveCell.current = false;
      requestAnimationFrame(() => focusHidden());
      return;
    }
    let newPi = 0;
    for (let pi = 0; pi < players.length; pi++) {
      const val = scores[zoomHole]?.[pi];
      if (val === '' || val == null) { newPi = pi; break; }
    }
    setActiveCell({ h: zoomHole, pi: newPi });
    requestAnimationFrame(() => focusHidden());
  }, [zoomHole]); // eslint-disable-line react-hooks/exhaustive-deps

  // Note: no auto-focus on mount — iOS requires a user gesture to show keyboard.
  // Keyboard appears when user taps their first cell.

  // ── Advance / retreat ───────────────────────────────────────────────────────
  const advanceTimer  = useRef(null);
  const pendingDigit  = useRef(null);

  const advance = useCallback((h, pi) => {
    const npi = pi + 1 < players.length ? pi + 1 : 0;
    const nh  = pi + 1 < players.length ? h : h + 1;
    if (nh >= 18) return;
    if (nh !== h) {
      setZoomHole(nh); // triggers useEffect above which sets activeCell + focuses
    } else {
      setActiveCell({ h: nh, pi: npi });
      requestAnimationFrame(() => focusHidden());
    }
  }, [players.length, setZoomHole, focusHidden]);

  const cancelAdvance = useCallback(() => {
    if (advanceTimer.current) { clearTimeout(advanceTimer.current); advanceTimer.current = null; }
  }, []);

  const scheduleAdvance = useCallback((h, pi, firstDigit) => {
    cancelAdvance();
    if (firstDigit === '1') {
      advanceTimer.current = setTimeout(() => {
        advanceTimer.current = null;
        advance(h, pi);
      }, 700);
    } else {
      advance(h, pi);
    }
  }, [advance, cancelAdvance]);

  const retreat = useCallback((h, pi) => {
    const ppi = pi - 1 >= 0 ? pi - 1 : players.length - 1;
    const ph  = pi - 1 >= 0 ? h : h - 1;
    if (ph < 0) return;
    if (ph !== h) {
      // Crossing to previous hole — land on last player, not first empty
      preserveActiveCell.current = true;
      setActiveCell({ h: ph, pi: players.length - 1 });
      setZoomHole(ph);
    } else {
      setActiveCell({ h: ph, pi: ppi });
      requestAnimationFrame(() => focusHidden());
    }
  }, [players.length, setZoomHole, focusHidden]);

  // ── Hidden input handlers ───────────────────────────────────────────────────
  // The hidden input value is always kept empty — we use it purely as a
  // keystroke receiver. All score state lives in the parent via handleScore.

  const handleHiddenKeyDown = useCallback((e) => {
    const { h, pi } = activeCell;

    if ((e.key === 'Enter' || e.key === 'Tab') && !e.shiftKey) {
      e.preventDefault(); cancelAdvance(); advance(h, pi); return;
    }
    if (e.key === 'Backspace') {
      cancelAdvance();
      const cur = scores[h]?.[pi];
      if (cur === '' || cur == null || cur === 0) {
        e.preventDefault();
        retreat(h, pi);
      } else {
        // Clear the current cell
        handleScore(h, pi, '');
      }
      return;
    }
    if (/^[1-9]$/.test(e.key)) {
      e.preventDefault();
      const curVal = String(scores[h]?.[pi] ?? '');
      cancelAdvance();
      // Two-digit score logic: if current is '1' and new digit forms 10-19
      if (curVal === '1') {
        const twoDigit = '1' + e.key;
        const v = Math.min(15, parseInt(twoDigit));
        handleScore(h, pi, String(v));
        cancelAdvance();
        advance(h, pi);
        pendingDigit.current = null;
        return;
      }
      const v = parseInt(e.key);
      handleScore(h, pi, String(v));
      pendingDigit.current = e.key;
      scheduleAdvance(h, pi, e.key);
    }
  }, [activeCell, scores, handleScore, advance, retreat, cancelAdvance, scheduleAdvance]);

  // Keep hidden input empty after any browser-inserted character
  const handleHiddenChange = useCallback(() => {
    const el = hiddenInputRef.current;
    if (el) el.value = '';
  }, []);

  // ── Tap a cell ──────────────────────────────────────────────────────────────
  const handleCellTap = useCallback((h, pi) => {
    focusHidden();
    if (h !== zoomHole) {
      // Tapping adjacent column — recenter on that hole at the tapped player row
      preserveActiveCell.current = true;
      setActiveCell({ h, pi });
      setZoomHole(h);
    } else {
      setActiveCell({ h, pi });
    }
  }, [zoomHole, setZoomHole, focusHidden]);

  // ── Layout constants ─────────────────────────────────────────────────────────
  const COL_W  = 62;
  const NAME_W = 90;
  const CELL_H = 67;

  const HDR_BG      = '#f0f4f0';
  const HDR_CLR     = '#555';
  const PAR_BG      = '#f8fbf8';
  const MHCP_BG     = '#fafcfa';
  const PLACEHOLDER = '#f0f4f0';

  const cols   = [zoomHole - 1, zoomHole, zoomHole + 1];
  const validH = (h) => h >= 0 && h < 18;
  const cellBg = (pi) => pi % 2 === 0 ? '#fff' : '#f5fbf5';

  const isActive = (h, pi) => activeCell.h === h && activeCell.pi === pi;

  // Cell div style — mimics input appearance
  const makeCellStyle = (h, pi) => ({
    width: '100%',
    height: '100%',
    boxSizing: 'border-box',
    border: isActive(h, pi) ? `2px solid ${G}` : '1px solid #ddd',
    borderRadius: 4,
    textAlign: 'center',
    fontSize: h === zoomHole ? 26 : 19,
    fontWeight: h === zoomHole ? 700 : 600,
    // Vertical centering
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#fff',
    color: h === zoomHole ? '#222' : '#444',
    cursor: 'pointer',
    userSelect: 'none',
    WebkitUserSelect: 'none',
    position: 'relative',
    // Min height matches input padding equivalent
    minHeight: h === zoomHole ? 63 : 63,
  });

  return (
    <div
      style={{
        position: 'fixed', inset: 0,
        background: 'rgba(0,0,0,0.40)',
        zIndex: 200,
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
        paddingTop: 92,
        paddingLeft: 8,
        paddingRight: 8,
      }}
      onMouseDown={() => setZoomOpen(false)}
    >
      {/* Hidden input — handles all keystrokes. Positioned above viewport so
          iOS focus causes no scroll. ScoreGrid has a companion input that
          captures the initial keyboard open on the zoom button tap gesture. */}
      <input
        ref={hiddenInputRef}
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
        defaultValue=""
        onKeyDown={handleHiddenKeyDown}
        onChange={handleHiddenChange}
        style={{
          position: 'fixed', top: -100, left: 0,
          width: 1, height: 1, opacity: 0,
          border: 'none', outline: 'none',
          background: 'transparent', fontSize: 16,
        }}
      />

      {/* Card */}
      <div
        style={{
          width: '100%',
          maxWidth: NAME_W + 3 * COL_W + 32,
          background: '#eef4ee',
          borderRadius: 14,
          boxShadow: '0 2px 8px rgba(0,0,0,0.18), 0 8px 28px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,0,0,0.06)',
          overflow: 'hidden',
        }}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* ── Header bar ── */}
        <div style={{
          background: G, padding: '9px 14px 8px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 14 }}>
            Hole {zoomHole + 1}
          </div>

          {isMixed && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <span style={{ fontSize: 9, color: 'rgba(255,255,255,0.6)' }}>Dots:</span>
              <div style={{ display: 'flex', borderRadius: 7, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.3)' }}>
                {['net', 'netofflow'].map(m => (
                  <button key={m} onClick={() => setDotModeOverride(m)} style={{
                    padding: '2px 8px', fontSize: 9, fontWeight: 600, fontFamily: 'inherit',
                    border: 'none', cursor: 'pointer', lineHeight: 1.4,
                    background: dotMode === m ? 'rgba(255,255,255,0.25)' : 'transparent',
                    color: dotMode === m ? '#fff' : 'rgba(255,255,255,0.5)',
                  }}>{m === 'net' ? 'Net' : 'NOL'}</button>
                ))}
              </div>
            </div>
          )}

          <button
            onClick={() => setZoomOpen(false)}
            style={{
              background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.3)',
              color: '#fff', borderRadius: 7, width: 28, height: 28,
              fontSize: 14, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}
            aria-label="Close zoom"
          >✕</button>
        </div>

        {/* ── Table wrapper ── */}
        <div style={{ overflow: 'hidden', padding: '0 8px' }}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%' }}>
            <colgroup>
              <col style={{ width: NAME_W }} />
              {cols.map((_, ci) => <col key={ci} style={{ width: COL_W }} />)}
            </colgroup>

            <thead>
              <tr>
                <th style={{ background: HDR_BG, padding: '5px 6px', fontSize: 11, color: HDR_CLR, textAlign: 'left', fontWeight: 500 }}></th>
                {cols.map((h, ci) => (
                  <th key={ci} style={{
                    background: !validH(h) ? PLACEHOLDER : HDR_BG,
                    color: h === zoomHole ? G : HDR_CLR,
                    fontSize: h === zoomHole ? 18 : 13,
                    fontWeight: h === zoomHole ? 800 : 500,
                    textAlign: 'center',
                    padding: '5px 2px',
                    borderBottom: '1px solid #d8e4d8',
                  }}>
                    {validH(h) ? h + 1 : ''}
                  </th>
                ))}
              </tr>
              <tr>
                <td style={{ background: PAR_BG, padding: '3px 6px', fontSize: 11, color: G, fontWeight: 700 }}>Par</td>
                {cols.map((h, ci) => (
                  <td key={ci} style={{
                    background: !validH(h) ? PLACEHOLDER : PAR_BG,
                    textAlign: 'center',
                    fontSize: h === zoomHole ? 16 : 11,
                    fontWeight: 700, color: G,
                    padding: '3px 2px',
                  }}>
                    {validH(h) ? pars[h] : ''}
                  </td>
                ))}
              </tr>
              <tr>
                <td style={{ background: MHCP_BG, padding: '2px 6px', fontSize: 10, color: '#aaa', fontWeight: 600 }}>M.Hcp</td>
                {cols.map((h, ci) => (
                  <td key={ci} style={{
                    background: !validH(h) ? PLACEHOLDER : MHCP_BG,
                    textAlign: 'center',
                    fontSize: 10, color: '#bbb',
                    padding: '2px 2px',
                  }}>
                    {validH(h) ? hcps[h] : ''}
                  </td>
                ))}
              </tr>
            </thead>

            <tbody>
              {players.map((p, pi) => {
                const { first, last } = splitName(p.name);
                return (
                  <tr key={pi}>
                    <td style={{
                      padding: '0 6px',
                      background: cellBg(pi),
                      borderTop: '1px solid #eee',
                      verticalAlign: 'middle',
                      height: CELL_H,
                    }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: '#222', lineHeight: 1.2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {first}
                      </div>
                      {last ? (
                        <div style={{ fontSize: 11, fontWeight: 400, color: '#888', lineHeight: 1.2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {last}
                        </div>
                      ) : null}
                    </td>

                    {cols.map((h, ci) => {
                      if (!validH(h)) {
                        return (
                          <td key={ci} style={{
                            background: PLACEHOLDER,
                            borderTop: '1px solid #eee',
                            height: CELL_H,
                          }} />
                        );
                      }

                      const dotCount = dotsGameActive ? sc(h, pi) : 0;
                      const val = scores[h]?.[pi] ?? '';

                      return (
                        <td key={ci} style={{
                          padding: 2,
                          position: 'relative',
                          background: cellBg(pi),
                          borderTop: '1px solid #eee',
                          height: CELL_H,
                        }}>
                          <div
                            style={makeCellStyle(h, pi)}
                            onMouseDown={e => {
                              e.preventDefault();
                              handleCellTap(h, pi);
                            }}
                            onTouchStart={() => startLongPress(h, pi)}
                            onTouchEnd={(e) => {
                              e.preventDefault();
                              cancelLongPress(h, pi);
                              handleCellTap(h, pi);
                            }}
                            onTouchMove={() => cancelLongPress(h, pi)}
                          >
                            {val !== '' && val !== 0 ? val : ''}
                            <ZoomDotBadge count={dotCount} />
                            {dotMode && (
                              <ZoomPopDots
                                courseHcp={courseHcps[pi]}
                                hcpRank={hcps[h]}
                                minCourseHcp={minCourseHcp}
                                mode={dotMode}
                              />
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Hint footer */}
        <div style={{ padding: '5px 10px 8px', fontSize: 10, color: '#999', textAlign: 'center' }}>
          Tap a cell to select · Hold for dots
        </div>
      </div>
    </div>
  );
}
