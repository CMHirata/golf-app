// ─── scorecard/ScoreGrid.jsx ──────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// Handles the hole-by-hole score entry grid, long-press dots popup, and
// handicap dot display. All scoring math arrives via props from ScorecardPage.
// See App Data Model Contract §8 for mutation rules.

import { useRef, useCallback, useState, useEffect } from 'react';
import { G } from '../../components/ui.jsx';
import { strokesForMode, scoreForMode } from '../../engine/handicap.js';
import { restoreDotDefs, COL_W, TOT_W, NAME_MIN } from './scorecardUtils.js';
import { getDotsPartner, getMatchTeamPartner, sixesSegForHole } from '../../engine/games.js';
import { DotsPopup }        from './DotsPopup.jsx';
import { ZoomModal }        from './ZoomModal.jsx';
import { NinesTable }       from '../tables/NinesTable.jsx';
import { StablefordTable }  from '../tables/StablefordTable.jsx';
import { SkinsTable }       from '../tables/SkinsTable.jsx';
import { StrokePlayTable }  from '../tables/StrokePlayTable.jsx';
import { MatchNassauTable } from '../tables/MatchNassauTable.jsx';
import { SixesTable }       from '../tables/SixesTable.jsx';
import { DotsTable }        from '../tables/DotsTable.jsx';
import { TotalsCard }       from './TotalsCard.jsx';

// ── PopDots ────────────────────────────────────────────────────────────────────
function PopDots({ courseHcp, hcpRank, minCourseHcp, mode }) {
  const n = strokesForMode(courseHcp, hcpRank, minCourseHcp, mode);
  if (n <= 0) return null;
  return (
    <div style={{ position: 'absolute', bottom: 2, right: 2, display: 'flex', gap: 1.5, pointerEvents: 'none' }}>
      {Array.from({ length: n }).map((_, i) => <div key={i} style={{ width: 3, height: 3, borderRadius: '50%', background: G }}/>)}
    </div>
  );
}

// ── DotBadge ───────────────────────────────────────────────────────────────────
function DotBadge({ count }) {
  if (!count) return null;
  return (
    <div style={{
      position: 'absolute', top: -2, right: -2,
      width: 13, height: 13, borderRadius: '50%',
      background: G, color: '#fff',
      fontSize: 7, fontWeight: 800, lineHeight: 1,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      pointerEvents: 'none', zIndex: 2,
    }}>{count}</div>
  );
}

// ── ScoreGrid ──────────────────────────────────────────────────────────────────
export function ScoreGrid({
  players, pars, hcps, courseHcps, minCourseHcp,
  scores, setScores,
  dotMode, isMixed, setDotModeOverride,
  primaryMode, activeGames, gameOpts,
  matches, sixesTeams, strokePlayPlayers, skinsPlayers, stablefordPlayers, ninesPlayers,
  dotsPlayers,
  dots, dotEntries, setDotEntries,
  manualPresses, setManualPresses,
  frontLabel, backLabel,
  isLandscape: isLandscapeProp,
  zoomTriggerRef,
}) {
  const refs  = useRef({});
  const [popup,    setPopup]    = useState(null);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [zoomHole, setZoomHole] = useState(0);
  const zoomHiddenInputRef      = useRef(null);
  const zoomFocusRef            = useRef(null); // set by ZoomModal to its focusHidden fn
  // Cleanup body lock if component unmounts while zoom is open
  // Find first hole with any empty score — zoom modal entry point
  const firstEmptyHole = useCallback(() => {
    for (let h = 0; h < 18; h++) {
      for (let pi = 0; pi < players.length; pi++) {
        const v = scores[h]?.[pi];
        if (v === '' || v == null) return h;
      }
    }
    return 17;
  }, [scores, players.length]);

  const openZoom = useCallback(() => {
    // Focus the hidden input SYNCHRONOUSLY here — we are still inside the
    // tap gesture. iOS will show the keyboard for this focus call.
    // The hidden input is always rendered (when canZoom) so it exists already.
    if (zoomHiddenInputRef.current) zoomHiddenInputRef.current.focus();
    setZoomHole(firstEmptyHole());
    setZoomOpen(true);
  }, [firstEmptyHole]);

  // Expose openZoom to parent (ScorecardPage) for landscape zoom button
  useEffect(() => {
    if (zoomTriggerRef) zoomTriggerRef.current = openZoom;
  }, [openZoom, zoomTriggerRef]);

  const closeZoom = useCallback(() => {
    setZoomOpen(false);
  }, []);

  // H-4: isLandscape passed from ScorecardPage; fall back to local detection.
  const [isLandscapeLocal, setIsLandscapeLocal] = useState(
    () => typeof window !== 'undefined' && window.innerWidth > window.innerHeight
  );
  useEffect(() => {
    if (isLandscapeProp !== undefined) return;
    const update = () => setIsLandscapeLocal(window.innerWidth > window.innerHeight);
    window.addEventListener('resize', update);
    window.addEventListener('orientationchange', update);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('orientationchange', update);
    };
  }, [isLandscapeProp]);
  const isLandscape = isLandscapeProp !== undefined ? isLandscapeProp : isLandscapeLocal;

  // Read-only guard: zoom only available when setScores is provided
  const canZoom = !!setScores;

  const dotsGameActive = activeGames.includes('Dots') || activeGames.includes('Specials');

  const SCORING_SPECIAL_PRIORITY = ['ace', 'condor', 'albatross', 'eagle', 'birdie'];

  const autoMark = useCallback((h, pi, g) => {
    if (!dotsGameActive) return;
    const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    if (!dtIdxs.includes(pi)) return;

    const par = pars[h];
    const dotsOpts   = gameOpts?.Dots || gameOpts?.Specials || {};
    const dotScoring = dotsOpts.scoring;
    const gNum = parseInt(g) || 0;
    const effectiveScore = (gNum && dotScoring === 'net' && courseHcps && hcps && minCourseHcp != null)
      ? scoreForMode(gNum, courseHcps[pi], hcps[h], minCourseHcp, 'net')
      : gNum || null;

    const rawTeamMode = dotsOpts.teamMode;
    const legacyTeam  = dotsOpts.teamScoring;
    const teamSource  = rawTeamMode && rawTeamMode !== 'none'
      ? rawTeamMode
      : (legacyTeam ? 'Sixes' : 'none');
    const isTeamMode = teamSource !== 'none';
    const getPartner = () => {
      if (teamSource === 'Sixes') return getDotsPartner(pi, sixesSegForHole(h), sixesTeams, players);
      if (teamSource === 'Match') return getMatchTeamPartner(pi, matches);
      return -1;
    };

    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);
    const restoredDots = restoreDotDefs(dots);
    const ens = restoredDots.filter(s => s.enabled);

    setDotEntries(prev => {
      const n = { ...prev };
      const autoSpecials = restoredDots.filter(s => s.enabled && s.auto && s.autoWhen && s.id !== 'team');

      if (!effectiveScore || !par) {
        autoSpecials.forEach(sp => { delete n[`${h}_${pi}_${sp.id}`]; });
      } else {
        const scoringIds = new Set(SCORING_SPECIAL_PRIORITY);
        const nonScoring = autoSpecials.filter(sp => !scoringIds.has(sp.id));
        const scoringCandidates = autoSpecials
          .filter(sp => scoringIds.has(sp.id))
          .sort((a, b) => SCORING_SPECIAL_PRIORITY.indexOf(a.id) - SCORING_SPECIAL_PRIORITY.indexOf(b.id));

        const winner = scoringCandidates.find(sp => sp.autoWhen(effectiveScore, par));

        scoringCandidates.forEach(sp => {
          const key = `${h}_${pi}_${sp.id}`;
          if (sp === winner) n[key] = 1;
          else delete n[key];
        });

        nonScoring.forEach(sp => {
          const key = `${h}_${pi}_${sp.id}`;
          if (sp.autoWhen(effectiveScore, par)) n[key] = 1;
          else delete n[key];
        });
      }

      if (isTeamMode) {
        const partnerIdx = getPartner();
        if (partnerIdx >= 0) {
          const compKey = `${h}_${partnerIdx}_team_dot_for_${pi}`;
          let total = 0;
          Object.entries(n).forEach(([key, v]) => {
            const cnt = entryCount(v);
            if (!cnt) return;
            const parts = key.split('_');
            if (parseInt(parts[0]) !== h || parseInt(parts[1]) !== pi) return;
            if (parts[2] === 'team') return;
            const sp = ens.find(s => s.id === parts[2]);
            if (sp) total += cnt;
          });
          if (total > 0) n[compKey] = total; else delete n[compKey];
        }
      }

      return n;
    });
  }, [pars, hcps, courseHcps, minCourseHcp, dots, dotsGameActive, gameOpts,
      dotsPlayers, players, sixesTeams, matches, setDotEntries]);

  useEffect(() => {
    if (!dotsGameActive) return;
    const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    for (let h = 0; h < 18; h++) {
      dtIdxs.forEach(pi => {
        const g = parseInt(scores[h]?.[pi]);
        if (g) autoMark(h, pi, g);
      });
    }
  }, [dotsGameActive]); // eslint-disable-line react-hooks/exhaustive-deps

  const longPressTimer = useRef({});

  const startLongPress = (h, pi) => {
    if (dotsGameActive) {
      const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
      if (!dtIdxs.includes(pi)) return;
    }
    longPressTimer.current[`${h}_${pi}`] = setTimeout(() => {
      // Blur hidden input before popup opens so keyboard dismisses
      if (zoomOpen && zoomHiddenInputRef.current) {
        zoomHiddenInputRef.current.blur();
      }
      setPopup({ hole: h, pi });
    }, 500);
  };

  const cancelLongPress = (h, pi) => {
    const key = `${h}_${pi}`;
    if (longPressTimer.current[key]) {
      clearTimeout(longPressTimer.current[key]);
      delete longPressTimer.current[key];
    }
  };

  const advanceRef = useRef(null);
  advanceRef.current = (h, pi) => {
    const npi = pi + 1 < players.length ? pi + 1 : 0;
    const nh  = pi + 1 < players.length ? h : h + 1;
    if (nh < 18) {
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const el = refs.current[`${nh}_${npi}`];
        if (el) { el.focus(); try { el.select(); } catch (_) {} }
      }));
    }
  };

  const advanceTimer = useRef(null);
  const scheduleAdvance = useCallback((h, pi, firstDigit) => {
    if (advanceTimer.current) clearTimeout(advanceTimer.current);
    if (firstDigit === '1') {
      advanceTimer.current = setTimeout(() => { advanceTimer.current = null; advanceRef.current(h, pi); }, 700);
    } else {
      advanceRef.current(h, pi);
    }
  }, []);

  const cancelAdvance = useCallback(() => {
    if (advanceTimer.current) { clearTimeout(advanceTimer.current); advanceTimer.current = null; }
  }, []);

  const pendingAdvance = useRef(null);

  const handleKeyDown = useCallback((h, pi, e) => {
    if ((e.key === 'Enter' || e.key === 'Tab') && !e.shiftKey) {
      e.preventDefault(); cancelAdvance(); advanceRef.current(h, pi); return;
    }
    if (e.key === 'Backspace') {
      cancelAdvance();
      const cur = scores[h]?.[pi];
      if (cur === '' || cur == null || cur === 0) {
        e.preventDefault();
        const ppi = pi - 1 >= 0 ? pi - 1 : players.length - 1;
        const ph  = pi - 1 >= 0 ? h : h - 1;
        if (ph >= 0) {
          requestAnimationFrame(() => requestAnimationFrame(() => {
            const el = refs.current[`${ph}_${ppi}`];
            if (el) { el.focus(); try { el.select(); } catch (_) {} }
          }));
        }
      }
      return;
    }
    if (/^[1-9]$/.test(e.key)) {
      const curVal = String(scores[h]?.[pi] ?? '');
      if (curVal === '1') cancelAdvance();
      pendingAdvance.current = { h, pi, key: e.key };
      const el = refs.current[`${h}_${pi}`];
      if (el && el.selectionStart === 0 && el.selectionEnd === el.value.length && e.key === curVal) {
        e.preventDefault();
        const v = parseInt(e.key);
        setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = v; return n; });
        if (v) autoMark(h, pi, v);
        scheduleAdvance(h, pi, e.key);
        pendingAdvance.current = null;
      }
    }
  }, [players.length, scores, autoMark, scheduleAdvance, cancelAdvance]);

  const handleScore = (h, pi, val) => {
    const digits  = val.replace(/[^0-9]/g, '');
    let effective;
    if (digits.length === 2 && digits[0] === '1') effective = digits;
    else if (digits.length > 1) effective = digits[0];
    else effective = digits;
    const v = effective === '' ? '' : Math.max(1, Math.min(15, parseInt(effective) || 0));
    setScores(prev => { const n = prev.map(r => [...r]); n[h][pi] = v; return n; });
    autoMark(h, pi, v);
    if (effective !== '' && pendingAdvance.current?.h === h && pendingAdvance.current?.pi === pi) {
      const firstDigit = pendingAdvance.current.key;
      pendingAdvance.current = null;
      if (digits.length === 2) { cancelAdvance(); advanceRef.current(h, pi); }
      else scheduleAdvance(h, pi, firstDigit);
    }
  };

  const dotsScoringMode = (gameOpts?.Dots || gameOpts?.Specials || {}).scoring || 'gross';
  useEffect(() => {
    if (!dotsGameActive) return;
    const dtIdxs = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
    for (let h = 0; h < 18; h++) {
      dtIdxs.forEach(pi => {
        const g = parseInt(scores[h]?.[pi]);
        autoMark(h, pi, g || 0);
      });
    }
  }, [dotsScoringMode]); // eslint-disable-line react-hooks/exhaustive-deps

  const grossTotal = (pi, hs) => hs.reduce((s, h) => s + (parseInt(scores[h]?.[pi]) || 0), 0);
  const netTotal   = (pi, hs) => hs.reduce((s, h) => {
    const g = parseInt(scores[h]?.[pi]);
    return g ? s + (scoreForMode(g, courseHcps[pi], hcps[h], minCourseHcp, primaryMode) || 0) : s;
  }, 0);
  const parTotal   = hs => hs.reduce((s, h) => s + (pars[h] || 0), 0);

  const sc = (h, pi) => {
    if (!dotsGameActive) return 0;
    const rs = restoreDotDefs(dots);
    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);
    return rs.filter(s => s.enabled && s.id !== 'team').reduce((sum, s) => {
      return sum + entryCount(dotEntries[`${h}_${pi}_${s.id}`]);
    }, 0);
  };

  // ── Zoom button — SVG magnifier, rendered as floating element above the
  // totals column header. Positioned absolutely in the wrapper div so it
  // sits in the negative space between the page header and the table header.
  // Only shown when canZoom (not in read-only RoundSummaryModal context).
  const ZoomBtn = () => (
    <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 2, paddingRight: 2 }}>
      <button
        onClick={openZoom}
        title="Open zoom score entry"
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          padding: '2px 4px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        aria-label="Zoom score entry"
      >
        {/* Refined magnifier — 28×28, clean strokes */}
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="7.5" stroke={G} strokeWidth="2.2"/>
          <line x1="17.8" y1="17.8" x2="24" y2="24" stroke={G} strokeWidth="2.4" strokeLinecap="round"/>
          <line x1="9" y1="12" x2="15" y2="12" stroke={G} strokeWidth="1.8" strokeLinecap="round"/>
          <line x1="12" y1="9" x2="12" y2="15" stroke={G} strokeWidth="1.8" strokeLinecap="round"/>
        </svg>
      </button>
    </div>
  );

  const renderHalf = (hs, halfLabel, showZoom = false) => {
    return (
      <div style={{ marginBottom: 14 }}>
        {/* Half label row — zoom button only on the first (Front 9) half */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
          <div style={{ fontWeight: 700, color: G, fontSize: 12 }}>{halfLabel}</div>
          {canZoom && showZoom && <ZoomBtn />}
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%', minWidth: NAME_MIN + 9 * COL_W + TOT_W }}>
            <colgroup>
              <col/>
              {hs.map(h => <col key={h} style={{ width: COL_W }}/>)}
              <col style={{ width: TOT_W }}/>
            </colgroup>
            <thead><tr>
              <th style={{ padding: '4px 4px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'left' }}></th>
              {hs.map(h => <th key={h} style={{ padding: '3px 1px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              {/* "T" for total — centered, was "9" */}
              <th style={{ padding: '3px 3px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>T</th>
            </tr></thead>
            <tbody>
              <tr>
                <td style={{ padding: '2px 6px', fontSize: 10, color: G, fontWeight: 700, background: '#f8fbf8' }}>Par</td>
                {hs.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 10, color: G, fontWeight: 600, background: '#f8fbf8' }}>{pars[h]}</td>)}
                <td style={{ textAlign: 'center', fontSize: 10, color: G, fontWeight: 700, background: '#f8fbf8' }}>{parTotal(hs)}</td>
              </tr>
              <tr>
                <td style={{ padding: '1px 6px', fontSize: 9, color: '#aaa', fontWeight: 600, background: '#fafcfa' }}>M.Hcp</td>
                {hs.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 9, color: '#ccc', background: '#fafcfa' }}>{hcps[h]}</td>)}
                <td/>
              </tr>
              {players.map((p, pi) => {
                const gt9 = grossTotal(pi, hs);
                const nt9 = netTotal(pi, hs);
                return <tr key={pi} style={{ background: pi % 2 === 0 ? '#fff' : '#f5fbf5' }}>
                  <td style={{ padding: '2px 4px', fontSize: 11, fontWeight: 600, color: '#333', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</td>
                  {hs.map(h => {
                    const dotCount = sc(h, pi);
                    return <td key={h} style={{ padding: 1, position: 'relative' }}>
                      <div style={{ position: 'relative' }}>
                        <input
                          ref={el => refs.current[`${h}_${pi}`] = el}
                          type="text" inputMode="numeric" pattern="[0-9]*"
                          value={scores[h]?.[pi] ?? ''}
                          onChange={e => handleScore(h, pi, e.target.value)}
                          onKeyDown={e => handleKeyDown(h, pi, e)}
                          onFocus={e => e.target.select()}
                          onMouseDown={e => { if (document.activeElement === e.target) { e.preventDefault(); e.target.select(); } }}
                          onTouchStart={() => startLongPress(h, pi)}
                          onTouchEnd={() => cancelLongPress(h, pi)}
                          onTouchMove={() => cancelLongPress(h, pi)}
                          style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #ddd', borderRadius: 4, textAlign: 'center', fontSize: 13, padding: '5px 0', fontFamily: 'inherit', background: '#fff', color: '#222', outline: 'none', WebkitAppearance: 'none', display: 'block' }}
                        />
                        <DotBadge count={dotCount}/>
                        {dotMode && <PopDots courseHcp={courseHcps[pi]} hcpRank={hcps[h]} minCourseHcp={minCourseHcp} mode={dotMode}/>}
                      </div>
                    </td>;
                  })}
                  <td style={{ textAlign: 'center', fontWeight: 700, color: '#222', fontSize: 11, padding: '2px 4px', whiteSpace: 'nowrap', lineHeight: 1.2 }}>
                    {gt9 || '-'}{gt9 > 0 && <><br/><span style={{ fontSize: 9, color: '#888', fontWeight: 400 }}>({nt9})</span></>}
                  </td>
                </tr>;
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderLandscape = () => {
    const FRONT = [0,1,2,3,4,5,6,7,8];
    const BACK  = [9,10,11,12,13,14,15,16,17];
    const tableMinW = NAME_MIN + 18 * COL_W + 2 * TOT_W + TOT_W;
    return (
      <div style={{ marginBottom: 14 }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%', minWidth: tableMinW }}>
            <colgroup>
              <col style={{ minWidth: NAME_MIN }}/>
              {FRONT.map(h => <col key={h} style={{ width: COL_W }}/>)}
              <col style={{ width: TOT_W }}/>
              {BACK.map(h => <col key={h} style={{ width: COL_W }}/>)}
              <col style={{ width: TOT_W }}/>
              <col style={{ width: TOT_W }}/>
            </colgroup>
            <thead>
              <tr>
                <th style={{ padding: '3px 4px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'left' }}></th>
                {FRONT.map(h => <th key={h} style={{ padding: '2px 1px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>{h+1}</th>)}
                <th style={{ padding: '2px 3px', background: '#e8f0e8', color: G, fontSize: 10, fontWeight: 800, textAlign: 'center' }}>F</th>
                {BACK.map(h => <th key={h} style={{ padding: '2px 1px', background: '#f0f4f0', color: '#555', fontSize: 10, textAlign: 'center' }}>{h+1}</th>)}
                <th style={{ padding: '2px 3px', background: '#e8f0e8', color: G, fontSize: 10, fontWeight: 800, textAlign: 'center' }}>B</th>
                <th style={{ padding: '2px 3px', background: '#d8ead8', color: G, fontSize: 10, fontWeight: 800, textAlign: 'center' }}>T</th>
              </tr>
              <tr>
                <td style={{ padding: '1px 6px', fontSize: 9, color: G, fontWeight: 700, background: '#f8fbf8' }}>Par</td>
                {FRONT.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 600, background: '#f8fbf8' }}>{pars[h]}</td>)}
                <td style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 700, background: '#f0f7f0' }}>{parTotal(FRONT)}</td>
                {BACK.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 600, background: '#f8fbf8' }}>{pars[h]}</td>)}
                <td style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 700, background: '#f0f7f0' }}>{parTotal(BACK)}</td>
                <td style={{ textAlign: 'center', fontSize: 9, color: G, fontWeight: 700, background: '#eaf4ea' }}>{parTotal([...FRONT,...BACK])}</td>
              </tr>
              <tr>
                <td style={{ padding: '1px 6px', fontSize: 9, color: '#aaa', fontWeight: 600, background: '#fafcfa' }}>M.Hcp</td>
                {FRONT.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 9, color: '#ccc', background: '#fafcfa' }}>{hcps[h]}</td>)}
                <td style={{ background: '#fafcfa' }}/>
                {BACK.map(h => <td key={h} style={{ textAlign: 'center', fontSize: 9, color: '#ccc', background: '#fafcfa' }}>{hcps[h]}</td>)}
                <td style={{ background: '#fafcfa' }}/><td style={{ background: '#fafcfa' }}/>
              </tr>
            </thead>
            <tbody>
              {players.map((p, pi) => {
                const gF = grossTotal(pi, FRONT), nF = netTotal(pi, FRONT);
                const gB = grossTotal(pi, BACK),  nB = netTotal(pi, BACK);
                return (
                  <tr key={pi} style={{ background: pi % 2 === 0 ? '#fff' : '#f5fbf5' }}>
                    <td style={{ padding: '2px 4px', fontSize: 11, fontWeight: 600, color: '#333', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</td>
                    {FRONT.map(h => {
                      const dotCount = sc(h, pi);
                      return <td key={h} style={{ padding: 1, position: 'relative' }}>
                        <div style={{ position: 'relative' }}>
                          <input
                            ref={el => refs.current[`${h}_${pi}`] = el}
                            type="text" inputMode="numeric" pattern="[0-9]*"
                            value={scores[h]?.[pi] ?? ''}
                            onChange={e => handleScore(h, pi, e.target.value)}
                            onKeyDown={e => handleKeyDown(h, pi, e)}
                            onFocus={e => e.target.select()}
                            onMouseDown={e => { if (document.activeElement === e.target) { e.preventDefault(); e.target.select(); } }}
                            onTouchStart={() => startLongPress(h, pi)}
                            onTouchEnd={() => cancelLongPress(h, pi)}
                            onTouchMove={() => cancelLongPress(h, pi)}
                            style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #ddd', borderRadius: 4, textAlign: 'center', fontSize: 12, padding: '4px 0', fontFamily: 'inherit', background: '#fff', color: '#222', outline: 'none', WebkitAppearance: 'none', display: 'block' }}
                          />
                          <DotBadge count={dotCount}/>
                          {dotMode && <PopDots courseHcp={courseHcps[pi]} hcpRank={hcps[h]} minCourseHcp={minCourseHcp} mode={dotMode}/>}
                        </div>
                      </td>;
                    })}
                    <td style={{ textAlign: 'center', fontWeight: 700, color: G, fontSize: 10, padding: '1px 2px', background: '#f0f7f0', whiteSpace: 'nowrap', lineHeight: 1.1 }}>
                      {gF||'-'}{gF>0&&<><br/><span style={{ fontSize:8,color:'#888',fontWeight:400 }}>({nF})</span></>}
                    </td>
                    {BACK.map(h => {
                      const dotCount = sc(h, pi);
                      return <td key={h} style={{ padding: 1, position: 'relative' }}>
                        <div style={{ position: 'relative' }}>
                          <input
                            ref={el => refs.current[`${h}_${pi}`] = el}
                            type="text" inputMode="numeric" pattern="[0-9]*"
                            value={scores[h]?.[pi] ?? ''}
                            onChange={e => handleScore(h, pi, e.target.value)}
                            onKeyDown={e => handleKeyDown(h, pi, e)}
                            onFocus={e => e.target.select()}
                            onMouseDown={e => { if (document.activeElement === e.target) { e.preventDefault(); e.target.select(); } }}
                            onTouchStart={() => startLongPress(h, pi)}
                            onTouchEnd={() => cancelLongPress(h, pi)}
                            onTouchMove={() => cancelLongPress(h, pi)}
                            style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #ddd', borderRadius: 4, textAlign: 'center', fontSize: 12, padding: '4px 0', fontFamily: 'inherit', background: '#fff', color: '#222', outline: 'none', WebkitAppearance: 'none', display: 'block' }}
                          />
                          <DotBadge count={dotCount}/>
                          {dotMode && <PopDots courseHcp={courseHcps[pi]} hcpRank={hcps[h]} minCourseHcp={minCourseHcp} mode={dotMode}/>}
                        </div>
                      </td>;
                    })}
                    <td style={{ textAlign: 'center', fontWeight: 700, color: G, fontSize: 10, padding: '1px 2px', background: '#f0f7f0', whiteSpace: 'nowrap', lineHeight: 1.1 }}>
                      {gB||'-'}{gB>0&&<><br/><span style={{ fontSize:8,color:'#888',fontWeight:400 }}>({nB})</span></>}
                    </td>
                    <td style={{ textAlign: 'center', fontWeight: 800, color: G, fontSize: 11, padding: '1px 3px', background: '#e8f4e8', whiteSpace: 'nowrap', lineHeight: 1.1 }}>
                      {(gF+gB)||'-'}{(gF+gB)>0&&<><br/><span style={{ fontSize:8,color:'#888',fontWeight:400 }}>(n{nF+nB})</span></>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const hasGameTables = ['Nines','Stableford','Skins','Stroke Play','Match / Nassau','Sixes'].some(g => activeGames.includes(g));

  return (
    <div>
      {/* Hidden input for zoom modal keyboard — always rendered when zoom is available
          so it can be focused synchronously inside the zoom button tap gesture.
          Positioned above viewport so iOS focus causes no scroll. */}
      {canZoom && (
        <input
          ref={zoomHiddenInputRef}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          defaultValue=""
          readOnly={!zoomOpen}
          style={{
            position: 'fixed', top: -100, left: 0,
            width: 1, height: 1, opacity: 0,
            border: 'none', outline: 'none',
            background: 'transparent',
            fontSize: 16,
          }}
        />
      )}
      {/* DotsPopup — zIndex 400, renders above ZoomModal (zIndex 200) */}
      {popup && (
        <DotsPopup
          hole={popup.hole} pi={popup.pi}
          playerName={players[popup.pi]?.name}
          par={pars[popup.hole]}
          gross={parseInt(scores[popup.hole]?.[popup.pi]) || null}
          dots={dots} entries={dotEntries} setEntries={setDotEntries}
          sixesTeams={sixesTeams} matches={matches} players={players}
          gameOpts={gameOpts}
          onClose={() => {
            setPopup(null);
            if (zoomOpen && zoomFocusRef.current) {
              requestAnimationFrame(() => zoomFocusRef.current?.());
            }
          }}
          courseHcps={courseHcps} hcps={hcps} minCourseHcp={minCourseHcp}
          paddingTop={zoomOpen ? 92 : undefined}
        />
      )}

      {/* ZoomModal */}
      {zoomOpen && (
        <ZoomModal
          players={players} pars={pars} hcps={hcps}
          courseHcps={courseHcps} minCourseHcp={minCourseHcp}
          scores={scores}
          dotMode={dotMode} isMixed={isMixed} setDotModeOverride={setDotModeOverride}
          handleScore={handleScore}
          startLongPress={startLongPress} cancelLongPress={cancelLongPress}
          dotsGameActive={dotsGameActive} sc={sc}
          zoomHole={zoomHole} setZoomHole={setZoomHole} setZoomOpen={closeZoom}
          setPopup={setPopup}
          hiddenInputRef={zoomHiddenInputRef}
          focusRef={zoomFocusRef}
        />
      )}

      {isLandscape
        ? renderLandscape()
        : (
          <>
            {renderHalf([0,1,2,3,4,5,6,7,8], `Front 9${frontLabel ? ` (${frontLabel})` : ''}`, true)}
            {renderHalf([9,10,11,12,13,14,15,16,17], `Back 9${backLabel ? ` (${backLabel})` : ''}`, false)}
          </>
        )
      }
      {dotsGameActive && (
        <div style={{ fontSize: 10, color: '#888', marginBottom: 10 }}>Hold any score cell to log dots · ⚡ birdie/eagle/ace auto-marked</div>
      )}
      <div style={{ paddingTop: 4, marginTop: 4 }}>
        <TotalsCard
          players={players} pars={pars} scores={scores}
          courseHcps={courseHcps} hcps={hcps}
          minCourseHcp={minCourseHcp} primaryMode={primaryMode}
        />
        {hasGameTables && (
          <>
            {activeGames.includes('Nines')           && <NinesTable        players={players} scores={scores} pars={pars} hcps={hcps} opts={gameOpts.Nines}          courseHcps={courseHcps} minCourseHcp={minCourseHcp} ninesPlayers={ninesPlayers}          isLandscape={isLandscape}/>}
            {activeGames.includes('Stableford')       && <StablefordTable   players={players} scores={scores} pars={pars} hcps={hcps} opts={gameOpts.Stableford}     courseHcps={courseHcps} minCourseHcp={minCourseHcp} stablefordPlayers={stablefordPlayers}  isLandscape={isLandscape}/>}
            {activeGames.includes('Skins')            && <SkinsTable        players={players} scores={scores}             hcps={hcps} opts={gameOpts.Skins}           courseHcps={courseHcps} minCourseHcp={minCourseHcp} skinsPlayerIdxs={skinsPlayers}          isLandscape={isLandscape}/>}
            {activeGames.includes('Stroke Play')      && <StrokePlayTable   players={players} scores={scores} pars={pars} hcps={hcps} opts={gameOpts['Stroke Play']} courseHcps={courseHcps} minCourseHcp={minCourseHcp} strokePlayPlayers={strokePlayPlayers}  isLandscape={isLandscape}/>}
            {activeGames.includes('Match / Nassau')   && <MatchNassauTable  players={players} scores={scores}             hcps={hcps} matches={matches || []}         courseHcps={courseHcps} minCourseHcp={minCourseHcp} manualPresses={manualPresses} setManualPresses={setManualPresses} isLandscape={isLandscape}/>}
            {activeGames.includes('Sixes') && <SixesTable players={players} scores={scores} hcps={hcps} opts={gameOpts.Sixes} courseHcps={courseHcps} minCourseHcp={minCourseHcp} sixesTeams={sixesTeams} manualPresses={manualPresses} setManualPresses={setManualPresses}/>}
          </>
        )}
        {dotsGameActive && (
          <DotsTable
            players={players} dots={dots} dotEntries={dotEntries}
            gameOpts={gameOpts} dotsPlayers={dotsPlayers}
            isLandscape={isLandscape}
          />
        )}
      </div>
    </div>
  );
}
