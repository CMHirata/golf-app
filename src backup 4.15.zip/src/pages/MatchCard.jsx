// ─── MatchCard.jsx ────────────────────────────────────────────────────────────
// One Match/Nassau instance configuration card.
// Render-only extraction from NewRoundPage.jsx — no logic changes.
// Props: match, idx, players, onChange, onRemove, canRemove

import { useState } from 'react';
import { BetInput, G, GA } from '../components/ui.jsx';
import { ConfigSection } from './tables/GameConfig.jsx';
import { PlayerDropdown, ReadOnlyBubble, StyledSel } from './PlayerDropdown.jsx';

const SCORING_OPTS    = [{ value:'net',label:'Net' },{ value:'gross',label:'Gross' },{ value:'netofflow',label:'Net Off Low' }];
const AUTO_PRESS_OPTS = [{ value:'none',label:'Press' },{ value:'1',label:'1 down' },{ value:'2',label:'2 down' },{ value:'3',label:'3 down' },{ value:'4',label:'4 down' },{ value:'5',label:'5 down' }];
const TIEBREAK_OPTS   = [{ value:'none',label:'None' },{ value:'second',label:'2nd ball' },{ value:'half',label:'Half point' }];

// Compact inline row: label on left, control on right
function InlineRow({ label, children }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, marginBottom:6 }}>
      <span style={{ fontSize:11, fontWeight:700, color:'#666', flexShrink:0 }}>{label}</span>
      <div style={{ flexShrink:0 }}>{children}</div>
    </div>
  );
}

export default function MatchCard({ match, idx, players, onChange, onRemove, canRemove }) {
  const set = (key, val) => onChange({ ...match, [key]: val });
  const isTeam = match.format === 'team';

  // Local UI state for bet mode — initialise from whether F/B bets are present
  const [betMode, setBetMode] = useState(() =>
    (match.betFront > 0 || match.betBack > 0) ? 'nassau' : 'single'
  );
  const isNassauBet = betMode === 'nassau';

  const switchBetMode = v => {
    setBetMode(v);
    if (v === 'single') onChange({ ...match, betFront: 0, betBack: 0 });
  };

  const teamA = match.teamA || [];

  // Team A slot setters — auto-derive Team B as the remaining two players
  const setTeamASlot = (slot, pi) => {
    const other = slot === 0 ? teamA[1] ?? null : teamA[0] ?? null;
    const newA = slot === 0
      ? [pi, other].filter(x => x != null)
      : [other, pi].filter(x => x != null);
    // Dedupe — if same player picked for both slots, only keep this pick
    const cleanA = pi != null && newA[0] === newA[1] ? [pi] : newA;
    const newB = players.map((_, i) => i).filter(i => !cleanA.includes(i));
    onChange({ ...match, teamA: cleanA, teamB: newB });
  };

  const teamASlot0 = teamA[0] ?? null;
  const teamASlot1 = teamA[1] ?? null;
  const teamAFull  = teamASlot0 != null && teamASlot1 != null;
  const teamBPlayers = teamAFull ? players.map((_, i) => i).filter(i => !teamA.includes(i)) : [];

  return (
    <div style={{ border:`1.5px solid ${G}`,borderRadius:12,padding:'12px 13px',marginBottom:8,background:'#fff' }}>
      {/* Header */}
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10 }}>
        <div style={{ fontWeight:700,fontSize:13,color:G }}>
          Match {idx + 1} · <span style={{ fontWeight:400,color:'#555',fontSize:12 }}>{isNassauBet ? 'Nassau' : 'Match'}</span>
        </div>
        {canRemove && (
          <button onClick={onRemove} style={{ border:'none',background:'none',cursor:'pointer',fontSize:16,color:'#ccc',padding:'0 4px',lineHeight:1 }}>✕</button>
        )}
      </div>

      {/* Format toggle */}
      <div style={{ display:'flex',gap:6,marginBottom:10 }}>
        {['individual','team'].map(f => (
          <button key={f} onClick={()=>set('format', f)}
            style={{ flex:1,padding:'6px 0',borderRadius:20,border:`1.5px solid ${match.format===f?G:'#ddd'}`,background:match.format===f?GA:'#fff',cursor:'pointer',fontSize:12,fontWeight:600,color:match.format===f?G:'#666',fontFamily:'inherit' }}>
            {f === 'individual' ? 'Individual' : 'Team'}
          </button>
        ))}
      </div>

      {/* ── Players section ── */}
      <ConfigSection label="Players">

        {/* Individual: two trigger bubbles + shared full-width dropdown panel */}
        {!isTeam && (
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <div style={{ flex:1, minWidth:0 }}>
              <PlayerDropdown
                players={players}
                value={match.p1}
                onChange={v => set('p1', v)}
                label="Player 1"
                excludeIdxs={match.p2 != null ? [match.p2] : []}
              />
            </div>
            <span style={{ fontSize:12, color:'#aaa', flexShrink:0 }}>vs</span>
            <div style={{ flex:1, minWidth:0 }}>
              <PlayerDropdown
                players={players}
                value={match.p2}
                onChange={v => set('p2', v)}
                label="Player 2"
                excludeIdxs={match.p1 != null ? [match.p1] : []}
              />
            </div>
          </div>
        )}

        {/* Team: Team A dropdowns + auto-populated Team B read-only bubbles */}
        {isTeam && (
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {/* Team A row */}
            <div>
              <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:5, textTransform:'uppercase', letterSpacing:'0.05em' }}>Team A</div>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <div style={{ flex:1, minWidth:0 }}>
                  <PlayerDropdown
                    players={players}
                    value={teamASlot0}
                    onChange={v => setTeamASlot(0, v)}
                    label="Player 1"
                    excludeIdxs={[teamASlot1].filter(x => x != null)}
                  />
                </div>
                <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>&</span>
                <div style={{ flex:1, minWidth:0 }}>
                  <PlayerDropdown
                    players={players}
                    value={teamASlot1}
                    onChange={v => setTeamASlot(1, v)}
                    label="Player 2"
                    excludeIdxs={[teamASlot0].filter(x => x != null)}
                  />
                </div>
              </div>
            </div>
            {/* Team B — only shown when Team A is full */}
            {teamAFull && (
              <div>
                <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:5, textTransform:'uppercase', letterSpacing:'0.05em' }}>Team B</div>
                <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                  <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[teamBPlayers[0]]??null}/></div>
                  <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>&</span>
                  <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[teamBPlayers[1]]??null}/></div>
                </div>
              </div>
            )}
            {/* Tiebreak moved to Options section */}
          </div>
        )}
      </ConfigSection>

      {/* ── Options ── */}
      <ConfigSection label="Options">
        <InlineRow label="Scoring">
          <StyledSel value={match.scoring||'net'} onChange={v=>set('scoring',v)} options={SCORING_OPTS}/>
        </InlineRow>
        {isTeam && teamAFull && teamBPlayers.length >= 2 && (
          <InlineRow label="Tie-break">
            <StyledSel value={match.tiebreak||'none'} onChange={v=>set('tiebreak',v)} options={TIEBREAK_OPTS}/>
          </InlineRow>
        )}
      </ConfigSection>

      {/* ── Bets & Press ── */}
      <ConfigSection label="Bets">
        {/* Line 1: Overall / Nassau full-width toggle */}
        <div style={{ display:'flex', gap:6, marginBottom:8 }}>
          {[{v:'single',l:'Overall'},{v:'nassau',l:'Nassau'}].map(({v,l}) => (
            <button key={v} onClick={()=>switchBetMode(v)}
              style={{ flex:1, padding:'7px 4px', borderRadius:20,
                       border:`1.5px solid ${betMode===v?G:'#ddd'}`,
                       background:betMode===v?GA:'#fff',
                       cursor:'pointer', fontSize:12, fontWeight:600,
                       color:betMode===v?G:'#666', fontFamily:'inherit', textAlign:'center' }}>
              {l}
            </button>
          ))}
        </div>

        {/* Overall mode: bet field and press each full width on own line */}
        {!isNassauBet && (
          <>
            <BetInput value={match.betOverall||0} onChange={v=>set('betOverall',v)} style={{ width:'100%',boxSizing:'border-box', marginBottom:5 }}/>
            <StyledSel value={match.autoPressO||'none'} onChange={v=>set('autoPressO',v)} options={AUTO_PRESS_OPTS} width="100%"/>
          </>
        )}

        {/* Nassau mode: labels row + bet fields row + press row */}
        {isNassauBet && (
          <>
            {/* Column labels */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, marginBottom:3 }}>
              {['Front','Back','Overall'].map(l => (
                <div key={l} style={{ fontSize:10,color:'#888',textAlign:'center' }}>{l}</div>
              ))}
            </div>
            {/* Bet inputs */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, marginBottom:5 }}>
              <BetInput value={match.betFront||0} onChange={v=>set('betFront',v)} style={{ width:'100%',boxSizing:'border-box' }}/>
              <BetInput value={match.betBack||0} onChange={v=>set('betBack',v)} style={{ width:'100%',boxSizing:'border-box' }}/>
              <BetInput value={match.betOverall||0} onChange={v=>set('betOverall',v)} style={{ width:'100%',boxSizing:'border-box' }}/>
            </div>
            {/* Press dropdowns — no column labels, directly below bet fields */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 }}>
              <StyledSel value={match.autoPressF||'none'} onChange={v=>set('autoPressF',v)} options={AUTO_PRESS_OPTS} width="100%"/>
              <StyledSel value={match.autoPressB||'none'} onChange={v=>set('autoPressB',v)} options={AUTO_PRESS_OPTS} width="100%"/>
              <StyledSel value={match.autoPressO||'none'} onChange={v=>set('autoPressO',v)} options={AUTO_PRESS_OPTS} width="100%"/>
            </div>
          </>
        )}
      </ConfigSection>

    </div>
  );
}
