// ─── tables/DotsTable.jsx ─────────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js

import { useState } from 'react';
import { restoreDotDefs, SP_CLR, SP_BG, SP_HDR, COL_W, TOT_W, NAME_MIN } from '../scorecard/scorecardUtils.js';
import { GameSection, HalfLabel, TableDivider } from '../scorecard/GameSection.jsx';

const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);

const SP = {
  hdrBg:  SP_HDR,
  hdrClr: SP_CLR,
  totBg:  '#dac8f5',   // always-dark shade for totals column
  totClr: SP_CLR,
  row:    [SP_BG, '#faf5ff'],
  border: '#dac8f5',
};

export function DotsTable({ players, dots, dotEntries, gameOpts, dotsPlayers, isLandscape }) {
  const [tooltip, setTooltip] = useState(null);

  const restored = restoreDotDefs(dots);

  const rawTeamMode = gameOpts?.Dots?.teamMode ?? gameOpts?.Specials?.teamMode;
  const legacyTeam  = gameOpts?.Dots?.teamScoring ?? gameOpts?.Specials?.teamScoring;
  const isTeamMode  = rawTeamMode ? rawTeamMode !== 'none' : !!legacyTeam;

  const enabled   = (restored || []).filter(s => s.enabled && (s.id !== 'team' || isTeamMode));
  if (!enabled.length) return null;

  const dtIdxs    = dotsPlayers?.length ? dotsPlayers : players.map((_, i) => i);
  const dtPlayers = dtIdxs.map(i => players[i]).filter(Boolean);
  const FRONT     = [0,1,2,3,4,5,6,7,8];
  const BACK      = [9,10,11,12,13,14,15,16,17];
  const ALL18     = [...FRONT, ...BACK];

  // Raw dot count for (hole, player) — all entries including team
  const cellCount = (h, pi) => {
    let total = 0;
    Object.entries(dotEntries || {}).forEach(([key, v]) => {
      const cnt = entryCount(v);
      if (!cnt) return;
      const parts = key.split('_');
      if (parseInt(parts[0]) !== h || parseInt(parts[1]) !== pi) return;
      total += cnt;
    });
    return total;
  };

  // Tooltip lines for (hole, player)
  const tooltipLines = (h, pi) => {
    const lines = [];
    enabled.filter(sp => sp.id !== 'team').forEach(sp => {
      const cnt = entryCount(dotEntries?.[`${h}_${pi}_${sp.id}`]);
      if (cnt > 0) lines.push(cnt > 1 ? `${sp.name} ×${cnt}` : sp.name);
    });
    if (isTeamMode) {
      let teamCnt = 0;
      Object.entries(dotEntries || {}).forEach(([key, v]) => {
        const cnt = entryCount(v);
        if (!cnt) return;
        const parts = key.split('_');
        if (parseInt(parts[0]) !== h || parseInt(parts[1]) !== pi) return;
        if (parts[2] === 'team') teamCnt += cnt;
      });
      if (teamCnt > 0) lines.push(teamCnt > 1 ? `Team ×${teamCnt}` : 'Team');
    }
    return lines;
  };

  const playerHolesTot = (pi, holes) => holes.reduce((s, h) => s + cellCount(h, pi), 0);
  const playerRoundTot = (pi)         => playerHolesTot(pi, ALL18);
  const holeTotal      = (h)          => dtIdxs.reduce((sum, pi) => sum + cellCount(h, pi), 0);

  const handleCellTap = (h, pi, count) => {
    if (!count) return;
    setTooltip(prev => (prev?.hole === h && prev?.pi === pi) ? null : { hole: h, pi });
  };

  const TooltipBubble = ({ h, pi }) => {
    const lines = tooltipLines(h, pi);
    if (!lines.length) return null;
    return (
      <div onClick={e => e.stopPropagation()} style={{
        position: 'absolute', top: '100%', right: 0, zIndex: 50,
        background: '#fff', border: `1.5px solid ${SP_CLR}`,
        borderRadius: 8, padding: '5px 9px', minWidth: 90,
        boxShadow: '0 4px 16px rgba(0,0,0,.18)',
        fontSize: 11, color: SP_CLR, fontWeight: 600, whiteSpace: 'nowrap',
      }}>
        {lines.map((l, i) => <div key={i}>{l}</div>)}
      </div>
    );
  };

  // ── Score cell ──────────────────────────────────────────────────────────────
  const ScoreCell = ({ h, pi }) => {
    const cnt    = cellCount(h, pi);
    const isOpen = tooltip?.hole === h && tooltip?.pi === pi;
    return (
      <td
        onClick={e => { e.stopPropagation(); handleCellTap(h, pi, cnt); }}
        style={{ textAlign: 'center', fontSize: 12, position: 'relative',
                 fontWeight: cnt > 0 ? 700 : 400,
                 color: cnt > 0 ? SP.hdrClr : '#ddd',
                 cursor: cnt > 0 ? 'pointer' : 'default',
                 padding: '3px 1px' }}
      >
        {cnt > 0 ? cnt : '·'}
        {isOpen && <TooltipBubble h={h} pi={pi}/>}
      </td>
    );
  };

  // ── Totals cell — always uses dark shade regardless of value ────────────────
  const TotCell = ({ value, wide }) => (
    <td style={{
      textAlign: 'center', fontWeight: 700,
      fontSize: wide ? 12 : 11,
      color: SP.totClr,
      background: SP.totBg,   // always dark — never transparent
      padding: wide ? '2px 4px' : '2px 4px',
    }}>
      {value > 0 ? value : '·'}
    </td>
  );

  // ── Grid for portrait half or full landscape ────────────────────────────────
  const renderGrid = (holes, label) => {
    const colLabel = label === 'Front 9' ? 'F9' : label === 'Back 9' ? 'B9' : 'Tot';
    return (
      <>
        {label && <HalfLabel>{label}</HalfLabel>}
        <div style={{ padding: '0 8px 4px', overflowX: 'auto' }} onClick={() => setTooltip(null)}>
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%',
                          minWidth: NAME_MIN + holes.length * COL_W + TOT_W }}>
            <colgroup>
              <col style={{ minWidth: NAME_MIN }}/>
              {holes.map(h => <col key={h} style={{ width: COL_W }}/>)}
              <col style={{ width: TOT_W }}/>
            </colgroup>
            <thead>
              <tr>
                <th style={{ padding: '3px 6px', background: SP.hdrBg, color: SP.hdrClr, fontSize: 10, textAlign: 'left' }}></th>
                {holes.map(h => (
                  <th key={h} style={{ padding: '2px 1px', background: SP.hdrBg, color: SP.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>
                ))}
                <th style={{ padding: '2px 4px', background: SP.totBg, color: SP.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>{colLabel}</th>
              </tr>
            </thead>
            <tbody>
              {dtIdxs.map((pi, rowIdx) => (
                <tr key={pi} style={{ background: SP.row[rowIdx % 2] }}>
                  <td style={{ padding: '2px 6px', fontSize: 11, fontWeight: 700, color: SP.hdrClr,
                               overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {players[pi]?.name || ''}
                  </td>
                  {holes.map(h => <ScoreCell key={h} h={h} pi={pi}/>)}
                  <TotCell value={playerHolesTot(pi, holes)}/>
                </tr>
              ))}
              <tr style={{ borderTop: `1px solid ${SP.border}` }}>
                <td style={{ padding: '2px 6px', fontSize: 10, color: '#aaa', fontWeight: 600 }}>Total</td>
                {holes.map(h => {
                  const ht = holeTotal(h);
                  return (
                    <td key={h} style={{ textAlign: 'center', fontSize: 10,
                                         color: ht > 0 ? SP.hdrClr : '#ddd', fontWeight: ht > 0 ? 700 : 400 }}>
                      {ht > 0 ? ht : '·'}
                    </td>
                  );
                })}
                <TotCell value={dtIdxs.reduce((s, pi) => s + playerHolesTot(pi, holes), 0)}/>
              </tr>
            </tbody>
          </table>
        </div>
      </>
    );
  };

  const renderAll18 = () => {
    const frontTots = dtIdxs.map(pi => playerHolesTot(pi, FRONT));
    const backTots  = dtIdxs.map(pi => playerHolesTot(pi, BACK));
    const roundTots = dtIdxs.map(pi => playerRoundTot(pi));
    return (
      <div style={{ padding: '0 8px 4px', overflowX: 'auto' }} onClick={() => setTooltip(null)}>
        <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%',
                        minWidth: NAME_MIN + 18 * COL_W + 3 * TOT_W }}>
          <colgroup>
            <col style={{ minWidth: NAME_MIN }}/>
            {FRONT.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
            {BACK.map(h => <col key={h} style={{ width: COL_W }}/>)}
            <col style={{ width: TOT_W }}/>
            <col style={{ width: TOT_W }}/>
          </colgroup>
          <thead>
            <tr>
              <th style={{ padding: '3px 6px', background: SP.hdrBg, color: SP.hdrClr, fontSize: 10, textAlign: 'left' }}></th>
              {FRONT.map(h => <th key={h} style={{ padding: '2px 1px', background: SP.hdrBg, color: SP.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              <th style={{ padding: '2px 4px', background: SP.totBg, color: SP.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>F9</th>
              {BACK.map(h => <th key={h} style={{ padding: '2px 1px', background: SP.hdrBg, color: SP.hdrClr, fontSize: 10, textAlign: 'center' }}>{h + 1}</th>)}
              <th style={{ padding: '2px 4px', background: SP.totBg, color: SP.totClr, fontSize: 10, textAlign: 'center', fontWeight: 700 }}>B9</th>
              <th style={{ padding: '2px 4px', background: SP.totBg, color: SP.totClr, fontSize: 10, textAlign: 'center', fontWeight: 800 }}>Tot</th>
            </tr>
          </thead>
          <tbody>
            {dtIdxs.map((pi, rowIdx) => (
              <tr key={pi} style={{ background: SP.row[rowIdx % 2] }}>
                <td style={{ padding: '2px 6px', fontSize: 11, fontWeight: 700, color: SP.hdrClr,
                             overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {players[pi]?.name || ''}
                </td>
                {FRONT.map(h => <ScoreCell key={h} h={h} pi={pi}/>)}
                <TotCell value={frontTots[rowIdx]}/>
                {BACK.map(h => <ScoreCell key={h} h={h} pi={pi}/>)}
                <TotCell value={backTots[rowIdx]}/>
                <TotCell value={roundTots[rowIdx]} wide/>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  // ── Pivot summary — dot types as rows, players as columns ──────────────────
  // Only shows dot types that at least one player earned during the round.
  const dotTypeCount = (pi, dotId) => {
    let cnt = 0;
    for (let h = 0; h < 18; h++) cnt += entryCount(dotEntries?.[`${h}_${pi}_${dotId}`]);
    return cnt;
  };
  const teamDotCount = (pi) => {
    let cnt = 0;
    Object.entries(dotEntries || {}).forEach(([key, v]) => {
      const c = entryCount(v); if (!c) return;
      const parts = key.split('_');
      if (parseInt(parts[1]) !== pi) return;
      if (parts[2] === 'team') cnt += c;
    });
    return cnt;
  };

  // Active dot-type rows — only those with at least one dot earned by any player
  const activeRows = [
    ...enabled.filter(sp => sp.id !== 'team').filter(sp => dtIdxs.some(pi => dotTypeCount(pi, sp.id) > 0)),
    ...(isTeamMode && dtIdxs.some(pi => teamDotCount(pi) > 0) ? [{ id: 'team', name: 'Team' }] : []),
  ];

  const renderPivot = () => {
    if (!activeRows.length) return null;
    const roundTots = dtIdxs.map(pi => playerRoundTot(pi));
    const maxTot    = Math.max(...roundTots);

    return (
      <div style={{ margin: '0 8px 0', borderRadius: 8, overflow: 'hidden',
                    border: `1px solid ${SP.border}`, background: SP_BG }}>
        <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%' }}>
          <colgroup>
            <col style={{ minWidth: 70 }}/>
            {dtIdxs.map(pi => <col key={pi} style={{ width: `${Math.floor(100 / (dtIdxs.length + 1))}%` }}/>)}
          </colgroup>
          <thead>
            <tr>
              <th style={{ padding: '4px 8px', background: SP.hdrBg, color: SP.hdrClr,
                           fontSize: 10, textAlign: 'left', fontWeight: 700 }}>Type</th>
              {dtPlayers.map((p, i) => (
                <th key={i} style={{ padding: '4px 4px', background: SP.hdrBg, color: SP.hdrClr,
                                     fontSize: 10, textAlign: 'center', fontWeight: 700,
                                     overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {p.name.split(' ')[0]}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {activeRows.map((sp, ri) => (
              <tr key={sp.id} style={{ background: ri % 2 === 0 ? SP_BG : '#faf5ff' }}>
                <td style={{ padding: '4px 8px', fontSize: 11, fontWeight: 600, color: SP.hdrClr }}>{sp.name}</td>
                {dtIdxs.map(pi => {
                  const cnt = sp.id === 'team' ? teamDotCount(pi) : dotTypeCount(pi, sp.id);
                  return (
                    <td key={pi} style={{ textAlign: 'center', fontSize: 12,
                                         fontWeight: cnt > 0 ? 700 : 400,
                                         color: cnt > 0 ? SP.hdrClr : '#ccc' }}>
                      {cnt > 0 ? cnt : '·'}
                    </td>
                  );
                })}
              </tr>
            ))}
            {/* Total row — always dark */}
            <tr style={{ borderTop: `1.5px solid ${SP.border}` }}>
              <td style={{ padding: '4px 8px', fontSize: 11, fontWeight: 800, color: SP.totClr,
                           background: SP.totBg }}>Dots</td>
              {dtIdxs.map((pi, i) => {
                const tot       = roundTots[i];
                const isLeader  = tot > 0 && tot === maxTot;
                return (
                  <td key={pi} style={{
                    textAlign: 'center', fontSize: 14, fontWeight: 800,
                    color: SP.totClr,
                    background: isLeader ? '#c9a8f0' : SP.totBg, // brighter purple for leader
                    padding: '4px 2px',
                  }}>
                    {tot > 0 ? tot : '·'}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <GameSection title="Dots" color={SP.hdrClr} borderColor={SP.border}
      onClick={() => setTooltip(null)}
    >
      {isLandscape
        ? renderAll18()
        : (
          <>
            {renderGrid(FRONT, 'Front 9')}
            <TableDivider/>
            {renderGrid(BACK, 'Back 9')}
          </>
        )
      }
      <TableDivider/>
      <div style={{ padding: '8px 0 10px' }}>
        {renderPivot()}
      </div>
    </GameSection>
  );
}
