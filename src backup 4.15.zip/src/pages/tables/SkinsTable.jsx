// ─── tables/SkinsTable.jsx ────────────────────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js

import { calcSkinsHole } from '../../engine/games.js';
import { K, nameTd, scoringLabel } from '../scorecard/scorecardUtils.js';
import { GameSection, GameTable, HalfLabel, TableDivider, ColNote, PlayerChips } from '../scorecard/GameSection.jsx';

const FRONT = [0,1,2,3,4,5,6,7,8];
const BACK  = [9,10,11,12,13,14,15,16,17];

export function SkinsTable({ players, scores, hcps, opts, courseHcps, minCourseHcp, skinsPlayerIdxs, isLandscape }) {
  const mode  = opts?.scoring   || 'net';
  const carry = (opts?.carryover || 'yes') === 'yes';

  const displayIdxs = skinsPlayerIdxs?.length ? skinsPlayerIdxs : players.map((_, i) => i);

  const rows = []; let carryCount = 0;
  for (let h = 0; h < 18; h++) {
    const result = calcSkinsHole(h, scores, players, hcps, mode, courseHcps, minCourseHcp, displayIdxs);
    if (!result) break;
    if (result.tied) { carryCount++; rows.push({ h, tied: true }); }
    else { rows.push({ h, wi: result.wiIdx, value: carry ? 1 + carryCount : 1 }); carryCount = 0; }
  }

  const totals = displayIdxs.map(pi => rows.reduce((s, r) => s + (r.wi === pi ? r.value : 0), 0));

  const cellVal = (displayPos, h) => {
    const pi = displayIdxs[displayPos];
    const r  = rows.find(r => r.h === h);
    if (!r) return null;
    if (r.tied) return 'tie';
    return r.wi === pi ? r.value : 0;
  };

  const skinTd = (v, h) => {
    if (v === null)  return <td key={h} style={{ textAlign: 'center', color: '#ddd', fontSize: 11 }}>·</td>;
    if (v === 'tie') return <td key={h} style={{ textAlign: 'center', color: '#bbb', fontSize: 11 }}>–</td>;
    if (v === 0)     return <td key={h} style={{ textAlign: 'center', color: '#ececec', fontSize: 11 }}>·</td>;
    return (
      <td key={h} style={{ textAlign: 'center', padding: '1px' }}>
        <span style={{ display: 'inline-block', width: 20, height: 18, lineHeight: '18px', fontSize: 10, fontWeight: 700, color: K.hdrClr, background: v > 1 ? '#c4aaf0' : K.totBg, borderRadius: 3 }}>{v}</span>
      </td>
    );
  };

  const renderHalf = (hs, label) => {
    const halfTotals = displayIdxs.map((pi, pos) =>
      rows.filter(r => hs.includes(r.h) && r.wi === pi).reduce((s, r) => s + r.value, 0)
    );
    const displayPlayers = displayIdxs.map(i => players[i]).filter(Boolean);
    return (
      <>
        <HalfLabel>{label}</HalfLabel>
        <div style={{ padding: '0 8px 4px' }}>
          <GameTable hs={hs} colHeader="Skins" headerBg={K.hdrBg} headerColor={K.hdrClr} totBg={K.totBg} totColor={K.totClr}>
            {displayPlayers.map((p, pos) => (
              <tr key={displayIdxs[pos]} style={{ background: K.row[pos % 2] }}>
                <td style={{ ...nameTd, color: K.hdrClr }}>{p.name}</td>
                {hs.map(h => skinTd(cellVal(pos, h), h))}
                <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: K.totClr, background: K.totBg, padding: '2px 4px' }}>{halfTotals[pos] || '·'}</td>
              </tr>
            ))}
          </GameTable>
        </div>
      </>
    );
  };

  const renderAll18 = () => {
    const displayPlayers = displayIdxs.map(i => players[i]).filter(Boolean);
    const frontTots = displayIdxs.map((pi, pos) => rows.filter(r => FRONT.includes(r.h) && r.wi === pi).reduce((s, r) => s + r.value, 0));
    const backTots  = displayIdxs.map((pi, pos) => rows.filter(r => BACK.includes(r.h)  && r.wi === pi).reduce((s, r) => s + r.value, 0));
    return (
      <div style={{ padding: '0 8px 4px' }}>
        <GameTable landscape headerBg={K.hdrBg} headerColor={K.hdrClr} totBg={K.totBg} totColor={K.totClr}>
          {displayPlayers.map((p, pos) => (
            <tr key={displayIdxs[pos]} style={{ background: K.row[pos % 2] }}>
              <td style={{ ...nameTd, color: K.hdrClr }}>{p.name}</td>
              {FRONT.map(h => skinTd(cellVal(pos, h), h))}
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{frontTots[pos] || '·'}</td>
              {BACK.map(h => skinTd(cellVal(pos, h), h))}
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{backTots[pos] || '·'}</td>
              <td style={{ textAlign: 'center', fontSize: 11, fontWeight: 800, color: K.totClr, background: K.totBg, padding: '2px 3px' }}>{totals[pos] || '·'}</td>
            </tr>
          ))}
        </GameTable>
      </div>
    );
  };

  if (!rows.length) return null;
  const displayPlayers = displayIdxs.map(i => players[i]).filter(Boolean);

  return (
    <GameSection title="Skins" badge={`${scoringLabel(mode)} · Carry ${carry ? 'on' : 'off'}`} color={K.hdrClr} borderColor={K.border}>
      {isLandscape ? (
        renderAll18()
      ) : (
        <>
          {renderHalf(FRONT, 'Front 9')}
          <TableDivider/>
          {renderHalf(BACK, 'Back 9')}
        </>
      )}
      <TableDivider/>
      <PlayerChips players={displayPlayers} values={totals} chipBg={K.hdrBg} chipColor={K.hdrClr} leaderBg={K.totBg} leaderColor={K.totClr} fmtVal={v => v} subLabel="skins"/>
      <ColNote>Number = skins on that hole · darker = carryover · – = tied</ColNote>
    </GameSection>
  );
}
