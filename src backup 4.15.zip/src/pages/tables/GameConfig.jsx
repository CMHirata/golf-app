// ─── GameConfig.jsx ───────────────────────────────────────────────────────────
// Per-game bet/scoring configuration panel rendered inside NewRoundPage
// when a game toggle is active.
// Render-only extraction from NewRoundPage.jsx — no logic changes.
//
// Also exports: PlayerSubsetChips, ConfigSection (used by MatchCard.jsx)
//
// Props: game, opts, setOpt, bet, setBet, players, activeGames,
//        matches, setMatches,
//        sixesTeams, setSixesTeams,
//        strokePlayPlayers, setStrokePlayPlayers,
//        skinsPlayers, setSkinsPlayers,
//        ninesPlayers, setNinesPlayers,
//        stablefordPlayers, setStablefordPlayers,
//        dotsPlayers, setDotsPlayers,
//        dots, setDots

import { useState, useRef } from 'react';
import { ls, SK } from '../../services/storage.js';
import { DEFAULT_STAB } from '../../engine/handicap.js';
import { Btn, Sel, Inp, Tog, BetInput, G, GA, GB, RED } from '../../components/ui.jsx';
import MatchCard from '../MatchCard.jsx';
import { PlayerDropdown, ReadOnlyBubble, StyledSel } from '../PlayerDropdown.jsx';

// ── defaultMatch / makeMatchId ─────────────────────────────────────────────────
function makeMatchId() { return `m_${Date.now()}_${Math.random().toString(36).slice(2,6)}`; }

function defaultMatch(players, format = 'individual') {
  if (format === 'individual') {
    const p1 = players.length >= 1 ? 0 : null;
    const p2 = players.length === 2 ? 1 : null;
    return { id: makeMatchId(), format: 'individual', p1, p2, scoring: 'net', autoPressF: 'none', autoPressB: 'none', autoPressO: 'none', tiebreak: 'none', betFront: 0, betBack: 0, betOverall: 0 };
  }
  const tA = players.length >= 4 ? [0, 1] : [];
  const tB = players.length >= 4 ? [2, 3] : [];
  return { id: makeMatchId(), format: 'team', teamA: tA, teamB: tB, scoring: 'net', autoPressF: 'none', autoPressB: 'none', autoPressO: 'none', tiebreak: 'none', betFront: 0, betBack: 0, betOverall: 0 };
}

// ─── Player chip selector (inline subset picker) ───────────────────────────────
// Used for Skins, Stableford, Dots subset selection.
// No "All" button — unselected state (empty array) means all players included.
export function PlayerSubsetChips({ players, selectedIdxs, onChange, label, note, maxSelect }) {
  const n = players.length;
  // Grid columns: ≤3 → all on one row; 4 → 2×2; ≥5 → 3 cols
  const cols = n <= 3 ? n : n === 4 ? 2 : 3;

  return (
    <div style={{ marginBottom:8 }}>
      {label && <div style={{ fontSize:11,fontWeight:700,color:'#666',marginBottom:4 }}>{label}</div>}
      {note && <div style={{ fontSize:10,color:'#888',marginBottom:5 }}>{note}</div>}
      <div style={{ display:'grid', gridTemplateColumns:`repeat(${cols}, 1fr)`, gap:5 }}>
        {players.map((p,i) => {
          const allIn = selectedIdxs.length === 0;
          const on = allIn || selectedIdxs.includes(i);
          const atMax = maxSelect != null && selectedIdxs.length >= maxSelect && !selectedIdxs.includes(i);
          const toggle = () => {
            if (atMax) return;
            if (allIn) {
              onChange(players.map((_,j)=>j).filter(j=>j!==i));
              return;
            }
            const next = on ? selectedIdxs.filter(x=>x!==i) : [...selectedIdxs,i];
            onChange(next.length === players.length ? [] : next);
          };
          const parts = (p?.name || '').trim().split(/\s+/);
          const first = parts[0] || '?';
          const last  = parts.length >= 2 ? parts[parts.length - 1] : '';
          return (
            <div key={i} onClick={toggle}
              style={{ border:`1.5px solid ${on?G:atMax?'#eee':'#ddd'}`,background:on?GA:'#fff',borderRadius:20,padding:'5px 8px',cursor:atMax?'not-allowed':'pointer',textAlign:'center',minWidth:0,opacity:atMax?0.5:1 }}>
              <div style={{ fontSize:12,fontWeight:600,color:on?G:'#aaa',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',lineHeight:1.2 }}>{first}</div>
              {last && <div style={{ fontSize:10,fontWeight:400,color:on?G:'#aaa',opacity:0.7,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',lineHeight:1.2 }}>{last}</div>}
            </div>
          );
        })}
      </div>
      {selectedIdxs.length > 0 && selectedIdxs.length < players.length && (
        <div style={{ fontSize:10,color:'#888',marginTop:4 }}>
          {selectedIdxs.length}{maxSelect ? `/${maxSelect}` : ` of ${players.length}`} players · tap to toggle
        </div>
      )}
    </div>
  );
}

// ─── Section divider for game config ──────────────────────────────────────────
export function ConfigSection({ label, children }) {
  return (
    <div style={{ borderTop:'1px solid #ddeedd', marginTop:10, paddingTop:10 }}>
      {label && <div style={{ fontSize:11,fontWeight:700,color:'#666',marginBottom:6,textTransform:'uppercase',letterSpacing:'0.04em' }}>{label}</div>}
      {children}
    </div>
  );
}

// ─── Inline label + control row ───────────────────────────────────────────────
function InlineRow({ label, children }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, marginBottom:6 }}>
      <span style={{ fontSize:11, fontWeight:700, color:'#666', flexShrink:0 }}>{label}</span>
      <div style={{ flexShrink:0 }}>{children}</div>
    </div>
  );
}

// ─── Payout mode toggle (shared button pair, fixed width matching StyledSel) ──
function PayoutToggle({ options, value, onChange }) {
  return (
    <div style={{ display:'flex', gap:5, width:200 }}>
      {options.map(({v,l}) => (
        <button key={v} onClick={()=>onChange(v)}
          style={{ flex:1, padding:'6px 4px', borderRadius:20,
                   border:`1.5px solid ${value===v?G:'#ddd'}`,
                   background:value===v?GA:'#fff',
                   cursor:'pointer', fontSize:11, fontWeight:600,
                   color:value===v?G:'#666', fontFamily:'inherit',
                   whiteSpace:'nowrap', textAlign:'center' }}>
          {l}
        </button>
      ))}
    </div>
  );
}

// ─── Custom dot adder ──────────────────────────────────────────────────────────
function CustomDotAdder({ onAdd }) {
  const [name,  setName]  = useState('');
  const [value, setValue] = useState(1);
  const [multi, setMulti] = useState(true);
  return (
    <div style={{ marginTop:8, display:'flex', flexDirection:'column', gap:6 }}>
      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
        <Inp value={name} onChange={setName} placeholder="Custom dot…" style={{ flex:1,fontSize:12,padding:'5px 9px' }}/>
        <span style={{ fontSize:11, color:'#888', flexShrink:0 }}>×</span>
        <input type="text" inputMode="numeric" value={value}
          onChange={e=>{const v=parseInt(e.target.value);setValue(isNaN(v)||v<1?1:v);}}
          onFocus={e=>e.target.select()}
          style={{ width:34,border:'1px solid #ddd',borderRadius:7,padding:'5px 4px',fontSize:12,textAlign:'center' }}/>
        <Btn small disabled={!name.trim()} onClick={()=>{
          if(name.trim()){
            onAdd({id:`c_${Date.now()}`,name:name.trim(),value,enabled:true,auto:false,multi});
            setName('');setValue(1);setMulti(true);
          }
        }}>+ Add</Btn>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:6, paddingLeft:2 }}>
        <Tog small checked={multi} onChange={setMulti}/>
        <span style={{ fontSize:11, color:'#888' }}>Allow multiples per hole</span>
      </div>
    </div>
  );
}

// ─── DotRow ────────────────────────────────────────────────────────────────────
// Single row in the Dots to Track list. Extracted as a component so that
// swipe state (useState, useRef) lives at component level — not inside a map().
function DotRow({ sp, isEditing, editName, editValue, setEditName, setEditValue,
                  commitEdit, setEditingId, setDots, startEdit, deleteCustom }) {
  const isCustom = sp.id.startsWith('c_');
  const spValue  = sp.value ?? sp.pts ?? 1;

  const [swipeX,  setSwipeX]  = useState(0);
  const [swiping, setSwiping] = useState(false);
  const touchStartX = useRef(0);
  const REVEAL = 88;

  const onTouchStart = e => {
    touchStartX.current = e.touches[0].clientX;
    setSwiping(false);
  };
  const onTouchMove = e => {
    const dx = e.touches[0].clientX - touchStartX.current;
    if (dx < 0) { setSwiping(true); setSwipeX(Math.max(dx, -REVEAL)); }
  };
  const onTouchEnd = () => {
    if (swipeX < -REVEAL / 2) setSwipeX(-REVEAL);
    else { setSwipeX(0); setSwiping(false); }
  };
  const closeSwipe = () => { setSwipeX(0); setSwiping(false); };

  return (
    <div style={{ position:'relative', overflow:'hidden', borderRadius:8 }}>
      {/* Swipe action strip — custom dots only */}
      {isCustom && (
        <div style={{ position:'absolute', right:0, top:0, bottom:0,
                      display:'flex', alignItems:'stretch', zIndex:0 }}>
          <button onClick={() => { closeSwipe(); startEdit(sp); }}
            style={{ width:44, background:'#fff9e6', border:'none', cursor:'pointer',
                     fontSize:11, fontWeight:700, color:'#7a6000', fontFamily:'inherit' }}>
            Edit
          </button>
          <button onClick={() => { closeSwipe(); deleteCustom(sp.id); }}
            style={{ width:44, background:'#c0392b', border:'none', cursor:'pointer',
                     fontSize:11, fontWeight:700, color:'#fff', fontFamily:'inherit' }}>
            Del
          </button>
        </div>
      )}
      {/* Row content */}
      <div
        onTouchStart={isCustom ? onTouchStart : undefined}
        onTouchMove={isCustom ? onTouchMove : undefined}
        onTouchEnd={isCustom ? onTouchEnd : undefined}
        style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 9px',
                 borderRadius:8,
                 background: sp.enabled ? '#f0f8f0' : '#fafafa',
                 border: `1px solid ${sp.enabled ? '#c0dcc0' : '#eee'}`,
                 position:'relative', zIndex:1,
                 transform: `translateX(${swipeX}px)`,
                 transition: swiping ? 'none' : 'transform 0.2s ease' }}
      >
        <Tog small checked={sp.enabled}
          onChange={v => setDots(p => p.map(s => s.id === sp.id ? { ...s, enabled:v } : s))}/>
        {isEditing ? (
          <>
            <input
              autoFocus
              value={editName}
              onChange={e => setEditName(e.target.value)}
              onBlur={() => commitEdit(sp.id)}
              onKeyDown={e => { if (e.key==='Enter') commitEdit(sp.id); if (e.key==='Escape') setEditingId(null); }}
              style={{ flex:1, fontSize:12, border:'1px solid #aaddaa', borderRadius:5, padding:'2px 5px' }}
            />
            <span style={{ fontSize:11, color:'#888', flexShrink:0 }}>×</span>
            <input type="text" inputMode="numeric" value={editValue}
              onChange={e => { const v=parseInt(e.target.value); setEditValue(isNaN(v)||v<1?1:v>10?10:v); }}
              onFocus={e => e.target.select()}
              onBlur={() => commitEdit(sp.id)}
              style={{ width:34, border:'1px solid #ddd', borderRadius:6, padding:'2px 3px', fontSize:12, textAlign:'center' }}/>
          </>
        ) : (
          <>
            <span style={{ flex:1, fontSize:13, color: sp.enabled ? '#222' : '#aaa' }}>
              {sp.name}{sp.auto && <span style={{ fontSize:10, color:G, marginLeft:4 }}>auto</span>}
            </span>
            <span style={{ fontSize:11, color:'#888', flexShrink:0 }}>×</span>
            <input type="text" inputMode="numeric"
              value={spValue === 0 ? '' : String(spValue)}
              onChange={e => { const v=parseInt(e.target.value); setDots(p=>p.map(s=>s.id===sp.id?{...s,value:isNaN(v)||v<1?1:v>10?10:v}:s)); }}
              onFocus={e => e.target.select()}
              style={{ width:34, border:'1px solid #ddd', borderRadius:6, padding:'2px 3px', fontSize:12, textAlign:'center' }}/>
          </>
        )}
      </div>
    </div>
  );
}

// ─── GameConfig Panel ──────────────────────────────────────────────────────────
export default function GameConfig({ game, opts, setOpt, bet, setBet, players, activeGames, matches, setMatches,
                                     sixesTeams, setSixesTeams,
                                     strokePlayPlayers, setStrokePlayPlayers,
                                     skinsPlayers, setSkinsPlayers,
                                     ninesPlayers, setNinesPlayers, stablefordPlayers, setStablefordPlayers,
                                     dotsPlayers, setDotsPlayers, dots, setDots }) {

  const SCORING_OPTS = [{ value:'net',label:'Net' },{ value:'gross',label:'Gross' },{ value:'netofflow',label:'Net Off Low' }];

  // ── Inline edit state for custom dots ─────────────────────────────────────
  const [editingId, setEditingId] = useState(null);
  const [editName,  setEditName]  = useState('');
  const [editValue, setEditValue] = useState(1);

  const startEdit = (sp) => { setEditingId(sp.id); setEditName(sp.name); setEditValue(sp.value ?? sp.pts ?? 1); };
  const commitEdit = (id) => {
    if (!editName.trim()) { setEditingId(null); return; }
    setDots(p => p.map(s => s.id === id ? { ...s, name: editName.trim(), value: Math.max(1, Math.min(10, editValue)) } : s));
    setEditingId(null);
  };

  const deleteCustom = (id) => {
    const updatedDots = dots.filter(s => s.id !== id);
    setDots(updatedDots);

    // G-12 fix: recompute team companion entries in the active round.
    const ar = ls.get(SK.activeRound);
    if (!ar?.dotEntries) return;
    const ens = updatedDots.filter(s => s.enabled);
    const entryCount = v => typeof v === 'number' ? v : (v === true ? 1 : 0);
    const entries = { ...ar.dotEntries };
    let changed = false;

    Object.keys(entries).forEach(key => {
      const parts = key.split('_');
      if (parts[2] !== 'team') return;
      const hole       = parseInt(parts[0]);
      const partnerIdx = parseInt(parts[1]);
      const earnerIdx  = parseInt(parts[parts.length - 1]);
      if (isNaN(earnerIdx)) return;

      let total = 0;
      Object.entries(entries).forEach(([k, v]) => {
        const cnt = entryCount(v);
        if (!cnt) return;
        const p = k.split('_');
        if (parseInt(p[0]) !== hole || parseInt(p[1]) !== earnerIdx) return;
        if (p[2] === 'team') return;
        const sp = ens.find(s => s.id === p[2]);
        if (sp) total += cnt;
      });

      const current = entryCount(entries[key]);
      if (total === 0) {
        delete entries[key];
        changed = true;
      } else if (total !== current) {
        entries[key] = total;
        changed = true;
      }
    });

    if (changed) {
      ls.set(SK.activeRound, { ...ar, dotEntries: entries });
    }
  };

  // ── Team mode options derived from active games ────────────────────────────
  const teamModeOpts = [{ value:'none', label:'Individual' }];
  if (activeGames?.includes('Sixes')) {
    teamModeOpts.push({ value:'Sixes', label:'Sixes Teams' });
  }
  if (activeGames?.includes('Match / Nassau') && matches?.some(m => m.format === 'team')) {
    teamModeOpts.push({ value:'Match', label:'Match Teams' });
  }

  const currentTeamMode = opts.teamMode ?? (opts.teamScoring ? 'Sixes' : 'none');
  const isTeamMode = currentTeamMode !== 'none';

  return (
    <div style={{ background:GB, borderRadius:10, padding:'12px 13px', marginTop:5, borderLeft:`3px solid ${G}` }}>

      {/* ── Match / Nassau ── */}
      {game === 'Match / Nassau' && (
        <div>
          {matches.map((m, idx) => (
            <MatchCard key={m.id} match={m} idx={idx} players={players}
              onChange={updated => setMatches(prev => prev.map(x => x.id === m.id ? updated : x))}
              onRemove={() => setMatches(prev => prev.filter(x => x.id !== m.id))}
              canRemove={matches.length > 1}
            />
          ))}
          <button onClick={() => setMatches(prev => [...prev, defaultMatch(players)])}
            style={{ width:'100%',padding:'9px 0',borderRadius:10,border:`1.5px dashed ${G}`,background:GA,cursor:'pointer',fontSize:13,fontWeight:700,color:G,fontFamily:'inherit' }}>
            + Add another Match
          </button>
        </div>
      )}

      {/* ── Skins ── */}
      {game === 'Skins' && (
        <>
          {players.length > 2 && (
            <div style={{ marginBottom:8 }}>
              <PlayerSubsetChips players={players} selectedIdxs={skinsPlayers} onChange={setSkinsPlayers}
                label="Players" note="Tap to remove a player from the Skins pool"/>
            </div>
          )}
          <ConfigSection label="Options">
            <InlineRow label="Scoring"><StyledSel value={opts.scoring||'net'} onChange={v=>setOpt('scoring',v)} options={SCORING_OPTS}/></InlineRow>
            <InlineRow label="Carryover"><StyledSel value={opts.carryover||'yes'} onChange={v=>setOpt('carryover',v)} options={[{value:'yes',label:'Yes'},{value:'no',label:'No'}]}/></InlineRow>
          </ConfigSection>
          <ConfigSection label="Bets">
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, alignItems:'center' }}>
              {[{v:'perSkin',l:'Per Skin'},{v:'pot',l:'Pot'}].map(({v,l}) => (
                <button key={v} onClick={()=>setOpt('mode',v)}
                  style={{ padding:'6px 4px', borderRadius:20, border:`1.5px solid ${(opts.mode||'perSkin')===v?G:'#ddd'}`, background:(opts.mode||'perSkin')===v?GA:'#fff', cursor:'pointer', fontSize:11, fontWeight:600, color:(opts.mode||'perSkin')===v?G:'#666', fontFamily:'inherit', whiteSpace:'nowrap', textAlign:'center' }}>
                  {l}
                </button>
              ))}
              <BetInput value={bet} onChange={setBet} style={{ width:'100%', boxSizing:'border-box' }}/>
            </div>
          </ConfigSection>
        </>
      )}

      {/* ── Stableford ── */}
      {game === 'Stableford' && (
        <>
          {players.length > 2 && (
            <div style={{ marginBottom:8 }}>
              <PlayerSubsetChips players={players} selectedIdxs={stablefordPlayers} onChange={setStablefordPlayers}
                label="Players" note="Tap to remove a player from Stableford"/>
            </div>
          )}
          <ConfigSection label="Options">
            <InlineRow label="Scoring"><StyledSel value={opts.scoring||'net'} onChange={v=>setOpt('scoring',v)} options={SCORING_OPTS}/></InlineRow>
          </ConfigSection>
          <ConfigSection label="Points">
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:4 }}>
              {[['+3','-3'],['Eagle','-2'],['Bird','-1'],['Par','0'],['Bog','1'],['Dbl','2'],['Worse','3']].map(([lbl,key]) => {
                const t = opts.stabTable || DEFAULT_STAB;
                return (
                  <div key={key} style={{ textAlign:'center' }}>
                    <div style={{ fontSize:9, color:'#888', marginBottom:2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{lbl}</div>
                    <input type="text" inputMode="numeric" value={t[key]??0}
                      onChange={e=>{const v=parseInt(e.target.value);if(!isNaN(v)&&v>=0)setOpt('stabTable',{...(opts.stabTable||DEFAULT_STAB),[key]:v});}}
                      style={{ width:'100%', boxSizing:'border-box', border:'1px solid #ddd', borderRadius:6, padding:'4px 2px', fontSize:12, textAlign:'center', fontFamily:'inherit' }}/>
                  </div>
                );
              })}
            </div>
            <button onClick={()=>setOpt('stabTable',{...DEFAULT_STAB})} style={{ marginTop:4, fontSize:11, color:G, background:'none', border:'none', cursor:'pointer', padding:0 }}>Reset</button>
          </ConfigSection>
          <ConfigSection label="Bets">
            {/* Three equal mode buttons */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, marginBottom:8 }}>
              {[{v:'perpoint',l:'Spread'},{v:'single',l:'Overall'},{v:'nassau',l:'Nassau'}].map(({v,l}) => (
                <button key={v} onClick={()=>setOpt('stabBetMode',v)}
                  style={{ padding:'7px 4px', borderRadius:20,
                           border:`1.5px solid ${(opts.stabBetMode||'nassau')===v?G:'#ddd'}`,
                           background:(opts.stabBetMode||'nassau')===v?GA:'#fff',
                           cursor:'pointer', fontSize:12, fontWeight:600,
                           color:(opts.stabBetMode||'nassau')===v?G:'#666', fontFamily:'inherit', textAlign:'center' }}>
                  {l}
                </button>
              ))}
            </div>
            {/* Bet line */}
            {(opts.stabBetMode||'nassau') === 'nassau' ? (
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 }}>
                {[['Front','betF'],['Back','betB'],['Overall','bet18']].map(([lbl,key]) => (
                  <div key={key} style={{ display:'flex', flexDirection:'column', alignItems:'stretch' }}>
                    <div style={{ fontSize:10,color:'#888',marginBottom:3,textAlign:'center' }}>{lbl}</div>
                    <BetInput value={opts[key]??bet} onChange={v=>{setOpt(key,v);setBet(v);}} style={{ width:'100%',boxSizing:'border-box' }}/>
                  </div>
                ))}
              </div>
            ) : (
              <BetInput value={bet} onChange={setBet} style={{ width:'100%',boxSizing:'border-box' }}/>
            )}
          </ConfigSection>
        </>
      )}

      {/* ── Nines ── */}
      {game === 'Nines' && (
        <>
          <div style={{ marginBottom:8 }}>
            {players.length < 3 && <div style={{ background:'#fce8e8',color:RED,borderRadius:8,padding:'8px 11px',fontSize:12,marginBottom:8 }}>Nines requires at least 3 players.</div>}
            {players.length > 3 && (
              <PlayerSubsetChips players={players} selectedIdxs={ninesPlayers||[]} onChange={setNinesPlayers}
                label="Players (select 3)" maxSelect={3}/>
            )}
            {players.length > 3 && (ninesPlayers||[]).length < 3 && (
              <div style={{ fontSize:11,color:RED,marginTop:4 }}>Select exactly 3 players</div>
            )}
          </div>
          <ConfigSection label="Options">
            <InlineRow label="Scoring"><StyledSel value={opts.scoring||'net'} onChange={v=>setOpt('scoring',v)} options={SCORING_OPTS}/></InlineRow>
            <InlineRow label="Niner">
              <div onClick={() => setOpt('blitz', !opts.blitz)}
                style={{ width:120, borderRadius:20, padding:'6px 10px', cursor:'pointer', boxSizing:'border-box',
                         border:`1.5px solid ${opts.blitz ? G : '#ddd'}`,
                         background:opts.blitz ? GA : '#fff',
                         display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
                <div style={{ width:28, height:16, borderRadius:10, background:opts.blitz?G:'#ccc', position:'relative', transition:'background .2s', flexShrink:0 }}>
                  <div style={{ position:'absolute', top:2, left:opts.blitz?14:2, width:12, height:12, borderRadius:'50%', background:'#fff', transition:'left .2s' }}/>
                </div>
                <span style={{ fontSize:12, fontWeight:opts.blitz?700:400, color:opts.blitz?G:'#aaa' }}>{opts.blitz ? 'On' : 'Off'}</span>
              </div>
            </InlineRow>
          </ConfigSection>
          <ConfigSection label="Bets">
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, marginBottom:8 }}>
              {[{v:'perpoint',l:'Spread'},{v:'single',l:'Overall'},{v:'nassau',l:'Nassau'}].map(({v,l}) => (
                <button key={v} onClick={()=>setOpt('ninesMode',v)}
                  style={{ padding:'7px 4px', borderRadius:20,
                           border:`1.5px solid ${(opts.ninesMode||'perpoint')===v?G:'#ddd'}`,
                           background:(opts.ninesMode||'perpoint')===v?GA:'#fff',
                           cursor:'pointer', fontSize:12, fontWeight:600,
                           color:(opts.ninesMode||'perpoint')===v?G:'#666', fontFamily:'inherit', textAlign:'center' }}>
                  {l}
                </button>
              ))}
            </div>
            {(opts.ninesMode||'perpoint') === 'nassau' ? (
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 }}>
                {[['Front','betF'],['Back','betB'],['Overall','bet18']].map(([lbl,key]) => (
                  <div key={key} style={{ display:'flex', flexDirection:'column', alignItems:'stretch' }}>
                    <div style={{ fontSize:10,color:'#888',marginBottom:3,textAlign:'center' }}>{lbl}</div>
                    <BetInput value={opts[key]??bet} onChange={v=>{setOpt(key,v);setBet(v);}} style={{ width:'100%',boxSizing:'border-box' }}/>
                  </div>
                ))}
              </div>
            ) : (
              <BetInput value={bet} onChange={setBet} style={{ width:'100%',boxSizing:'border-box' }}/>
            )}
          </ConfigSection>
        </>
      )}

      {/* ── Sixes ── */}
      {game === 'Sixes' && (
        <>
          {players.length < 4 && (
            <div style={{ background:'#fce8e8',color:RED,borderRadius:8,padding:'8px 11px',fontSize:12,marginBottom:8 }}>Sixes requires 4 players.</div>
          )}
          {players.length >= 4 && (
            <div style={{ marginBottom:8 }}>
              <div style={{ fontSize:11, fontWeight:700, color:'#666', marginBottom:5 }}>Teams (Team A for each six)</div>
              {[0,1].map(seg => {
                const t = sixesTeams[seg];
                const p1 = t?.a ?? null;
                const p2 = t?.b ?? null;
                const teamAFull = p1 != null && p2 != null;

                // Build all committed teammate pairs across ALL segments (including auto-derived back 6).
                // A pair is [i, j] where i and j are on the same team in any segment.
                const allPairs = [];
                [0, 1].forEach(s => {
                  const st = sixesTeams[s];
                  const a = st?.a ?? null;
                  const b = st?.b ?? null;
                  // Team A pair
                  if (a != null && b != null) allPairs.push([a, b]);
                  // Team B is the remaining two players
                  if (a != null && b != null) {
                    const teamB = players.map((_,i)=>i).filter(i=>i!==a&&i!==b);
                    if (teamB.length === 2) allPairs.push([teamB[0], teamB[1]]);
                  }
                });

                // Given a player index `anchor`, return all players who have already been
                // that player's teammate in any segment.
                const priorTeammates = (anchor) => {
                  if (anchor == null) return [];
                  return allPairs
                    .filter(([x, y]) => x === anchor || y === anchor)
                    .map(([x, y]) => x === anchor ? y : x);
                };

                // excludeIdxs for p1 slot: the other slot (p2) + anyone already paired with p2
                const excludeP1 = [
                  p2,
                  ...priorTeammates(p2),
                ].filter(x => x != null);

                // excludeIdxs for p2 slot: the other slot (p1) + anyone already paired with p1
                const excludeP2 = [
                  p1,
                  ...priorTeammates(p1),
                ].filter(x => x != null);

                const oth = teamAFull ? players.map((_,i)=>i).filter(i=>i!==p1&&i!==p2) : [];
                return (
                  <div key={seg} style={{ marginBottom:10 }}>
                    <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:5, textTransform:'uppercase', letterSpacing:'0.05em' }}>{['Front 6','Middle 6'][seg]}</div>
                    {/* Team A */}
                    <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:4, letterSpacing:'0.03em' }}>Team A</div>
                    <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                      <div style={{ flex:1, minWidth:0 }}>
                        <PlayerDropdown
                          players={players}
                          value={p1}
                          onChange={vi => setSixesTeams(prev => { const n=[...prev]; n[seg]={a:vi,b:vi===p2?null:p2}; return n; })}
                          label="Player 1"
                          excludeIdxs={excludeP1}
                          panelLabel={`${['Front 6','Middle 6'][seg]} — Player 1`}
                        />
                      </div>
                      <span style={{ fontSize:11, color:'#aaa', flexShrink:0 }}>+</span>
                      <div style={{ flex:1, minWidth:0 }}>
                        <PlayerDropdown
                          players={players}
                          value={p2}
                          onChange={vi => setSixesTeams(prev => { const n=[...prev]; n[seg]={a:p1,b:vi}; return n; })}
                          label="Player 2"
                          excludeIdxs={excludeP2}
                          panelLabel={`${['Front 6','Middle 6'][seg]} — Player 2`}
                        />
                      </div>
                    </div>
                    {/* Team B — only shown when Team A is full */}
                    {teamAFull && (
                      <>
                        <div style={{ fontSize:10, fontWeight:700, color:G, marginBottom:4, letterSpacing:'0.03em' }}>Team B</div>
                        <div style={{ display:'flex', gap:8 }}>
                          <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[oth[0]]??null}/></div>
                          <span style={{ fontSize:11, color:'#aaa', flexShrink:0, alignSelf:'center' }}>+</span>
                          <div style={{ flex:1, minWidth:0 }}><ReadOnlyBubble p={players[oth[1]]??null}/></div>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <ConfigSection label="Options">
            <InlineRow label="Scoring"><StyledSel value={opts.scoring||'net'} onChange={v=>setOpt('scoring',v)} options={SCORING_OPTS}/></InlineRow>
            <InlineRow label="Tie-break"><StyledSel value={opts.tiebreak||'none'} onChange={v=>setOpt('tiebreak',v)} options={[{value:'none',label:'None'},{value:'half',label:'Half pt'},{value:'second',label:'2nd ball'}]}/></InlineRow>
          </ConfigSection>
          <ConfigSection label="Bets">
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
              <BetInput value={bet} onChange={setBet} style={{ width:'100%',boxSizing:'border-box' }}/>
              <StyledSel value={opts.autoPress||'none'} onChange={v=>setOpt('autoPress',v)}
                options={[{value:'none',label:'Press'},{value:'1',label:'1 down'},{value:'2',label:'2 down'},{value:'3',label:'3 down'},{value:'4',label:'4 down'},{value:'5',label:'5 down'}]}
                width="100%"/>
            </div>
          </ConfigSection>
        </>
      )}

      {/* ── Stroke Play ── */}
      {game === 'Stroke Play' && (
        <>
          {players.length > 2 && (
            <div style={{ marginBottom:8 }}>
              <PlayerSubsetChips players={players} selectedIdxs={strokePlayPlayers} onChange={setStrokePlayPlayers}
                label="Players" note="Tap to remove a player from Stroke Play"/>
            </div>
          )}
          <ConfigSection label="Options">
            <InlineRow label="Scoring"><StyledSel value={opts.scoring||'gross'} onChange={v=>setOpt('scoring',v)} options={SCORING_OPTS}/></InlineRow>
          </ConfigSection>
          <ConfigSection label="Bets">
            <div style={{ display:'flex', gap:6, marginBottom:8 }}>
              {[{v:'single',l:'Overall'},{v:'nassau',l:'Nassau'}].map(({v,l}) => (
                <button key={v} onClick={()=>setOpt('strokeMode',v)}
                  style={{ flex:1, padding:'7px 4px', borderRadius:20,
                           border:`1.5px solid ${(opts.strokeMode||'single')===v?G:'#ddd'}`,
                           background:(opts.strokeMode||'single')===v?GA:'#fff',
                           cursor:'pointer', fontSize:12, fontWeight:600,
                           color:(opts.strokeMode||'single')===v?G:'#666', fontFamily:'inherit', textAlign:'center' }}>
                  {l}
                </button>
              ))}
            </div>
            {(opts.strokeMode||'single') === 'nassau' ? (
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 }}>
                {[['Front','betF'],['Back','betB'],['Overall','bet18']].map(([lbl,key]) => (
                  <div key={key} style={{ display:'flex', flexDirection:'column', alignItems:'stretch' }}>
                    <div style={{ fontSize:10,color:'#888',marginBottom:3,textAlign:'center' }}>{lbl}</div>
                    <BetInput value={opts[key]??bet} onChange={v=>{setOpt(key,v);setBet(v);}} style={{ width:'100%',boxSizing:'border-box' }}/>
                  </div>
                ))}
              </div>
            ) : (
              <BetInput value={bet} onChange={setBet} style={{ width:'100%',boxSizing:'border-box' }}/>
            )}
          </ConfigSection>
        </>
      )}

      {/* ── Dots ── */}
      {game === 'Dots' && (
        <>
          {/* Players subset — hidden in team mode (all must participate) */}
          {!isTeamMode && players.length > 2 && (
            <div style={{ marginBottom:8 }}>
              <PlayerSubsetChips
                players={players}
                selectedIdxs={dotsPlayers}
                onChange={setDotsPlayers}
                label="Players"
                note="Tap to remove a player from Dots"
              />
            </div>
          )}
          {/* Options */}
          <ConfigSection label="Options">
            {teamModeOpts.length > 1 && (
              <InlineRow label="Teams">
                <StyledSel value={currentTeamMode}
                  onChange={v => {
                    setOpt('teamMode', v);
                    setOpt('teamScoring', false);
                    if (v === 'none') {
                      setDotsPlayers([]);
                    } else if (v === 'Sixes') {
                      const t0 = sixesTeams?.[0], t1 = sixesTeams?.[1];
                      if (t0 && t1) {
                        const idxs = [...new Set([t0.a, t0.b, t1.a, t1.b]
                          .filter(i => i != null && players[i]))].sort((a,b) => a-b);
                        setDotsPlayers(idxs.length === 4 ? idxs : []);
                      } else { setDotsPlayers([]); }
                    } else if (v === 'Match') {
                      const teamMatch = matches?.find(m => m.format === 'team');
                      if (teamMatch) {
                        const idxs = [...new Set([...(teamMatch.teamA||[]), ...(teamMatch.teamB||[])]
                          .filter(i => i != null && players[i]))].sort((a,b) => a-b);
                        setDotsPlayers(idxs.length >= 2 ? idxs : []);
                      } else { setDotsPlayers([]); }
                    }
                  }}
                  options={teamModeOpts}/>
              </InlineRow>
            )}
            <InlineRow label="Scoring">
              <StyledSel value={opts.scoring||'gross'} onChange={v=>setOpt('scoring',v)}
                options={[{value:'gross',label:'Gross'},{value:'net',label:'Net'}]}/>
            </InlineRow>
          </ConfigSection>
          {/* Bets */}
          <ConfigSection label="Bets">
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, alignItems:'center' }}>
              {[{v:'spread',l:'Spread'},{v:'overall',l:'Overall'}].map(({v,l}) => (
                <button key={v} onClick={()=>setOpt('dotsMode',v)}
                  style={{ padding:'6px 4px', borderRadius:20,
                           border:`1.5px solid ${(opts.dotsMode||'spread')===v?G:'#ddd'}`,
                           background:(opts.dotsMode||'spread')===v?GA:'#fff',
                           cursor:'pointer', fontSize:11, fontWeight:600,
                           color:(opts.dotsMode||'spread')===v?G:'#666', fontFamily:'inherit', whiteSpace:'nowrap', textAlign:'center' }}>
                  {l}
                </button>
              ))}
              <BetInput value={bet} onChange={setBet} style={{ width:'100%', boxSizing:'border-box' }}/>
            </div>
          </ConfigSection>
          {/* Dots list */}
          <ConfigSection label="Dots to Track">
            <div style={{ display:'grid', gap:'5px' }}>
              {dots.filter(sp => sp.id !== 'team').map(sp => (
                <DotRow
                  key={sp.id}
                  sp={sp}
                  isEditing={editingId === sp.id}
                  editName={editName}
                  editValue={editValue}
                  setEditName={setEditName}
                  setEditValue={setEditValue}
                  commitEdit={commitEdit}
                  setEditingId={setEditingId}
                  setDots={setDots}
                  startEdit={startEdit}
                  deleteCustom={deleteCustom}
                />
              ))}
            </div>
            <CustomDotAdder onAdd={sp => setDots(p => [...p, sp])}/>
          </ConfigSection>
        </>
      )}
    </div>
  );
}
