// ─── NewRoundPage.jsx ─────────────────────────────────────────────────────────
import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ls, SK } from '../services/storage.js';
import { playerLib } from '../services/playerLib.js';
import { courseLib } from '../services/courseLib.js';
import { roundLib } from '../services/roundLib.js';
import { buildLayout, DEF_PARS, DEF_HCP, groupCourseHandicaps, minGroupHandicap, DEFAULT_STAB, courseHandicap, parseIndex } from '../engine/handicap.js';
import { DOTS_DEF, ALL_GAMES } from '../engine/games.js';
import { Btn, Sel, Inp, Tog, Card, BetInput, G, GA, GB, RED, AMB, AMBBG } from '../components/ui.jsx';
import PlayerPickerPopup from './PlayerPickerPopup.jsx';
import GameConfig from './tables/GameConfig.jsx';
import { PlayerDropdown } from './PlayerDropdown.jsx';

const SETUP_KEY = 'golf_round_setup_v5';
const loadSetup = () => { try { return JSON.parse(localStorage.getItem(SETUP_KEY) || 'null'); } catch { return null; } };

// ─── Helpers ───────────────────────────────────────────────────────────────────
function makeMatchId() { return `m_${Date.now()}_${Math.random().toString(36).slice(2,6)}`; }

function defaultMatch(players, format = 'individual') {
  if (format === 'individual') {
    const p1 = players.length >= 1 ? 0 : null;
    const p2 = players.length === 2 ? 1 : null;
    return { id: makeMatchId(), format: 'individual', p1, p2, scoring: 'net', autoPressF: 'none', autoPressB: 'none', autoPressO: 'none', tiebreak: 'none', betFront: 0, betBack: 0, betOverall: 0 };
  }
  const tA = players.length >= 4 ? [0, 1] : [];
  const tB = players.length >= 4 ? [2, 3] : [];
  return { id: makeMatchId(), format: 'team', teamA: tA, teamB: tB, scoring: 'net', autoPressF: 'none', autoPressB: 'none', autoPressO: 'none', tiebreak: 'none', betFront: 0, betBack: 0, betOverall: 0 };
}

// ─── CoursePickerPopup ─────────────────────────────────────────────────────────
// Bottom-sheet popup for selecting a course, mirrors PlayerPickerPopup pattern.
function CoursePickerPopup({ allCourses, snapshotCourse, selectedId, onConfirm, onClose }) {
  const [picked, setPicked] = useState(selectedId || '');
  const courses = [
    ...(snapshotCourse && !allCourses.find(c => c.id === snapshotCourse.id)
      ? [{ ...snapshotCourse, _fromHistory: true }] : []),
    ...allCourses,
  ];
  return (
    <div style={{ position:'fixed',inset:0,background:'rgba(0,0,0,.5)',zIndex:300,display:'flex',alignItems:'flex-end',justifyContent:'center' }} onClick={onClose}>
      <div style={{ background:'#fff',borderRadius:'20px 20px 0 0',width:'100%',maxWidth:520,maxHeight:'80vh',display:'flex',flexDirection:'column' }} onClick={e=>e.stopPropagation()}>
        <div style={{ overflowY:'auto',flex:1,padding:'20px 20px 8px' }}>
          <div style={{ fontWeight:800,fontSize:17,color:G,marginBottom:4 }}>Select Course</div>
          <div style={{ fontSize:11,color:'#888',marginBottom:14 }}>Tap to select</div>
          <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
            {courses.map(c => {
              const sel = picked === c.id;
              return (
                <div key={c.id} onClick={() => { setPicked(c.id); }}
                  style={{ padding:'11px 14px',borderRadius:12,border:`1.5px solid ${sel?G:'#eee'}`,background:sel?GA:'#fff',cursor:'pointer' }}>
                  <div style={{ fontWeight:700,fontSize:14,color:sel?G:'#222' }}>{c.name}{c._fromHistory ? <span style={{ fontSize:11,fontWeight:400,color:'#aaa',marginLeft:6 }}>(from history)</span> : ''}</div>
                  {c.location && <div style={{ fontSize:11,color:'#888',marginTop:1 }}>{c.location}</div>}
                  {c.tees?.length > 0 && <div style={{ fontSize:11,color:'#aaa',marginTop:1 }}>{c.tees.map(t=>t.name).join(' · ')}</div>}
                </div>
              );
            })}
          </div>
        </div>
        <div style={{ padding:'10px 20px 24px',borderTop:'1px solid #eee',background:'#fff',flexShrink:0 }}>
          <div style={{ display:'flex',gap:8 }}>
            <Btn variant="outline" onClick={onClose} style={{ flex:1 }}>Cancel</Btn>
            <Btn onClick={() => onConfirm(picked)} disabled={!picked} style={{ flex:2 }}>Confirm</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── NineDropdown ──────────────────────────────────────────────────────────────
// Styled dropdown for selecting a nine (e.g. Front 9 / Back 9).
function NineDropdown({ nines, value, onChange, label }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    document.addEventListener('touchstart', h);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('touchstart', h); };
  }, [open]);
  const selected = nines.find(n => n.name === value);
  return (
    <div ref={ref} style={{ position:'relative' }}>
      <div onClick={() => setOpen(o => !o)}
        style={{ borderRadius:20, padding:'6px 10px', border:`1.5px solid ${value ? G : '#ddd'}`, background:value ? GA : '#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', gap:4 }}>
        {selected
          ? <span style={{ fontSize:12, fontWeight:700, color:G }}>{selected.name} <span style={{ fontWeight:400, opacity:0.7 }}>(par {selected.pars?.reduce((a,b)=>a+b,0)})</span></span>
          : <span style={{ fontSize:12, color:'#aaa' }}>{label}</span>}
        <span style={{ fontSize:9, color:value ? G : '#bbb', flexShrink:0 }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && (
        <div style={{ position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:50, background:'#fff', border:`1.5px solid ${G}`, borderRadius:12, padding:'8px', boxShadow:'0 4px 16px rgba(0,0,0,0.13)' }}>
          {nines.map(n => {
            const sel = n.name === value;
            return (
              <div key={n.name} onClick={() => { onChange(n.name); setOpen(false); }}
                style={{ borderRadius:10, padding:'7px 10px', border:`1.5px solid ${sel?G:'#ddd'}`, background:sel?GA:'#f9fdf9', cursor:'pointer', marginBottom:5 }}>
                <span style={{ fontSize:12, fontWeight:700, color:sel?G:'#333' }}>{n.name}</span>
                <span style={{ fontSize:11, color:'#888', marginLeft:6 }}>par {n.pars?.reduce((a,b)=>a+b,0)}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── TeeDropdown ───────────────────────────────────────────────────────────────
// Styled dropdown for per-player tee selection.
function TeeDropdown({ tees, value, onChange, label }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    document.addEventListener('touchstart', h);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('touchstart', h); };
  }, [open]);
  const selected = tees.find(t => t.name === value);
  return (
    <div ref={ref} style={{ position:'relative' }}>
      <div onClick={() => setOpen(o => !o)}
        style={{ borderRadius:20, padding:'5px 10px', border:`1.5px solid ${value ? G : '#ddd'}`, background:value ? GA : '#fff', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', gap:4 }}>
        {selected ? (
          <span style={{ fontSize:11, fontWeight:700, color:G }}>
            {selected.name}{(selected.rating || selected.slope) ? <span style={{ fontWeight:400, opacity:0.7 }}> · {selected.rating}/{selected.slope}</span> : ''}
          </span>
        ) : (
          <span style={{ fontSize:11, color:'#aaa' }}>{label}</span>
        )}
        <span style={{ fontSize:9, color:value ? G : '#bbb', flexShrink:0 }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && (
        <div style={{ position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:50, background:'#fff', border:`1.5px solid ${G}`, borderRadius:12, padding:'8px', boxShadow:'0 4px 16px rgba(0,0,0,0.13)' }}>
          {tees.map(t => {
            const sel = t.name === value;
            return (
              <div key={t.name} onClick={() => { onChange(t.name); setOpen(false); }}
                style={{ borderRadius:10, padding:'6px 10px', border:`1.5px solid ${sel?G:'#ddd'}`, background:sel?GA:'#f9fdf9', cursor:'pointer', marginBottom:5, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:12, fontWeight:700, color:sel?G:'#333' }}>{t.name}</span>
                {(t.rating || t.slope) && <span style={{ fontSize:11, color:'#888' }}>{t.rating}/{t.slope}</span>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── HIField ───────────────────────────────────────────────────────────────────
// HI input: shows "HI" placeholder when empty; shows "HI: X.X" when blurred
// with a value; shows raw number when focused for editing.
function HIField({ value, onChange }) {
  const [focused, setFocused] = useState(false);
  const G = '#1a472a';
  const hasVal = value !== '' && value != null;

  return (
    <input
      type="text"
      inputMode="decimal"
      value={focused ? value : (hasVal ? `HI: ${value}` : '')}
      placeholder="HI"
      onFocus={e => { setFocused(true); setTimeout(() => e.target.select(), 0); }}
      onChange={e => onChange(e.target.value)}
      onBlur={() => setFocused(false)}
      style={{
        border:'1px solid #ddd', borderRadius:7, padding:'5px 4px',
        fontSize:12, textAlign:'center', fontFamily:'inherit',
        width:'100%', boxSizing:'border-box',
        color: hasVal ? G : '#a8d5b5', fontWeight: hasVal ? 700 : 400,
      }}
    />
  );
}

// ─── NewRoundPage ──────────────────────────────────────────────────────────────
export default function NewRoundPage({ onStart, onGoScorecard, onSaveEdits, inProgress, loadedRound, onLoadedRoundConsumed, getActiveRound }) {
  const allPlayers = useMemo(() => playerLib.list(), []);
  const allCourses = useMemo(() => courseLib.list(), []);

  // initSrc is used only for useState initializers (read once at mount).
  // loadedRound takes priority over the setup draft so that a reload always
  // wins over whatever was left in the draft key from a previous session.
  const initSrc = loadedRound || loadSetup();

  // A-10: Use local date, not UTC. toISOString() returns UTC which shows
  // tomorrow's date for US timezones after ~5pm.
  const today = (() => {
    const d = new Date();
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  })();

  const [roundDate,           setRoundDate]           = useState(loadedRound?.roundDate || today);
  const [selectedCourseId,    setSelectedCourseId]    = useState(initSrc?.selectedCourseId || '');
  const [frontNine,           setFrontNine]            = useState(initSrc?.frontNine || '');
  const [backNine,            setBackNine]             = useState(initSrc?.backNine || '');
  const [selectedTee,         setSelectedTee]          = useState(initSrc?.selectedTee || '');
  const [selectedPlayerIds,   setSelectedPlayerIds]    = useState(initSrc?.selectedPlayerIds || []);
  const [activeGames,         setActiveGames]          = useState(initSrc?.activeGames || []);
  const [gameOpts,            setGameOpts]             = useState(initSrc?.gameOpts || {});
  const [gameBets,            setGameBets]             = useState(initSrc?.gameBets || {});
  const [matches,             setMatches]              = useState(initSrc?.matches || []);
  const [strokePlayPlayers,   setStrokePlayPlayers]    = useState(initSrc?.strokePlayPlayers || []);
  const [skinsPlayers,        setSkinsPlayers]         = useState(initSrc?.skinsPlayers || []);
  const [ninesPlayers,        setNinesPlayers]         = useState(initSrc?.ninesPlayers || []);
  const [stablefordPlayers,   setStablefordPlayers]    = useState(initSrc?.stablefordPlayers || []);
  const [dotsPlayers,         setDotsPlayers]          = useState(initSrc?.dotsPlayers || []);
  // G-1 fix: sixesPlayers was missing entirely from state — added here.
  const [sixesPlayers,        setSixesPlayers]         = useState(initSrc?.sixesPlayers || []);
  const [sixesTeams,          setSixesTeams]           = useState(initSrc?.sixesTeams || [null, null, null]);
  const [dots,                setDots]                 = useState(initSrc?.dots || DOTS_DEF.map(s => ({...s})));
  const [showPlayerPicker,    setShowPlayerPicker]     = useState(false);
  const [showCoursePicker,    setShowCoursePicker]     = useState(false);
  const [isReload,            setIsReload]             = useState(!!loadedRound?.isReload);

  // B-2 fix: courseSnapshot and playerSnapshots are frozen into state at mount.
  // They must NEVER be recomputed from loadedRound after mount — App.jsx clears
  // loadedRound immediately after mount via onLoadedRoundConsumed, so any value
  // derived from loadedRound outside of useState would become null on the next
  // render. These are the authoritative time-capsule values for the round being
  // edited. They never fall back to the live library.
  const [courseSnapshot,  setCourseSnapshot]  = useState(initSrc?.courseSnapshot  || null);
  const [playerSnapshots, setPlayerSnapshots] = useState(initSrc?.playerSnapshots || []);

  // G-2/G-3: Per-player HI and tee state (replaces HIConfirmPopup).
  // playerHIs: { [playerId]: string } — editable HI for each player
  // playerTees: { [playerId]: string } — selected tee name per player
  // Initialized from frozen playerSnapshots (reload) or player library (new round).
  const [playerHIs, setPlayerHIs] = useState(() => {
    const src = initSrc?.playerSnapshots || [];
    return Object.fromEntries(src.map(p => [p.id, p.ghin || '']));
  });
  const [playerTees, setPlayerTees] = useState(() => {
    // Restore per-player tees from frozen snapshots (reload path), else default to selectedTee
    const src = initSrc?.playerSnapshots || [];
    const fallback = initSrc?.selectedTee || '';
    return Object.fromEntries(src.map(p => [p.id, p.selectedTee || fallback]));
  });

  useEffect(() => {
    if (loadedRound && onLoadedRoundConsumed) onLoadedRoundConsumed();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // B-3 fix: freeze roundId at mount from loadedRound (not initSrc).
  // initSrc may fall through to the setup draft on re-renders after
  // onLoadedRoundConsumed clears loadedRound — the draft has no roundId.
  // loadedRound is only available on the first render, so we capture it here.
  const roundIdRef = useRef(loadedRound?.roundId || null);

  const isReloadRef = useRef(!!loadedRound?.isReload);
  useEffect(() => {
    if (isReloadRef.current) return;
    localStorage.setItem(SETUP_KEY, JSON.stringify({
      roundDate, selectedCourseId, frontNine, backNine, selectedTee,
      selectedPlayerIds, activeGames, gameOpts, gameBets,
      matches, strokePlayPlayers, skinsPlayers, ninesPlayers, stablefordPlayers,
      dotsPlayers, sixesPlayers, sixesTeams, dots,
    }));
  }, [roundDate, selectedCourseId, frontNine, backNine, selectedTee, selectedPlayerIds, activeGames,
      gameOpts, gameBets, matches, strokePlayPlayers, skinsPlayers, ninesPlayers, stablefordPlayers,
      dotsPlayers, sixesPlayers, sixesTeams, dots]);

  const courseFromLib  = allCourses.find(c => c.id === selectedCourseId) || null;

  // B-2 fix: In reload mode, the course comes from the frozen snapshot only —
  // never from the live library. The snapshot is the authoritative time capsule.
  // In new-round mode, the course comes from the library (user is picking a course).
  const course = isReload
    ? (courseFromLib || courseSnapshot || null)
    : (courseFromLib || null);

  const handleCourseSelect = (id) => {
    setSelectedCourseId(id);
    const c = allCourses.find(x => x.id === id);
    if (c) {
      setFrontNine(c.nines?.[0]?.name || '');
      setBackNine(c.nines?.[1]?.name || c.nines?.[0]?.name || '');
      const pref = ['White','Blue','Middle','Silver','Black','Gold','Championship','Red','Green'];
      const best = c.tees?.reduce((b, t) => {
        const bi = pref.findIndex(p => b?.name?.toLowerCase().includes(p.toLowerCase()));
        const ti = pref.findIndex(p => t.name?.toLowerCase().includes(p.toLowerCase()));
        return ti >= 0 && (bi < 0 || ti < bi) ? t : b;
      }, c.tees?.[0]);
      const defaultTeeName = best?.name || c.tees?.[0]?.name || '';
      setSelectedTee(defaultTeeName);
      // When course changes, reset all per-player tees to the new default
      setPlayerTees(prev => {
        const updated = { ...prev };
        Object.keys(updated).forEach(id => { updated[id] = defaultTeeName; });
        return updated;
      });
    }
  };

  const toggleGame = (g) => {
    setActiveGames(prev => {
      const next = prev.includes(g) ? prev.filter(x => x !== g) : [...prev, g];
      if (g === 'Match / Nassau' && !prev.includes(g)) {
        if (matches.length === 0) setMatches([defaultMatch(activePlayers)]);
      }
      return next;
    });
  };

  const setOpt = (g, k, v) => setGameOpts(prev => ({ ...prev, [g]: { ...(prev[g]||{}), [k]: v } }));

  const layout = course ? buildLayout(course.nines || [], frontNine, backNine) : null;
  const pars   = layout?.pars || DEF_PARS;
  const hcps   = layout?.hcps || DEF_HCP;
  const allOpts = Object.fromEntries(ALL_GAMES.map(g => [g, { ...(gameOpts[g]||{}), bet: gameBets[g]||0 }]));

  // playerSnapshots is frozen in state at mount (see useState above).
  // activePlayers resolves each selected ID against the live library first,
  // then falls back to the frozen snapshot. In reload mode the snapshot IS
  // the authoritative source, so players not in the current library still load.
  const activePlayers = selectedPlayerIds.map(id => {
    const snap = playerSnapshots.find(p => p.id === id);
    if (snap) return snap;                          // snapshot always wins in reload
    return allPlayers.find(p => p.id === id) || null; // new-round: live library only
  }).filter(Boolean);

  // G-2/G-3: When selectedPlayerIds changes, initialise any new players' HI and tee.
  useEffect(() => {
    setPlayerHIs(prev => {
      const next = { ...prev };
      activePlayers.forEach(p => {
        if (!(p.id in next)) next[p.id] = p.ghin || '';
      });
      return next;
    });
    setPlayerTees(prev => {
      const next = { ...prev };
      activePlayers.forEach(p => {
        if (!(p.id in next)) next[p.id] = selectedTee || '';
      });
      return next;
    });
  }, [selectedPlayerIds]); // eslint-disable-line react-hooks/exhaustive-deps

  // G-3: Compute per-player course handicap for display in the Players card.
  // Returns null if no tee data available.
  const computePlayerCH = (playerId, hiStr) => {
    const teeName = playerTees[playerId] || selectedTee || '';
    const tee = course?.tees?.find(t => t.name === teeName) || null;
    if (!tee && !hiStr) return null;
    const totalPar = pars.reduce((a, b) => a + b, 0);
    return courseHandicap(parseIndex(hiStr || '0'), tee?.slope, tee?.rating, totalPar);
  };

  const handleStart = () => {
    if (activePlayers.length < 2) { alert('Select at least 2 players'); return; }

    // G-5: Sixes requires exactly 4 players (Round Lifecycle Contract §2.5, §14)
    if (activeGames.includes('Sixes') && activePlayers.length === 5) {
      alert('Sixes requires 4 players. A 5-player subset picker for Sixes is not yet available. Remove one player or disable Sixes to continue.');
      return;
    }

    // Nines requires exactly 3 players selected in a 4+ player round (Nines Contract §9 / G-5)
    if (activeGames.includes('Nines') && activePlayers.length > 3 && (ninesPlayers||[]).length < 3) {
      alert('Nines requires exactly 3 players to be selected. Please select 3 players in the Nines options.');
      return;
    }

    // G-4: Score-overwrite warning (Round Lifecycle Contract §2.6)
    // Only warn when lineup has changed AND the existing round has scored holes.
    const existingAr = getActiveRound ? getActiveRound() : null;
    if (existingAr) {
      const existingPlayerIds = existingAr.activePlayers?.map(p => p.id) ?? [];
      const newPlayerIds = activePlayers.map(p => p.id);
      const lineupChanged =
        existingPlayerIds.length !== newPlayerIds.length ||
        existingPlayerIds.some((id, i) => id !== newPlayerIds[i]);
      const hasScores = existingAr.scores?.some(holeScores =>
        holeScores?.some(s => s !== '' && s != null)
      );
      if (lineupChanged && hasScores) {
        const ok = window.confirm('Starting a new round will erase all current scores. Continue?');
        if (!ok) return;
      }
    }

    // Assemble round — G-2: no popup, do it directly here.
    // Update player library records if HI changed.
    const updatedPlayers = activePlayers.map(p => ({
      ...p,
      ghin: playerHIs[p.id] ?? p.ghin,
      selectedTee: playerTees[p.id] || selectedTee || '',
    }));
    updatedPlayers.forEach(p => {
      const orig = allPlayers.find(x => x.id === p.id);
      if (orig && orig.ghin !== p.ghin) playerLib.update(p.id, { ghin: p.ghin });
    });

    // G-3: Build per-player tee array for groupCourseHandicaps
    const perPlayerTees = updatedPlayers.map(p => {
      const teeName = p.selectedTee || selectedTee || '';
      return course?.tees?.find(t => t.name === teeName) || null;
    });

    const courseHcps   = groupCourseHandicaps(updatedPlayers, perPlayerTees, pars);
    const minCourseHcp = minGroupHandicap(courseHcps);

    // Preserve existing scores/dotEntries only when lineup is unchanged
    const existingAr2 = getActiveRound ? getActiveRound() : null;
    const existingPlayerIds2 = existingAr2?.activePlayers?.map(p => p.id) ?? [];
    const newPlayerIds2 = updatedPlayers.map(p => p.id);
    const playerLineupUnchanged =
      existingAr2 &&
      existingPlayerIds2.length === newPlayerIds2.length &&
      existingPlayerIds2.every((id, i) => id === newPlayerIds2[i]);

    const scores = isReload && initSrc?.reloadedScores?.length
      ? initSrc.reloadedScores
      : playerLineupUnchanged && existingAr2?.scores
        ? existingAr2.scores
        : Array.from({ length: 18 }, () => new Array(updatedPlayers.length).fill(''));

    const dotEntries = isReload
      ? (initSrc?.dot_entries || {})
      : playerLineupUnchanged && existingAr2?.dotEntries
        ? existingAr2.dotEntries
        : {};

    // G-1: sixesPlayers is now included in roundState.
    // B-3 fix: roundId comes from roundIdRef (frozen at mount from loadedRound)
    // NOT from initSrc — initSrc may be the setup draft after onLoadedRoundConsumed
    // clears loadedRound, and the draft has no roundId.
    const roundState = {
      roundId:  roundIdRef.current,
      roundDate, course, frontNine, backNine, selectedTee, layout, pars, hcps,
      activePlayers: updatedPlayers.map((p, i) => ({ ...p, courseHcpVal: courseHcps[i] })),
      courseHcps, minCourseHcp,
      activeGames,
      gameOpts: allOpts,
      matches,
      strokePlayPlayers,
      skinsPlayers,
      // Auto-populate ninesPlayers for 3-player rounds (picker never shown; Nines Contract §9 G-5).
      ninesPlayers: activeGames.includes('Nines') && updatedPlayers.length === 3
        ? [0, 1, 2]
        : (ninesPlayers || []),
      stablefordPlayers,
      sixesTeams,
      sixesPlayers,
      dotsPlayers,
      dots,
      dotEntries,
      scores,
    };
    onStart(roundState);
  };

  const handleResumeReload = () => { onGoScorecard(); };

  const handleSaveEdits = () => {
    const roundId = initSrc?.roundId;
    if (!roundId) { alert('Cannot save: original round ID missing.'); return; }

    // Build updated player snapshots reflecting any HI or tee changes made in setup.
    const updatedPlayerSnapshots = activePlayers.map(p => ({
      id:           p.id,
      name:         p.name,
      gender:       p.gender || '',
      ghin:         playerHIs[p.id] ?? p.ghin ?? '',
      courseHcpVal: p.courseHcpVal ?? null,
      selectedTee:  playerTees[p.id] || selectedTee || '',
    }));

    const changes = {
      date:                roundDate,
      course_name:         course?.name || 'Unknown',
      course_snapshot:     course       || null,
      front_nine:          frontNine,
      back_nine:           backNine,
      selected_tee:        selectedTee,
      players:             updatedPlayerSnapshots,
      active_games:        activeGames,
      game_opts:           allOpts,
      matches,
      stroke_play_players: strokePlayPlayers,
      skins_players:       skinsPlayers,
      nines_players:       ninesPlayers,
      stableford_players:  stablefordPlayers,
      sixes_teams:         sixesTeams,
      sixes_players:       sixesPlayers,
      dots_players:        dotsPlayers,
      dots,
    };
    roundLib.update(roundId, changes);
    if (onSaveEdits) onSaveEdits();
  };

  return (
    <div style={{ minHeight: '100vh', background: '#eef4ee' }}>
      <div style={{ background:G, padding:'8px 16px 7px', position:'sticky', top:0, zIndex:10, boxShadow:'0 2px 12px rgba(0,0,0,.2)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <img src="/logo_lockup.png" alt="The Card" style={{ height:58, width:'auto', display:'block' }} />
        <div style={{ color:'#fff', fontWeight:800, fontSize:16, letterSpacing:'0.12em', textTransform:'uppercase', fontFamily:'inherit' }}>
          {isReload ? 'Edit Round' : 'New Round'}
        </div>
      </div>

      <div style={{ padding: '14px 14px', maxWidth: 520, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* Reload banner */}
        {isReload && (
          <div style={{ background:'#e8f5e8', border:'1.5px solid #a0d0a0', borderRadius:12, padding:'12px 14px' }}>
            <div style={{ fontWeight:700, fontSize:13, color:G, marginBottom:4 }}>Editing Historical Round</div>
            <div style={{ fontSize:12, color:'#555', marginBottom:10 }}>
              Change the date, bets, games, or tee below, then tap <strong>Save Changes</strong> to update without touching scores.
              Or tap <strong>Go to Scorecard</strong> to correct individual scores.
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <Btn onClick={handleSaveEdits} style={{ flex:1 }}>Save Changes</Btn>
              <Btn variant="outline" onClick={handleResumeReload} style={{ flex:1 }}>Go to Scorecard</Btn>
            </div>
          </div>
        )}

        {/* Resume banner */}
        {inProgress && !isReload && (
          <div style={{ background:'#fff9e6', border:'1.5px solid #f0c040', borderRadius:12, padding:'10px 14px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div style={{ fontSize:13, color:RED, fontWeight:700 }}>Round in progress</div>
            <Btn small onClick={onGoScorecard} style={{ background:RED, color:'#fff', border:'none' }}>Resume →</Btn>
          </div>
        )}

        {/* Date */}
        <Card>
          <div style={{ fontSize:12, fontWeight:700, color:'#666', marginBottom:5 }}>Round Date</div>
          <input
            type="date"
            value={roundDate}
            onChange={e => setRoundDate(e.target.value)}
            style={{ width:'100%', boxSizing:'border-box', border:'1px solid #ddd', borderRadius:8,
              padding:'8px 10px', fontSize:13, fontFamily:'inherit', background:'#fff',
              color:G, fontWeight:600, outline:'none', WebkitAppearance:'none', display:'block' }}
          />
        </Card>

        {/* Course */}
        <Card>
          <div style={{ fontWeight:700, fontSize:14, color:G, marginBottom:8 }}>Course</div>
          {isReload && courseSnapshot && !courseFromLib && (
            <div style={{ background:'#fff8e8', border:'1px solid #f0d070', borderRadius:8, padding:'7px 11px', marginBottom:8, fontSize:12, color:'#7a5800' }}>
              <strong>{courseSnapshot.name}</strong> is not in your current course library. Using saved course data.
            </div>
          )}
          {allCourses.length === 0 && !courseSnapshot ? (
            <p style={{ fontSize:12, color:'#aaa' }}>No courses saved. Go to Courses tab to add one.</p>
          ) : (
            /* Course picker trigger — styled like player picker */
            <button onClick={() => setShowCoursePicker(true)}
              style={{ width:'100%', padding:'10px 12px', borderRadius:12, border:`1.5px solid ${course ? G : '#ddd'}`, background:course ? GA : '#fff', cursor:'pointer', fontFamily:'inherit', marginBottom: course ? 8 : 0, textAlign:'left', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              {course ? (
                <div style={{ minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:700, color:G, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{course.name}</div>
                  {course.location && <div style={{ fontSize:11, color:G, opacity:0.7, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{course.location}</div>}
                </div>
              ) : (
                <span style={{ fontSize:13, color:'#aaa' }}>Select a course…</span>
              )}
              <span style={{ fontSize:11, color: course ? G : '#bbb', flexShrink:0, marginLeft:8 }}>▼</span>
            </button>
          )}

          {/* Front 9 / Back 9 — only shown when course has more than 2 nines */}
          {course?.nines?.length > 2 && (
            <div style={{ display:'flex', gap:8, marginBottom:8 }}>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4 }}>Front 9</div>
                <NineDropdown
                  nines={course.nines}
                  value={frontNine}
                  onChange={setFrontNine}
                  label="Front 9"
                />
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:10, fontWeight:700, color:'#666', marginBottom:4 }}>Back 9</div>
                <NineDropdown
                  nines={course.nines}
                  value={backNine}
                  onChange={setBackNine}
                  label="Back 9"
                />
              </div>
            </div>
          )}

        </Card>

        {/* Players — G-2/G-3: inline per-player HI + tee setup replaces HIConfirmPopup */}
        <Card>
          <div style={{ fontWeight:700, fontSize:14, color:G, marginBottom:8 }}>Players</div>

          {/* Player selector — tap to open picker */}
          <button onClick={()=>setShowPlayerPicker(true)}
            style={{ width:'100%', padding: activePlayers.length > 0 ? '8px 10px' : '10px 12px', borderRadius:12, border:'1.5px solid #ddd', background:'#fff', cursor:'pointer', fontFamily:'inherit', marginBottom: activePlayers.length > 0 ? 10 : 0, textAlign:'left' }}>
            {activePlayers.length === 0
              ? <span style={{ fontSize:13, color:'#aaa' }}>Select players…</span>
              : <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:5 }}>
                  {activePlayers.map((p, i) => {
                    const parts = p.name?.trim().split(/\s+/) || [];
                    const first = parts.slice(0,-1).join(' ') || p.name;
                    const last  = parts.length >= 2 ? parts[parts.length-1] : '';
                    return (
                      <div key={p.id} style={{ background:GA, borderRadius:10, padding:'5px 8px', minWidth:0 }}>
                        <div style={{ fontSize:11, fontWeight:700, color:G, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{first}</div>
                        {last && <div style={{ fontSize:10, fontWeight:600, color:G, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', opacity:0.75 }}>{last}</div>}
                      </div>
                    );
                  })}
                </div>
            }
          </button>

          {/* Per-player HI / tee rows — shown once players are selected */}
          {activePlayers.length > 0 && (
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {activePlayers.map(p => {
                const hi  = playerHIs[p.id] ?? p.ghin ?? '';
                const ch  = computePlayerCH(p.id, hi);
                const teeName = playerTees[p.id] || selectedTee || '';

                return (
                  <div key={p.id} style={{ background:'#f8fbf8', borderRadius:10, border:'1px solid #e8f0e8', padding:'6px 10px' }}>
                    {/* Row 1: name + HI input + CH display */}
                    <div style={{ display:'grid', gridTemplateColumns:'1fr 70px 70px', gap:6, alignItems:'center' }}>
                      <div style={{ fontWeight:600, fontSize:13, color:G, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                        {p.name}
                      </div>
                      {/* HI field — shows "HI" placeholder; "HI: X.X" prefix when blurred with value */}
                      <HIField
                        value={hi}
                        onChange={v => setPlayerHIs(prev => ({ ...prev, [p.id]: v }))}
                      />
                      {/* CH display — auto-calculated, read-only */}
                      <div style={{ textAlign:'center', fontSize:12, fontWeight:700,
                        color: ch != null ? G : '#ccc',
                        border:'1px solid #eee', borderRadius:7, padding:'5px 4px',
                        background:'#fff', minHeight:30, display:'flex', alignItems:'center', justifyContent:'center' }}>
                        {ch != null ? `CH: ${ch}` : 'CH'}
                      </div>
                    </div>
                    {/* Row 2: tee selector */}
                    {course?.tees?.length > 0 && (
                      <div style={{ marginTop:6 }}>
                        <TeeDropdown
                          tees={course.tees}
                          value={teeName}
                          onChange={v => setPlayerTees(prev => ({ ...prev, [p.id]: v }))}
                          label="Select tee…"
                        />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Games */}
        <Card>
          <div style={{ fontWeight:700, fontSize:14, color:G, marginBottom:8 }}>Games & Bets</div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {ALL_GAMES.map(g => {
              const on = activeGames.includes(g);
              return (
                <div key={g}>
                  <button onClick={()=>toggleGame(g)}
                    style={{ width:'100%', display:'flex', alignItems:'center', gap:8, padding:'8px 12px', borderRadius:12, border:`1.5px solid ${on?G:'#eee'}`, background:on?GA:'#fff', cursor:'pointer', fontFamily:'inherit', textAlign:'left' }}>
                    <input type="checkbox" checked={on} readOnly style={{ accentColor:G, width:13, height:13 }}/>
                    <span style={{ flex:1, fontWeight:600, fontSize:13, color:on?G:'#333' }}>
                      {g}{g==='Dots'&&<span style={{ fontSize:11, color:'#888', fontWeight:400, marginLeft:5 }}>Specials, Junk</span>}
                    </span>
                  </button>
                  {on && (
                    <GameConfig game={g} opts={gameOpts[g]||{}} setOpt={(k,v)=>setOpt(g,k,v)}
                      bet={gameBets[g]||0} setBet={v=>setGameBets(p=>({...p,[g]:v}))}
                      players={activePlayers}
                      activeGames={activeGames}
                      matches={matches} setMatches={setMatches}
                      sixesTeams={sixesTeams} setSixesTeams={setSixesTeams}
                      strokePlayPlayers={strokePlayPlayers} setStrokePlayPlayers={setStrokePlayPlayers}
                      skinsPlayers={skinsPlayers} setSkinsPlayers={setSkinsPlayers}
                      ninesPlayers={ninesPlayers} setNinesPlayers={setNinesPlayers}
                      stablefordPlayers={stablefordPlayers} setStablefordPlayers={setStablefordPlayers}
                      dotsPlayers={dotsPlayers} setDotsPlayers={setDotsPlayers}
                      dots={dots} setDots={setDots}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Start */}
        <button onClick={handleStart} disabled={activePlayers.length < 2}
          style={{ width:'100%', background: activePlayers.length<2?'#ccc':G, color:'#fff', border:'none', borderRadius:16, padding:'18px 20px', fontSize:16, fontWeight:800, cursor: activePlayers.length<2?'not-allowed':'pointer', fontFamily:'inherit', marginBottom:8 }}>
          {isReload ? 'Re-score Round →' : 'Start Scoring →'}
        </button>
      </div>

      {showPlayerPicker && (
        <PlayerPickerPopup allPlayers={allPlayers} selectedIds={selectedPlayerIds}
          onConfirm={ids=>{setSelectedPlayerIds(ids);setShowPlayerPicker(false);}} onClose={()=>setShowPlayerPicker(false)}/>
      )}
      {showCoursePicker && (
        <CoursePickerPopup
          allCourses={allCourses}
          snapshotCourse={isReload && courseSnapshot && !courseFromLib ? courseSnapshot : null}
          selectedId={selectedCourseId}
          onConfirm={id => { handleCourseSelect(id); setShowCoursePicker(false); }}
          onClose={() => setShowCoursePicker(false)}
        />
      )}
    </div>
  );
}
