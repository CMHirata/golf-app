// ─── pages/ImportModals.jsx ───────────────────────────────────────────────────
// Extracted from HistoryPage.jsx.
// Contains the two-step import modal flow:
//   ImportModal         — step 1: choose which sections (players/courses/rounds) to import
//   ImportConflictModal — step 2: resolve name-based duplicates one at a time
// No page state. No round data. Pure modal UI.

import { useState } from 'react';
import { Btn, G, GA } from '../components/ui.jsx';

const AMB   = '#b45309';
const AMBBG = '#fffbeb';

// ── Name normaliser & fuzzy-match ─────────────────────────────────────────────
function normName(n) { return (n || '').trim().toLowerCase().replace(/\s+/g, ' '); }

export function likelySameCourse(a, b) {
  const na = normName(a), nb = normName(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  if (na.includes(nb) || nb.includes(na)) return true;
  const wa = new Set(na.split(/\s+/)), wb = new Set(nb.split(/\s+/));
  const shared = [...wa].filter(w => wb.has(w)).length;
  return shared / Math.max(wa.size, wb.size) >= 0.6;
}

export function likelySamePlayer(a, b) {
  return normName(a) === normName(b);
}

// ── Deep-diff two courses ─────────────────────────────────────────────────────
export function diffCourses(existing, incoming) {
  const diffs = [];
  if ((existing.location || '') !== (incoming.location || '') && (incoming.location || '')) {
    diffs.push({ field: 'location', label: 'Location', old: existing.location || '—', neu: incoming.location });
  }
  const existTeeMap = Object.fromEntries((existing.tees || []).map(t => [t.name?.toLowerCase(), t]));
  const incomTeeMap = Object.fromEntries((incoming.tees || []).map(t => [t.name?.toLowerCase(), t]));
  const allTeeNames = new Set([...Object.keys(existTeeMap), ...Object.keys(incomTeeMap)]);
  for (const tn of allTeeNames) {
    const et = existTeeMap[tn], it = incomTeeMap[tn];
    if (!et && it) {
      diffs.push({ field: `tee_new_${tn}`, label: `Tee "${it.name}"`, old: '—', neu: `Rating ${it.rating}/${it.slope}` });
    } else if (et && it) {
      if (et.rating !== it.rating || et.slope !== it.slope) {
        diffs.push({ field: `tee_${tn}`, label: `${et.name} (Men's)`, old: `${et.rating}/${et.slope}`, neu: `${it.rating}/${it.slope}` });
      }
      if ((et.ratingW || it.ratingW) && (et.ratingW !== it.ratingW || et.slopeW !== it.slopeW)) {
        diffs.push({ field: `teeW_${tn}`, label: `${et.name} (Women's)`, old: `${et.ratingW||'—'}/${et.slopeW||'—'}`, neu: `${it.ratingW||'—'}/${it.slopeW||'—'}` });
      }
      const etTotal = et.totalYards || (et.nineYards?.reduce((a,b)=>a+b,0));
      const itTotal = it.totalYards || (it.nineYards?.reduce((a,b)=>a+b,0));
      if (itTotal && etTotal !== itTotal) {
        diffs.push({ field: `yards_${tn}`, label: `${et.name} Yardage`, old: etTotal ? `${etTotal} yds` : '—', neu: `${itTotal} yds` });
      }
    }
  }
  (incoming.nines || []).forEach((inNine, ni) => {
    const exNine = (existing.nines || [])[ni];
    if (!exNine) {
      diffs.push({ field: `nine_${ni}`, label: `Nine "${inNine.name}"`, old: '—', neu: `Par ${inNine.pars?.reduce((a,b)=>a+b,0)}` });
      return;
    }
    const parDiff = inNine.pars?.some((p, i) => p !== (exNine.pars||[])[i]);
    if (parDiff) diffs.push({ field: `par_${ni}`, label: `${inNine.name} Pars`, old: (exNine.pars||[]).join('-'), neu: (inNine.pars||[]).join('-') });
    const hcpDiff = inNine.handicaps?.some((h, i) => h !== (exNine.handicaps||[])[i]);
    if (hcpDiff) diffs.push({ field: `hcp_${ni}`, label: `${inNine.name} M-Handicaps`, old: (exNine.handicaps||[]).join('-'), neu: (inNine.handicaps||[]).join('-') });
    const hcpWDiff = inNine.handicapsWomen?.some((h, i) => h !== (exNine.handicapsWomen||[])[i]);
    if (hcpWDiff) diffs.push({ field: `hcpw_${ni}`, label: `${inNine.name} W-Handicaps`, old: (exNine.handicapsWomen||[]).join('-') || '—', neu: (inNine.handicapsWomen||[]).join('-') });
  });
  return diffs;
}

// ── Step 1: Section selector ──────────────────────────────────────────────────
export function ImportModal({ parsed, onConfirm, onClose }) {
  const [sel, setSel] = useState({
    players: !!parsed.players?.length,
    courses: !!parsed.courses?.length,
    rounds:  !!parsed.rounds?.length,
  });

  const toggle = (k) => setSel(p => ({ ...p, [k]: !p[k] }));
  const noneSelected = !sel.players && !sel.courses && !sel.rounds;

  const rows = [
    { key: 'players', label: 'Players',      emoji: '👤', count: parsed.players?.length || 0 },
    { key: 'courses', label: 'Courses',       emoji: '⛳', count: parsed.courses?.length || 0 },
    { key: 'rounds',  label: 'Round history', emoji: '📋', count: parsed.rounds?.length  || 0 },
  ].filter(r => r.count > 0);

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.5)', zIndex:400,
      display:'flex', alignItems:'flex-end', justifyContent:'center' }} onClick={onClose}>
      <div style={{ background:'#fff', borderRadius:'20px 20px 0 0', padding:22,
        width:'100%', maxWidth:520 }} onClick={e => e.stopPropagation()}>

        <div style={{ fontWeight:800, fontSize:17, color:G, marginBottom:2 }}>📥 Import Data</div>
        <div style={{ fontSize:12, color:'#888', marginBottom:16 }}>
          Choose what to import. You'll be able to resolve any conflicts before saving.
        </div>

        {rows.length === 0 && (
          <div style={{ textAlign:'center', color:'#aaa', padding:'20px 0', fontSize:13 }}>
            No importable data found in this file.
          </div>
        )}

        <div style={{ display:'flex', flexDirection:'column', gap:8, marginBottom:18 }}>
          {rows.map(({ key, label, emoji, count }) => (
            <div key={key} onClick={() => toggle(key)}
              style={{ display:'flex', alignItems:'center', gap:12, padding:'11px 14px',
                borderRadius:12, border:`1.5px solid ${sel[key] ? G : '#ddd'}`,
                background: sel[key] ? GA : '#fff', cursor:'pointer' }}>
              <div style={{ width:22, height:22, borderRadius:6,
                border:`2px solid ${sel[key] ? G : '#ccc'}`,
                background: sel[key] ? G : '#fff',
                display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                {sel[key] && <span style={{ color:'#fff', fontSize:13, fontWeight:900 }}>✓</span>}
              </div>
              <span style={{ fontSize:16 }}>{emoji}</span>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700, fontSize:14, color: sel[key] ? G : '#333' }}>{label}</div>
                <div style={{ fontSize:11, color:'#888' }}>{count} record{count !== 1 ? 's' : ''}</div>
              </div>
            </div>
          ))}
        </div>

        {(sel.players || sel.courses || sel.rounds) && (
          <div style={{ background:'#fff8e1', border:'1px solid #f0d070', borderRadius:8,
            padding:'8px 12px', fontSize:11, color:'#7a5800', marginBottom:14 }}>
            ℹ️ Records with matching IDs will be overwritten. Name-based duplicates will be flagged for review.
            Your existing data not in this file will be kept.
          </div>
        )}

        <div style={{ display:'flex', gap:8 }}>
          <Btn variant="outline" onClick={onClose} style={{ flex:1 }}>Cancel</Btn>
          <Btn onClick={() => onConfirm(sel)} disabled={noneSelected || rows.length === 0}
            style={{ flex:2 }}>
            Next →
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ── Step 2: Conflict resolver ─────────────────────────────────────────────────
export function ImportConflictModal({ conflicts, onResolved, onClose }) {
  const [idx, setIdx]         = useState(0);
  const [decisions, setDecisions] = useState({});
  const [mergeChoices, setMergeChoices] = useState({});

  const conflict = conflicts[idx];
  if (!conflict) return null;

  const isCourse = conflict.type === 'course';
  const diffs    = conflict.diffs || [];
  const choices  = mergeChoices[idx] || Object.fromEntries(diffs.map(d => [d.field, 'new']));

  const toggleChoice = (field) => {
    setMergeChoices(prev => ({
      ...prev,
      [idx]: { ...choices, [field]: choices[field] === 'new' ? 'old' : 'new' }
    }));
  };

  const decide = (action) => {
    let merged = null;
    if (action === 'merge' && isCourse) {
      merged = { ...conflict.incoming, id: conflict.existing.id };
      diffs.forEach(d => {
        if (choices[d.field] === 'old') {
          if (d.field === 'location') merged.location = conflict.existing.location;
          else if (d.field.startsWith('tee_new_')) {
            const tn = d.field.replace('tee_new_', '');
            merged.tees = (merged.tees || []).filter(t => t.name?.toLowerCase() !== tn);
          } else if (d.field.startsWith('tee_')) {
            const tn = d.field.replace('tee_', '');
            const exT = (conflict.existing.tees || []).find(t => t.name?.toLowerCase() === tn);
            if (exT) merged.tees = (merged.tees || []).map(t =>
              t.name?.toLowerCase() === tn ? { ...t, rating: exT.rating, slope: exT.slope } : t);
          } else if (d.field.startsWith('teeW_')) {
            const tn = d.field.replace('teeW_', '');
            const exT = (conflict.existing.tees || []).find(t => t.name?.toLowerCase() === tn);
            if (exT) merged.tees = (merged.tees || []).map(t =>
              t.name?.toLowerCase() === tn ? { ...t, ratingW: exT.ratingW, slopeW: exT.slopeW } : t);
          } else if (d.field.startsWith('yards_')) {
            const tn = d.field.replace('yards_', '');
            const exT = (conflict.existing.tees || []).find(t => t.name?.toLowerCase() === tn);
            if (exT) merged.tees = (merged.tees || []).map(t =>
              t.name?.toLowerCase() === tn ? { ...t, totalYards: exT.totalYards, nineYards: exT.nineYards } : t);
          } else if (d.field.startsWith('par_')) {
            const ni = parseInt(d.field.replace('par_', ''));
            if (merged.nines?.[ni]) merged.nines[ni] = { ...merged.nines[ni], pars: conflict.existing.nines?.[ni]?.pars };
          } else if (d.field.startsWith('hcp_')) {
            const ni = parseInt(d.field.replace('hcp_', ''));
            if (merged.nines?.[ni]) merged.nines[ni] = { ...merged.nines[ni], handicaps: conflict.existing.nines?.[ni]?.handicaps };
          } else if (d.field.startsWith('hcpw_')) {
            const ni = parseInt(d.field.replace('hcpw_', ''));
            if (merged.nines?.[ni]) merged.nines[ni] = { ...merged.nines[ni], handicapsWomen: conflict.existing.nines?.[ni]?.handicapsWomen };
          }
        }
      });
    }
    const newDecisions = { ...decisions, [idx]: { action, merged } };
    setDecisions(newDecisions);
    if (idx < conflicts.length - 1) {
      setIdx(idx + 1);
    } else {
      onResolved(newDecisions);
    }
  };

  const progress = `${idx + 1} of ${conflicts.length}`;

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.55)', zIndex:410,
      display:'flex', alignItems:'flex-end', justifyContent:'center' }}>
      <div style={{ background:'#fff', borderRadius:'20px 20px 0 0', padding:20,
        width:'100%', maxWidth:520, maxHeight:'88vh', overflowY:'auto' }}>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:4 }}>
          <div>
            <div style={{ fontWeight:800, fontSize:16, color:AMB }}>⚠️ Duplicate Found</div>
            <div style={{ fontSize:11, color:'#888', marginTop:1 }}>Conflict {progress}</div>
          </div>
          <button onClick={onClose} style={{ border:'none', background:'none', fontSize:18, color:'#bbb', cursor:'pointer', padding:'0 4px' }}>✕</button>
        </div>

        <div style={{ background: AMBBG, border:`1px solid #f0d070`, borderRadius:10,
          padding:'8px 12px', marginBottom:12 }}>
          <div style={{ fontSize:13, fontWeight:700, color:'#444' }}>
            {isCourse ? '⛳' : '👤'} {conflict.incoming.name}
          </div>
          <div style={{ fontSize:11, color:'#888', marginTop:1 }}>
            {conflict.sameId
              ? `Same record (matching ID), but data differs from your library. Choose which version to keep.`
              : `A ${isCourse ? 'course' : 'player'} with this name already exists in your library with a different ID.`}
          </div>
        </div>

        {isCourse && diffs.length === 0 && (
          <div style={{ background:'#f0faf0', border:'1px solid #c8e8c8', borderRadius:10,
            padding:'10px 14px', marginBottom:12, fontSize:12, color:'#2d6a2d' }}>
            ✅ These records appear identical — no field differences found.
          </div>
        )}

        {isCourse && diffs.length > 0 && (
          <div style={{ marginBottom:12 }}>
            <div style={{ fontSize:12, fontWeight:700, color:'#555', marginBottom:6 }}>
              Field differences — tap to toggle which value to keep:
            </div>
            <div style={{ border:'1px solid #e0e0e0', borderRadius:10, overflow:'hidden' }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', background:'#f5f5f5',
                padding:'5px 10px', fontSize:10, fontWeight:700, color:'#888', gap:4 }}>
                <span>Field</span>
                <span style={{ color:'#1a6e1a' }}>Library (existing)</span>
                <span style={{ color:'#1a5c8c' }}>File (incoming)</span>
              </div>
              {diffs.map((d, di) => {
                const picked = choices[d.field] || 'new';
                return (
                  <div key={d.field} style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr',
                    padding:'7px 10px', fontSize:11, gap:4, alignItems:'center',
                    background: di % 2 === 0 ? '#fff' : '#fafafa',
                    borderTop:'1px solid #f0f0f0' }}>
                    <span style={{ fontWeight:600, color:'#555', fontSize:10 }}>{d.label}</span>
                    <div onClick={() => toggleChoice(d.field)}
                      style={{ padding:'4px 8px', borderRadius:6, cursor:'pointer',
                        background: picked === 'old' ? '#e8f5e9' : '#fafafa',
                        border: picked === 'old' ? '1.5px solid #43a047' : '1.5px solid transparent',
                        color: picked === 'old' ? '#1a6e1a' : '#999',
                        fontWeight: picked === 'old' ? 700 : 400 }}>
                      {d.old}
                      {picked === 'old' && <span style={{ marginLeft:4, fontSize:10 }}>✓</span>}
                    </div>
                    <div onClick={() => toggleChoice(d.field)}
                      style={{ padding:'4px 8px', borderRadius:6, cursor:'pointer',
                        background: picked === 'new' ? '#e3f2fd' : '#fafafa',
                        border: picked === 'new' ? '1.5px solid #1e88e5' : '1.5px solid transparent',
                        color: picked === 'new' ? '#1a5c8c' : '#999',
                        fontWeight: picked === 'new' ? 700 : 400 }}>
                      {d.neu}
                      {picked === 'new' && <span style={{ marginLeft:4, fontSize:10 }}>✓</span>}
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{ fontSize:10, color:'#aaa', marginTop:4, textAlign:'center' }}>
              Tap either value to select it for the merged record
            </div>
          </div>
        )}

        {!isCourse && (() => {
          const fields = ['gender', 'ghin', 'email', 'phone'];
          const labels = { gender:'Gender', ghin:'Handicap Index', email:'Email', phone:'Phone' };
          const playerDiffs = fields.filter(f =>
            conflict.existing[f] !== conflict.incoming[f] &&
            (conflict.existing[f] || conflict.incoming[f])
          );
          return playerDiffs.length > 0 ? (
            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:12, fontWeight:700, color:'#555', marginBottom:6 }}>Field differences:</div>
              <div style={{ border:'1px solid #e0e0e0', borderRadius:10, overflow:'hidden' }}>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', background:'#f5f5f5',
                  padding:'5px 10px', fontSize:10, fontWeight:700, color:'#888', gap:4 }}>
                  <span>Field</span>
                  <span style={{ color:'#1a6e1a' }}>Library</span>
                  <span style={{ color:'#1a5c8c' }}>File</span>
                </div>
                {playerDiffs.map((f, di) => (
                  <div key={f} style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr',
                    padding:'7px 10px', fontSize:11, gap:4,
                    background: di % 2 === 0 ? '#fff' : '#fafafa',
                    borderTop:'1px solid #f0f0f0' }}>
                    <span style={{ fontWeight:600, color:'#555', fontSize:10 }}>{labels[f]}</span>
                    <span style={{ color:'#1a6e1a' }}>{conflict.existing[f] || '—'}</span>
                    <span style={{ color:'#1a5c8c' }}>{conflict.incoming[f] || '—'}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ background:'#f0faf0', border:'1px solid #c8e8c8', borderRadius:10,
              padding:'10px 14px', marginBottom:12, fontSize:12, color:'#2d6a2d' }}>
              ✅ Records appear identical — no field differences found.
            </div>
          );
        })()}

        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={() => decide('keep')}
              style={{ flex:1, padding:'10px 8px', borderRadius:10, border:'1.5px solid #43a047',
                background:'#e8f5e9', color:'#1a6e1a', fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>
              Keep Library
              <div style={{ fontSize:10, fontWeight:400, color:'#4caf50', marginTop:1 }}>Ignore the imported copy</div>
            </button>
            <button onClick={() => decide('replace')}
              style={{ flex:1, padding:'10px 8px', borderRadius:10, border:'1.5px solid #1e88e5',
                background:'#e3f2fd', color:'#1a5c8c', fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>
              Use File
              <div style={{ fontSize:10, fontWeight:400, color:'#42a5f5', marginTop:1 }}>Replace with imported data</div>
            </button>
          </div>
          {isCourse && diffs.length > 0 && (
            <button onClick={() => decide('merge')}
              style={{ width:'100%', padding:'10px 8px', borderRadius:10, border:`1.5px solid ${G}`,
                background: '#e8f4e8', color: G, fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>
              Merge (apply selected field choices above)
            </button>
          )}
          <button onClick={() => decide('keep')}
            style={{ width:'100%', padding:'8px', borderRadius:10, border:'1px solid #eee',
              background:'#fafafa', color:'#aaa', fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>
            Skip — decide later (keeps existing)
          </button>
        </div>

        {conflicts.length > 1 && (
          <div style={{ display:'flex', justifyContent:'center', gap:5, marginTop:14 }}>
            {conflicts.map((_, i) => (
              <div key={i} style={{ width:7, height:7, borderRadius:'50%',
                background: i === idx ? G : i < idx ? '#a8d8a8' : '#ddd' }} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
