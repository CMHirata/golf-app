# NewRoundPage Design Spec
_Session 11-H — April 2026_
_Status: AUTHORITATIVE — required reading before any 11-I code or contracts are written_
_No code in this document. Prose and tables only._

---

## Purpose

This document is the authoritative UI/UX specification for the New Round setup page. It was produced in session 11-H through a structured design review of all current implementation files and a complete owner-confirmed decision process. Session 11-I must read this document before writing any contracts or code. Any layout, component, or labeling decision made in 11-I that conflicts with this spec must be resolved by amending this spec first — not by making ad-hoc implementation choices.

---

## 1. Page-Level Structure

### 1.1 Layout

The page is a single vertically scrolling column of `Card` components. From top to bottom:

1. Course card
2. Players card
3. Games & Bets card (contains all game config blocks)

The page renders inside the standard app shell with the nav bar at the bottom.

### 1.2 Pinned Start Round button

The "Start Scoring →" button is pinned as a fixed action bar at the bottom of the viewport, sitting above the nav bar. It uses the existing `ACTION_BAR_HEIGHT` constant from `layout.js`. Page content has `paddingBottom` equal to the action bar height so the last card is never hidden behind it.

The button is disabled (grey, `not-allowed` cursor) when fewer than 2 players are selected. Enabled state uses primary green (`G`).

### 1.3 Section headers — deferred visual decision

Two variants must be implemented in 11-I and tested on device before a final decision is made:

**Option 1 — All headers:** Every ConfigSection has a named label (Players, Options, Bets, etc.) as currently implemented.

**Option 4 — Separators + labels only where needed:** Hairline separator lines provide visual rhythm between sections. Labels appear only where the content genuinely needs a name — "Dots to Track" in Dots, "Points" in Stableford, "Teams" in Sixes and Match. Sections whose content is self-evident (scoring pill row, bet fields) have no label.

Both variants are built. Owner selects after on-device review.

---

## 2. Shared Components

These components are built once in 11-I and used across all games that need them. No game may implement its own version of any of these.

### 2.1 `<BetRow>`

The universal betting row. Used by every game except Sixes and Dots (which use a simplified version — see §2.2).

**Props:**
- `modes` — array of `{ value, label }` objects defining the mode dropdown options
- `mode` — current mode value (string)
- `onModeChange` — callback
- `values` — object `{ front, back, total, single }` — current bet field values
- `onValueChange` — callback `(field, value) => void`
- `pressable` — boolean — whether press dropdowns appear
- `pressValues` — object `{ front, back, total, single }` — current press values
- `onPressChange` — callback `(field, value) => void`

**Layout — F/B/T mode:**
```
[Mode▼]  [$Front  ][$Back   ][$Total  ]
         [Manual▼ ][Manual▼ ][Manual▼ ]
```
- Mode dropdown: fixed width, left-justified
- Three equal bet fields fill remaining right width
- Press row sits directly below, no left cell, dropdowns aligned under their bet fields
- Press row only rendered when `pressable` is true

**Layout — Total mode:**
```
[Mode▼]              [$Total  ]
                     [Manual▼ ]
```
- Single bet field right-justified, matching Total column position from F/B/T mode
- Press dropdown below the bet field, same width, same right-justified position
- F and B columns are absent — not empty, just not rendered

**Layout — Per Point / Per Skin / Pot mode:**
```
[Mode▼]  [$field                        ]
```
- Single bet field fills full remaining right width
- No press row for these modes

**Bet field internal labels:** `$Front`, `$Back`, `$Total`, `$per point`, `$per skin`, `$buy-in` — label lives inside the field as placeholder, no external column headers.

**Press dropdown internal labels:** "Manual" as default. Options: Manual / 1 Down / 2 Down / 3 Down / 4 Down / 5 Down. Stored values: `'none'` / `'1'` / `'2'` / `'3'` / `'4'` / `'5'`.

### 2.2 `<SimpleBetRow>`

Used by Sixes and Dots — single bet field with optional press, no mode dropdown.

**Props:**
- `value` — bet amount
- `onChange` — callback
- `pressable` — boolean
- `pressValue` — current press value
- `onPressChange` — callback
- `label` — internal field label string (e.g. `'$per match'`, `'$per dot'`)

**Layout — with press (Sixes):**
```
[$per match                 ][Manual▼]
```
Horizontal — bet field and press dropdown share one row, equal-ish widths.

**Layout — without press (Dots):**
```
[$per dot                              ]
```
Single field, full row width.

### 2.3 `<ScoringPills>`

Segmented pill row for scoring mode selection. Used by all games. Dots is the only game that passes `includeNOL=false` (Gross/Net only). All other games including Sixes use the full three options (Gross / Net / Net Off Low).

**Props:**
- `value` — current scoring mode string: `'gross'` / `'net'` / `'netofflow'`
- `onChange` — callback
- `includeNOL` — boolean, default true — when false renders only Gross / Net

**Renders:**
```
[Gross]  [Net✓]  [Net Off Low]
```
Full-width pill row. Active option has green border and green tint background. All options always visible — one tap to change.

Decision is provisional — owner reserves the right to revert to `StyledSel` dropdown after on-device review.

### 2.4 `<PlayerSubsetDropdown>`

Inline subset picker presented as a single `InlineRow`-style control. Used by Skins, Stableford, Stroke Play, Nines, Dots.

**Props:**
- `players` — full players array
- `selectedIdxs` — array of included player indices (empty = all in)
- `onChange` — callback
- `required` — number or null — exact count required (Nines passes 3)

**Visibility rule:** Only rendered when more players exist than the game requires. Exact rules:

| Game | Render when |
|---|---|
| Match (individual) | >2 players |
| Match (team) | Never |
| Stroke Play | >2 players |
| Skins | >2 players |
| Nines | >3 players |
| Stableford | >2 players |
| Sixes | Never |
| Dots | >2 players and not in team mode |

**Closed state — all players in:**
```
[All Players                           ▼]
```

**Closed state — subset active, unique first names:**
```
[Chris, Mike, Tom                      ▼]
```

**Closed state — duplicate first names in subset:**
```
[Chris H., Chris T., Mike              ▼]
```
Last initial added only for players with a duplicate first name in the current subset.

**Closed state — names overflow bubble width:**
```
[Chris, Mike, To…                      ▼]
```

**Closed state — Nines, no valid selection:**
```
[All Players                           ▼]   ← red border
```

**Closed state — Nines, valid selection:**
```
[Chris, Mike, Tom                      ▼]   ← green border
```

**Open state — dropdown panel:**
A panel drops below the bubble, right-aligned. Header text "Select Players" (or "Select 3 Players" for Nines). Player chips in a 2-per-row grid using the established chip style (green border/tint = included, grey = excluded). Full two-line name blocks in panel — first name larger/bolder over last name smaller/lighter. No truncation in panel. Tap chip to toggle. Tap outside to close.

For Nines: count shown at bottom of panel ("3 of 4 selected ✓" when valid). Panel may be closed at any time — invalid state shown on bubble if constraint not met.

### 2.5 `<ConfigSection>` — existing, no changes

Named export from `GameConfig.jsx`. Section divider with optional label. Used throughout. No changes in 11-I.

### 2.6 `<InlineRow>` — promote to shared export

Currently defined privately and identically in both `GameConfig.jsx` and `MatchCard.jsx`. Must be consolidated to a single named export from `GameConfig.jsx` in 11-I. No behavior change.

### 2.7 `<PlayerSubsetChips>` — existing, no changes

Named export from `GameConfig.jsx`. Used inside `<PlayerSubsetDropdown>` panel. No changes to the chip component itself.

---

## 3. Per-Game Layout Spec

All game config panels share a common container: `background: GB`, `borderRadius: 10`, `borderLeft: 3px solid G`, `marginTop: 5`, `padding: 12px 13px`.

Standard field order within every game block:
1. Player subset picker (if applicable per §2.4 visibility rules)
2. Scoring mode + paired option (same line where applicable)
3. Betting row
4. Game-specific controls

### 3.1 Match / Nassau

Match renders one `<MatchCard>` per match instance. Multiple instances stack vertically. A dashed "+ Add another Match" button sits below the stack.

**MatchCard internal layout:**

**Header row:**
```
Match 1 · [Individual][Team]          [✕]
```
Match number label left. Format toggle (Individual / Team pill row) center/right. Remove button (`✕`) far right — hidden when only one match exists.

**Players section:**

*Individual format:*
```
[Player 1 ▼]    vs    [Player 2 ▼]
```
Two `PlayerDropdown` bubbles with "vs" separator. Each excludes the other.

*Team format:*
```
TEAM A
[Player 1 ▼]    &    [Player 2 ▼]

TEAM B
[Name      ]    &    [Name      ]   ← ReadOnlyBubble, auto-derived
```
Team B only shown when Team A is fully selected.

**Options section:**
```
[Gross][Net✓][Net Off Low]    [No Tie-break▼]
```
Scoring pills left, Tie-break dropdown right on same line. Tie-break only shown for team format when Team A is full. Tie-break options: No Tie-break / 2nd Ball / Half Point.

**Bets section:**

*Nassau mode (default):*
```
[Nassau▼]  [$Front  ][$Back   ][$Total  ]
           [Manual▼ ][Manual▼ ][Manual▼ ]
```

*Total mode:*
```
[Nassau▼]              [$Total  ][Manual▼]
```
Total bet field and press dropdown share one row — horizontal layout, consistent with the single-field press rule. Both right-justified, aligned to Total column position. F and B space is absent.

Bet mode dropdown options: Nassau / Total. Default: Nassau.

**Add match button:**
```
[ + Add another Match                      ]
```
Dashed border, green tint background, full width, below last match card.

### 3.2 Skins

```
[PlayerSubsetDropdown — if >2 players]
[Gross][Net✓][Net Off Low]    [Carryover▼]
[Per Skin▼]  [$per skin                  ]
```

Scoring pills + Carryover on same line.
Bet row: Per Skin / Pot mode dropdown left, single field right.
No press row for either mode.

Carryover options: Carryover (default) / No Carryover.
Bet mode options: Per Skin (default) / Pot.
Field labels: `$per skin` / `$buy-in` depending on mode.

### 3.3 Stableford

```
[PlayerSubsetDropdown — if >2 players]
[Gross][Net✓][Net Off Low]
[Per Point▼]  [$per point              ]
[Points table — see below]
```

Scoring pills full width (no paired option for Stableford).
Bet row: Per Point / F/B/T mode dropdown left, field(s) right.
No press row for either mode.

Bet mode options: Per Point (default) / F/B/T.

*Points table (always visible, in "Points" ConfigSection):*
7-column grid of number inputs:
```
+3  Eagle  Bird  Par  Bog  Dbl  Worse
[  ][    ][    ][   ][   ][   ][     ]
                              [Reset]
```
Small column labels above inputs. "Reset" text link below restores defaults.

### 3.4 Nines

```
[PlayerSubsetDropdown — if >3 players, required=3]
[Gross][Net✓][Net Off Low]    [No Niner▼]
[Per Point▼]  [$per point              ]
```

Scoring pills + Niner dropdown on same line.
Bet row: Per Point / F/B/T mode dropdown left, field(s) right.
No press row for either mode.

Niner options: No Niner (default) / Niner.
Bet mode options: Per Point (default) / F/B/T.

Player count error: if fewer than 3 players in the round, red error banner shown above subset picker: "Nines requires at least 3 players."

Subset validation: red border on `<PlayerSubsetDropdown>` bubble until exactly 3 players selected (when >3 players in round).

### 3.5 Sixes

```
[Player count error if <4 players]
[Teams section — if ≥4 players]
[Gross][Net✓][Net Off Low]    [No Tie-break▼]
[$per match                 ][Manual▼]
```

No mode dropdown, no player subset picker. All four player slots are explicitly assigned in the Teams section.

**Teams section:**

Two segments rendered: Front 6, Middle 6 (indices 0 and 1 of `sixesTeams`).

Per segment:
```
FRONT 6
Team A
[Player 1▼]   +   [Player 2▼]

Team B
[Name     ]   +   [Name     ]   ← ReadOnlyBubble, auto-derived
```
Team B only shown when Team A is fully selected. Complex exclusion logic (prior teammate prevention) unchanged from current implementation.

Bet row uses `<SimpleBetRow>` with `pressable=true`. Horizontal layout: bet field + press dropdown on same line.

Scoring pills + Tie-break on same line. Tie-break options: No Tie-break / 2nd Ball / Half Point.

### 3.6 Stroke Play

```
[PlayerSubsetDropdown — if >2 players]
[Gross][Net✓][Net Off Low]
[Total▼]  [$total                      ]
```

Scoring pills full width (no paired option).
Bet row: Total / F/B/T mode dropdown left, field(s) right.
No press row for either mode.

Bet mode options: Total (default) / F/B/T.

### 3.7 Dots

```
[PlayerSubsetDropdown — if >2 players and not team mode]
[Gross][Net✓]    [Individual▼]
[Spread▼]  [$per dot                   ]
[Dots to Track section — see below]
```

Scoring pills (Gross/Net only, no NOL) + Teams dropdown on same line.
Bet row uses `<SimpleBetRow>` with `pressable=false`. Single field, full width.

Bet mode options: Spread (default) / Total.
Teams options: Individual (default) / Sixes Teams / Match Teams (dynamic based on active games).

*Dots to Track section (always visible, in "Dots to Track" ConfigSection):*
Unchanged from current implementation. One `DotRow` per dot with toggle, name, value input. Swipe-to-edit/delete for custom dots. `CustomDotAdder` at bottom.

---

## 4. Players Card Spec

### 4.1 Empty state

```
┌─ PLAYERS ─────────────────────────────────┐
│  [ Select players…                      ] │
└───────────────────────────────────────────┘
```

Single full-width primary button. Tapping opens `PlayerPickerPopup`.

### 4.2 Populated state

```
┌─ PLAYERS ─────────────────────────────────┐
│  Chris H.   [HI: 8.2][CH: 9 ][White▼]    │
│  Mike T.    [HI:12.4][CH: 14][White▼]    │
│  Tom B.     [HI: 5.1][CH: 6 ][Blue ▼]    │
│  ─────────────────────────────────────── │
│  tap a name to change players             │
└───────────────────────────────────────────┘
```

Player rows replace the button. No summary tile above rows — rows are the only player list on the page.

### 4.3 Tap zones per row

| Zone | Behavior |
|---|---|
| Name area (left of HI field) | Opens `PlayerPickerPopup` |
| HI field | Opens keyboard for HI editing |
| CH display | No interaction — display only |
| Tee dropdown | Opens tee selector panel |

`stopPropagation` on HI input and tee dropdown prevents bubbling to the row's tap handler.

### 4.4 HI / CH behavior

**HI entered, no manual CH override:**
CH auto-calculates from HI using selected tee slope/rating and displays in the CH field. CH field is editable — user may tap and type to override the calculated value. HI saved to player library on round start.

**HI entered, CH manually overridden:**
Manual CH entry clears the HI field (shows "HI" placeholder only — no value). HI is cleared from the player library. The manual CH value is used for the round as-is. CH is not saved to the player library (it is course and tee specific).

**HI absent:**
CH field shows "CH" placeholder. User may tap and type a CH value directly. Used for the round as-is, not saved to library. HI field remains empty.

**Manual CH entry in either case:**
The act of typing in the CH field always clears the HI field and clears HI from the player library. CH is authoritative for the round. HI is no longer relevant once CH is manually entered.

**Both empty:**
Player plays gross — no handicap strokes applied.

**Rationale:** HI is the only persistent player attribute (future API hook). CH is course and tee specific — it is never stored in the player library. Manual CH entry invalidates HI, so HI is cleared from the library to prevent stale data from being used in future rounds.

### 4.5 Tap hint

"tap a name to change players" shown below a hairline separator, below the last player row. Shown until first interaction with the name tap zone, then hidden permanently (persisted in localStorage or component state — 11-I to decide).

### 4.6 Tee selector

Per-player tee dropdown (`TeeDropdown`) unchanged from current implementation. Only shown when the selected course has tees defined.

---

## 5. Course Card

No changes to the Course card in 11-I. Current implementation (date input, course picker button, nine selectors, default tee selector) is correct and out of scope.

---

## 6. `GAME_CONFIGS` Constant Shape

A static constant defined in `NewRoundPage.jsx` (or a co-located constants file). Never stored in `gameOpts` or any persisted state. Used only by the setup UI to determine which components and modes to render for each game.

```js
const GAME_CONFIGS = {
  'Match / Nassau': {
    betType: 'segment',           // primary betting structure
    modes: [                      // mode dropdown options for <BetRow>
      { value: 'nassau', label: 'Nassau' },
      { value: 'total',  label: 'Total'  },
    ],
    defaultMode: 'nassau',
    pressable: true,              // press dropdowns appear in segment mode
    subsetPicker: false,          // players assigned explicitly via MatchCard
    scoringModes: ['gross','net','netofflow'],
    pairedOption: 'tiebreak',     // option paired with scoring pills (team only)
  },
  'Stroke Play': {
    betType: 'segment',
    modes: [
      { value: 'total',   label: 'Total' },
      { value: 'segments', label: 'F/B/T' },
    ],
    defaultMode: 'total',
    pressable: false,
    subsetPicker: true,
    subsetMinPlayers: 2,          // show picker when players > this value
    scoringModes: ['gross','net','netofflow'],
    pairedOption: null,
  },
  'Nines': {
    betType: 'rate',
    modes: [
      { value: 'perpoint',  label: 'Per Point' },
      { value: 'segments',  label: 'F/B/T'     },
    ],
    defaultMode: 'perpoint',
    pressable: false,
    subsetPicker: true,
    subsetMinPlayers: 3,
    subsetRequired: 3,            // exactly this many must be selected
    scoringModes: ['gross','net','netofflow'],
    pairedOption: 'niner',
  },
  'Stableford': {
    betType: 'rate',
    modes: [
      { value: 'perpoint',  label: 'Per Point' },
      { value: 'segments',  label: 'F/B/T'     },
    ],
    defaultMode: 'perpoint',
    pressable: false,
    subsetPicker: true,
    subsetMinPlayers: 2,
    scoringModes: ['gross','net','netofflow'],
    pairedOption: null,
    hasPointsTable: true,         // renders points table section
  },
  'Skins': {
    betType: 'rate',
    modes: [
      { value: 'perSkin', label: 'Per Skin' },
      { value: 'pot',     label: 'Pot'      },
    ],
    defaultMode: 'perSkin',
    pressable: false,
    subsetPicker: true,
    subsetMinPlayers: 2,
    scoringModes: ['gross','net','netofflow'],
    pairedOption: 'carryover',
  },
  'Sixes': {
    betType: 'perMatch',          // single scalar, no mode dropdown
    modes: [],                    // no mode dropdown rendered
    defaultMode: null,
    pressable: true,
    subsetPicker: false,          // all slots assigned explicitly
    scoringModes: ['gross','net','netofflow'],
    pairedOption: 'tiebreak',
  },
  'Dots': {
    betType: 'rate',
    modes: [
      { value: 'spread',  label: 'Spread' },
      { value: 'total',   label: 'Total'  },
    ],
    defaultMode: 'spread',
    pressable: false,
    subsetPicker: true,
    subsetMinPlayers: 2,
    scoringModes: ['gross','net'],  // no NOL for Dots
    pairedOption: 'teamsMode',
    hasDotsTable: true,            // renders Dots to Track section
  },
};
```

**Rules:**
- `GAME_CONFIGS` is read-only at runtime. Never mutate it.
- `betType` is a display-routing hint only — it determines which component renders, not any stored value.
- `modes` drives the mode dropdown. Empty array = no dropdown rendered (`<SimpleBetRow>` used instead of `<BetRow>`).
- `pairedOption` identifies which secondary control shares the scoring row. `null` = scoring pills fill full row width.
- Game-specific flags (`hasPointsTable`, `hasDotsTable`, `subsetRequired`) are additive — absence means false.

---

## 7. Wolf Extension Point

`GAME_CONFIGS` accommodates a future Wolf entry without modification to any other game's config or to the shared components. Wolf would be added as a new key with its own `betType`, `modes`, and flag properties. The `betType` value `'wolf'` (or an extension of `'rate'`) would route to a Wolf-specific betting component that handles the doubling mechanic — this component does not exist yet and is not specified here. The `GAME_CONFIGS` shape does not need to change to support it; only a new entry and a new rendering branch in `GameConfig.jsx` are required. No existing game's config is affected.

---

## 8. Cross-Game Design Standards

These are binding rules, not suggestions. Any implementation that violates them must be corrected.

1. **Internal labels only.** No external labels above or beside bet fields or dropdowns. Every control communicates its own state through its content.
2. **Betting row shape is always `[Mode▼] + [field(s)]`.** The left dropdown is always present when a game has more than one betting mode. Games with one mode use `<SimpleBetRow>` (no dropdown).
3. **Press is always vertical for F/B/T mode.** Press dropdowns sit directly below their bet fields, no left cell, aligned per column.
4. **Press is always horizontal for single-field modes.** Bet field and press dropdown share one row.
5. **Total field is always right-justified.** In Total mode the single field occupies the Total column position — same horizontal position as the Total field in F/B/T mode. F and B space is absent, not empty.
6. **Scoring mode selector is a segmented pill row.** Provisional — owner may revert to `StyledSel` after on-device review.
7. **Scoring pills pair with a secondary option on the same line where applicable.** Skins: Carryover. Match and Sixes: Tie-break (team/≥4 players only). All other games: full-width pills.
8. **Player subset picker is `<PlayerSubsetDropdown>` only.** No inline chip grids in game config blocks.
9. **Player subset picker hidden when not needed.** Visibility rules per §2.4.
10. **Terminology.** Overall → Total throughout. Segments → F/B/T in all mode labels. Nassau retained as a label for Match bet mode only.
11. **`InlineRow` is a shared export.** Single definition in `GameConfig.jsx`. No private duplicates.
12. **Niner is a `StyledSel` dropdown.** Options: No Niner (default) / Niner. No custom toggle widget.
13. **"Players" section heading is capitalized** to match all other section label styles.
14. **Start Round button is always pinned** to the bottom of the viewport. Never scrolls with content.
15. **Section headers — build both Option 1 and Option 4.** Owner decides after on-device review. Do not implement only one variant.

---

## 9. Open Questions

These items arose during the session and are deferred to a future session or to owner's discretion at implementation time.

| # | Item | Deferred to |
|---|---|---|
| OQ-1 | Section headers: Option 1 (all labels) vs Option 4 (separators + selective labels) — build both, decide on device | 11-I implementation + owner review |
| OQ-2 | Scoring mode selector: pill row vs StyledSel dropdown — pill row confirmed provisional, owner reserves right to revert after on-device review | 11-I implementation + owner review |
| OQ-3 | "Tap a name to change players" hint persistence — localStorage vs component state | 11-I implementation decision |
| OQ-4 | Press "Off" state — current decision is that Manual (default, `'none'`) means long-press chips enabled but no auto-trigger. A true "presses disabled" state was considered and deferred. If a use case emerges, `'off'` can be added as a value without breaking existing data | Future session if needed |
| OQ-5 | Per-match instance labeling (Match A, Match B, etc.) — designed but not yet implemented | Session 11-J |
| OQ-6 | NOL dot selector — per-game/per-match dot minimum | Session 11-K |

---

## 10. Files Changed in 11-I

This spec implies changes to the following files. No other files should be touched in 11-I without explicit owner approval.

| File | Nature of change |
|---|---|
| `NewRoundPage.jsx` | Pinned Start button; Players card redesign; GAME_CONFIGS constant; draft persistence update |
| `GameConfig.jsx` | All game config blocks rebuilt using shared components; GAME_CONFIGS routing; InlineRow promoted to named export |
| `MatchCard.jsx` | Rebuilt using BetRow; terminology updates; format toggle moved to header row |
| `PlayerDropdown.jsx` | No changes expected — existing components remain |
| New: `BetRow.jsx` (or inline in GameConfig) | `<BetRow>` and `<SimpleBetRow>` components |
| New: `ScoringPills.jsx` (or inline in GameConfig) | `<ScoringPills>` component |
| New: `PlayerSubsetDropdown.jsx` (or inline in GameConfig) | `<PlayerSubsetDropdown>` component |

Whether new components live in dedicated files or as named exports within `GameConfig.jsx` is an 11-I implementation decision. Named exports within `GameConfig.jsx` is acceptable given the app's current file organization pattern.

