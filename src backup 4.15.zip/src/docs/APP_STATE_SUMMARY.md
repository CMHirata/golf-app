_Last updated: April 2026 — Session 11-H complete (design-only session): NewRoundPage UX/UI design spec produced. Full game-by-game inventory of current setup fields completed. All Phase 2 design decisions confirmed by owner. Key decisions: (1) Unified betting row pattern `[Mode▼][field(s)]` across all games — mode dropdown left, fields right; `<BetRow>` and `<SimpleBetRow>` shared components. (2) Nassau terminology retired from UI except as display label for Match bet mode dropdown only (stored value is neutral). (3) Overall → Total throughout; Segments → F/B/T in all mode labels. (4) Press dropdowns: Manual default (`'none'` stored), 1 Down–5 Down options; vertical under F/B/T bet fields, horizontal beside single-field bet. (5) Players card redesigned: no duplicate roster, per-player HI/CH/tee rows are the only player list; name tap zone opens picker; CH editable (manual entry clears HI and player library HI); pinned Start Round button. (6) `<ScoringPills>` segmented pill row (provisional); `<PlayerSubsetDropdown>` inline dropdown with chip-toggle panel; `<InlineRow>` promoted to shared export. (7) Section headers: both Option 1 (all labels) and Option 4 (separators + selective labels) to be built in 11-I — owner decides on device. (8) `GAME_CONFIGS` static constant shape fully specified. Output: `NewRoundPage_Design_Spec.md` — authoritative required reading for 11-I. No code produced this session._

_Last updated: April 2026 — Session 11-G-1 complete (planning session): NOL subset dot display design work led to identification of foundational architectural debt. Decisions made: (1) Nassau terminology retired from all user-facing surfaces; replaced by segment-based betting (Front/Back/Overall fields) applied selectively per game. (2) `betType` adopted as a static config concept only — lives in a `GAME_CONFIGS` constant in `NewRoundPage`, never stored in `gameOpts` or round state. (3) Shared bet config UI components to be built: `<SegmentBetConfig>` (Match, Stroke Play, Nines), `<RateBetConfig>` (Nines, Skins perSkin, Dots, future Wolf), `<PotBetConfig>` (Skins pot). (4) Sixes uses a simple per-match scalar — no shared component needed, one field. (5) Wolf door left open as next game format: `GAME_CONFIGS` must include an extension point for Wolf's doubling mechanic. (6) Match/Nassau UX: the two formats are NOT split into separate game keys — they remain in a unified `matches` array distinguished by segment bet configuration. Per-match instance labeling (Match A, Match B) deferred to 11-G-3. (7) NOL dot selector (11-G-4) correctly includes Match instances: each match uses its own 2- or 4-player subset minimum; selecting "Match A" shows dots only for Match A's players using Match A's subset min; non-participants show plain blank. Ephemeral A/B/C labels derived from match array index used for dot selector only (not stored); persistent labels added in 11-G-3. Sequencing: 11-H (NewRoundPage UX/UI design spec) → 11-I (betting model refactor) → 11-J (instance labeling) → 11-K (NOL dot selector). No code produced this session._

_Last updated: April 2026 — Session 11-F complete and confirmed on device ✅: Zoom score entry modal (`ZoomModal.jsx` — new file). Full-screen scorecard-style popup showing 3-hole window (prev/current/next) for all players with magnified cells. Single hidden input at `top:-100px` (off-screen) receives all keystrokes — iOS never scrolls viewport to bring it into view. Zoom button (magnifying glass SVG) appears in Front 9 label row (portrait) and control row next to Net/NOL toggle (landscape). `ScorecardPage.jsx` exposes `zoomTriggerRef` for landscape button. `ScoreGrid.jsx` holds hidden input ref, focuses it synchronously inside zoom button tap gesture so iOS shows keyboard immediately on modal open. `DotsPopup.jsx` amended: `paddingTop` prop added — when opened from zoom modal (`zoomOpen=true`) popup renders at top of screen (paddingTop=92) matching modal position; `onMouseDown={e=>e.preventDefault()}` on card div prevents focus steal from hidden input. Active cell tracked via `focusedCell` state — only active cell gets green border (not full column). Tap prev/next column navigates to tapped player row. Backspace from top cell retreats to last player of previous hole. Files changed: `ZoomModal.jsx` (new), `ScoreGrid.jsx`, `ScorecardPage.jsx`, `DotsPopup.jsx`._

_Last updated: April 2026 — Sessions 11-D/E/post-E complete and confirmed on device ✅: (11-D) `resolveDisplayNames` added to `scorecardUtils.js`; `PlayerChips` added to `GameSection.jsx`; `TotalsCard`, `StrokePlayTable` footer chips, `PlayerSubsetChips` migrated to first-name display; `PlayerDropdown.jsx` new file (`PlayerDropdown`, `StyledSel`, `ReadOnlyBubble`); `MatchCard.jsx` and `GameConfig.jsx` Sixes picker rebuilt with custom dropdowns. (11-E) `Btn` disabled style fix (`ui.jsx` — explicit conditional spread after caller `style`); "Net Off Low" label audit confirmed consistent — no code changes needed. (post-E) Name display convention unified: all picker bubbles and game-table chips always show first name (larger/darker) + last name (smaller/lighter) unconditionally; `resolveDisplayNames` removed from `PlayerDropdown`, `GameSection`, `TotalsCard`, `StrokePlayTable`, `GameConfig`. Sixes duplicate-team prevention: `excludeIdxs` now blocks any player who has been a teammate with the current slot's partner in any segment (Team A or auto-derived Team B). Files changed: `ui.jsx`, `PlayerDropdown.jsx`, `GameConfig.jsx`, `MatchCard.jsx`, `GameSection.jsx`, `TotalsCard.jsx`, `StrokePlayTable.jsx`._

_Last updated: April 2026 — Session 11-C complete: D-1 Match/Nassau team hole winner display. `MatchNassauTable.jsx` — team chips now show slash-separated single first initials (`C/D`), colorblind-safe blue/red matching Sixes (`TMA_*`/`TMB_*` tokens); color-coded `nm1 vs nm2` header; `resolveMatchTeamNames` helper for cross-team collision-aware name resolution. Front 9 closure bug fixed: `buildDisplayBets` now scopes `runHoles` to segment holes (`hs`) not `ALL18_H` — `holesLeft` now correctly reaches 0 within Front 9 so `matchOver` fires and status shows `3&2` not `4UP`. Landscape `allRows18` stores `leadStateFront`/`leadStateBack` scoped to 9-hole ranges for correct F9/B9 status columns. Nassau_Match_Contract.md → v2.4._

_Last updated: April 2026 — Session 11-A complete: Dots (Specials) full rework across three phases. Phase 1: Dots_Contract.md v2.0 — data model (`pts`→`value`), display split (DotsTable + DotBadge), full Specials→Dots rename, retroactive autoMark scan. Phase 2: 12 files modified, DotsPopup.jsx + DotsTable.jsx added, SpecialsCard/SpecialsPopup deleted; migration shims in roundLib.migrateRecord. Phase 3: discrete scoring specials (ace/condor/albatross/eagle/birdie, mutually exclusive), popup redesign, pivot summary tile, PALE_YELLOW token; Dots_Contract.md → v2.1; App_Data_Model_Contract.md → v2.5. Pending on-device test + bulk round migration before shim removal._

 Share image overhauled. Root cause of modal share failure was `buildShareImage` missing from `RoundSummaryModal.jsx` import line (worked from swipe button only). Fixed. Share image now uses SVG foreignObject exclusively — Canvas 2D fallback removed entirely. Logo fetched fresh on each share tap via fetch→FileReader (SW cache makes it instant; module-level pre-fetch abandoned due to Vite HMR module reset). iOS Safari does not render `<img>` tags inside SVG foreignObject — logo is drawn directly onto the canvas after the foreignObject renders via `ctx.drawImage()`, with a same-size spacer div in the HTML to preserve header layout. Visual improvements: green header matches ScorecardPage exactly (logo 58px left, course name uppercase right-justified, date below); player chips in separate mint strip below header; Stroke Index row added to scorecard; ESC row removed from scorecard; scorecard totals chip row added (gross large, ESC small); three primary section labels (Scorecard/Game Results/Payouts) use 32px top margin + 2px green underline; payouts hierarchy: Overall = dark green header card (highest weight), By Game = grey secondary label, per-game sections = mid-green (#2d6a4f) headers; Nines F9/B9/18 zero rows suppressed (net=null and isHeader rows excluded from payout display). Files changed: `roundUtils.js`, `RoundSummaryModal.jsx`._

_Last updated: April 2026 — Session 10-B complete: Item 2 (logo heights + header consistency) — all pages now use `padding:'8px 16px 7px'` and `height:58` lockup logo; `HomePage` corrected from `height:52` / `padding:'10px 16px 8px'`; `ResultsPage` corrected from `height:52` / `.jpg`; `ScorecardPage` `.jpg`→`.png`. Files changed: `HomePage.jsx`, `ResultsPage.jsx`, `ScorecardPage.jsx`. Item 3 (landscape full-width scorecard + game tables) — root cause was `App.jsx` wrapper `maxWidth:520` constraining all pages; fixed with `isLandscape` state in `App.jsx`. `MatchNassauTable` now supports `isLandscape` with 18-hole combined table. `ScorecardPage` now owns `isLandscape` as single source of truth, passes to `ScoreGrid`. `isLandscape` wired to `NinesTable`, `StablefordTable`, `SkinsTable`, `StrokePlayTable`, `MatchNassauTable` in both `ScoreGrid` and `RoundSummaryModal`. Files changed: `App.jsx`, `ScorecardPage.jsx`, `ScoreGrid.jsx`, `MatchNassauTable.jsx`, `RoundSummaryModal.jsx`, `GameSection.jsx`. Item 4 (Courses triangles) — removed. `PressModal` `SinglePressChip` winner name now renders on single line. `NewRoundPage` date input fixed (iOS overflow). On-device confirmed ✅._

_Last updated: April 2026 — Session 10-A complete: Item 2 (RoundSummaryModal round totals) — `TotalsCard` now renders below the scorecard grid inside `RoundSummaryModal`; `primaryMode` derived locally (same logic as `ScorecardPage`). Files changed: `RoundSummaryModal.jsx`. Item 3 (ESC/Net Double Bogey) — `escTotal()` added to `handicap.js`; `TotalsCard` now shows gross + ESC for every player regardless of scoring mode; `primaryMode` prop removed from `TotalsCard`. Files changed: `handicap.js`, `TotalsCard.jsx`. Contract updated: `Handicap_Contract.md` → v1.5. Pending on-device testing._

_Last updated: April 2026 — Session 1-C complete: C-1 score cell shift fixed (`display: 'block'` on all score inputs prevents iOS from expanding focused input height) ✅; C-2 DotsPopup (then SpecialsPopup) iOS copy/paste callout fixed (`userSelect: 'none'` on popup inner card prevents text selection when finger lifts onto popup after long-press) ✅; E-1 deferred — Specials scoring/display rework planned as dedicated session. Files changed: `ScoreGrid.jsx`, `SpecialsPopup.jsx` (now `DotsPopup.jsx`)._

_Last updated: April 2026 — Session 9 complete: PWA implemented — manifest.json, sw.js, updated index.html + main.jsx. Logo files replaced with square PNGs (logo_icon.png = icon only, logo_lockup.png = icon + text). All logo references updated from .jpg to .png across 7 JSX files. App installable on iPhone home screen ✅._

_Session 8 complete: CoursesPage.jsx full extraction — CourseCard, CourseMergeModal, ManualCourseModal, PhotoImportModal, CourseSearchModal. normCourseName/likelySameCourse/diffCourses moved to courseLib.js. Confirmed on device ✅._

_Session 7 confirmed: `src/constants/layout.js` created with `NAV_BAR_HEIGHT` + `ACTION_BAR_HEIGHT`; all three import sites updated (App.jsx, ScorecardPage.jsx, ResultsPage.jsx); no local const declarations remain ✅. `PlayerPickerPopup.jsx` extracted (~69 lines) ✅; `MatchCard.jsx` extracted (~169 lines) ✅; `GameConfig.jsx` extracted (~580 lines, includes `PlayerSubsetChips` + `ConfigSection` named exports) ✅; `NewRoundPage.jsx` reduced from 1,360 → 592 lines ✅. On-device confirmed._

_Session 6 confirmed: Nav bar always visible on all pages ✅; TheCardIcon logo super-tab center button ✅; gold dot on in-progress round ✅; scroll-to-top on every tab change ✅; Scorecard ← Setup|Discard|Results → pinned action bar ✅; Results ← Scorecard|Save Round|Share pinned action bar (equal-width buttons) ✅; PlayerPickerPopup Cancel/Confirm pinned to sheet bottom ✅; dividing line between scorecard and Round Totals chips removed ✅. Pending on-device confirmation of full master checklist._

_Session 5 confirmed: Full visual reskin deployed across all pages. Logo JPEGs integrated. All emojis replaced with SVG icons. Consistent mint background. New header pattern on all pages. Swipe strip redesigned. Player chips moved out of Results header. Pending on-device confirmation of all pages._

_Session 4 confirmed working: B-3 all three back-to-setup paths populate correctly ✅; S-4 share sheet opens with PNG attached via iOS native share sheet from RoundSummaryModal ✅, ResultsPage ✅, HistoryPage swipe strip ✅._

_Session 3 confirmed working: R-1 per-match payout breakdown on ResultsPage ✅; R-2 no emojis in game labels ✅; R-3 named nine labels in portrait scorecard ✅; R-4 HomePage recent round tap opens RoundSummaryModal ✅; R-5 player chips in green header with stacked layout ✅._

_Session 2 confirmed working: swipe-left strip with real-time finger tracking ✅; right-swipe closes ✅; one strip at a time ✅; full-swipe (90%) delete ✅; tap opens RoundSummaryModal ✅; modal shows scorecard + game tables + payouts ✅; landscape scorecard 18-hole single row ✅; landscape modal full-width ✅; landscape game tables 18-hole ✅; portrait scorecard front-over-back ✅; per-match payouts broken out individually ✅; Stroke Index gender-aware labeling ✅; player chips HI/CH/Tee order ✅; Edit restricted to most-recent-date rounds ✅; H-3 passed first time ✅._

_Session 1-B confirmed working: static snapshot integrity ✅; round reload restores all game data ✅; edit flow pre-fills correctly ✅; Save Changes (Path A) persists tee/player data ✅._

**Purpose of this document:**
- Track what is and isn't yet implemented (vs. what is specified)
- Record implementation gotchas that AI must not re-break
- Handoff context between sessions
- Open items with priority rankings (do not remove items unless confirmed tested and resolved by project owner)

For schemas, layer rules, and architecture decisions → see `ARCHITECTURE_FOUNDATIONS.md` and the contract documents.

---

## Tech Stack

- **React 18** (JSX, hooks) — no class components
- **Vite** — dev server and bundler
- **Pure CSS-in-JS** — all styles are inline JS objects; no external CSS libraries
- **localStorage** — sole persistence layer; no backend, no database
- **Netlify** — drag-and-drop `dist/` deploy

---

## Implementation Gotchas (AI must not re-break these)

### H-1: `restoreDotDefs()` required after deserialization
Any code path that reads `dots` from localStorage or from `activeRound` must call
`restoreDotDefs(dots)` before using the dot definitions. Serialization strips the
`autoWhen` functions. Skipping this call causes auto-marking to silently fail.
Renamed from `restoreAutoWhen()` in Session 11-A.

### H-2: Score inputs must use `display: 'block'`
iOS expands the height of focused inputs unless `display: 'block'` is set explicitly.
Without this, focusing a score cell shifts the entire row downward. Fixed in 1-C.
Do not remove this style from score `<input>` elements.

### H-3: `activeRound` must be a deep clone on load
`getActiveRound()` in `App.jsx` must return a parsed copy from localStorage, never
a live reference. Mutating a cached reference corrupts the stored state silently.

### H-4: Landscape detection — single source of truth in `ScorecardPage`
`isLandscape` is computed once in `ScorecardPage.jsx` and passed down as a prop to
`ScoreGrid` and all game table components. `ScoreGrid` has a local fallback detection
only for the case where the prop is not supplied (e.g. read-only summary view).
Do not add a second independent landscape detector in `ScoreGrid` — it will diverge.

### H-5: `TotalsCard` is rendered inside `ScoreGrid`, not `ScorecardPage`
`TotalsCard` is mounted at the bottom of `ScoreGrid`'s return tree, not in
`ScorecardPage`. This is intentional — it keeps all scorecard display logic
co-located. Do not move it to `ScorecardPage` without explicit owner approval.

### H-6: `StyledSel` / `PlayerDropdown` — do not create parallel picker implementations
All player picker UI and option selects in New Round setup must use `StyledSel`,
`PlayerDropdown`, or `ReadOnlyBubble` from `PlayerDropdown.jsx`. These were created
in 11-D specifically to unify picker appearance. A second custom select component
anywhere in setup UI is a violation of this pattern.

### H-7: Name display convention — always first + last, no collision detection
The final convention (established post-11-D) is: always show first name (larger,
darker) + last name (smaller, lighter) unconditionally. `resolveDisplayNames` was
removed from most consumers after this decision. Do not reintroduce collision-aware
logic or first-name-only display without explicit owner approval.

### H-8: `GAME_CONFIGS` is static — `betType` is never stored in round state
`betType` is a UI dispatch concept that lives only in the static `GAME_CONFIGS`
constant (to be created in 11-G-2). It must never appear in `gameOpts`, `activeRound`,
or any persisted state. The game key (e.g. `'Match'`, `'Skins'`) implies the
allowed betting models — they do not need to be stored. Adding `betType` to
`gameOpts` is a contract violation.

### H-9: Nassau terminology is retired from all user-facing surfaces
As of 11-G-2, the word "Nassau" must not appear in any UI label, button, toggle,
game tile, or payout display. The behavior formerly called "Nassau" is exposed as
Front/Back/Overall bet fields. Code comments may retain the word for historical
clarity. Do not reintroduce "Nassau" as a UI term without explicit owner approval.

---

## Open Items

### Betting model refactor (11-G-2 prerequisite for 11-G-3 and 11-G-4)
- Nassau terminology retired; replaced by segment betting (Front/Back/Overall fields)
- `GAME_CONFIGS` static constant to be created as sole source of truth for which
  betting model(s) each game supports
- Shared bet config components: `<SegmentBetConfig>`, `<RateBetConfig>`, `<PotBetConfig>`
- Migration shim required in `roundLib` for saved rounds using old `nassau: true` schema
- Wolf extension point must be preserved in `GAME_CONFIGS` design
- Priority: High (blocks 11-J and 11-K)

### Per-match instance labeling (11-J)
- Match instances need A/B/C labels for dot selector and future UI consistency
- Persistent `label` field added to each match object in `matches` array
- Labels assigned in `NewRoundPage` match setup UI
- Propagated to: `MatchNassauTable`, `PressModal`, `RoundSummaryModal`
- Contract: amend `Nassau_Match_Contract.md` + `App_Data_Model_Contract.md`
- Priority: High (blocks 11-K)

### NOL dot selector (11-K)
- When NOL dot mode is active and a subset/match game excludes the round's low player,
  scorecard dots use full-field min — misleading for subset participants
- Design decision made (11-G-1): Option A — per-game selector pill row
- Selector shows only when at least one active NOL game excludes the low player
- Selecting a game shows dots only for that game's participants using subset min
- Match instances use ephemeral A/B/C labels (from array index) for selector only
- Plain blank (no dots) for non-participants when a match/subset is selected
- ZoomModal inherits same selection
- Switching to Net dot mode resets selection to "Field"
- Contract: amend `Handicap_Contract.md` §5 → v1.6
- Priority: High

### NewRoundPage UX/UI design spec (11-H) — ✅ COMPLETE
- `NewRoundPage_Design_Spec.md` produced and approved by owner
- All design decisions confirmed — see spec for full detail
- Required reading before any 11-I contracts or code are written

### Stableford F/B/O bets (12-A) — now absorbed into 11-I betting model refactor
- D-4 original item: Stableford front/back/overall bet fields
- Will be implemented as part of the universal segment betting rollout in 11-I
- Remove from Sprint 12 standalone session; close 12-A after 11-I confirms it

### G-3: `buildPayoutArgs` uses full-field `minCourseHcp` for NOL Skins subset
- When `netofflow` mode is active, `buildPayoutArgs` in `App.jsx` computes
  `minCourseHcp` from all players rather than the Skins subset
- Fix is targeted addition to `buildPayoutArgs` in `App.jsx` only
- No other files affected
- Priority: Medium

### Nines table fixes (12-B)
- D-6: NinesTable renders only 3-player subset (contracted, not implemented)
- D-7: NinesTable breakdown rows filter to subset
- D-2: "pts" label on Nines total chips
- Priority: Medium

### Match status columns (12-D)
- D-3: Decision and implementation of match status columns
- D-8: Match numbering on result cards (superseded by 11-J label work — coordinate)
- Priority: Medium

---

## Session Roadmap

| Session | Scope | Status |
|---|---|---|
| 1-A | Round lifecycle bugs + safety guards | ✅ Complete |
| 1-B | History data integrity + edit flow | ✅ Complete |
| 2 | History UX: swipe actions, read-only summary modal, landscape mode | ✅ Complete |
| 3 | ResultsPage redesign + RoundSummaryModal polish | ✅ Complete |
| 4 | B-3 fix + Share / formatted export (PNG via iOS share sheet) | ✅ Complete |
| 5 | Visual polish + branding: logo, headers, mint bg, SVG icons, swipe strip | ✅ Complete (pending on-device test) |
| 6 | Navigation overhaul: always-visible nav, logo super-tab, pinned action bars, scroll-to-top | ✅ Complete (pending on-device test) |
| 7 | Shared layout constants + NewRoundPage extractions (PlayerPickerPopup, MatchCard, GameConfig) | ✅ Complete |
| 8 | CoursesPage full extraction: 5 components + helpers to courseLib.js | ✅ Complete |
| 9 | PWA: manifest, service worker, PNG logos, home screen install | ✅ Complete |
| 1-C | Scorecard input bugs: score cell shift (C-1), Specials popup iOS callout (C-2) | ✅ Complete |
| 10-A | RoundSummaryModal totals row + ESC (Net Double Bogey) in TotalsCard | ✅ Complete (pending on-device test) |
| 10-B | Visual regressions: header heights, logos, landscape full-width, Courses triangles, share image | ✅ Complete — all items including Item 1 (share image) confirmed |
| 11-A | Dots (Specials) full rework: contract v2.0→v2.1, full rename, DotsTable, DotsPopup, DotBadge, discrete scoring specials, mutual exclusivity, popup redesign, pivot summary, retroactive autoMark, contract updates | ✅ Complete — pending bulk round migration before shim removal |
| 11-C | D-1: Match/Nassau team hole winner display — slash-initials (C/D), colorblind-safe blue/red chips matching Sixes; color-coded header; Front 9 closure bug fixed (buildLeadState scoped to segment holes) | ✅ Complete ✅ confirmed on device |
| 11-D | resolveDisplayNames rollout + PlayerDropdown.jsx new file (PlayerDropdown, StyledSel, ReadOnlyBubble); MatchCard and GameConfig/Sixes migrated to custom pickers | ✅ Complete ✅ confirmed on device |
| 11-E | Disabled Btn style fix (ui.jsx G-5); "Net Off Low" label audit (confirmed already consistent); name display convention unified; Sixes duplicate-team prevention | ✅ Complete ✅ confirmed on device |
| 11-F | Zoom score entry modal: ZoomModal.jsx (new), hidden-input keyboard pattern, 3-hole window, stacked player names, active-cell-only border, magnifying glass button | ✅ Complete ✅ confirmed on device |
| 11-G | Planning: NOL dot display design decision; betting model architecture decision (Nassau retired → segment betting); betType as static config; GAME_CONFIGS pattern; Wolf extension point; session sequencing | ✅ Complete (planning only — no code) |
| 11-H | NewRoundPage UX/UI design spec: full game-by-game setup field inventory; shared component identification; layout decisions for dual-mode games, scoring selectors, player pickers, toggles; output: NewRoundPage_Design_Spec.md | ✅ Complete (design only — no code) |
| 11-I | Betting model refactor: Nassau → Front/Back/Overall segment fields; GAME_CONFIGS constant; shared bet config components; migration shim; all contracts | 🔲 Not started |
| 11-J | Per-match instance labeling: persistent label field on match objects; NewRoundPage UI; MatchNassauTable, PressModal, RoundSummaryModal propagation; contract updates | 🔲 Not started |
| 11-K | NOL dot selector: per-game/per-match dot minimum; Handicap_Contract.md §5 amendment → v1.6; ScoreGrid, ScorecardPage, ZoomModal updates | 🔲 Not started |

---

## Document Index

| Document | Purpose |
|---|---|
| `ARCHITECTURE_FOUNDATIONS.md` | Mental models, layer system, the "why" |
| `App_Data_Model_Contract.md` (v2.5) | State schema, storage keys, mutation rules — fully updated for Dots rename |
| `Handicap_Contract.md` (v1.5) | USGA math, `scoreForMode`, `escTotal`, `DEFAULT_STAB`, NOL+subset invariant §5 |
| `Payout_Contract.md` (v1.9) | `computePayouts` entry point, `subsetMin` pattern, per-game payout logic |
| `Nassau_Match_Contract.md` (v2.4) | Nassau/Match Play rules, press system, engine API, §13 hole winner cell display |
| `Sixes_Contract.md` (v1.7) | Sixes team rotation, hole scoring, press system, payout rules |
| `Skins_Contract.md` (v1.4) | Skins carryover rules, subset behavior, engine API, payout pool formula |
| `Stableford_Contract.md` (v1.1) | Stableford points table, three payout modes, subset/NOL rules |
| `Nines_Contract.md` (v1.1) | Nines point table, blitz rule, 3-player constraint, payout modes |
| `Dots_Contract.md` (v2.1) | Dots/Junk: `DOTS_DEF`, discrete scoring specials, mutual exclusivity, `value` field, `dotEntries`, `DotsTable` pivot spec, popup interaction, migration shims, payout, teamMode |
| `Round_Lifecycle_Contract.md` (v1.5) | Setup→score→save flow, activeRound lifecycle, §6.5 read-only summary view |
| `Stroke_Play_Contract.md` | Stroke play scoring modes, `strokePlayPlayers` subset, `calcStrokePlay` |
| `UI_Component_Contract.md` | `ui.jsx` tokens, all components, `style` prop pattern |
| `APP_STATE_SUMMARY.md` (this file) | Status, gotcha, open items, session handoff |
