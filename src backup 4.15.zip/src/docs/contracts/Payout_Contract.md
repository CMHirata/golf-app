# Payout Contract

_Version 1.9 — April 2026_
_Supersedes Payout Contract v1.8._
_Changes in v1.9: §7.5 Nines nassau mode — corrected description from "§5.0 split
formula" to the actual pairwise bilateral loop (`payNassauSeg`). The split formula
description was inaccurate; the implementation was always correct. See Nines Contract
§5.4 and §14 G-3._
_Status: AUTHORITATIVE._
_All implementation must conform to this contract._
_If code conflicts with this contract, the contract wins._

---

## 1. Purpose and Scope

This contract defines all rules governing how `computePayouts()` in `engine/payouts.js`
converts engine scoring outputs into dollar amounts. It is the authoritative
reference for:

- The entry point, parameter contract, and output shape of `computePayouts()`
- The `buildPayoutArgs` synchronization rule (mirrored in App Data Model Contract §10)
- The universal NOL+subset implementation rule via `subsetMin()` (§4.3)
- Per-game payout logic for all active games
- Tie-handling rules for all games (§5)
- Incomplete-round payout policy
- The `payWinner` helper and its usage constraints
- Architecture boundaries: what belongs in the engine vs. display layer

Game-specific scoring rules (hole winners, match lead progression, team
rotation, etc.) are defined in the relevant game contracts. This document
covers only how those scoring outcomes translate into money.

---

## 2. Architecture Boundary

`computePayouts()` is a pure engine function. It has no side effects,
no React dependency, and no localStorage access. It is always called
from `App.jsx` via `buildPayoutArgs()` before navigating to ResultsPage.

```
App.jsx
  └── buildPayoutArgs(activeRound)        // maps activeRound fields to engine args
        └── computePayouts(args)          // engine: pure function → { bank, breakdown }
              └── ResultsPage.jsx         // render only — no engine calls
```

**`computePayouts()` must not be called from any UI component, table
component, or `scorecardUtils.js`.** It is called exactly once per
Results navigation, in `App.jsx`.

`breakdown` and `bank` are written to `activeRound` for display purposes
and persisted in the history record at save time. They are display caches
only and are never used as inputs to any engine function.

---

## 3. Output Shape

### 3.1 Return value

```js
computePayouts(args) → { bank, breakdown }
```

| Field | Type | Description |
|---|---|---|
| `bank` | `{ [playerName]: number }` | Net dollar amount per player across all games. Always sums to zero. |
| `breakdown` | `BreakdownEntry[]` | Per-game result rows for display in ResultsPage. |

### 3.2 `BreakdownEntry` shape

```js
{
  game: string,   // display label, e.g. '💰 Skins', '🥊 Match / Nassau'
  rows: [
    {
      name:     string,           // player name
      detail:   string,           // human-readable scoring detail
      net:      number | null,    // net dollars for this player in this game
      isHeader: true,             // present only on header rows (Nines Nassau)
    }
  ]
}
```

### 3.3 `initBank` helper

Each game block initializes a local `gb` (game bank) via `initBank(players)`,
which creates a zero-valued object keyed by player name over all players.
At the end of the game block, `gb` values are merged into the global `bank`.
Non-participants remain at 0 in `gb` for the duration of that game block.

### 3.4 `payWinner` helper

```js
payWinner(winner: string, players: Player[], bet: number, gb: object)
```

Charges each player whose name ≠ `winner` by `bet` and credits `winner`
an equivalent amount per losing player. Used for sole-winner scenarios only.

**Usage constraint:** `payWinner` must only be called when exactly one
winner has been determined. For tie cases use the §5.0 split formula directly.
`payWinner` must never be called when two or more players share the winning score.

---

## 4. `buildPayoutArgs` Synchronization Rule

`buildPayoutArgs(ar)` in `App.jsx` is the sole mapping from the `activeRound`
blob to the argument object consumed by `computePayouts()`.

**Synchronization rule (mirrored from App Data Model Contract §10):**
Every field consumed by `computePayouts()` must be present in `buildPayoutArgs`.
Adding a game or a parameter without updating `buildPayoutArgs` is a contract
violation. Silent incorrect payouts (not an error) will result.

### 4.1 Current `buildPayoutArgs` shape

```js
buildPayoutArgs(ar) → {
  players:             ar.activePlayers,
  pars:                ar.pars,
  hcps:                ar.hcps,
  scores:              ar.scores,
  activeGames:         ar.activeGames,
  gameOpts:            ar.gameOpts,
  matches:             ar.matches             || [],
  strokePlayPlayers:   ar.strokePlayPlayers   || [],  // subset; [] = all players
  skinsPlayers:        ar.skinsPlayers        || [],  // subset; [] = all players
  stablefordPlayers:   ar.stablefordPlayers   || [],  // subset; [] = all players
  ninesPlayers:        ar.ninesPlayers        || [],  // exactly 3 indices
  sixesTeams:          ar.sixesTeams,
  sixesPlayers:        ar.sixesPlayers        || [],  // deferred 5-player subset
  specialsPlayers:     ar.specialsPlayers     || [],  // subset; [] = all players
  specials:            ar.specials,
  specEntries:         ar.specEntries,
  courseHcps:          ar.courseHcps,
  minCourseHcp:        ar.minCourseHcp,               // full-field minimum; subsetMin() applied per-game
  manualPresses:       ar.manualPresses       || {},
}
```

`minCourseHcp` in `buildPayoutArgs` is always the full-field minimum
(`Math.min(...cHcps)`). Per-game NOL+subset adjustment is applied inside
`computePayouts` via `subsetMin()` — see §4.3.

### 4.2 Checklist for adding a new game

1. Add new `activeRound` fields to the App Data Model Contract §5
2. Add those fields to `buildPayoutArgs`
3. Add `fromActiveRound` / `toActiveRound` / `toSetupState` in `roundLib.js`
4. Verify `computePayouts()` receives and uses all required fields
5. Apply `subsetMin()` in the new game block if the game has a subset and
   supports `netofflow` scoring (see §4.3)

### 4.3 Universal NOL + Subset Implementation Rule

**Root rule (Handicap Contract §5):** `minCourseHcp` passed to any engine
function must always be the minimum course handicap among the players
actually participating in that calculation — never from a superset.

**Implementation pattern in `computePayouts`:** A `subsetMin()` helper
function enforces this invariant. Every game block that has a player
subset and supports `netofflow` scoring must call it before invoking any
engine function.

```js
/**
 * Returns the minimum course handicap for a subset of player indices.
 * When mode is 'netofflow' and idxs is non-empty, returns min of cHcps[i]
 * for i in idxs only.
 * When mode is not 'netofflow' or idxs is empty, returns globalMin unchanged.
 */
function subsetMin(cHcps, idxs, globalMin, mode) {
  if (mode !== 'netofflow' || !idxs?.length) return globalMin;
  return Math.min(...idxs.map(i => cHcps[i]));
}
```

**Per-game application:**

| Game | Subset indices | `subsetMin` / NOL handling |
|---|---|---|
| Stroke Play | `strokePlayPlayers` (or all) | Passed as 8th arg to `calcStrokePlay`; function derives `effMin` internally |
| Skins | `skinsPlayers` (or all) | `subsetMin(cHcps, idxs, minCHcp, scoringMode)` |
| Match/Nassau | `[p1, p2]` or `[...teamA, ...teamB]` per match | `subsetMin(cHcps, involved, minCHcp, matchMode)` — computed per match |
| Stableford | `stablefordPlayers` (or all) | `subsetMin(cHcps, stabIdxs, minCHcp, mode)` |
| Nines | `nPlayerIdx` (exactly 3) | `subsetMin(cHcps, nPlayerIdx, minCHcp, mode)` |
| Sixes | full field (currently) | `minCHcp` used directly — see §7.6 for 5-player note |
| Specials | no scoring mode | N/A |

**Invariant:** For any engine call inside `computePayouts`, the
`minCourseHcp` argument equals `Math.min(...cHcps[participants])`.
Violation produces silent incorrect net-off-low scores.

---

## 5. Tie-Handling Rules

### 5.0 General split formula

When multiple players tie for a winning position in any game where a
sole-winner payout is expected, apply the following split formula:

- Identify `winners[]` — players with the best score/total.
- Identify `losers[]` — all other players in the relevant set.
- If `losers.length === 0`: no payout (all players tied).
- If `winners.length === 1`: `payWinner(winner, players, bet, gb)`.
- If `winners.length > 1`: each loser pays `bet`; each winner collects
  `(losers.length × bet) / winners.length`.

This formula is zero-sum and applies uniformly. Fractional amounts are
correct and accepted (see §11, Invariant 11).

### 5.1 Stroke Play ties

Ties handled by the §5.0 split formula. Winners are all players who share
the minimum net score. Losers are all other players.

### 5.2 Skins ties — carryover

When two or more players tie for the low score on a hole in Skins (after
handicap adjustment), no skin is awarded on that hole.

**With carryover enabled:** The skin value accumulates to the next hole.
Accumulated skins are awarded to the sole winner of the first subsequent
hole where a single player posts the low score.

**Without carryover:** A tied hole awards no skin and no value carries
forward.

### 5.3 Match Play ties (per hole)

In individual or team match play, a tied hole results in no points exchanged
for that hole. The hole is halved. Per-segment results reflect hole win
counts; a tied segment (`lead === 0`) produces no payout.

### 5.4 Stableford ties

In `perpoint` mode, a tied point total between two players produces zero
differential for that pair — no movement between them. Other pairwise
differentials still apply.

In `nassau` mode, a tied segment top score results in no winner for that
segment — no payout for that segment.

### 5.5 Nines ties

See Nines payout spec §7.5. A tie between two Nines players on a hole
produces zero differential for that pair.

---

## 6. Zero-Sum Invariant Check

All games are zero-sum: money only moves between players, never created
or destroyed. `computePayouts` includes a development-mode assertion at
the end of the function:

```js
if (process.env.NODE_ENV !== 'production') {
  const total = Object.values(bank).reduce((a, b) => a + b, 0);
  if (Math.abs(total) > 0.01) {
    console.error('[payouts] Zero-sum violation — total net:', total, bank);
  }
}
```

**Purpose:** Detects double-counting, subset misapplication, or rounding
bugs immediately during development. The `0.01` tolerance accommodates
floating-point arithmetic. A violation in production would indicate a
contract violation in one of the game blocks.

**This check does not run in production** (`NODE_ENV !== 'production'`)
to avoid any performance impact on the pure function.

---

## 7. Per-Game Payout Logic

### 7.1 Stroke Play

Source fields: `gameOpts['Stroke Play']`, `strokePlayPlayers`

| Field | Type | Default |
|---|---|---|
| `bet` | number | 0 |
| `scoring` | scoring mode | `'net'` |

**Subset:** `strokePlayPlayers` indices; empty = all players participate.

**NOL+subset:** Subset indices are passed as the optional 8th argument to
`calcStrokePlay`. The function internally derives `effMin` from the subset
when `mode === 'netofflow'` — the payout block does not need to call
`subsetMin()` separately (Handicap Contract §5.2).

**Engine call:** `calcStrokePlay(scores, players, hcps, pars, mode, cHcps, minCHcp, spIdxs)`
Returns subset players sorted ascending by net-to-par differential. Each row
includes `pi` (original player index).

**Payout:** If `bet > 0` and there is a sole leader (`rows[0]`), apply
`payWinner(rows[0].name, spPlayers, bet, gb)` — `spPlayers` is the subset
player array, not the full `players` array. For tie at top, apply §5.0
split formula over `spPlayers`.

**Breakdown row format:**
```js
{ name, detail: '${gt} gross / ${nt} net (${nd})', net }
```

### 7.2 Skins

Source fields: `gameOpts.Skins`, `skinsPlayers`

| Field | Type | Default |
|---|---|---|
| `mode` | `'perSkin'`\|`'pot'` | `'perSkin'` |
| `bet` | number | 0 |
| `scoring` | scoring mode | `'net'` |
| `carryover` | `'yes'`\|`'no'` | `'yes'` |

**Subset:** `skinsPlayers` indices; empty = all players.

**NOL+subset:** `skinsMin = subsetMin(cHcps, idxs, minCHcp, scoringMode)`
passed to `calcSkins` as `minCourseHcp`. See §4.3.

**Engine call:** `calcSkins(scores, players, hcps, scoringMode, carryover, cHcps, skinsMin, idxs)`

For full payout formulas (`perSkin` and `pot` modes) see Skins Contract §7.
Zero-sum proofs are in Skins Contract §7.1 and §7.2.

**`minCHcp` field in `buildPayoutArgs`:** The full-field minimum is passed
from `buildPayoutArgs`. `subsetMin()` inside the Skins block derives the
correct subset minimum before the engine call. ✅ Implemented.

**Breakdown row format:**
```js
{ name, detail: '${totals[p.name]} skins', net }
// sorted descending by net; subset players only
```

### 7.3 Match / Nassau

Source fields: `matches[]`, `manualPresses`

For full scoring rules see Nassau/Match Contract. Payout logic only:

**NOL + match subset:** Each match involves 2 players (individual) or 4
players (team). When scoring mode is `'netofflow'`, the `minCourseHcp`
passed to `runMatchNassau` must be the minimum of the match participants'
course handicaps only — not the full-field minimum. This is enforced via
`subsetMin()` per match. ✅ Implemented.

```js
const involved   = [...sideA, ...sideB].filter(i => players[i]);
const matchMode  = matchDef.scoring || 'net';
const matchMin   = subsetMin(cHcps, involved, minCHcp, matchMode);
// matchMin passed to runMatchNassau, not minCHcp
```

**Engine call per match:** `runMatchNassau(scores, players, hcps, matchDef, cHcps, matchMin, manualPressesForMatch)`
Returns `{ front: [...bets], back: [...bets], overall: [...bets] }`.

**Per-segment, per-bet payout:**

For each segment (front/back/overall) and for each bet object in that
segment's array:
1. If `bet.thru === 0`: skip — no result.
2. Individual match: if `m.lead > 0` → p1 wins; if `m.lead < 0` → p2 wins;
   if `m.lead === 0` → tied, no movement.
3. Team match: winning side (determined by sign of `m.lead`) collects
   `betAmt` each; losing side pays `betAmt` each.

**Breakdown row format:**
```js
{ name, detail: '<match label> <segment> (<press label>): <status>', net }
// sorted descending by net; all involved players appear
```

### 7.4 Stableford

Source field: `gameOpts.Stableford`

| Field | Type | Default |
|---|---|---|
| `bet` | number | 0 |
| `scoring` | scoring mode | `'net'` |
| `stabBetMode` | `'nassau'`\|`'perpoint'`\|other | `'nassau'` |
| `stabTable` | `object \| null` | null (use DEFAULT_STAB) |

> **Removed field:** `nassauMode: boolean` previously appeared here. Confirmed dead code —
> read in `payouts.js` but never referenced in any conditional branch. Removed in v1.8.
> Old records containing this field are unaffected (engine ignores unknown fields).
> See Stableford Contract §14 G-1.

**Subset:** `stablefordPlayers` indices; empty = all players.

**NOL+subset:** `stabMin = subsetMin(cHcps, stabIdxs, minCHcp, mode)`
passed to `calcStablefordTotal` as `minCourseHcp`. ✅ Implemented.

**Engine call:** `calcStablefordTotal(scores, pi, pars, hcps, courseHcp, stabMin, mode, stabTable, holes)`

**`perpoint` mode:** Compute 18-hole point totals for each subset player.
Apply point-differential payout over all **unordered pairs `(i < j)`** —
each pair is evaluated exactly once. A tie between two players (zero
differential) produces no movement between them.

```js
for (let i = 0; i < ranked.length; i++)
  for (let j = i + 1; j < ranked.length; j++) {
    const diff = ranked[i].pts - ranked[j].pts;
    if (diff > 0) { gb[ranked[i].name] += diff * bet; gb[ranked[j].name] -= diff * bet; }
  }
```

**`nassau` mode:** Evaluate Front 9, Back 9, and 18-hole totals independently.
For each segment, sole winner (strict — no tie allowed) wins `bet` from each
other participant. Tied segment top = no payout for that segment.

**CRITICAL implementation rule:** The sole-winner guard in `payNassauStab` must
use the segment-specific field (`'ptsF'`, `'ptsB'`, `'pts'`) — not always `'pts'`.
Using `sorted[0].pts > sorted[1].pts` for all three segments is the previous bug
(fixed). Correct form: `sorted[0]?.[field] > (sorted[1]?.[field] ?? -Infinity)`.
Do not revert. See Stableford Contract §5.3.

**Single-winner mode** (any `stabBetMode` other than `'nassau'` or `'perpoint'`):
Highest 18-hole total wins `bet` from each other participant; sole winner guard
applies. Uses `payWinner(pts18[0].name, stabPs, bet, gb)`.

**Breakdown row format:**
```js
{ name, detail: '${pts} pts', net }
```

### 7.5 Nines

Source field: `gameOpts.Nines`

| Field | Type | Default |
|---|---|---|
| `bet` | number | 0 |
| `scoring` | scoring mode | `'net'` |
| `ninesMode` | `'perpoint'`\|`'nassau'` | `'perpoint'` |
| `blitz` | boolean | false |

**Player count requirement:** Nines requires exactly 3 players.
`ninesPlayers` must contain exactly 3 valid player indices. If fewer
than 3 valid indices are resolved, the Nines block is skipped entirely.

**NOL+subset:** `ninesMin = subsetMin(cHcps, nPlayerIdx, minCHcp, mode)`
passed to `calcNines`. ✅ Implemented.

**`perpoint` mode:** Compute 18-hole point totals for each of the 3 players.
Apply point-differential payout over all **unordered pairs `(i < j)`** —
each pair is evaluated exactly once. A tie between two players produces
zero differential for that pair — no movement between them.

**`nassau` mode:** Evaluate Front 9, Back 9, and 18-hole totals as independent
segments. For each segment, apply pairwise bilateral settlement over the 3 Nines
players using all unordered pairs `(i < j)`. For each pair: if player i's segment
point total is **strictly greater** than player j's, `gb[i] += bet; gb[j] -= bet`.
Equal totals between a pair → no movement for that pair in that segment.
All three tied in a segment → no movement for any pair (full segment wash).

```js
// payNassauSeg — called once per segment (f9, b9, ov)
for (let i = 0; i < ranked.length; i++)
  for (let j = i + 1; j < ranked.length; j++)
    if (ranked[i].pts > ranked[j].pts && bet > 0) {
      gb[ranked[i].name] += bet;
      gb[ranked[j].name] -= bet;
    }
```

> **Note (v1.9 correction):** Earlier versions of this section referenced the "§5.0
> split formula" for nassau mode. The actual implementation is the pairwise loop
> above, which is correct and zero-sum for 3 players. The split formula description
> was inaccurate. See Nines Contract §5.4 and §14 G-3.

**Breakdown row format:**
- `perpoint`: `{ name, detail: '${pts} pts', net }` sorted descending by net.
- `nassau`: header rows per segment (`{ name: 'F9', detail: seg, net: null, isHeader: true }`),
  followed by player net rows sorted descending.

### 7.6 Sixes

Source field: `gameOpts.Sixes`

| Field | Type | Default |
|---|---|---|
| `bet` | number | 0 |
| `scoring` | scoring mode | `'net'` |
| `tiebreak` | `'none'`\|`'half'`\|`'second'` | `'none'` |

For full scoring rules see Sixes Contract. Payout logic only:

**Current player scope:** Sixes is currently a strict 4-player game.
All round players participate in every segment. `minCHcp` (full-field
minimum) is passed directly to `runSixesSegment` — no subset adjustment
is needed.

**Future 5-player scope (Session 5):** When `sixesPlayers` subset is
implemented, a `subsetMin()` call must be added using the 4 participating
player indices for each segment before calling `runSixesSegment`. See
Sixes Contract §NOL note and Handicap Contract §5.2. A forward comment
is present in the Sixes block in `payouts.js` marking the required
insertion point.

**Engine calls:**
- `getSixesTeam(segIdx, sixesTeams, players)` — resolves team for each segment.
- `runSixesSegment(holes, scores, players, hcps, team, mode, tiebreak, cHcps, minCHcp, autoN, mpHoles)` — returns array of match levels.
- If `getSixesTeam` returns `null`: skip that segment.
- If `runSixesSegment` returns `null`: skip (< 4 players guard).

**Per-match-level payout:** For each match level in each segment, if
`m.winTeam` is non-null and `m.thru > 0`, pay `bet` to each player on
the winning team; deduct `bet` from each player on the losing team.

**Breakdown row format:**
```js
{ name, detail: '', net }
// sorted descending by net; all 4 players appear
```

### 7.7 Specials

Source fields: `gameOpts.Specials`, `specials`, `specEntries`, `specialsPlayers`

| Field | Type | Default |
|---|---|---|
| `bet` | number | 0 |
| `teamScoring` | boolean | false |
| `scoring` | `'gross'`\|`'net'` | `'gross'` |

**Subset:** `specialsPlayers` indices; empty = all players.

**`scoring` scope:** The `scoring` field controls only the score value used
for **auto-marking** (birdie/eagle/ace detection) in `ScoreGrid` and
`SpecialsPopup`. It has no effect on payout math — payout is always
point-based regardless of scoring mode.

**NOL exclusion:** `'netofflow'` is intentionally excluded from `scoring`
because auto-mark detection is a per-hole achievement test (`"did this
player make a birdie?"`) that compares a single score against par. Net-off-
low strokes require the group minimum handicap as a reference point, making
the detection threshold vary across players in a way that is unintuitive and
rarely meaningful for junk/specials purposes. The selector offers only
`'gross'` and `'net'`. Existing records that do not have `scoring` default to
`'gross'` (no behavior change for pre-existing rounds).

Specials payouts are unaffected by the NOL+subset rule — payout is
determined by point totals only, not by any score comparison.

**Individual mode** (`teamScoring: false`): Each earner collects `bet × pts`
from each other participating player per point earned.

**Team mode** (`teamScoring: true`): Each special earned triggers a team
payout. The earner's Sixes-segment team collects `bet` from each opponent
player.

**Breakdown row format:**
```js
{ name, detail: '${pts} pts' or segment breakdown, net }
```

---

## 8. Known Gaps and Open Items

All previously open NOL+subset gaps are now closed:

| # | Status | Description |
|---|---|---|
| ~~Skins G-3~~ | ✅ **CLOSED** | NOL+subset: Skins block now uses `subsetMin()`. `skinsMin` derived from subset indices only when `netofflow`. |
| ~~Match G-2~~ | ✅ **CLOSED** | NOL+match subset: per-match `matchMin` now derived from involved player indices only. |
| ~~Stab NOL~~ | ✅ **CLOSED** | Stableford block now uses `subsetMin()` for `stabMin`. |
| ~~Nines NOL~~ | ✅ **CLOSED** | Nines block now uses `subsetMin()` for `ninesMin`. |
| ~~Stab display NOL~~ | ✅ **CLOSED** | `StablefordTable` now accepts `stablefordPlayers` prop and computes `displayMin` via inline `subsetMin` logic (mirrors `StrokePlayTable`). Scorecard display now agrees with payout for NOL+subset rounds. |
| ~~Nines nassau desc~~ | ✅ **CLOSED v1.9** | §7.5 nassau description corrected from "§5.0 split formula" to pairwise bilateral loop. Implementation was always correct; only the contract description was wrong. |
| Sixes (5-player) | 🔵 **DEFERRED** | When `sixesPlayers` subset is implemented, `subsetMin()` must be applied per segment. Forward comment in code marks insertion point. |

---

## 9. Incomplete Round Policy

`incompletePolicy` field in `buildPayoutArgs` controls how incomplete
segments pay out. Current default: `'payComplete'` — pay based on
results through the last scored hole.

Full incomplete round policy spec is deferred to the Round Lifecycle
Contract (not yet written).

---

## 10. Per-Game Invariants

1. Every game block's local `gb` sums to zero before merging into `bank`.
2. Non-participating players remain at `0` in `gb` for the duration of any
   game block they are not part of.
3. `payWinner` is never called when two or more players share the winning
   score — §5.0 split formula is used instead.
4. Skins `totals` is iterated by subset index, never by full `totals` key
   iteration (which would include non-subset players at 0).
5. Match payout is derived from `m.lead` sign — positive = sideA wins,
   negative = sideB wins, zero = no movement.
6. Stableford and Nines `perpoint` pairwise loops use `i < j` — each
   unordered pair is evaluated exactly once.
7. Sixes pays each match level independently — press outcomes are not
   merged with base match outcomes.

---

## 11. Global Invariants

These hold across the entire `computePayouts` function:

1. `bank` is initialized to zero for all players before any game block runs.
2. Every game block reads from `bank` only via its local `gb`; it never
   reads `bank` directly.
3. `gb` is merged into `bank` exactly once per game block, at the end.
4. No game block modifies `gb` after merging into `bank`.
5. `breakdown` contains exactly one entry per active game that was processed.
6. Engine functions (`calcSkins`, `runMatchNassau`, etc.) are the sole
   source of scoring truth — no arithmetic that reproduces engine logic
   may appear in `computePayouts`.
7. `subsetMin()` is called before every engine function invocation that
   involves a player subset and supports `netofflow` scoring.
8. `minCourseHcp` passed to any engine function equals
   `Math.min(...cHcps[participants])` — the minimum over participating
   players only. Any deviation is a contract violation.
9. `bank` sums to zero across all players at function exit. Verified by
   the zero-sum check in development (§6).
10. `breakdown` rows for non-participating players are never included in
    any game's breakdown row array.
11. Fractional payout amounts are correct and accepted. No rounding is
    applied inside `computePayouts`.
