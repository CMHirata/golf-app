# The Card — Master Build Plan

_Last updated: April 2026_
_Maintained in this chat as the authoritative sequence and history of all build sessions._
_The APP_STATE_SUMMARY.md in the project knowledge base is the authoritative record of_
_what is implemented. This file is the authoritative record of what was planned, why,_
_and in what order — including items that shifted, were skipped, reinstated, or renumbered._

---

## Critical Rules for All Future Sessions

1. **Contracts before code.** Any item marked "contract first" below must have a contract
   amendment approved before a single line of implementation code is written.

2. **Session naming is owner-assigned.** Claude must never auto-assign new session
   designations (e.g. creating "11-B" when it doesn't exist in this plan). Sub-tasks within
   a session are labeled as phases (Phase 1, Phase 2). New session rows in APP_STATE_SUMMARY.md
   are only added when the owner explicitly provides the designation.

3. **APP_STATE_SUMMARY.md is not a bug tracker.** Open items live there; closed items are
   struck through. The external spreadsheet is the master bug/feature tracker.

4. **Do not remove open items from ASS** without confirmed on-device testing by owner.

5. **Derived values are never stored.** All derived state is computed from the activeRound blob.

6. **`restoreDotDefs()` is critical.** Must always be called before using dots from any
   serialized state. Was `restoreAutoWhen()` prior to Session 11-A rename.

7. **`betType` is a static config concept only.** It lives in the `GAME_CONFIGS` constant
   and must never be stored in `gameOpts`, `activeRound`, or any persisted state.
   Decision made in 11-G-1. Do not revisit without owner approval.

8. **Nassau terminology is retired from all user-facing surfaces.** The behavior is exposed
   as Front/Back/Overall segment bet fields. Decision made in 11-G-1. Do not reintroduce
   "Nassau" as a UI term without explicit owner approval.

---

## Numbering History & Collision Notes

The session numbering in this project has a complex history. Key facts:

- **Sessions 1–9** were numbered sequentially as work progressed, not always matching
  the original sprint plan (which used Sprint 1/2/3 with lettered sub-sessions).
- **Sessions 11-B and 11-C** were auto-created by Claude mid-session during the Dots
  rework, colliding with planned future sessions. This was corrected: all three phases
  of the Dots rework were collapsed into **11-A** in the ASS.
- **11-B** in this plan = Shared GameTable shell (deferred to post-Sprint 12).
- **11-C** in this plan = Match/Nassau team hole display (completed).
- **11-D** in this plan = Fixed-width player name fields + PlayerDropdown component system (completed but scope exceeded plan; not audited until 11-E — see Completed Sessions for full detail).
- **11-E** in this plan = Disabled Btn fix + NOL label consistency + 11-D audit (completed; both sessions pending combined on-device test).
- **11-G** was originally planned as a single session (NOL subset display). It was
  expanded in planning session **11-G** (formerly 11-G-1) into five sessions after
  architectural debt was identified. The downstream sessions were initially named
  11-G-2/3/4 then renumbered to **11-H, 11-I, 11-J, 11-K** for cleanliness.
  **11-G is a planning-only session** (no code). 11-H is the UX design spec session.
  11-I is the betting model refactor. 11-J is per-match labeling. 11-K is NOL dots.
- **13-C** was discussed but deferred back (early-end / partial round) — still planned.

---

## Key Architectural Decisions Made in Planning Sessions

These are decisions made during planning that should not be revisited without good reason:

1. **Contracts are authoritative over code.** When contract language and implementation
   conflict, contracts win. Code is updated to match.

2. **Write contracts before fixing engines.** The contract defines the spec the engine
   fix must conform to.

3. **Derived values are never stored.** All derived state computed from activeRound blob.

4. **Session naming is owner-assigned.** Claude never invents new session designations.

5. **Generic swipe component** extracted when adding swipe to Players/Courses (12-F),
   not before — avoid premature abstraction.

6. **Dots/Specials shim removal** only after owner confirms all saved rounds have been
   opened and re-exported. Do not rush this.

7. **Per-player tee selection (13-B)** is its own full session — high risk, do not bundle.

8. **Late player join (14-D)** is complex enough to require its own contract and should
   not be attempted until owner explicitly schedules it.

9. **The `resolveDisplayNames` approach** was tried in 11-D then superseded by a post-session
   patch: the final convention is to always show first name (larger/darker) + last name
   (smaller/lighter) unconditionally, without collision detection. Simpler, more readable,
   no edge cases. `resolveDisplayNames` was removed from most consumers after this decision.

10. **`PlayerDropdown.jsx`** is a new shared component created in 11-D housing `PlayerDropdown`,
    `StyledSel`, and `ReadOnlyBubble`. All player picker UI in New Round setup should use
    these components. Do not create parallel picker implementations.

11. **Scope creep in 11-D is documented, not penalized.** The PlayerDropdown work was
    valuable and the results are good. The lesson is: when a session's scope expands
    significantly mid-session, the ASS must be updated to reflect what actually happened —
    not what was planned.

12. **Nassau terminology retired (11-G).** The betting behavior formerly called "Nassau"
    is exposed as Front/Back/Overall (segment) bet fields applied selectively per game.
    `betType` is a static UI dispatch concept in `GAME_CONFIGS` — never stored in round state.
    Shared bet config components (`<SegmentBetConfig>`, `<RateBetConfig>`, `<PotBetConfig>`)
    are written once and reused across all games that share the same betting model.

13. **Wolf is the next planned game format.** `GAME_CONFIGS` design in 11-I must preserve
    a clean extension point for Wolf's rotating-player and doubling mechanics. Owner has
    confirmed Wolf will not be added until rest of app is considered solid.

14. **NOL dot selector design (11-G).** When NOL is the active dot mode and a subset/match
    game excludes the round's low-handicap player, a per-game selector pill row appears.
    Selecting a game shows dots only for that game's participants using subset min; non-
    participants show plain blank. Match instances use persistent labels from 11-J. Switching
    to Net dot mode resets the selection to "Field".
    participants show plain blank. Match instances use ephemeral A/B/C labels derived from
    array index (selector only); persistent labels are added in 11-G-3. Switching to Net
    dot mode resets the selection to "Field".

---

## Completed Sessions

| Session | Scope | Notes |
|---|---|---|
| 1-A | Round lifecycle bugs + safety guards: cancel/delete in-progress round; New Round full reset; score-overwrite warning; history-load conflict check; "Round in Progress" banner suppressed on new round; date defaults to today | All confirmed |
| 1-B | History data integrity: static snapshot audit; loading old rounds restores game data; edit historical round settings load correctly | All confirmed |
| 1-C | Scorecard input bugs: score cell shift fix (`display:block`); Specials popup iOS copy/paste callout fix (`userSelect:none`) | All confirmed. E-1 (Specials totals) deferred to 11-A |
| 2 | History UX: swipe-left strip with real-time tracking; full-swipe delete; RoundSummaryModal; landscape scorecard 18-hole; per-match payouts; Stroke Index gender-aware labeling | All confirmed |
| 3 | ResultsPage redesign; RoundSummaryModal polish; per-match payout breakdown; named nine labels on scorecard; HomePage recent round tap opens modal; player chips in header | All confirmed |
| 4 | Back-to-setup fix (B-3); share sheet PNG via iOS native share; share from modal, ResultsPage, History swipe | All confirmed |
| 5 | Visual polish: logo, mint bg, SVG icons, swipe strip redesign, headers, player chips moved out of Results header | Confirmed (pending on-device) |
| 6 | Navigation overhaul: always-visible nav; logo super-tab; pinned action bars; scroll-to-top; divider removed between scorecard and chips | Confirmed (pending on-device) |
| 7 | Shared layout constants (`layout.js`); NewRoundPage extractions: `PlayerPickerPopup.jsx`, `MatchCard.jsx`, `GameConfig.jsx`; NewRoundPage reduced from 1,360→592 lines | Confirmed on device |
| 8 | CoursesPage full extraction: 5 components + helpers to courseLib.js | Confirmed on device |
| 9 | PWA: manifest.json, sw.js, PNG logos, home screen install | Confirmed on device |
| 10-A | RoundSummaryModal totals row; ESC (Adjusted Gross Score) in TotalsCard; `escTotal()` added to handicap.js; Handicap_Contract.md → v1.5 | Confirmed |
| 10-B | Visual regressions: logo heights + header consistency; landscape full-width fix (App.jsx maxWidth); MatchNassauTable isLandscape; Courses triangles removed; share image complete rework | All confirmed on device |
| 11-A | Dots (Specials) full rework: contract v2.0→v2.1; full Specials→Dots rename at all layers; DotsTable, DotsPopup, DotBadge; discrete scoring specials; mutual exclusivity; popup redesign; pivot summary tile; retroactive autoMark; App_Data_Model_Contract v2.5 | Complete — pending bulk round migration before shim removal |
| 11-C | D-1: Match/Nassau team hole winner display: slash-initials (C/D), colorblind-safe blue/red chips matching Sixes; color-coded header; Front 9 closure bug fixed (buildLeadState scoped to segment holes); Nassau_Match_Contract v2.4 | Confirmed on device |
| 11-D | Scope exceeded plan significantly. Planned: resolveDisplayNames + PlayerChips migration. Actually built: (1) `resolveDisplayNames` added to scorecardUtils.js; (2) `PlayerChips` added to GameSection.jsx; (3) TotalsCard, StrokePlayTable, PlayerSubsetChips migrated to first-name display; (4) **`PlayerDropdown.jsx` — entirely new file** with `PlayerDropdown`, `StyledSel`, `ReadOnlyBubble` components; (5) GameConfig.jsx Sixes team picker fully redesigned using PlayerDropdown; (6) MatchCard.jsx individual and team pickers rebuilt using PlayerDropdown/StyledSel; (7) All scoring/option selects across setup replaced with StyledSel. Post-session patch: name display convention changed from collision-aware first-name-only to unconditional first+last. | Confirmed on device |
| 11-E | Btn disabled style fix; NOL label audit (confirmed clean); name display convention unified; Sixes duplicate-team prevention | Confirmed on device |
| 11-F | Zoom score entry modal: ZoomModal.jsx (new), hidden-input keyboard pattern, 3-hole window, stacked player names, active-cell-only border, magnifying glass button, landscape zoom via zoomTriggerRef, DotsPopup position + focus coordination | Confirmed on device |
| 11-G | Planning session: NOL dot display design decision; betting model architecture (Nassau retired → segment betting); betType as static config; GAME_CONFIGS pattern; Wolf extension point; downstream sessions renamed 11-H/I/J/K | Complete — no code produced |
| 11-H | Design-only session: full NewRoundPage setup UI design spec. Game-by-game field inventory; all Phase 2 design decisions owner-confirmed; unified betting row pattern (`[Mode▼][field(s)]`); shared components identified (`<BetRow>`, `<SimpleBetRow>`, `<ScoringPills>`, `<PlayerSubsetDropdown>`); Players card redesign; pinned Start button; `GAME_CONFIGS` shape specified; section header decision deferred to on-device review. Output: `NewRoundPage_Design_Spec.md` | Complete — no code produced |

---

## Items Completed Out-of-Order or Under Different Session Names

| Original Plan Item | Completed In | Notes |
|---|---|---|
| B-3: Match display redesign | Session 3 | Per-match payout breakdown |
| B-5: Results page redesign | Session 3 | |
| B-7: Native share sheet | Session 4 | PNG via iOS share API |
| B-6: Graphic scorecard for share | Session 10-B | Complete rework; original was inadequate |
| C-3: Scroll-to-top on scorecard navigate | Session 6 | |
| C-6: Remove line between scorecard and chips | Session 6 | |
| C-10: Named nine labels on scorecard | Session 3 | |
| F-1: Bottom navigation on all pages | Session 6 | |
| F-3: Remove emojis / SVG icons | Session 5 | |
| J-1: App name + logo branding | Session 5 | |
| I-1: PWA / service worker | Session 9 | |
| A-11: Remove expand triangles | Sessions 6+10-B | Session 6 did most; Courses triangles fixed in 10-B |
| B-1: Static snapshot on save | Session 1-B | |
| B-2: Edit historical round settings | Session 1-B | |
| B-4: Loading old rounds restores game data | Session 1-B | |
| E-1: Specials totals rework | Session 11-A | Became full Dots rework |
| D-1: Match team hole winner display | Session 11-C | |
| C-1: Score field shift | Session 1-C | |
| C-2: Long-press iOS accidental input | Session 1-C | |
| C-4/C-5: Fixed-width chips + first-name display | Session 11-D | Exceeded scope — also produced PlayerDropdown.jsx, StyledSel, ReadOnlyBubble; full Sixes and MatchCard picker redesign |
| D-5: Sixes dropdown widths | Session 11-D | Absorbed into full Sixes picker redesign |
| F-2: UI G-5 disabled Btn | Session 11-E | Also included 11-D audit |
| F-4: NOL label consistency | Session 11-E | Audit confirmed already consistent — no code changes needed |
| D-4: Stableford F/B/O bet fields | 11-I | Absorbed into betting model refactor — do not implement in 12-A |
| D-8: Match numbering on cards | 11-J | Absorbed into per-match instance labeling session |
| C-11: NOL subset display per-game | 11-K | Design decision made in 11-G; implementation in 11-K |

---

## Items Skipped / Not Yet Done From Original Sprint Plan

| Item | Original Sprint | Current Status |
|---|---|---|
| A-5: Save game settings from prior round as defaults | Sprint 2-D | Open — Session 12-C |
| A-7: Per-player tee selection | Sprint 4-B | Open — Session 13-B (contract first) |
| A-8: Auto-export on save with correct naming | Sprint 4-A | Open — Session 13-A |
| A-9: Handicap multiplier | Sprint 5-E | Open — Session 14-C (contract first) |
| A-12: Remove "Default Tee" buttons from Setup | Sprint 2-D | Open — Session 12-C |
| B-8: Edit any history round (not just most recent) | Sprint 5-D | Open — Session 14-A |
| C-7: Birdie/bogey indicators on scorecard | Sprint 5-C | Open — Session 14-B (contract first) |
| C-8: Lock/pin scorecard toggle | Sprint 5-E | Open — Session 14-C |
| C-9: Zoomed score entry | Sprint 5-E | Completed in 11-F |
| D-2: "pts" label on Nines total chips | Sprint 3-B | Open — Session 12-B |
| D-3: Match status columns decision | Sprint 3-C | Open — Session 12-D |
| D-6: NinesTable renders only 3-player subset | Sprint 3-B | Open — Session 12-B |
| D-7: NinesTable breakdown rows filter | Sprint 3-B | Open — Session 12-B |
| F-5: Remove legacy shims | Sprint 5-A | Open — Session 14-A |
| F-6: Hint text review | Sprint 5-A | Open — Session 14-A |
| G-1: Starred players | Sprint 5-B | Open — Session 12-E |
| G-2: Leaderboard exclude/include | Sprint 5-B | Open — Session 12-E |
| H-1: Sahalee hole numbering + yardage | Sprint 5-A | Open — Session 14-A |
| I-2: iCloud-friendly export naming | Sprint 4-A | Open — Session 13-A |
| I-3: API key / Face ID security | Sprint 5-E | Open — Session 14-C |
| I-5: Delete hooks.js (dead code) | Sprint 5-A | Open — Session 14-A |

---

## New Items Added Post-Original-Plan (from owner spreadsheet + discoveries)

| Item | Priority | Session |
|---|---|---|
| Results F9/B9/Overall zeros bug | High | Completed in 10-A |
| Summary popup missing round totals | High | Completed in 10-A |
| Partial round / early end (player leaves) | High | Session 13-C (contract first) |
| Specials rework → became full Dots rework | High | Completed in 11-A |
| Setup continuity between games (shared bet fields) | Medium | Absorbed into 11-I |
| Course selection as popup (like player picker) | Medium | Session 12-C |
| Only show nine-selection for 3-nine courses | Medium | Session 12-C |
| Players/Courses swipe-left actions | Medium | Session 12-F |
| Late player join / missed early holes | Low | Session 14-D (contract first — complex) |
| PlayerDropdown / custom picker component | Done | Completed in 11-D |
| Shared GameTable shell documentation | Deferred | Session 11-B (deferred to post-Sprint 12) |

---

## Open Session Plan

Sessions are listed in recommended execution order. Items marked "contract first"
require a contract amendment to be written and approved before any code is produced.

---

### Sprint 11 — Remaining Sessions

**11-B: Shared GameTable shell** *(DEFERRED to post-Sprint 12)*
- Move GameTable/PlayerChips documentation into UI_Component_Contract.md
- Audit SkinsTable, SixesTable, MatchNassauTable, StrokePlayTable for further shared chrome
- Low urgency — patterns already working; this is a documentation + optional refactor pass
- Files: `GameSection.jsx`, `UI_Component_Contract.md`

**11-H: NewRoundPage UX/UI design spec** *(design-only session — no code produced)*
- Deliberate design pass across all game setup UIs before any betting model code is written
- Full game-by-game inventory of current setup fields, layout, and options
- Identify and name all repeating UI patterns that become shared components
- Decisions to make per game: field order, grouping, labels, visual hierarchy
- Cross-game decisions: how dual-mode games (rate + segments) present both options;
  G/N/NOL selector consistency; player subset picker patterns; carryover/press/toggle labeling
- Output: `NewRoundPage_Design_Spec.md` — required reading for 11-I
- Priority: High (blocks 11-I)
- Risk: Low — design only; no code risk

**11-I: Betting model refactor** *(contract first — large foundational session)*
- Requires `NewRoundPage_Design_Spec.md` from 11-H as input before contracts are drafted
- Retire Nassau terminology from all user-facing surfaces
- Introduce `GAME_CONFIGS` static constant as sole source of truth for each game's
  allowed betting model(s): segments (Front/Back/Overall), rate ($ per unit), pot (buy-in),
  perMatch (Sixes scalar), none
- Build shared bet config components per 11-H design spec:
  `<SegmentBetConfig>`, `<RateBetConfig>`, `<PotBetConfig>`
- Games and their betting models:
  - Match: segments (with press dropdowns)
  - Stroke Play: segments (no press)
  - Nines: rate (primary) + segments (optional)
  - Stableford: rate (primary) + segments (optional)
  - Skins: rate (perSkin) OR pot (buy-in) — user selects one
  - Sixes: perMatch scalar
  - Dots: rate only
  - Wolf (future): rate + extension point for doubling mechanic — do not close this door
- Standardize `gameOpts` field names across all games (betFront, betBack, betOverall,
  betUnit, buyIn, betPerMatch)
- Migration shim in `roundLib` for saved rounds using old `nassau: true` schema
- Contract: amend `Nassau_Match_Contract.md`, `Stableford_Contract.md`, `Nines_Contract.md`,
  `Skins_Contract.md`, `Stroke_Play_Contract.md`, `App_Data_Model_Contract.md`
- Absorbs: 12-A (Stableford F/B/O bets)
- Priority: High (blocks 11-J and 11-K)
- Risk: Large scope — contract drafts must be reviewed before any code

**11-J: Per-match instance labeling** *(contract first)*
- Add persistent `label` field (e.g. 'A', 'B', 'C') to each match object in `matches` array
- Assign labels in `NewRoundPage` match setup UI
- Propagate to: `MatchNassauTable`, `PressModal`, `RoundSummaryModal`
- Contract: amend `Nassau_Match_Contract.md` + `App_Data_Model_Contract.md`
- Absorbs: D-8 (match numbering on cards)
- Priority: High (blocks 11-K)
- Risk: Medium — touches setup UI and multiple display components

**11-K: NOL dot selector** *(contract first)*
- Contract: amend `Handicap_Contract.md` §5 → v1.6
- Design decisions confirmed in 11-G:
  - Option A: per-game selector pill row (labeled "NOL dots: Field | Skins | Match A...")
  - Appears only when ≥1 active NOL game excludes the round's low-HCP player
  - Selecting a game shows dots only for that game's participants using subset min
  - Plain blank for non-participants
  - ZoomModal inherits selection
  - Switching to Net dot mode resets to "Field"
  - Match instances use persistent labels from 11-J (not ephemeral index labels)
- Files: `Handicap_Contract.md`, `ScoreGrid.jsx`, `ScorecardPage.jsx`, `ZoomModal.jsx`,
  `scorecardUtils.js` (helper if needed)
- Priority: High
- Risk: Low-medium — display only, no engine changes

---

### Sprint 12 — Medium Priority Features

**12-A: Stableford front/back/overall bet fields** *(ABSORBED INTO 11-I — retire this session)*

**12-B: Nines table fixes**
- D-6: NinesTable renders only 3-player subset (contracted, not implemented)
- D-7: NinesTable breakdown rows filter to subset
- D-2: "pts" label on Nines total chips
- Files: `NinesTable.jsx`, `ScoreGrid.jsx`
- Priority: Medium

**12-C: Setup UX polish**
- A-5: Save game settings from prior round as defaults for next round
- Course selection as popup (like player picker)
- Only show nine-selection when course has 3 nines
- A-12: Remove "Default Tee" buttons from course selection
- Files: `NewRoundPage.jsx`, `GameConfig.jsx`, `PlayerPickerPopup.jsx`
- Priority: Medium

**12-D: Match status columns**
- D-3: Match status columns — decide and implement
- Note: D-8 (match numbering) absorbed into 11-J; do not re-implement here
- Files: `MatchNassauTable.jsx`
- Priority: Medium

**12-E: Players and leaderboard enhancements**
- G-1: Starred/favorite players float to top
- G-2: Include/exclude from leaderboard — filter one-off players off money list
- Files: `PlayersPage.jsx`, `HomePage.jsx`
- Priority: Medium

**12-F: Players/Courses swipe-left actions**
- Swipe-left Edit/Delete strip matching HistoryPage pattern
- Extract generic swipe component at the same time (avoid third copy of HistoryPage logic)
- Import PALE_YELLOW from ui.jsx for Edit button background (already specified in ASS gotcha)
- Files: `PlayersPage.jsx`, `CoursesPage.jsx` + new generic swipe component
- Priority: Medium

---

### Sprint 13 — Infrastructure

**13-A: Auto-export + iCloud naming**
- A-8: Auto-export on save with `The Card YYYY-MM-DD HH-MM.json` naming (RLC §5.2 already specifies)
- I-2: Confirm save-to-Files flow on iOS Safari
- Files: `App.jsx`
- Priority: Medium

**13-B: Per-player tee selection** *(contract first — large, high risk)*
- A-7: Per-player tee dropdown with smart defaults; retain per-course preference
- Contract: amend Round_Lifecycle_Contract.md §2.3, §2.4, §7 + Handicap_Contract.md §3
- Files: `NewRoundPage.jsx`, `handicap.js`, `roundLib.js`, `App.jsx`
- Priority: Medium
- Risk: High — own full session, do not bundle with anything else

**13-C: Partial round / early end** *(contract first)*
- Player leaves early: lastCompletedHole + earlyEndOpts
- Game starts on hole X: configurable starting hole per game
- Contract: amend Round_Lifecycle_Contract.md §4.5–4.7 (already written but not implemented)
- Known open gaps: RLC G-6, Stroke_Play_Contract G-4/G-5/G-6
- Files: `App.jsx`, `ScorecardPage.jsx`, `payouts.js`, `games.js`, `roundLib.js`
- Priority: High (real-life need)
- Risk: High — touches engine and lifecycle; own full session

---

### Sprint 14 — Low Priority Polish

**14-A: Cleanup**
- F-5: Remove legacy shims (all data is test data — confirm before removing)
- F-6: Hint text review and cleanup
- I-5: Delete hooks.js (confirmed dead code)
- H-1: Sahalee hole numbering 1–9 per nine + yardage total fix
- B-8: Edit any history round (not just most recent)
- History date range persistence across sessions
- Files: misc

**14-B: Advanced scorecard options**
- C-7: Birdie/bogey indicators (contract first — amend UI_Component_Contract.md)
- C-8: Lock/pin scorecard toggle
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`

**14-C: Security and misc**
- I-3: API key / Face ID security gate for Anthropic API
- A-9: Handicap multiplier (contract first — amend Handicap_Contract.md)
- In-app splash screen on cold load (~1.5s, logo on green)
- Replace PNG logos with SVG when designer provides file
- Files: `CoursesPage.jsx`, `storage.js`, `App.jsx`

**14-D: Late player join / missed early holes** *(contract first — complex)*
- Player joins after round starts; "X" scores for missed holes
- Affects: handicap calculations, game eligibility, Skins carryover, Nassau match validity,
  Nines subset requirements
- Contract: amend Round_Lifecycle_Contract.md (new section)
- Priority: Low — earmarked but not scheduled until owner confirms need
- Risk: High — do not underestimate complexity

---

### Future — New Game Formats

Each format requires its own contract session before any code.
Recommended order:

1. **Wolf** — rotating Wolf player; highest priority next format. `GAME_CONFIGS` in 11-I
   must preserve extension point for Wolf's doubling mechanic. Owner has confirmed Wolf
   will not be added until rest of app is considered solid.
2. **High/Low** — low ball + high ball per hole
3. **Banker (Quota)**, **Scotch/Greensomes**, **Chapman/Pinehurst**
4. **Bingo Bango Bongo**, **Vegas**, **Round Robin**, **Snake**, **Rabbit/Flags/String**
5. **Uneven team matches (1v2)**

---

## Items Requiring Contract Work Before Code

| Item | Contract Action | Session |
|---|---|---|
| 11-H: NewRoundPage UX/UI design spec | No contracts — design only; output is NewRoundPage_Design_Spec.md | 11-H |
| 11-I: Betting model refactor | Amend Nassau_Match_Contract.md, Stableford_Contract.md, Nines_Contract.md, Skins_Contract.md, Stroke_Play_Contract.md, App_Data_Model_Contract.md | 11-I |
| 11-J: Per-match instance labeling | Amend Nassau_Match_Contract.md + App_Data_Model_Contract.md | 11-J |
| 11-K: NOL dot selector | Amend Handicap_Contract.md §5 → v1.6 | 11-K |
| 13-B: Per-player tee | Amend Round_Lifecycle_Contract.md §2.3/§2.4/§7 + Handicap_Contract.md §3 | 13-B |
| 13-C: Partial round/early end | RLC §4.5–4.7 already written; engine gaps G-4/G-5/G-6 in Stroke_Play_Contract | 13-C |
| 14-B: Birdie/bogey indicators | Amend UI_Component_Contract.md | 14-B |
| 14-C: Handicap multiplier | Amend Handicap_Contract.md | 14-C |
| 14-D: Late player join | New section in Round_Lifecycle_Contract.md | 14-D |
| Future: Wolf | New Wolf_Contract.md | Future |
| Future: Other formats | New contract per format | Future |

---

## Deferred / Deprioritized Items (not abandoned, just not sequenced)

| Item | Reason deferred |
|---|---|
| 11-B: Shared GameTable shell | Pattern already working; documentation value only; post-Sprint 12 |
| Dark mode | Token structure ready in ui.jsx; low demand |
| Undo delete toast | Low impact |
| Match scorecard rows collapse by default | Low priority |
| CoursesPage GHIN/USGA API import | External dependency; low priority |
| ResultsPage share as graphic email | Done as share sheet PNG; email redesign deprioritized |
| SixesTable landscape support | Sixes press-chip rendering makes this non-trivial; deferred |
| Scorecard options menu (gear icon) | Deferred pending dot display mode design decision |
| Press modal UX: show live match status | Low priority UX enhancement |
