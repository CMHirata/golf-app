// ─── services/roundUtils.js ───────────────────────────────────────────────────
// Shared utilities: engine arg assembly, per-match payouts, share image.
//
// buildShareImage renders the round summary as a PNG via SVG foreignObject:
//   • Full HTML with inline styles rendered into an SVG foreignObject
//   • Logo loaded via fetch→FileReader as a base64 data URI (no canvas taint)
//   • SVG encoded as base64 data URI (not blob URL) to avoid iOS Safari taint
//   • Height measured via visibility:hidden fixed div before rendering
//   • All dynamic strings XML-escaped to prevent SVG parse failures

import { runMatchNassau, matchLabel, calcSkins, ninesPts } from '../engine/games.js';
import { scoreForMode, stabPts, escTotal } from '../engine/handicap.js';

// ─── Shared constants ─────────────────────────────────────────────────────────
const G_COLOR = '#1a472a';
const GRN_PAY = '#27ae60';
const RED_PAY = '#c0392b';
const FRONT   = [0,1,2,3,4,5,6,7,8];
const BACK    = [9,10,11,12,13,14,15,16,17];

const TK = {
  S: { hdr:'#fef3e8', hdrC:'#7b3f00', tot:'#fce4c4', totC:'#7b3f00', rA:'#fffdf8', rB:'#fef9f0', bdr:'#fce4c4', title:'Skins' },
  N: { hdr:'#e8f0fc', hdrC:'#1a3a5c', tot:'#c8d8f8', totC:'#1a3a5c', rA:'#f0f5ff', rB:'#e8f0fc', bdr:'#c8d8f8', title:'Nines' },
  K: { hdr:'#f2eafa', hdrC:'#4a1580', tot:'#dac8f5', totC:'#4a1580', rA:'#f9f5ff', rB:'#f2eafa', bdr:'#dac8f5', title:'Stableford' },
  P: { hdr:'#edf7ed', hdrC:'#1a5c1a', tot:'#c8e8c8', totC:'#1a5c1a', rA:'#f5fbf5', rB:'#edf7ed', bdr:'#c8e8c8', title:'Stroke Play' },
  M: { hdr:'#e8f4e8', hdrC:'#1f4d1f', tot:'#c8e0c8', totC:'#1f4d1f', rA:'#ffffff', rB:'#f5fbf5', bdr:'#c8e0c8', title:'Match / Nassau' },
};

// ── Logo loader ────────────────────────────────────────────────────────────────
async function getLogoDataUri() {
  try {
    const resp = await fetch('/logo_lockup.png');
    if (!resp.ok) return null;
    const blob = await resp.blob();
    return new Promise(resolve => {
      const fr = new FileReader();
      fr.onload  = () => resolve(fr.result);
      fr.onerror = () => resolve(null);
      fr.readAsDataURL(blob);
    });
  } catch(e) { return null; }
}

// ── buildPayoutArgs ──────────────────────────────────────────────────────────
export function buildPayoutArgs(ar) {
  return {
    players:           ar.activePlayers,
    pars:              ar.pars,
    hcps:              ar.hcps,
    scores:            ar.scores,
    activeGames:       ar.activeGames,
    gameOpts:          ar.gameOpts,
    matches:             ar.matches             || [],
    strokePlayPlayers:   ar.strokePlayPlayers   || [],
    skinsPlayers:        ar.skinsPlayers        || [],
    stablefordPlayers:   ar.stablefordPlayers   || [],
    ninesPlayers:        ar.ninesPlayers        || [],
    sixesTeams:          ar.sixesTeams,
    sixesPlayers:        ar.sixesPlayers        || [],
    dotsPlayers:         ar.dotsPlayers         || [],
    dots:                ar.dots,
    dotEntries:          ar.dotEntries,
    courseHcps:          ar.courseHcps,
    minCourseHcp:        ar.minCourseHcp,
    manualPresses:       ar.manualPresses       || {},
  };
}

// ── computePerMatchPayouts ───────────────────────────────────────────────────
export function computePerMatchPayouts(matches, players, scores, hcps, courseHcps, minCourseHcp, manualPresses) {
  if (!matches?.length) return [];
  const subsetMin = (cHcps, idxs, globalMin, mode) => {
    if (mode !== 'netofflow' || !idxs?.length) return globalMin;
    return Math.min(...idxs.map(i => cHcps[i]));
  };
  return matches.map((matchDef, mi) => {
    const matchKey = matchDef.id || `match_${mi}`;
    const isTeam   = matchDef.format === 'team';
    const sideA    = isTeam ? (matchDef.teamA || []) : [matchDef.p1];
    const sideB    = isTeam ? (matchDef.teamB || []) : [matchDef.p2];
    const involved = [...sideA, ...sideB].filter(i => players[i]);
    const mode     = matchDef.scoring || 'net';
    const matchMin = subsetMin(courseHcps, involved, minCourseHcp, mode);
    const mp = {
      front:   (manualPresses||{})[`Match:${matchKey}:Front`]   || [],
      back:    (manualPresses||{})[`Match:${matchKey}:Back`]    || [],
      overall: (manualPresses||{})[`Match:${matchKey}:Overall`] || [],
    };
    const { front, back, overall } = runMatchNassau(scores, players, hcps, matchDef, courseHcps, matchMin, mp);
    const betF = matchDef.betFront   || 0;
    const betB = matchDef.betBack    || 0;
    const betO = matchDef.betOverall || 0;
    const lbl  = matchLabel(matchDef, players);
    const net  = {};
    players.forEach(p => (net[p.name] = 0));
    [{ bets: front, betAmt: betF }, { bets: back, betAmt: betB }, { bets: overall, betAmt: betO }].forEach(({ bets, betAmt }) => {
      if (betAmt <= 0) return;
      bets.forEach(m => {
        if (m.thru <= 0 || m.lead === 0) return;
        if (!isTeam) {
          const wi = m.lead > 0 ? matchDef.p1 : matchDef.p2;
          const li = m.lead > 0 ? matchDef.p2 : matchDef.p1;
          if (players[wi] && players[li]) { net[players[wi].name] += betAmt; net[players[li].name] -= betAmt; }
        } else {
          const winSide = m.lead > 0 ? sideA : sideB;
          const losSide = m.lead > 0 ? sideB : sideA;
          winSide.forEach(wi => { if (players[wi]) net[players[wi].name] += betAmt; });
          losSide.forEach(li => { if (players[li]) net[players[li].name] -= betAmt; });
        }
      });
    });
    const rows = involved
      .map(pi => ({ name: players[pi]?.name, net: net[players[pi]?.name] || 0 }))
      .filter(r => r.name)
      .sort((a, b) => b.net - a.net);
    return { label: lbl, rows };
  });
}

// ── cleanGameName ────────────────────────────────────────────────────────────
export function cleanGameName(g) {
  return g.replace(/^[\p{Emoji}\s]+/u, '').trim();
}

// ─── XML / HTML escaping ──────────────────────────────────────────────────────
function fmtMoney(v) {
  if (v > 0) return `+$${Math.abs(v).toFixed(2)}`;
  if (v < 0) return `-$${Math.abs(v).toFixed(2)}`;
  return '$0';
}

function fmtDate(ds) {
  if (!ds) return '';
  const d = new Date(ds + 'T12:00:00');
  return d.toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric', year:'numeric' });
}

function xe(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Fixed render width for the foreignObject content
const FO_WIDTH = 740;

function buildShareHtml(r, ar, bank, breakdown, matchPayouts, logoDataUri) {
  const {
    activePlayers: players, pars, hcps, scores, courseHcps, minCourseHcp,
    activeGames, gameOpts,
    ninesPlayers, stablefordPlayers, skinsPlayers, strokePlayPlayers,
    manualPresses,
    frontNine, backNine,
  } = ar;

  const ao = activeGames || [];
  const nP = players.length;
  const parF = FRONT.reduce((s,h)=>s+(pars[h]||0),0);
  const parB = BACK.reduce((s,h)=>s+(pars[h]||0),0);

  const ninesSuffix = (() => {
    const n = (r.course_snapshot?.nines||[]).length;
    if (n <= 1 || !frontNine) return '';
    return ` · ${frontNine}/${backNine||'B9'}`;
  })();

  const logoHtml = logoDataUri
    ? `<img src="" style="height:58px;width:auto;display:block;visibility:hidden;" alt=""/>`
    : `<div style="height:58px;"></div>`;

  const cols = Math.min(nP, 4);
  const chipHtml = players.map(p => {
    const ch = courseHcps?.[players.indexOf(p)] ?? 0;
    return `<div style="background:#fff;border-radius:8px;padding:5px 8px;text-align:center;">
      <div style="font-size:12px;font-weight:700;color:#1a472a;">${xe(p.name)}</div>
      <div style="font-size:10px;color:#666;">HI ${xe(p.ghin||'—')} · CH ${xe(ch)}</div>
    </div>`;
  }).join('');

  // Scorecard
  const hdCols = `<colgroup><col style="width:70px"/>${[...FRONT,...BACK].map(()=>`<col style="width:28px"/>`).join('')}<col style="width:36px"/><col style="width:36px"/></colgroup>`;
  const hdRow = h => `<td style="text-align:center;font-size:9px;color:#555;background:#f0f4f0;">${h+1}</td>`;
  const parRow = `<tr><td style="font-size:9px;color:#1a472a;font-weight:700;padding:2px 4px;background:#f8fbf8;">Par</td>${[...FRONT,...BACK].map(h=>`<td style="text-align:center;font-size:9px;color:#1a472a;background:#f8fbf8;">${pars[h]||''}</td>`).join('')}<td style="text-align:center;font-size:9px;font-weight:700;background:#f0f7f0;">${parF}</td><td style="text-align:center;font-size:9px;font-weight:700;background:#f0f7f0;">${parB}</td></tr>`;
  const hcpRow = `<tr><td style="font-size:9px;color:#aaa;padding:1px 4px;background:#fafcfa;">M.Hcp</td>${[...FRONT,...BACK].map(h=>`<td style="text-align:center;font-size:9px;color:#ccc;background:#fafcfa;">${hcps[h]||''}</td>`).join('')}<td style="background:#fafcfa;"></td><td style="background:#fafcfa;"></td></tr>`;
  const hcpStrokesHtml = (pi, h) => {
    const ch = courseHcps?.[pi]??0; const rank = hcps[h]??0;
    const min = minCourseHcp??0; const strokes = Math.max(0,Math.floor((ch-min)/18)+((((ch-min)%18)+18)%18 >= rank?1:0));
    return strokes>0?`<span style="font-size:6px;vertical-align:super;color:#1a472a;">${'·'.repeat(strokes)}</span>`:'';
  };
  const escRow = (pi) => {
    const esc = escTotal(scores, pi, pars, hcps, courseHcps?.[pi]??0, minCourseHcp??0);
    const gross = [...FRONT,...BACK].reduce((s,h)=>s+(parseInt(scores[h]?.[pi])||0),0);
    return `<tr style="background:${pi%2===0?'#fff':'#f5fbf5'}"><td style="font-size:10px;font-weight:600;color:#333;padding:2px 4px;overflow:hidden;white-space:nowrap;">${xe(players[pi].name)}</td>${[...FRONT,...BACK].map(h=>{const g=parseInt(scores[h]?.[pi])||0;return `<td style="text-align:center;font-size:10px;">${g||''}${hcpStrokesHtml(pi,h)}</td>`;}).join('')}<td style="text-align:center;font-size:10px;font-weight:700;background:#f0f7f0;">${[...FRONT].reduce((s,h)=>s+(parseInt(scores[h]?.[pi])||0),0)||''}</td><td style="text-align:center;font-size:10px;font-weight:700;background:#f0f7f0;">${[...BACK].reduce((s,h)=>s+(parseInt(scores[h]?.[pi])||0),0)||''}</td></tr>`;
  };
  const scorecardHtml = `<div style="overflow-x:auto;margin-bottom:12px;"><table style="border-collapse:collapse;table-layout:fixed;width:100%;">${hdCols}<thead><tr><th style="background:#f0f4f0;font-size:9px;text-align:left;padding:2px 4px;"></th>${[...FRONT,...BACK].map(hdRow).join('')}<th style="background:#e8f0e8;font-size:9px;color:#1a472a;font-weight:800;text-align:center;">F9</th><th style="background:#e8f0e8;font-size:9px;color:#1a472a;font-weight:800;text-align:center;">B9</th></tr>${parRow}${hcpRow}</thead><tbody>${players.map((_,pi)=>escRow(pi)).join('')}</tbody></table></div>`;

  // Game tables (simplified for share image)
  let gamesHtml = '';
  const drawTbl = (tk, rows) => {
    if (!rows?.length) return '';
    let s = `<div style="margin-bottom:10px;border-radius:8px;overflow:hidden;border:1px solid ${tk.bdr};">`;
    s += `<div style="background:${tk.hdr};padding:5px 10px;"><span style="font-size:11px;font-weight:700;color:${tk.hdrC};">${tk.title}</span></div>`;
    rows.forEach((rr,i)=>{
      if(rr.isHeader){s+=`<div style="padding:3px 10px;background:${i%2===0?tk.rA:tk.rB};font-size:10px;font-weight:700;color:${tk.hdrC};">${xe(rr.name)}: ${xe(rr.detail)}</div>`;return;}
      s+=`<div style="display:flex;justify-content:space-between;font-size:11px;padding:4px 10px;background:${i%2===0?tk.rA:tk.rB};">`;
      s+=`<span style="color:#333;">${xe(rr.name)}</span><span style="color:#333;">${xe(rr.detail)}</span></div>`;
    });
    s+='</div>'; return s;
  };

  breakdown.forEach(e => {
    if(e.game==='🥊 Match / Nassau'||e.game==='Match / Nassau') return;
    const g = cleanGameName(e.game);
    if(g==='Skins') gamesHtml+=drawTbl(TK.S,e.rows);
    else if(g==='Nines'||g.startsWith('Nines')) gamesHtml+=drawTbl(TK.N,e.rows);
    else if(g==='Stableford'||g.startsWith('Stableford')) gamesHtml+=drawTbl(TK.K,e.rows);
    else if(g==='Stroke Play') gamesHtml+=drawTbl(TK.P,e.rows);
  });

  const secLabel = t => `<div style="font-size:13px;font-weight:800;color:#1a472a;margin:32px 0 8px;padding-bottom:4px;border-bottom:2px solid #1a472a;">${t}</div>`;

  // Payouts
  const sorted = Object.entries(bank||{}).sort((a,b)=>b[1]-a[1]);
  let payHtml = secLabel('Payouts');
  payHtml += `<div style="border-radius:8px;overflow:hidden;border:1px solid #d8ead8;margin-bottom:16px;">`;
  payHtml += `<div style="background:${G_COLOR};padding:6px 12px;"><span style="font-size:11px;font-weight:800;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Overall (all games)</span></div>`;
  sorted.forEach(([nm, v], i) => {
    const clr = v>0?GRN_PAY:v<0?RED_PAY:'#888';
    const bg  = i%2===0 ? '#fff' : '#f5fbf5';
    payHtml += `<div style="display:flex;justify-content:space-between;align-items:center;font-size:13px;padding:7px 12px;background:${bg};${i>0?'border-top:1px solid #eef4ee;':''}">`;
    payHtml += `<span style="font-weight:500;color:#222;">${xe(nm)}</span>`;
    payHtml += `<span style="font-weight:800;color:${clr};font-size:14px;">${xe(fmtMoney(v))}</span>`;
    payHtml += `</div>`;
  });
  payHtml += `</div>`;
  payHtml += `<div style="font-size:10px;font-weight:700;color:#666;text-transform:uppercase;letter-spacing:0.4px;margin-bottom:8px;padding-bottom:3px;border-bottom:1px solid #ccc;">By Game</div>`;
  const drawPaySec = (label, rows) => {
    const nz = (rows||[]).filter(rr => rr.net != null && rr.net !== 0 && !rr.isHeader);
    if (!nz.length) return '';
    let s = `<div style="margin-bottom:10px;border-radius:8px;overflow:hidden;border:1px solid #c8ddc8;">`;
    s += `<div style="background:#2d6a4f;padding:5px 10px;"><span style="font-size:11px;font-weight:700;color:#fff;">${xe(label)}</span></div>`;
    nz.forEach((rr, i) => {
      const clr = rr.net>0?GRN_PAY:RED_PAY;
      const bg  = i%2===0 ? '#fff' : '#f5fbf5';
      s += `<div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;padding:5px 10px;background:${bg};${i>0?'border-top:1px solid #f0f0f0;':''}">`;
      s += `<span style="color:#444;">${xe(rr.name)}</span>`;
      s += `<span style="font-weight:700;color:${clr};">${xe(fmtMoney(rr.net))}</span>`;
      s += `</div>`;
    });
    s += `</div>`; return s;
  };
  (matchPayouts||[]).forEach(m => { payHtml += drawPaySec(`Match / Nassau — ${m.label}`, m.rows); });
  (breakdown||[]).filter(e=>e.game!=='🥊 Match / Nassau'&&e.game!=='Match / Nassau').forEach(e => {
    payHtml += drawPaySec(cleanGameName(e.game), (e.rows||[]).map(rr=>({name:rr.name,net:rr.net})));
  });

  return `
    <div xmlns="http://www.w3.org/1999/xhtml" style="margin:0;padding:0;font-family:-apple-system,'Helvetica Neue',sans-serif;background:#fff;width:${FO_WIDTH}px;">
      <div style="background:${G_COLOR};padding:10px 18px;display:flex;align-items:center;justify-content:space-between;">
        ${logoHtml}
        <div style="text-align:right;flex:1;margin-left:16px;">
          <div style="font-weight:800;font-size:16px;color:#fff;letter-spacing:0.06em;text-transform:uppercase;line-height:1.2;">${xe((r.course_name||'Unknown Course'))}${ninesSuffix}</div>
          <div style="font-size:11px;color:#a8d8a8;margin-top:3px;">${xe(fmtDate(r.date))}</div>
        </div>
      </div>
      <div style="background:#ddeedd;padding:8px 14px;">
        <div style="display:grid;grid-template-columns:repeat(${cols},1fr);gap:6px;">${chipHtml}</div>
      </div>
      <div style="padding:4px 14px 24px;background:#eef4ee;">
        ${scorecardHtml}
        ${gamesHtml.length > 0 ? secLabel('Game Results') + gamesHtml : ''}
        ${payHtml}
        <div style="text-align:center;margin-top:16px;padding-top:8px;border-top:1px solid #e8f0e8;font-size:10px;color:#aaa;">The Card</div>
      </div>
    </div>`;
}

async function buildShareImageForeignObject(r, ar, bank, breakdown, matchPayouts) {
  const logoDataUri = await getLogoDataUri();
  const html = buildShareHtml(r, ar, bank, breakdown, matchPayouts, logoDataUri);

  const probe = document.createElement('div');
  probe.style.cssText = `position:fixed;top:0;left:0;width:${FO_WIDTH}px;visibility:hidden;pointer-events:none;z-index:9999;`;
  probe.innerHTML = html;
  document.body.appendChild(probe);
  await new Promise(res => requestAnimationFrame(() => requestAnimationFrame(res)));
  const measuredH = probe.scrollHeight;
  document.body.removeChild(probe);

  if (!measuredH || measuredH < 100) {
    throw new Error('foreignObject: height measurement failed (' + measuredH + ')');
  }

  const svgStr = `<svg xmlns="http://www.w3.org/2000/svg" width="${FO_WIDTH}" height="${measuredH}">
    <foreignObject width="${FO_WIDTH}" height="${measuredH}">
      ${html}
    </foreignObject>
  </svg>`;
  const svgB64  = btoa(unescape(encodeURIComponent(svgStr)));
  const dataUri = `data:image/svg+xml;base64,${svgB64}`;

  const SCALE = 2;
  const canvas = document.createElement('canvas');
  canvas.width  = FO_WIDTH  * SCALE;
  canvas.height = measuredH * SCALE;
  const ctx = canvas.getContext('2d');
  ctx.scale(SCALE, SCALE);

  await new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => { ctx.drawImage(img, 0, 0, FO_WIDTH, measuredH); resolve(); };
    img.onerror = () => reject(new Error('foreignObject img load failed'));
    img.src = dataUri;
  });

  if (logoDataUri) {
    await new Promise(resolve => {
      const logoImg = new Image();
      logoImg.onload = () => {
        const LOGO_H = 58;
        const logoW  = Math.round(LOGO_H * (logoImg.naturalWidth / logoImg.naturalHeight));
        ctx.drawImage(logoImg, 18, 10, logoW, LOGO_H);
        resolve();
      };
      logoImg.onerror = () => resolve();
      logoImg.src = logoDataUri;
    });
  }

  return new Promise((resolve, reject) => {
    try {
      canvas.toBlob(blob => {
        if (blob) resolve(blob);
        else reject(new Error('foreignObject: toBlob returned null'));
      }, 'image/png');
    } catch(e) { reject(e); }
  });
}

export async function buildShareImage(r, ar, bank, breakdown, matchPayouts) {
  return buildShareImageForeignObject(r, ar, bank, breakdown, matchPayouts);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href=url; a.download=filename;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function triggerRoundShare(r, ar, bank, breakdown, matchPayouts, prebuiltBlob) {
  const blob     = prebuiltBlob || await buildShareImage(r, ar, bank, breakdown, matchPayouts);
  const filename = `the-card-${r.date||'round'}.png`;
  const file     = new File([blob], filename, { type:'image/png' });
  const subject  = `${r.course_name||'Golf'} — The Card · ${r.date||''}`;
  const text     = `Round summary from ${r.course_name||'golf'} on ${r.date||'today'}.`;
  if (navigator.canShare && navigator.canShare({ files:[file] })) {
    try { await navigator.share({ files:[file], title:subject, text }); return; }
    catch(err) { if (err.name==='AbortError') return; }
  }
  downloadBlob(blob, filename);
}
