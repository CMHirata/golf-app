_Last updated: April 2026 — Session 13-C complete (planning + contract only — no code). **Output: `PartialGameContract.md` → v1.3 AUTHORITATIVE.** `Early_Departure_Contract.md` (v1.0 DRAFT) and `Late_Arrival_Contract.md` (v1.0 DRAFT) superseded in their entirety. **Three concepts unified:** predetermined game ranges, mid-round game start, early departure all governed by one contract with a shared `[startHole, endHole]` data model. **Key decisions confirmed:** (1) `games.js` and `handicap.js` are never modified by partial-round features — all range/departure logic lives in `payouts.js` pre-processing layer, which is a provable no-op for full rounds; (2) every press is an independent bet with its own Pay/Abandon toggle — no parent-segment inheritance; (3) `exclude_player` available for Stableford individual, Stroke Play, Dots (3+ players must remain; never for Match, Nines, Sixes, Stableford team); (4) Sixes segment length = `rangeLength / 3` (dynamic — standard 18-hole round = 6, 9-hole = 3); (5) dormie+1 clinch rule `h > n - h` applies uniformly to all clinch-segment bets; (6) `–` is the authoritative display for unplayed holes (distinct from `X` = picked up, blank = not entered); (7) D-C1 confirmed: `end_at_k` for Nines departure; (8) D-C2 confirmed: partial segments pay to leader (Option A), user may override per pill; (9) D-C3 confirmed: departed player chip = gray tint / reduced opacity. **Session plan:** 13-C.2 (predetermined ranges — build), 13-C.3 (mid-round start — build), 13-C.4 (resolver UI design — planning), 13-C.5 (proactive departure — build), 13-C.6 (reactive departure — build), 13-C.7 (engine departure handling — build). **Next session: 13-C.2.**_

_Last updated: April 2026 — Post-13-B.1 follow-on fixes ✅ confirmed on device: X score handling in display tables + ScoreGrid cell sizing. **X bugs fixed in display tables:** `SixesTable.holeWinFn` — `allScored` check was using `parseInt(v)` (falsy for `'X'`) causing X holes to be treated as unplayed; `val` function was passing `NaN` to `scoreForMode`. Fixed: `allScored` uses `v !== '' && v != null`; `val` returns `Infinity` for `'X'`. `NinesTable.allData` — parallel `parseInt`-based totals-chips path silently dropped X holes from running totals; replaced with `holeData([...Array(18).keys()])` which already handles X correctly. `StablefordTable.scoreHole` — `parseInt('X')` = `NaN`, falsy, caused X holes to score 0 pts; fixed to substitute `xGrossScore()` for `'X'` before `stabPts` call; added `xGrossScore` import. **Audit of all tables:** `MatchNassauTable` ✅ clean (fixed 13-B); `SkinsTable` ✅ clean (engine `calcSkinsHole` handles X, table delegates entirely); `StrokePlayTable` ✅ correct by contract (X = unscored in stroke play; `!NaN` = true already skips X holes); `TotalsCard` ✅ clean (uses `xGrossScore` explicitly); `DotsTable` ✅ clean (no score parsing). **ScoreGrid cell sizing fix:** `renderCell` div had `minHeight: 24` with no explicit height — empty cells collapsed to padding height (~24px) then expanded on score entry. Fixed: replaced `minHeight` with computed `height = round(fontSize × 1.2) + vertPad + 2` matching old `<input>` browser sizing; removed `padding` from cellStyle (height + `alignItems: center` handles vertical centering). **Contract amendments:** `Sixes_Contract.md`, `Nines_Contract.md`, `Stableford_Contract.md` — display table X handling bullets added to existing X Score Behavior sections. **Files changed:** `SixesTable.jsx`, `NinesTable.jsx`, `StablefordTable.jsx`, `ScoreGrid.jsx`._

_Last updated: April 2026 — Session 13-B.1 complete ✅ confirmed on device: ZoomModal stabilization + pre-13 bug fixes + keypad/touch isolation hardening. **ZoomModal rebuilt as pure display component (final):** No hidden input, no `.focus()` calls, no advance/retreat logic. Receives `activeKpCell` prop (drives green border), `onCellTap` prop (routes to `openKeypadOnCell` in ScoreGrid), `cardRef` prop (attached to card div for dismiss-handler exemption). **ScoreGrid keypad integration completed:** `openZoom` no longer calls `.focus()` on hidden input (was triggering iOS keyboard). `kpVisible = canZoom && !!activeKpCell` (no `!zoomOpen` suppression — keypad shows above ZoomModal at zIndex 300). `zoomCardRef` ref attached to ZoomModal card and exempted from global `touchend` dismiss handler so tapping ZoomModal cells does not clear `activeKpCell`. `closeZoom` clears `activeKpCell` + `kpValue`. `useEffect` on `[zoomOpen]` defers first cell activation by one tick (avoids dismiss handler clearing it on the same zoom-button tap). `kpAdvanceCell`/`kpRetreatCell` call `setZoomHole` when crossing hole boundaries. `longPressFired` ref guards `onCellTap` wrapper — long-press finger-lift does not reopen keypad. `savedKpCellRef` + `activeKpCellRef` pattern: long-press saves current `activeKpCell`, clears it (keypad hides during DotsPopup), restores on DotsPopup close. **DotsPopup touch isolation:** `touchStartedOnBackdrop` ref prevents auto-close from long-press finger-lift. `onTouchStart`/`onTouchEnd` with `stopPropagation` on both backdrop and card prevent touch bleed-through to ZoomModal/ScoreGrid below. **ZoomModal touch isolation:** backdrop `onTouchStart` stops propagation; `onTouchEnd` closes only when `e.target === e.currentTarget`; card `onTouchStart`/`onTouchEnd` stop propagation. **Bug A fix (HI/tee/CH not persisting on back-to-setup):** `handleBackToSetup` changed `if (ar?.roundId)` → `if (ar)` so fresh rounds (roundId=null) also restore setup. `playerCHOverrides` lazy-initialized from `initSrc.playerSnapshots` — players with `courseHcpVal` set and empty `ghin` have their CH restored as a manual override. **Bug B fix (Sixes autopress):** `SixesTable` and `payouts.js` both changed `autoPress === 'auto'` → `autoPress !== 'none'` with `parseInt(autoPress)`. `autoPressN` was never stored — threshold IS `autoPress`. **Bug C fix (Match autopress):** `MatchNassauTable` and `games.js` `runMatchNassau` both changed `legacyN` check from `=== 'auto'` → `!== 'none'`. **Other fixes:** `handleCourseSelect` no longer auto-picks a tee — tees start blank; first player to pick propagates to all blank players. ZoomModal dot badges: center column 22px/12px, outer columns 15px/7px, offsets -5/-3 respectively. **Files changed:** `ZoomModal.jsx`, `ScoreGrid.jsx`, `DotsPopup.jsx`, `App.jsx`, `NewRoundPage.jsx`, `SixesTable.jsx`, `payouts.js`, `games.js`, `MatchNassauTable.jsx`._

_Last updated: April 2026 — Session 13-B complete ✅ confirmed on device: Custom keypad + X score type. **`ScoreKeypad.jsx` (new):** Fixed-bottom overlay, 4 rows (1-2-3 / 4-5-6 / 7-8-9 / ⌫-0-X), 56px row height, `position:fixed bottom:0`, `zIndex:300` (covers nav bar), safe-area-inset padding. Replaces iOS system keyboard everywhere — no `.focus()` on hidden inputs for score entry. **`'X'` score type:** `scores[h][i]` now valid as `'X'` (player picked up). Displays as NX with amber X suffix and `#fffbe6` background. `xGrossScore()` added to `handicap.js` (par + 2 + full-net strokes). ESC-capped by definition. "X always loses to real score; X ties X" — holds across all 7 games. **Architecture:** `ScoreGrid` owns all keypad state (`activeKpCell`, `kpValue`, advance timers). `ZoomModal` rebuilt as pure display component — no hidden input, no keyboard focus logic, no advance/retreat logic. Tapping a ZoomModal cell calls `onCellTap(h, pi)` → `openKeypadOnCell` in ScoreGrid. `kpAdvanceCell`/`kpRetreatCell` update `zoomHole` when zoom is open and hole changes. Keypad opens automatically when ZoomModal opens (`setTimeout(0)` deferral past dismiss handler). Dismiss handler spares touches inside `kpContainerRef` (keypad) and `zoomCardRef` (ZoomModal card). **Entry behavior:** `kpValue` always seeded `''` on open/advance/retreat — first digit replaces, never appends. ⌫: removes last char if `kpValue` non-empty; clears committed score if `kpValue` empty + score present; retreats if cell is empty. Auto-advance: immediate for all values except `'1'` (700ms window). Navigation row (←/✓/→) removed after device testing — too much screen space. **X score fixes in engine/tables:** `NinesTable.holeData` and `MatchNassauTable.indivHoleWinner`/`teamHoleWinner` fixed to handle `'X'` — `parseInt('X')` was silently returning NaN and collapsing entire holes. **Discard bug fixed:** `isDiscardingRef` in `ScorecardPage` prevents unmount cleanup flush from re-writing cleared storage after discard. **Contracts:** `ScoreKeypad_Contract.md` → v2.1 AUTHORITATIVE. 11 contracts amended: all 7 game contracts (X score behavior sections added), `App_Data_Model_Contract.md` (§5.6 + invariants #8/#9), `Round_Lifecycle_Contract.md` (§12 invariant #3), `Handicap_Contract.md` (§5.14 amended, §5.15 `xGrossScore` added, §10 arch boundary, invariants #15–#17), `Payout_Contract.md` → v1.11 (§4.4 X score handling, invariants #12/#13). **Files changed:** `ScoreKeypad.jsx` (new), `ScoreGrid.jsx`, `ZoomModal.jsx`, `ScorecardPage.jsx`, `games.js`, `handicap.js`, `TotalsCard.jsx`, `NinesTable.jsx`, `MatchNassauTable.jsx`, `RoundSummaryModal.jsx`, `roundUtils.js`, `payouts.js`._

_Last updated: April 2026 — Session 13-A complete (planning only — no code): Sprint 13 restructured. Custom keypad, X score type, early departure, and late arrival designed and contracted. Output: `ScoreKeypad_Contract.md` (v1.0 DRAFT), `Early_Departure_Contract.md` (v1.0 DRAFT), `Late_Arrival_Contract.md` (v1.0 DRAFT). All three contracts require owner sign-off (AUTHORITATIVE) before Session 13-B Phase 2 begins. iCloud export moved to 14-D._

_Last updated: April 2026 — Session 11-O complete ✅ confirmed on device: Audit session + B-8. **Audit findings:** All 7 game tables (Match/Nassau, Skins, Stableford, Nines, Stroke Play, Sixes, Dots) confirmed correctly wired in both `RoundSummaryModal` and `buildShareHtml`/`buildSharePdf` — no code bugs found. C-10 named nine labels confirmed working in scorecard header and share image main header; game table section labels intentionally remain 'Front 9'/'Back 9'. Nines missing from old round summaries was a stored-data issue (pre-dates `nines_players` field) — resolved by re-saving rounds via the edit flow. **B-8 — Edit any history round:** Lock/unlock icon added to bottom of Rounds tile in `HistoryPage.jsx`. Locked state (default, resets to locked on every page load — not persisted) restricts Edit swipe action to most-recent-date rounds only, matching prior behavior. Unlocked state enables Edit on all historical rounds. Implementation exceeds original B-8 spec by giving the user deliberate control rather than making all rounds always editable — accidental edits to old rounds are prevented by default. Files changed: `HistoryPage.jsx`._

_Last updated: April 2026 — Session 11-L complete ✅ confirmed on device: Stableford Teams engine support. **Phase 1 — contracts:** `Stableford_Contract.md` → v1.5 (team format `'individual'|'team'`; team scoring rule `'cumulative'|'bestball'`; `'total'` added as third explicit `betMode` with split-pot semantics; condor key `'4'` default 6 pts, clamp `[-3,4]`; team payout formulas — each player settles at full per-mode rate independently; `App_Data_Model_Contract.md` → v3.1 (team fields + condor in `gameOpts.Stableford`). **Phase 2 — engine:** `handicap.js` — `DEFAULT_STAB` gains `'4':6`, clamp expanded; `games.js` — `calcTeamStablefordTotal()` added (pure function, cumulative/bestball aggregation); `payouts.js` — team mode branch (perpoint/total/segments), `'total'` split-pot replaces sole-winner else-branch, `opts.scoring` fallback removed from `mode` read. **Phase 2 — UI:** `NewRoundPage.jsx` — Teams option enabled with 4-player guard and start guard; `'total'` betMode added; GNL_DEFAULTS Stableford collision fix; `GameConfig.jsx` — Sixes-style stacked team picker, 8-col condor row, full-width scoring dropdown, `onFocus` select-all on points inputs; `StablefordTable.jsx` — team layout (TeamTotalRow, custom chip rendering, badge2 for scoring rule inline with Net badge); `GameSection.jsx` — `badge2` prop, landscape headers → "Total"; `ScoreGrid.jsx`, `NinesTable.jsx`, `StrokePlayTable.jsx`, `MatchNassauTable.jsx` — all total column headers → "Total"; `payouts.js` — Stableford game name unified; `ResultsPage.jsx` — tied games show "Tie — no payout". **Key gotcha:** `opts.scoring` field name collision — in Stableford, `scoring` holds the team hole-scoring rule (`'cumulative'`/`'bestball'`), conflicting with the legacy `grossNetNOL` fallback chain (`o.grossNetNOL ?? o.scoring ?? default`). Fixed in `NewRoundPage.allOpts`, `App.jsx getActiveRound`, `payouts.js`, and `StablefordTable`. `Stableford: 'net'` added to `GNL_DEFAULTS` in both locations to short-circuit the fallback before it reaches `o.scoring`._

 (1) **SixesTable `opts` prop fix** — both `RoundSummaryModal.jsx` and `roundUtils.js` share render were passing `gameOpts={gameOpts?.Sixes}` instead of `opts={gameOpts?.Sixes}`; caused wrong hole winners and `Net` badge instead of `NOL` in round summary and share image. (2) **Handicap stroke dots in `ReadOnlyScorecard`** — `RoundSummaryModal` scorecard now shows NOL/Net handicap stroke dots; `ReadOnlyScorecard` accepts `courseHcps`, `minCourseHcp`, `dotMode` props; dots rendered as absolutely-positioned 3×3px green circles (matching `PopDots` in `ScoreGrid`); `dotMode` derived from active scoring games only — Dots game excluded to avoid `gross` contaminating the priority. (3) **Handicap stroke dots in share image** — `hcpStrokesHtml` in `roundUtils.js` updated from invisible `6px` superscript text to visible green circle dots. (4) **Sixes pivot Total row** — `DotsTable.jsx` now uses `pivotSegTot` (own + companions per segment) instead of `playerSegTot` (own only). (5) **Portrait PDF** — `FO_WIDTH_PORTRAIT` corrected to 390px; portrait output is now a PDF (single tall page via jsPDF, no breaks) so iOS opens full-width without pinch-zoom; portrait header/chip/nine-name sizing tuned for 390px width. **Contract:** `Round_Lifecycle_Contract.md` → v1.8. **Files changed:** `RoundSummaryModal.jsx`, `roundUtils.js`, `DotsTable.jsx`._

 Portrait share orientation now outputs a PDF instead of PNG, solving the iOS Photos "fit to screen" zoom problem. **Root cause of PNG issue:** iOS Photos always opens images scaled to fit the full image on screen — a tall portrait summary renders tiny; user must pinch-zoom to read. **Solution:** `jsPDF` library added (`npm install jspdf`, added to `package.json` + `package-lock.json`). New `buildSharePdf` function in `roundUtils.js`: (1) measures content height using the same hidden-div probe as the PNG path; (2) renders HTML → canvas via the existing SVG foreignObject pipeline (no `html2canvas` dependency needed); (3) creates a single jsPDF page sized exactly `[FO_WIDTH_PORTRAIT × measuredH]` in px units with `hotfixes:['px_scaling']`; (4) places the canvas as JPEG (quality 0.92) onto the single page — one continuous document, no page breaks. `buildShareImage` dispatches: portrait → `buildSharePdf` (PDF blob), landscape → `buildShareImageForeignObject` (PNG blob). `triggerRoundShare` uses `application/pdf` MIME type + `.pdf` filename extension for portrait. `FO_WIDTH_PORTRAIT` updated from 480 → 390px. **iOS PDF viewer behavior:** opens PDF full-width automatically, user scrolls vertically — no pinch-zoom. **Files changed:** `roundUtils.js`, `package.json`, `package-lock.json`. No contract changes (Round_Lifecycle_Contract.md v1.7 already documents the orientation param and portrait layout — PDF vs PNG is an implementation detail). **⚠️ REVERT INSTRUCTIONS (if PDF fails or PNG preferred):** (1) In `roundUtils.js`: remove `import { jsPDF } from 'jspdf'` line; delete the entire `buildSharePdf` function; in `buildShareImage` replace the portrait branch with `return buildShareImageForeignObject(r, ar, bank, breakdown, matchPayouts, orientation)`; in `triggerRoundShare` revert filename/MIME to always use `'image/png'` and `'.png'`. (2) Run `npm uninstall jspdf` (updates `package.json` + `package-lock.json` automatically). (3) Run `npm run build` and deploy. Total revert time: ~5 minutes._

 Team Dots payout fix + DotsTable team layout + share image Dots pivot + portrait share report (out of scope, added same session). **Root cause of Match team payout bug:** companion entries were being written using Sixes segment pairings even when `teamMode` was set to a Match, because the `dotsScoringMode` effect re-ran `autoMark` for all holes after the user changed setup — old Sixes companions were never cleaned up. **Fix 1 — stale companion cleanup (`ScoreGrid.jsx` + `DotsPopup.jsx`):** `autoMark` now deletes all `h_*_team_dot_for_pi` companion keys for the earner+hole before writing the new correct companion — eliminating cross-contamination between teamMode changes. `DotsPopup.writeCompanion` applies the same cleanup. **Fix 2 — `payouts.js`:** Match team Dots block now looks up the team match by `matchId` sliced from `teamSource` (was using `matches.find(m => m.format === 'team')` blindly — wrong match when multiple matches exist). **Fix 3 — `DotsTable.jsx`:** `getMatchTeams` and `getMatchPairing` also look up by matchId. By-hole grid cells now show only non-team dots (`nonTeamCellCount`) — team companion dots appear only in the pivot Team row. Total row removed from all by-hole grids. Column labels renamed: segment cols → "Total", pivot sum row "Dots" → "Total". `pivotRoundTot` (all dots including companions, for pivot total row) distinguished from `playerHolesTot` (non-team only, for grid subtotals). **DotsTable display summary:** Dots total row = own + team received (e.g. 8/8/4/4 for equal-dot teammates). **roundUtils.js share image Dots pivot:** Match team mode now renders Team A / Team B column groups with `allDotCnt` totals matching scorecard. `deriveShareDotMode(ar)` added — derives handicap stroke dot display mode from all active game `grossNetNOL` values (priority: net > NOL-full > NOL-subset > gross); share scorecard now shows handicap stroke dots for all modes. **Portrait share report:** `FO_WIDTH_PORTRAIT = 480` added; portrait scorecard splits into F9/B9 stacked tables with single "Tot" column each. `buildShareImage` and `triggerRoundShare` accept `orientation` param (`'landscape'`|`'portrait'`). **`ShareOrientationPicker`** bottom-sheet component added to `ui.jsx` — imported and wired into all three share surfaces (`ResultsPage`, `HistoryPage`, `RoundSummaryModal`): tap Share → picker appears → user chooses orientation → image built and shared. **Contracts:** `Dots_Contract.md` → v2.3 (already complete from prior partial session); `UI_Component_Contract.md` → v1.3 (§4.9 `ShareOrientationPicker`); `Round_Lifecycle_Contract.md` → v1.7 (§6.5 orientation picker, portrait layout, `deriveShareDotMode` rules). **Files changed:** `payouts.js`, `DotsPopup.jsx`, `DotsTable.jsx`, `ScoreGrid.jsx`, `roundUtils.js`, `ResultsPage.jsx`, `HistoryPage.jsx`, `RoundSummaryModal.jsx`, `ui.jsx`, `UI_Component_Contract.md`, `Round_Lifecycle_Contract.md`._

_Last updated: April 2026 — Session 11-K complete ✅ confirmed on device: NOL dot selector. **Contract-first session. Phase 1 — 2 contracts amended:** `Handicap_Contract.md` → v1.6 (§5.6–§5.14 added: unified segmented pill spec, qualifying condition `subsetMin > minCourseHcp`, subset grouping by fingerprint — games with identical participant sets merged into one button e.g. "NOL Skins / Match A", `nolDotGame` ephemeral state, ZoomModal inheritance, `computeNolDotOptions` helper spec); `Round_Lifecycle_Contract.md` → v1.6 (§3.4 center button now triggers `handleStart` when on setup tab; §2.6 `manualPresses` preservation confirmed implemented; G-11 closed). **Phase 2 — 6 implementation files:** `scorecardUtils.js` — `computeNolDotOptions` (two-phase: qualify then group by fingerprint); `ScorecardPage.jsx` — `nolDotGame` state + two reset effects (dotMode change + validity check) + `nolDotOptions`/`effectiveMinCourseHcp`/`nonParticipantIdxs` memos + unified pill render (right-justified, `flex-wrap`) + hint text row removed; `ScoreGrid.jsx` — all four `PopDots` call sites updated with `effectiveMinCourseHcp` + `nonParticipantIdxs` guard; `ZoomModal.jsx` — pill moved below green header (matches scorecard size/style exactly), hint footer removed; `NewRoundPage.jsx` — `manualPresses` preserved in `roundState` when lineup unchanged + `startTriggerRef` exposed via `useEffect`; `App.jsx` — `useRef` added, `startTriggerRef` wired, `handleCenterTap` updated to call `handleStart` when `tab === 'new-round' && inProgress`. **5 bugs caught and fixed during session:** (1) Qualifying condition inverted (`<` should be `>`); (2) `isNOL` guard missing — Net-mode games generated NOL pills; (3) `nolDotOptions` referenced before declaration (TDZ crash); (4) `manualPresses` not preserved on lineup-unchanged `handleStart` re-entry; (5) Center nav button from setup tab bypassed game config commit._

_Last updated: April 2026 — Session 11-N complete ✅ confirmed on device: Round totals regression restore. `TotalsCard` was missing from `RoundSummaryModal.jsx` (never imported after 11-I/11-J rebuilds) and absent from the share image (`buildShareHtml` had no totals block). **Fix 1 — `RoundSummaryModal.jsx`:** added `import { TotalsCard } from './scorecard/TotalsCard.jsx'`; rendered `<TotalsCard players={players} pars={pars} scores={scores} courseHcps={courseHcps} hcps={hcps} />` immediately after `<ReadOnlyScorecard>` and before the Game Results section — all five props were already destructured from `ar`. **Fix 2 — `roundUtils.js`:** added `totalsHtml` IIFE in `buildShareHtml` between `scorecardHtml` and the game-results block — green header ("Round Totals" label + "Par N" badge), per-player `<td>` columns showing first name / last name / gross total / ESC, alternating `#fff`/`#f5fbf5` rows, consistent with existing share image aesthetic. `escTotal` was already imported. No contract changes. No engine changes. Files changed: `RoundSummaryModal.jsx`, `roundUtils.js`._

_Last updated: April 2026 — Session 11-J complete ✅ confirmed on device: Per-match instance labeling and Dots teamMode per-instance dropdown. **Design decision:** match labels derive from current array index at render time — not stored on the match object; labels renumber on delete. **`teamMode` value format change:** `'Match'` → `'Match:{matchId}'` (stable ID reference, not label). **Phase 1 — 2 contracts amended:** `App_Data_Model_Contract.md` v3.0 (§5.5 Dots `teamMode` expanded to `'Match:{matchId}'`; label derivation documented; §7.1 migration shim); `Nassau_Match_Contract.md` v2.8 (§5.6 new — match instance label spec; §16.3 new — Dots teamMode per-instance dropdown). **Phase 2 — 7 files changed:** `roundLib.js` — migration shim in `migrateRecord`: `teamMode:'Match'` → `'Match:{firstTeamMatchId}'` or `'none'`; `roundUtils.js` — `computePerMatchPayouts` label changed from `matchLabel()` (player names) to `'Match A'`/`'Match B'` from array index; `matchLabel` import removed; share image payout section updated; `MatchNassauTable.jsx` — section header now `'Match A'`/`'Match B'` from map index (was `'Nassau'`/`'Match'`); `NewRoundPage.jsx` — Dots dropdown enumerates per-match `'Match:{id}'` options with index-derived letter labels; `onChange` uses `startsWith('Match:')` + `slice(6)`; match delete resets `teamMode` when it references the deleted match; `ScoreGrid.jsx` — `getPartner()` handles `teamSource.startsWith('Match:')`, looks up match by ID with fallback; `RoundSummaryModal.jsx` — payout sub-header changed from `Match / Nassau — ${match.label}` to `match.label` only; `ResultsPage.jsx` — same fix (was missed in Phase 2; found during testing). **Nassau terminology fully purged** from all payout display surfaces._

_Last updated: April 2026 — Session 11-I.3 complete ✅ confirmed on device: Pure semantic field rename — no behavior changes. **Renames:** `gameOpts.*.scoring` (`'gross'|'net'|'netofflow'`) → `grossNetNOL` across all games and MatchDef; `gameOpts.Sixes.tiebreak` and `matchDef.tiebreak` (team hole-scoring rule) → `scoring`. Final name `grossNetNOL` chosen over originally-planned `handicap` — three valid values embedded in the name. `scoreForMode`/`strokesForMode` function names in `handicap.js` not renamed (deferred). **Phase 1 — 10 contracts amended:** `App_Data_Model_Contract.md` v2.9 (§5.5 all gameOpts shapes, §5.7 MatchDef, §7.1 four new migration shims); `Nassau_Match_Contract.md` v2.7 (§2, §3.4 renamed to "Scoring rule", naming notes removed); `Sixes_Contract.md` v1.9 (§3.4 renamed to "Scoring Rule", §3.5 param renamed); `Skins_Contract.md` v1.6; `Stableford_Contract.md` v1.4; `Nines_Contract.md` v1.4; `Stroke_Play_Contract.md` v1.6 (G-1 closed); `Dots_Contract.md` v2.2 (renamed from `Dots_Contract_v2_1.md`); `Payout_Contract.md` v1.10 (all field reads + §4.1 stale Specials names fixed); `NewRoundPage_Design_Spec.md` (pairedOption `'tiebreak'`→`'scoring'` ×2). **Phase 2 — 19 implementation files:** backward-compat fallback chains everywhere (`opts.grossNetNOL ?? opts.scoring ?? default`; `opts.scoring ?? opts.tiebreak ?? 'none'`); 4 migration shims in `roundLib.migrateRecord`; `App.jsx` `getActiveRound` migrates in-progress rounds transparently; `NewRoundPage` `allOpts` always writes `grossNetNOL` explicitly with correct per-game defaults (Stroke Play + Dots → `'gross'`, others → `'net'`). **Three pre-existing bugs fixed during testing:** (1) `StrokePlayTable` default fallback `'net'`→`'gross'` — closes Stroke_Play_Contract G-1; (2) `SixesTable.holeWinFn` missing `cumulative` branch added; (3) `MatchNassauTable.teamHoleWinner` missing `cumulative` branch added._

_Last updated: April 2026 — Session 11-I.2 complete ✅ confirmed on device: Full game config UI rebuild. New shared components: `GameTile` (unified morph tile — single container, hairline separator, pale-green `GB` fill, dark-green `G` border; collapsed = header row only, expanded = header + body; header uses `1fr 1fr 1fr` CSS grid so all tiles have identical column proportions); `BetSection` (universal bet layout — "Bet" label `13/700/G` left, mode dropdown right in `1fr 1fr` grid; F/B/T mode renders 3-column labels + fields + optional press row); `TeamPickerPair` (kept as named export, used internally). `PlayerSubsetDropdown` C-2 chip closed state (first-name chips, overflow hidden). `PlayerDropdown` and `ReadOnlyBubble` gain `firstNameOnly` prop (single-line height matching StyledSel). `MatchCard` rebuilt as body-only component (header owned by GameTile); individual + team player rows use `1fr auto 1fr` grid with horizontal "vs". Match placeholder model: collapsed "Match" tile when off, per-match `Match A/B/C` tiles (ephemeral index-based labels) + dashed "+ Add another Match" tile when on; unchecking last match reverts to placeholder. Games sorted alphabetically by display name (stored `ALL_GAMES` order unchanged). "Match / Nassau" display-renamed to "Match" (stored key unchanged — zero migration). Sixes Match 1/2/3 use stacked left/right `1fr auto 1fr` layout with "vs" centered. Dots subtitle ("Specials, Junk") shown only when collapsed. Stableford labels: "Bogey", "Double" (was "Bog", "Dbl"). Stableford Teams option disabled (Option Z). Dots teamMode side-effect logic moved to NewRoundPage. No contracts changed — pure UI session. Files changed: `GameConfig.jsx`, `MatchCard.jsx`, `NewRoundPage.jsx`, `PlayerDropdown.jsx`._

_Last updated: April 2026 — Session 11-I.1 complete (Players card + contracts + shared components). Phase 1: all 6 contracts amended — App_Data_Model_Contract.md v2.7 (`betMode` field replacing `strokeMode`/`stabBetMode`/`ninesMode`; `carryover` boolean; `GAME_CONFIGS` subsection); Nassau_Match_Contract.md v2.5 (§16 setup UI vocabulary); Stableford_Contract.md v1.3 (`betMode`, default `perpoint`); Nines_Contract.md v1.3 (`betMode`, `segments`); Skins_Contract.md v1.5 (`carryover` boolean); Stroke_Play_Contract.md v1.4 (`betMode`, `total`/`segments`). Phase 2: engine changes in `payouts.js`; `SkinsTable.jsx` carryover fix; `roundLib.js` migration shim; `NewRoundPage.jsx` Players card rebuilt; `PlayerDropdown.jsx` controls normalized; `ui.jsx` BetInput padding normalized; `GameConfig.jsx` and `MatchCard.jsx` partially rebuilt. Players card confirmed on device ✅. Games section NOT confirmed — deferred to 11-I.2._

_Last updated: April 2026 — Session 11-G-1 complete (planning session): NOL subset dot display design work led to identification of foundational architectural debt. Decisions made: (1) Nassau terminology retired from all user-facing surfaces. (2) `betType` adopted as a static config concept only — lives in a `GAME_CONFIGS` constant in `NewRoundPage`, never stored in `gameOpts` or round state. (3) Shared bet config UI components to be built. (4) Wolf door left open as next game format. (5) Match/Nassau UX: unified `matches` array. (6) Per-match instance labeling deferred to **11-J**. (7) NOL dot selector deferred to **11-K**. Sequencing: 11-H → 11-I → 11-J → 11-K. No code produced this session._

_Last updated: April 2026 — Session 11-F complete and confirmed on device ✅: Zoom score entry modal (`ZoomModal.jsx` — new file). Full-screen scorecard-style popup showing 3-hole window (prev/current/next) for all players with magnified cells. Single hidden input at `top:-100px` (off-screen) receives all keystrokes — iOS never scrolls viewport to bring it into view. Zoom button (magnifying glass SVG) appears in Front 9 label row (portrait) and control row next to Net/NOL toggle (landscape). `ScorecardPage.jsx` exposes `zoomTriggerRef` for landscape button. `ScoreGrid.jsx` holds hidden input ref, focuses it synchronously inside zoom button tap gesture so iOS shows keyboard immediately on modal open. `DotsPopup.jsx` amended: `paddingTop` prop added — when opened from zoom modal (`zoomOpen=true`) popup renders at top of screen (paddingTop=92) matching modal position; `onMouseDown={e=>e.preventDefault()}` on card div prevents focus steal from hidden input. Active cell tracked via `focusedCell` state — only active cell gets green border (not full column). Tap prev/next column navigates to tapped player row. Backspace from top cell retreats to last player of previous hole. Files changed: `ZoomModal.jsx` (new), `ScoreGrid.jsx`, `ScorecardPage.jsx`, `DotsPopup.jsx`._

_Last updated: April 2026 — Sessions 11-D/E/post-E complete and confirmed on device ✅: (11-D) `resolveDisplayNames` added to `scorecardUtils.js`; `PlayerChips` added to `GameSection.jsx`; `TotalsCard`, `StrokePlayTable` footer chips, `PlayerSubsetChips` migrated to first-name display; `PlayerDropdown.jsx` new file (`PlayerDropdown`, `StyledSel`, `ReadOnlyBubble`); `MatchCard.jsx` and `GameConfig.jsx` Sixes picker rebuilt with custom dropdowns. (11-E) `Btn` disabled style fix (`ui.jsx` — explicit conditional spread after caller `style`); "Net Off Low" label audit confirmed consistent — no code changes needed. (post-E) Name display convention unified: all picker bubbles and game-table chips always show first name (larger/darker) + last name (smaller/lighter) unconditionally; `resolveDisplayNames` removed from `PlayerDropdown`, `GameSection`, `TotalsCard`, `StrokePlayTable`, `GameConfig`. Sixes duplicate-team prevention: `excludeIdxs` now blocks any player who has been a teammate with the current slot's partner in any segment (Team A or auto-derived Team B). Files changed: `ui.jsx`, `PlayerDropdown.jsx`, `GameConfig.jsx`, `MatchCard.jsx`, `GameSection.jsx`, `TotalsCard.jsx`, `StrokePlayTable.jsx`._

_Last updated: April 2026 — Session 11-C complete: D-1 Match/Nassau team hole winner display. `MatchNassauTable.jsx` — team chips now show slash-separated single first initials (`C/D`), colorblind-safe blue/red matching Sixes (`TMA_*`/`TMB_*` tokens); color-coded `nm1 vs nm2` header; `resolveMatchTeamNames` helper for cross-team collision-aware name resolution. Front 9 closure bug fixed: `buildDisplayBets` now scopes `runHoles` to segment holes (`hs`) not `ALL18_H` — `holesLeft` now correctly reaches 0 within Front 9 so `matchOver` fires and status shows `3&2` not `4UP`. Landscape `allRows18` stores `leadStateFront`/`leadStateBack` scoped to 9-hole ranges for correct F9/B9 status columns. Nassau_Match_Contract.md → v2.4._

_Last updated: April 2026 — Session 11-A complete: Dots (Specials) full rework across three phases. Phase 1: Dots_Contract.md v2.0 — data model (`pts`→`value`), display split (DotsTable + DotBadge), full Specials→Dots rename, retroactive autoMark scan. Phase 2: 12 files modified, DotsPopup.jsx + DotsTable.jsx added, SpecialsCard/SpecialsPopup deleted; migration shims in roundLib.migrateRecord. Phase 3: discrete scoring specials (ace/condor/albatross/eagle/birdie, mutually exclusive), popup redesign, pivot summary tile, PALE_YELLOW token; Dots_Contract.md → v2.1; App_Data_Model_Contract.md → v2.5. Pending on-device test + bulk round migration before shim removal._

_Last updated: April 2026 — Session 10-B complete (continued): Share image overhauled (Item 1). Root cause of modal share failure was `buildShareImage` missing from `RoundSummaryModal.jsx` import line. Fixed. Share image now uses SVG foreignObject exclusively — Canvas 2D fallback removed entirely. Logo fetched fresh on each share tap via fetch→FileReader. iOS Safari does not render `<img>` tags inside SVG foreignObject — logo is drawn directly onto the canvas after the foreignObject renders via `ctx.drawImage()`. Visual improvements: green header matches ScorecardPage exactly; player chips in separate mint strip below header; Stroke Index row added to scorecard; ESC row removed from scorecard; scorecard totals chip row added (gross large, ESC small); three primary section labels use 32px top margin + 2px green underline; payouts hierarchy: Overall = dark green header card, By Game = grey secondary label, per-game sections = mid-green headers; Nines F9/B9/18 zero rows suppressed. Files changed: `roundUtils.js`, `RoundSummaryModal.jsx`._

_Last updated: April 2026 — Session 10-B complete: Item 2 (logo heights + header consistency) — all pages now use `padding:'8px 16px 7px'` and `height:58` lockup logo. Item 3 (landscape full-width scorecard + game tables) — root cause was `App.jsx` wrapper `maxWidth:520` constraining all pages; fixed with `isLandscape` state in `App.jsx`. `MatchNassauTable` now supports `isLandscape` with 18-hole combined table. Item 4 (Courses triangles) — removed. On-device confirmed ✅._

_Last updated: April 2026 — Session 10-A complete ✅ confirmed on device (via 10-B): Item 2 (RoundSummaryModal round totals) — `TotalsCard` now renders below the scorecard grid inside `RoundSummaryModal`. Item 3 (ESC/Net Double Bogey) — `escTotal()` added to `handicap.js`; `TotalsCard` now shows gross + ESC for every player. Contract updated: `Handicap_Contract.md` → v1.5._

_Last updated: April 2026 — Session 1-C complete: C-1 score cell shift fixed (`display: 'block'` on all score inputs) ✅; C-2 DotsPopup iOS copy/paste callout fixed (`userSelect: 'none'` on popup inner card) ✅; E-1 deferred — Specials scoring/display rework planned as dedicated session._

_Last updated: April 2026 — Session 9 complete: PWA implemented — manifest.json, sw.js, updated index.html + main.jsx. Logo files replaced with square PNGs. App installable on iPhone home screen ✅._

_Session 8 complete: CoursesPage.jsx full extraction — CourseCard, CourseMergeModal, ManualCourseModal, PhotoImportModal, CourseSearchModal. normCourseName/likelySameCourse/diffCourses moved to courseLib.js. Confirmed on device ✅._

_Session 7 confirmed: `src/constants/layout.js` created; `PlayerPickerPopup.jsx` extracted ✅; `MatchCard.jsx` extracted ✅; `GameConfig.jsx` extracted ✅; `NewRoundPage.jsx` reduced from 1,360 → 592 lines ✅. On-device confirmed._

_Session 6 confirmed on device ✅: Nav bar always visible on all pages ✅; TheCardIcon logo super-tab center button ✅; gold dot on in-progress round ✅; scroll-to-top on every tab change ✅; Scorecard ← Setup|Discard|Results → pinned action bar ✅; Results ← Scorecard|Save Round|Share pinned action bar (equal-width buttons) ✅; PlayerPickerPopup Cancel/Confirm pinned to sheet bottom ✅; dividing line between scorecard and Round Totals chips removed ✅._

_Session 5 confirmed on device ✅: Full visual reskin deployed across all pages. Logo JPEGs integrated. All emojis replaced with SVG icons. Consistent mint background. New header pattern on all pages. Swipe strip redesigned. Player chips moved out of Results header._

_Session 4 confirmed working: B-3 all three back-to-setup paths populate correctly ✅; S-4 share sheet opens with PNG attached via iOS native share sheet from RoundSummaryModal ✅, ResultsPage ✅, HistoryPage swipe strip ✅._

_Session 3 confirmed working: R-1 per-match payout breakdown on ResultsPage ✅; R-2 no emojis in game labels ✅; R-3 named nine labels in portrait scorecard ✅; R-4 HomePage recent round tap opens RoundSummaryModal ✅; R-5 player chips in green header with stacked layout ✅._

_Session 2 confirmed working: swipe-left strip with real-time finger tracking ✅; right-swipe closes ✅; one strip at a time ✅; full-swipe (90%) delete ✅; tap opens RoundSummaryModal ✅; modal shows scorecard + game tables + payouts ✅; landscape scorecard 18-hole single row ✅; landscape modal full-width ✅; landscape game tables 18-hole ✅; portrait scorecard front-over-back ✅; per-match payouts broken out individually ✅; Stroke Index gender-aware labeling ✅; player chips HI/CH/Tee order ✅; Edit restricted to most-recent-date rounds ✅; H-3 passed first time ✅._

_Session 1-B confirmed working: static snapshot integrity ✅; round reload restores all game data ✅; edit flow pre-fills correctly ✅; Save Changes (Path A) persists tee/player data ✅._

**Purpose of this document:**
- Track what is and isn't yet implemented (vs. what is specified)
- Record implementation gotchas that AI must not re-break
- Handoff context between sessions
- Open items with priority rankings (do not remove items unless confirmed tested and resolved by project owner)

For schemas, layer rules, and architecture decisions → see `ARCHITECTURE_FOUNDATIONS.md` and the contract documents.

---

## Tech Stack

- **React 18** (JSX, hooks) — no class components
- **Vite** — dev server and bundler
- **Pure CSS-in-JS** — all styles are inline JS objects; no external CSS libraries
- **localStorage** — sole persistence layer; no backend, no database
- **Netlify** — drag-and-drop `dist/` deploy

---

## Implementation Gotchas (AI must not re-break these)

### H-1: `restoreDotDefs()` required after deserialization
Any code path that reads `dots` from localStorage or from `activeRound` must call
`restoreDotDefs(dots)` before using the dot definitions. Serialization strips the
`autoWhen` functions. Skipping this call causes auto-marking to silently fail.
Renamed from `restoreAutoWhen()` in Session 11-A.

### H-2: Score inputs must use `display: 'block'`
iOS expands the height of focused inputs unless `display: 'block'` is set explicitly.
Without this, focusing a score cell shifts the entire row downward. Fixed in 1-C.
Do not remove this style from score `<input>` elements.

### H-3: `activeRound` must be a deep clone on load
`getActiveRound()` in `App.jsx` must return a parsed copy from localStorage, never
a live reference. Mutating a cached reference corrupts the stored state silently.

### H-4: Landscape detection — single source of truth in `ScorecardPage`
`isLandscape` is computed once in `ScorecardPage.jsx` and passed down as a prop to
`ScoreGrid` and all game table components. `ScoreGrid` has a local fallback detection
only for the case where the prop is not supplied (e.g. read-only summary view).
Do not add a second independent landscape detector in `ScoreGrid` — it will diverge.

### H-5: `TotalsCard` is rendered inside `ScoreGrid`, not `ScorecardPage`
`TotalsCard` is mounted at the bottom of `ScoreGrid`'s return tree, not in
`ScorecardPage`. This is intentional — it keeps all scorecard display logic
co-located. Do not move it to `ScorecardPage` without explicit owner approval.

### H-6: `StyledSel` / `PlayerDropdown` — do not create parallel picker implementations
All player picker UI and option selects in New Round setup must use `StyledSel`,
`PlayerDropdown`, or `ReadOnlyBubble` from `PlayerDropdown.jsx`. These were created
in 11-D specifically to unify picker appearance. A second custom select component
anywhere in setup UI is a violation of this pattern.

### H-7: Name display convention — always first + last, no collision detection
The final convention (established post-11-D) is: always show first name (larger,
darker) + last name (smaller, lighter) unconditionally. `resolveDisplayNames` was
removed from most consumers after this decision. Do not reintroduce collision-aware
logic or first-name-only display without explicit owner approval.

### H-8: `GAME_CONFIGS` is static — `betType` is never stored in round state
`betType` is a UI dispatch concept that lives only in the static `GAME_CONFIGS`
constant in `NewRoundPage.jsx` (created in 11-I.1). It must never appear in
`gameOpts`, `activeRound`, or any persisted state. The game key (e.g. `'Match'`,
`'Skins'`) implies the allowed betting models — they do not need to be stored.
Adding `betType` to `gameOpts` is a contract violation.

### H-9: Nassau terminology is retired from all user-facing surfaces
As of 11-I, the word "Nassau" must not appear in any UI label, button, toggle,
game tile, or payout display. The behavior formerly called "Nassau" is exposed as
Front/Back/Overall bet fields. Code comments may retain the word for historical
clarity. Do not reintroduce "Nassau" as a UI term without explicit owner approval.

### H-10: NOL dot selector — `subsetIdxs` is authoritative, never parse `nolDotGame` value
`nolDotGame` state value can be a single-game string (`'Skins'`), a match ID
(`'Match:m_123'`), or a fingerprint string (`'1,2,3'`) when games share a subset.
`ScorecardPage` always derives `effectiveMinCourseHcp` and `nonParticipantIdxs` from
`opt.subsetIdxs` — never by parsing or inspecting the value string beyond identity
comparison (`o.value === nolDotGame`). Do not add value-string parsing logic anywhere.

### H-11: Center nav button from setup tab triggers `handleStart`, not a direct tab switch
As of 11-K, `handleCenterTap` in `App.jsx` calls `startTriggerRef.current?.()` when
`inProgress && tab === 'new-round'`. This runs the full round re-assembly (same as
"Start Scoring"), committing any game config changes to `activeRound` before the
scorecard mounts. The ref is kept current via a no-dep-array `useEffect` in
`NewRoundPage`. Do not change this back to a direct `setTab('scorecard')` call —
doing so breaks the NOL pill reset and reverts the `manualPresses` preservation fix.

### H-12: Stableford `opts.scoring` field — do not use as `grossNetNOL` fallback
As of 11-L, `gameOpts.Stableford.scoring` holds the team hole-scoring rule
(`'cumulative'` | `'bestball'`), not a handicap mode value. The generic fallback chain
`o.grossNetNOL ?? o.scoring ?? default` used by all other games must **not** be applied
to Stableford — it would corrupt `grossNetNOL` to `'cumulative'` whenever team mode is
active. `Stableford: 'net'` is explicitly listed in `GNL_DEFAULTS` in both
`NewRoundPage.allOpts` and `App.jsx getActiveRound` to short-circuit the fallback.
`payouts.js` and `StablefordTable` read `mode` as `grossNetNOL ?? 'net'` only (no
`scoring` fallback). Do not reintroduce `?? o.scoring` for Stableford at any read site.

### H-13: `'X'` is a valid score value — do not sanitize it away
`scores[h][i]` may contain `'X'` (player picked up). The score normalization guard
that sanitizes invalid values to `''` must explicitly pass `'X'` through as valid.
Sanitizing `'X'` to `''` silently converts a deliberate pickup into a missing score,
breaking payout calculations. `'X'` is never stored as `'7X'` — the computed gross
value is derived at render time via `xGrossScore()`. Do not persist display strings.

### H-14: System keyboard must never appear during score entry
`ScoreKeypad.jsx` is the sole score entry mechanism throughout the app. The
hidden-input / `.focus()` pattern in `ZoomModal.jsx` is retired as of 13-B. Any
code path that calls `.focus()` on a hidden input for score entry is a contract
violation. Do not reintroduce native `<input>` focus for score cells.

### H-15: `parseInt('X')` returns NaN — always check for `'X'` before parseInt
Any function that accepts a raw score from `scores[h][i]` must check `raw === 'X'`
before calling `parseInt(raw)`. `parseInt('X')` returns `NaN`, which silently
corrupts all downstream comparisons and totals. This applies to display tables
(`NinesTable`, `MatchNassauTable`) as well as engine functions. Both were fixed
in 13-B; do not regress this.

### H-16: `kpValue` is always seeded `''` — first digit always replaces committed score
When `openKeypadOnCell`, `kpAdvanceCell`, `kpRetreatCell`, or `handleKpNavigate`
sets a new active cell, `kpValue` is always initialized to `''`. The keypad treats
every cell activation as a fresh entry — the first digit replaces whatever committed
score is in the cell. Seeding `kpValue` from the committed score causes the
"15 bug" (digit appends to existing score and clamps to 15). Do not change this.

### H-17: ZoomModal is a pure display component — no keyboard machinery
`ZoomModal` contains no hidden input, no `.focus()` calls, no advance/retreat timer,
and no `onKeyDown` handler. Score entry flows entirely through ScoreGrid's keypad
state via the `onCellTap` prop. The active cell border is driven by the `activeKpCell`
prop. The `cardRef` prop attaches ScoreGrid's `zoomCardRef` to the card div so the
global `touchend` dismiss handler exempts touches inside ZoomModal. Do not add
keyboard focus logic or internal active-cell state back to ZoomModal.

### H-18: `zoomCardRef` must remain in dismiss handler exemption list
ScoreGrid's global `touchend` dismiss handler (which clears `activeKpCell`) exempts
three targets: `INPUT` elements, `kpContainerRef` (the keypad), and `zoomCardRef`
(the ZoomModal card). Removing `zoomCardRef` from this list causes tapping any
ZoomModal cell to immediately clear `activeKpCell` — the keypad closes on every
cell tap. Do not remove this exemption.

### H-19: DotsPopup saves/restores `activeKpCell` — do not bypass this
When a long-press fires, `startLongPress` saves `activeKpCellRef.current` to
`savedKpCellRef` and clears `activeKpCell` (hides keypad). When DotsPopup closes,
`onClose` restores from `savedKpCellRef`. This is how the keypad reappears on the
correct cell after DotsPopup without requiring the user to tap again. `activeKpCellRef`
is a ref mirror of `activeKpCell` state (updated via `useEffect`) — it always holds
the current value inside the `setTimeout` closure. Do not read `activeKpCell` state
directly inside `startLongPress`'s timer callback — the closure would capture a stale
value.

---

## Open Items

### Nines table display (12-B)
- D-2: "pts" label on Nines total chips
- Note: D-6 (NinesTable renders only 3-player subset) and D-7 (breakdown rows filter to subset) were completed in 11-I.1 ✅
- Priority: Medium

### Sprint 13 — remaining sessions

**13-B.2:** Keypad in ZoomModal — contract amendment only
- `ScoreKeypad_Contract.md` §3.4 needs amendment to document the final implemented
  architecture: `onCellTap` prop, `activeKpCell` prop, `cardRef` prop, `zoomCardRef`
  dismiss exemption, `savedKpCellRef` save/restore pattern
- ZoomModal is already a pure display component as of 13-B.1 — no code changes needed
- Amendment must be completed before 13-C begins

**13-C and 13-D:** blocked until 13-B.2 contract amendment complete
- `Early_Departure_Contract.md` (v1.0 DRAFT) — awaiting AUTHORITATIVE sign-off + decisions D-C1/D-C2/D-C3
- `Late_Arrival_Contract.md` (v1.0 DRAFT) — awaiting AUTHORITATIVE sign-off + decision D-D1
- Priority: High

---

## Session Roadmap

| Session | Scope | Status |
|---|---|---|
| 1-A | Round lifecycle bugs + safety guards | ✅ Complete |
| 1-B | History data integrity + edit flow | ✅ Complete |
| 2 | History UX: swipe actions, read-only summary modal, landscape mode | ✅ Complete |
| 3 | ResultsPage redesign + RoundSummaryModal polish | ✅ Complete |
| 4 | B-3 fix + Share / formatted export (PNG via iOS share sheet) | ✅ Complete |
| 5 | Visual polish + branding: logo, headers, mint bg, SVG icons, swipe strip | ✅ Complete |
| 6 | Navigation overhaul: always-visible nav, logo super-tab, pinned action bars, scroll-to-top | ✅ Complete |
| 7 | Shared layout constants + NewRoundPage extractions (PlayerPickerPopup, MatchCard, GameConfig) | ✅ Complete |
| 8 | CoursesPage full extraction: 5 components + helpers to courseLib.js | ✅ Complete |
| 9 | PWA: manifest, service worker, PNG logos, home screen install | ✅ Complete |
| 1-C | Scorecard input bugs: score cell shift (C-1), Specials popup iOS callout (C-2) | ✅ Complete |
| 10-A | RoundSummaryModal totals row + ESC (Net Double Bogey) in TotalsCard | ✅ Complete |
| 10-B | Visual regressions: header heights, logos, landscape full-width, Courses triangles, share image | ✅ Complete — all items including Item 1 (share image) confirmed |
| 11-A | Dots (Specials) full rework: contract v2.0→v2.1, full rename, DotsTable, DotsPopup, DotBadge, discrete scoring specials, mutual exclusivity, popup redesign, pivot summary, retroactive autoMark, contract updates | ✅ Complete — pending bulk round migration before shim removal |
| 11-C | D-1: Match/Nassau team hole winner display — slash-initials (C/D), colorblind-safe blue/red chips matching Sixes; color-coded header; Front 9 closure bug fixed (buildLeadState scoped to segment holes) | ✅ Complete ✅ confirmed on device |
| 11-D | resolveDisplayNames rollout + PlayerDropdown.jsx new file (PlayerDropdown, StyledSel, ReadOnlyBubble); MatchCard and GameConfig/Sixes migrated to custom pickers | ✅ Complete ✅ confirmed on device |
| 11-E | Disabled Btn style fix (ui.jsx G-5); "Net Off Low" label audit (confirmed already consistent); name display convention unified; Sixes duplicate-team prevention | ✅ Complete ✅ confirmed on device |
| 11-F | Zoom score entry modal: ZoomModal.jsx (new), hidden-input keyboard pattern, 3-hole window, stacked player names, active-cell-only border, magnifying glass button | ✅ Complete ✅ confirmed on device |
| 11-G | Planning: NOL dot display design decision; betting model architecture decision (Nassau retired → segment betting); betType as static config; GAME_CONFIGS pattern; Wolf extension point; session sequencing | ✅ Complete (planning only — no code) |
| 11-H | NewRoundPage UX/UI design spec: full game-by-game setup field inventory; shared component identification; layout decisions for dual-mode games, scoring selectors, player pickers, toggles; output: NewRoundPage_Design_Spec.md | ✅ Complete (design only — no code) |
| 11-I.1 | Contracts (all 6 game contracts amended, App_Data_Model v2.7); engine field renames (betMode, carryover boolean); migration shim; Players card rebuilt and confirmed on device; shared components built (BetRow, SimpleBetRow, ScoringDropdown, PlayerSubsetDropdown, InlineRow promoted); GameConfig/MatchCard partially rebuilt — not confirmed | ✅ Complete — Players card confirmed on device ✅; games config NOT confirmed, deferred to 11-I.2 |
| 11-I.2 | Game config UI rebuild: component-first design using owner mockups; all game config blocks (Match, Skins, Stableford, Nines, Stroke Play, Sixes, Dots) rebuilt from scratch using shared components; MatchCard final state; on-device confirmation of full 11-I testing checklist | ✅ Complete ✅ confirmed on device |
| 11-I.3 | Semantic field rename: `scoring`→`grossNetNOL` (all games), `tiebreak`→`scoring` (Sixes/Match); 10 contracts amended; 19 files updated; 4 migration shims; 3 pre-existing display bugs fixed | ✅ Complete ✅ confirmed on device |
| 11-J | Per-match instance labeling: persistent index-derived labels (Match A/B/C); Dots teamMode per-instance dropdown; Nassau terminology purged from all payout surfaces; contracts App_Data_Model v3.0, Nassau_Match v2.8 | ✅ Complete ✅ confirmed on device |
| 11-K | NOL dot selector: unified segmented pill (Net/NOL/NOL Skins/…); subset grouping by fingerprint; ZoomModal inheritance; center button → handleStart; manualPresses fix; contracts Handicap v1.6, Round_Lifecycle v1.6 | ✅ Complete ✅ confirmed on device |
| 11-L | Stableford Teams: contract v1.5; `calcTeamStablefordTotal`; team payout (perpoint/total/segments); Teams UI enabled; condor row; `'total'` betMode; total column headers renamed; tied games shown on results; `opts.scoring` collision fix | ✅ Complete ✅ confirmed on device |
| 11-N | Round totals regression: `TotalsCard` added to `RoundSummaryModal.jsx`; `totalsHtml` block added to share image in `roundUtils.js` | ✅ Complete ✅ confirmed on device |
| 11-M | Team Dots payout fix + DotsTable team layout + share image Dots pivot + portrait share report. Stale companion cleanup in `ScoreGrid.autoMark` + `DotsPopup.writeCompanion`; matchId lookup in `payouts.js` + `DotsTable`; non-team-only grid cells; Total row removed from grids; `ShareOrientationPicker` in `ui.jsx`; `deriveShareDotMode` + portrait scorecard in `roundUtils.js`; contracts Dots v2.3, UI_Component v1.3, Round_Lifecycle v1.7 | ✅ Complete ✅ confirmed on device |
| Portrait PDF share | Post-11-M incremental: portrait orientation outputs PDF (single tall page, no breaks) via `jsPDF`. `buildSharePdf` in `roundUtils.js`; `FO_WIDTH_PORTRAIT` = 390px; `package.json` + `package-lock.json` updated. Revert instructions in ASS top entries. | ✅ Confirmed on device |
| Post-11-M bug fixes | SixesTable `opts` prop fix (`RoundSummaryModal` + `roundUtils.js`); `ReadOnlyScorecard` handicap dots (abs-positioned green circles, dotMode derivation excludes Dots game); share image dots visible; Sixes pivot `pivotSegTot`; `Round_Lifecycle_Contract.md` → v1.8 | ✅ Confirmed on device |
| 11-O | Audit session: all 7 game tables in RoundSummaryModal and share image confirmed correctly wired; C-10 nine labels confirmed; B-8 lock/unlock in HistoryPage | ✅ Complete ✅ confirmed on device |
| 13-A | Planning session: custom keypad design, X score type, early departure model, late arrival model. Output: ScoreKeypad_Contract.md (DRAFT), Early_Departure_Contract.md (DRAFT), Late_Arrival_Contract.md (DRAFT) | ✅ Complete (planning only — no code) |
| 13-B | Custom keypad + X score type: `ScoreKeypad.jsx` (new, 4-row fixed-bottom overlay); `'X'` score type across engine/display/contracts; ZoomModal rebuilt as pure display component; discard bug fix; `NinesTable`/`MatchNassauTable` X handling; `ScoreKeypad_Contract.md` → v2.1 AUTHORITATIVE; 11 contracts amended | ✅ Complete ✅ confirmed on device |
| 13-B.1 | ZoomModal event isolation + pre-13 bug fixes: touch isolation on ZoomModal/DotsPopup; HI/tee/CH persistence (Bug A); Sixes autopress (Bug B); Match autopress (Bug C); tee blank-on-new-round; ZoomModal pure display with onCellTap/cardRef/zoomCardRef/savedKpCellRef patterns | ✅ Complete ✅ confirmed on device |
| 13-B.2 | ScoreKeypad_Contract.md §3.4 amendment to document final ZoomModal architecture — no code changes needed | 🔲 Not started |

---

## Document Index

| Document | Purpose |
|---|---|
| `ARCHITECTURE_FOUNDATIONS.md` | Mental models, layer system, the "why" |
| `App_Data_Model_Contract.md` (v3.1 + 13-B amendments) | State schema, storage keys, mutation rules — `betMode` field, `carryover` boolean, `GAME_CONFIGS` constant, `grossNetNOL` replaces `scoring`, `tiebreak` expanded → renamed to `scoring` in Sixes/Match; Dots `teamMode` expanded to `'Match:{matchId}'`; v3.1: `gameOpts.Stableford` team fields (`format`, `teamA`, `teamB`, `scoring`), `betMode` gains `'total'`, `stabTable` key range extended to `'4'` (condor); 13-B: §5.6 `scores[h][i]` valid values updated to include `'X'`; invariants #8/#9 added (`'X'` not sanitized; `'X'` never stored as `'NX'`) |
| `Handicap_Contract.md` (v1.6 + 13-B amendments) | USGA math, `scoreForMode`, `escTotal`, `DEFAULT_STAB`, NOL+subset invariant §5; v1.6 adds §5.6–§5.14: unified NOL dot selector pill spec, qualifying rule, subset grouping by fingerprint, `nolDotGame` state, ZoomModal inheritance, `computeNolDotOptions` helper; 13-B adds §5.14 X handling in `escTotal`, §5.15 `xGrossScore()` spec, arch boundary update, invariants #15–#17 |
| `Payout_Contract.md` (v1.11) | `computePayouts` entry point, `subsetMin` pattern, per-game payout logic; all field reads updated for `grossNetNOL`/`scoring` rename; v1.11: §4.4 X score handling (X always loses invariant, Infinity/sentinel/filter patterns per game, Stroke Play exception, `parseInt('X')` prohibition), global invariants #12–#13 |
| `Nassau_Match_Contract.md` (v2.8 + 13-B) | Nassau/Match Play rules, press system, engine API, §13 hole winner cell display, §16 setup UI vocabulary, `'cumulative'` scoring rule; `grossNetNOL`+`scoring` rename; §5.6 match instance label spec; §16.3 Dots teamMode per-instance dropdown; 13-B: X score behavior section added |
| `Sixes_Contract.md` (v1.9 + 13-B) | Sixes team rotation, hole scoring, press system, payout rules, `'cumulative'` scoring rule; `grossNetNOL`+`scoring` rename; 13-B: X score behavior section added |
| `Skins_Contract.md` (v1.6 + 13-B) | Skins carryover rules (boolean), subset behavior, engine API, payout pool formula; `grossNetNOL` rename; 13-B: X score behavior section added |
| `Stableford_Contract.md` (v1.5 + 13-B) | Stableford points table, `betMode` perpoint/total/segments, subset/NOL rules; condor key `'4'` default 6 pts, clamp `[-3,4]`; team format: `'cumulative'`/`'bestball'` scoring rule, team payout (per-player full-rate settlement), `calcTeamStablefordTotal` spec; `grossNetNOL` rename; `opts.scoring` collision gotcha documented in H-12; 13-B: X score behavior section added |
| `Nines_Contract.md` (v1.4 + 13-B) | Nines point table, `betMode` perpoint/segments, blitz rule, 3-player constraint; `grossNetNOL` rename; 13-B: X score behavior section added (1X→1pt, 2X→2pts each, 3X→3pts each) |
| `Dots_Contract.md` (v2.3 + 13-B) | Dots/Junk: `DOTS_DEF`, discrete scoring specials, mutual exclusivity, `value` field, `dotEntries`, `DotsTable` pivot spec, popup interaction, migration shims, payout, teamMode; `grossNetNOL` rename; v2.3: team payout exclusion rule (§7.6), per-segment breakdown columns (§7.7), DotsTable team layout spec (§10.5–§10.6), worked examples §15.6–§15.7; 13-B: X score behavior section added (no auto-mark on X holes) |
| `Round_Lifecycle_Contract.md` (v1.8 + 13-B amendments) | Setup→score→save flow, activeRound lifecycle, §6.5 share: orientation picker, portrait PDF (390px jsPDF single page), `deriveShareDotMode` rules, `ReadOnlyScorecard` handicap dots spec (rule 8), `SixesTable` `opts` prop invariant (rule 9); 13-B: §12 invariant #3 updated to include `'X'` as valid score value with no-sanitize rule |
| `Stroke_Play_Contract.md` (v1.6 + 13-B) | Stroke play `betMode` total/segments, `strokePlayPlayers` subset, `calcStrokePlay`; `grossNetNOL` rename; G-1 closed; 13-B: X score behavior section added (X not valid in stroke play — treated as unscored) |
| `UI_Component_Contract.md` (v1.3) | `ui.jsx` tokens, all components, `style` prop pattern; v1.3: §4.9 `ShareOrientationPicker` — bottom-sheet orientation picker, `onPick`/`onDismiss` props, usage pattern for all three share surfaces |
| `ScoreKeypad_Contract.md` (v2.1 AUTHORITATIVE) | Custom keypad: 4-row fixed-bottom overlay (nav row removed in v2.1); `ScoreGrid` owns all keypad state; ZoomModal is pure display; X score type: `xGrossScore()`, "X always loses" invariant, per-game X behavior, Nines X point distribution; display table X handling (`NinesTable`, `MatchNassauTable`); amendments required to all 11 contracts documented |
| `Early_Departure_Contract.md` (v1.0 DRAFT) | Early departure model: one player leaves (Scenario A) or all stop (Scenario B); departure detection heuristic (contiguous trailing empty = departure, scattered = missing scores); resolver sheet with per-game options (Pay / Abandon / Remove player); `earlyDepartureOpts` field; long-press X proactive entry; Results → reactive entry; per-game rules for all 7 games |
| `Late_Arrival_Contract.md` (v1.0 DRAFT) | Late arrival model: append-only player addition preserves scores; `playerJoinHoles[]` field; `gameHoleRanges{}` field; "Starts on hole" picker in GameConfig (in-progress only); universal eligibility rule; Nines fresh-start rotation at non-zero start; Sixes segment discard rule; Nassau midpoint segment split for non-standard ranges |
| `APP_STATE_SUMMARY.md` (this file) | Status, gotcha, open items, session handoff |
| `handoff_11I1.md` | 11-I.1 → 11-I.2 handoff: files changed, Players card state, shared components, gameOpts schema, migration shim, what was not built, gotchas |
| `handoff_11I2.md` | 11-I.2 prep handoff: design decisions, component architecture, visual system constraints, Sixes/Match tiebreak mechanic, 11-I.3 rename spec (now superseded — 11-I.3 complete) |
