# Partial Game Contract

_Version 1.4 DRAFT — April 2026_
_Status: DRAFT — requires owner review and approval before any implementation code is written._
_Changes in v1.4: §1.2 build order updated — round length is now the first build step;
§1.3 session plan updated — 13-C.2 (Round Length) inserted before former 13-C.2
(now 13-C.3), all subsequent sessions renumbered; §1A (new) — Round Length concept
documented; §4.1 data model adds `roundStartHole` and `roundNumHoles`; §4.4
`buildPayoutArgs` updated; §4.5 `roundLib` updated; §2 game range defaults changed
from hardcoded `[0,17]` to `[roundStartHole, roundEndHole]`; §2.4 ScoreGrid updated
to show `roundNumHoles` columns only; §5.2 classification updated — Complete defined
relative to `roundEndHole` not `highWaterMark`; §5.1 Scenario B proactive entry
clarified — Results → tap is the end-round gesture, always tappable including
mid-round for current standings; §5.4 Scenario A corrected — `lastCompletedHole`
and remaining players' boundary both use `roundEndHole` (not ambiguous `endHole`);
§13 backward compatibility updated; §14 invariants updated; §15 open items updated._
_Changes in v1.3: §7.1 duplicate closed-definition bullet removed; §7.2 front segment
complete formula clarified; §15 D-1 removed; §5.4 Scenario A lastCompletedHole
corrected to endHole (further corrected to roundEndHole in v1.4)._
_Changes in v1.1: §6.1 `exclude_player` restored with correct availability rules and two-player
guard; §6.3 press independence — presses evaluated independently with their own Pay/Abandon
toggles; §7.1 Match/Sixes clinch-segment family updated to reflect press independence;
§10.1 resolver sheet UI updated to show presses as independent rows; §11.1 engine firewall
invariant added — `games.js` and `handicap.js` are never touched; §11.7/§11.8 press
independence rules updated; §14 invariants updated; §1.3 session plan added._
_Supersedes: `Early_Departure_Contract.md` (v1.0 DRAFT) and `Late_Arrival_Contract.md`
(v1.0 DRAFT) in their entirety._
_All implementation must conform to this contract once marked AUTHORITATIVE._
_If code conflicts with this contract, the contract wins._

---

**Primary files:**
`App.jsx`, `ScorecardPage.jsx`, `ScoreGrid.jsx`, `NewRoundPage.jsx`, `GameConfig.jsx`,
`payouts.js`, `roundLib.js`, `roundUtils.js`, `RoundSummaryModal.jsx`

**Files explicitly NOT modified by this contract:**
`games.js`, `handicap.js` — engine functions are range-unaware and departure-unaware by design.
See §11.1 (Engine Firewall).

**Contract amendments required when this contract reaches AUTHORITATIVE:**
- `Sixes_Contract.md` — segment length generalized from hardcoded 6 to `rangeLength / 3`
- `Round_Lifecycle_Contract.md` — §4.5–4.7 superseded by this contract
- `App_Data_Model_Contract.md` — new fields in §5 (`roundStartHole`, `roundNumHoles`,
  `gameRanges`, `earlyDepartureOpts`, `playerJoinHoles`); `buildPayoutArgs` shape in §10

**Cross-references:**
- `App_Data_Model_Contract.md` §5 — `activeRound` blob (new fields added here)
- `Payout_Contract.md` §2 — `computePayouts` entry point
- `Round_Lifecycle_Contract.md` §4 — round lifecycle (§4.5–4.7 superseded by this contract)
- `ScoreKeypad_Contract.md` §5 — long-press X triggers departure resolver
- `Nassau_Match_Contract.md` — Match segment and press definitions
- `Sixes_Contract.md` — Sixes segment definitions (segment length amendment required)
- `Nines_Contract.md` — Nines bet modes
- All other game contracts — per-game behavior

---

## §1. Core Concept — Game Ranges

### §1.1 Every game has a hole range

Every active game in a round has an effective hole range `[startHole, endHole]`
(both 0-based inclusive). The engine computes the game only over this range.

**Default:** `startHole = 0`, `endHole = 17` (full 18 holes).

A non-default range arises from one of three sources:

| Source | When known | startHole | endHole |
|---|---|---|---|
| **Predetermined range** | At round setup | Any hole | Any hole ≤ 17 |
| **Mid-round game start** | When game/player is added | > 0 | 17 (or predetermined) |
| **Early departure** | At runtime (player leaves or group stops) | 0 (or predetermined start) | Discovered at runtime |

All three sources write to the same data model fields (§4). The engine
is range-agnostic — it always receives pre-processed inputs trimmed to
the effective range. See §11.1.

### §1.2 Build order

These features share the same engine foundation and must be built in order:

1. **Round length** — `roundStartHole` + `roundNumHoles` establish the round boundary;
   all other features depend on this baseline
2. **Predetermined game ranges** — per-game overrides within the round boundary
3. **Mid-round game start** — known at add-time; extends range concept to non-zero starts
4. **Early departure** — runtime-discovered end hole; resolver UI on top of engine foundation

No feature in this list may be implemented before the prior feature's engine
support is complete and confirmed on device.

### §1.3 Session plan

| Session | Type | Content |
|---|---|---|
| **13-C** | Planning + Contract | Full walkthrough; `PartialGameContract.md` drafted and approved |
| **13-C.2** | Build | Round length — `roundStartHole` + `roundNumHoles` fields, NewRoundPage pickers, ScoreGrid column count, Results → classification boundary, game range defaults |
| **13-C.3** | Build | Predetermined game ranges — `gameRanges` data model, `payouts.js` pre-processing layer, `GameConfig` range picker UI, game table column trimming, `buildPayoutArgs` changes |
| **13-C.4** | Build | Mid-round game start — `playerJoinHoles`, eligibility logic, Nines rotation, Sixes dynamic segments, Nassau midpoint |
| **13-C.5** | Planning | Resolver UI design — `DepartureResolverSheet` spec, `BetPillRow` props, press independence rows, clinch detection algorithm, close G-1 through G-4 |
| **13-C.6** | Build | Early departure proactive entry — long-press X flow, `DepartureResolverSheet`, locked cells, undo |
| **13-C.7** | Build | Early departure reactive entry — Results → gate, classification logic, Scenario A/B/combined |
| **13-C.8** | Build | Engine departure handling in `payouts.js` — `end_at_k`, `continue`, `exclude_player`, segment Pay/Abandon, press independence, `RoundSummaryModal` display |

---

## §1A. Round Length

### §1A.1 Concept

Every round has a defined length — a start hole and a number of holes to play.
This is set at round setup and establishes the boundary for all game ranges,
completion detection, and ScoreGrid display.

**Default:** Start hole 1, 18 holes (`roundStartHole = 0`, `roundNumHoles = 18`).

**Examples:**
- Standard round: start hole 1, 18 holes
- Front 9 only: start hole 1, 9 holes
- Back 9 only: start hole 10, 9 holes
- Partial round: start hole 1, 12 holes
- Mid-course start: start hole 4, 9 holes

### §1A.2 UI — round length pickers

Two fields in `NewRoundPage` (alongside course, players, tees):
- **Start hole:** numeric entry, 1–18 (displayed 1-based; stored 0-based)
- **Number of holes:** numeric entry, 3–18

Validation: `(startHole + numHoles - 1) <= 17` — the round cannot run off
the end of the course.

Defaults: Start hole 1, 18 holes. Both fields are always shown — not optional.

### §1A.3 Derived value

`roundEndHole = roundStartHole + roundNumHoles - 1` (0-based).
This is always derived and never stored.

### §1A.4 Effect on game ranges

All game ranges default to `[roundStartHole, roundEndHole]`. Per-game overrides
(§2) must satisfy `game.startHole >= roundStartHole` and
`game.endHole <= roundEndHole`. A game range can never extend beyond the round.

### §1A.5 Effect on ScoreGrid

ScoreGrid shows exactly `roundNumHoles` columns, starting at `roundStartHole`.
Holes outside the round are not shown in the score entry grid.

### §1A.6 Effect on Results →

Results → is always tappable — including mid-round, where it shows current
standings based on holes scored so far.

Classification of "Complete" is relative to `roundEndHole`:
- A player is **Complete** when they have a non-empty score on every hole from
  `roundStartHole` through `roundEndHole`.
- A player is **Early departure** when they have scores through some hole `k`
  (where `roundStartHole <= k < roundEndHole`), then all empty after `k`.
- A player has **Missing scores** when they have scattered empty holes within
  `[roundStartHole, roundEndHole]`.

When all players are Complete (through `roundEndHole`), Results → computes
payouts normally — no resolver needed, even if the round was shorter than 18 holes.

### §1A.7 Backward compatibility

`roundStartHole` absent → 0 (hole 1).
`roundNumHoles` absent → 18.
Old saved rounds load correctly with full 18-hole behavior.

---

## §2. Predetermined Game Ranges

### §2.1 Overview

At round setup (`NewRoundPage`), the user may optionally configure a game to
cover a hole range shorter than the round length. All games default to the
full round range `[roundStartHole, roundEndHole]` (§1A.4). Per-game ranges
are restrictions within the round — they can be shorter but never longer.

Examples (assuming a standard 18-hole round starting hole 1):
- Match covering only front 9: `startHole = 0, endHole = 8`
- Stableford covering holes 1–12: `startHole = 0, endHole = 11`
- Skins covering back 9 only: `startHole = 9, endHole = 17`
- 9-hole Sixes / "Threes" (within a 9-hole round): inherits `[0, 8]` by default

The range is set once at setup and does not change during the round
(unless subsequently modified by early departure).

### §2.2 UI — range picker

An optional "Start hole" and "End hole" picker is available in `GameConfig`
for each game. Both default to the round's start and end holes respectively.
If left at defaults, no entry is written to `gameRanges` — the game uses the
round range automatically.

Validation rules:
- `game.startHole >= roundStartHole`
- `game.endHole <= roundEndHole`
- `game.startHole < game.endHole`
- Minimum range: 3 holes (`game.endHole - game.startHole >= 2`)
- Range must satisfy the game's structural requirements (see §6 per-game rules and §16 G-4)

### §2.3 Engine behavior

`payouts.js` pre-processes scores and inputs to the effective range before
calling any engine function. The engine functions in `games.js` receive
only the holes within `[startHole, endHole]` and are unaware a range exists.
See §11.1.

### §2.4 Display — ScoreGrid, ZoomModal, game tables, round summaries

**ScoreGrid and ZoomModal:** Show exactly `roundNumHoles` columns starting
at `roundStartHole`. Holes outside the round are not shown. Score entry is
not restricted within the round — all holes in `[roundStartHole, roundEndHole]`
are always scoreable. Per-game ranges are not visually distinguished in the
score entry grid — the grid is a scoring surface, not a game display surface.

**Game tables (in-round and RoundSummaryModal):** Each game table renders
only the columns for holes within its `[startHole, endHole]` range. Holes
outside the range are not shown — the table is trimmed to the game's range.
Column headers, totals columns, and all row data reflect the trimmed range.

**ReadOnlyScorecard (RoundSummaryModal and share image):** Shows `–` for
holes outside any player's effective range. See §5.5 for the full `–`
display rule.

---

## §3. Mid-Round Game Start

### §3.1 Overview

A game may be added after hole 1 has been played. The game's `startHole`
is the current hole at the time the game is added. All scoring before
`startHole` is ignored for this game.

### §3.2 Player eligibility

All players in the round at the time the game is added are eligible
participants. The universal eligibility rule: a player participates in
a game only for holes where both the player and the game are active.

Effective hole range for any player `i` in any game:
```
playerGameStart = max(game.startHole, player.joinHole ?? 0)
playerGameEnd   = min(game.endHole,   player.departureHole ?? roundEndHole)
```

### §3.3 Data model

`playerJoinHoles: { [playerIdx]: number }` — 0-based hole index where each
late-arriving player joined. Absent or 0 = joined at hole 0.

Set in `NewRoundPage` when a player is added mid-round. Preserved through
`fromActiveRound` / `toActiveRound`.

### §3.4 Nines fresh-start rotation

When Nines starts on a hole other than 0, the point rotation begins fresh
from that hole. The rotation is not influenced by prior holes.

### §3.5 Sixes dynamic segment alignment

Sixes always has exactly **three equal segments**. Segment length is
determined by the game's range:

```
rangeLength  = endHole - startHole + 1
segLength    = rangeLength / 3          // must be a whole number — see §16 G-4
Segment 0:   startHole               to  startHole + segLength - 1
Segment 1:   startHole + segLength   to  startHole + (segLength * 2) - 1
Segment 2:   startHole + (segLength * 2)  to  endHole
```

For a standard full round: `rangeLength = 18`, `segLength = 6`
(holes 0–5, 6–11, 12–17 — the existing "Sixes" behavior, unchanged).

For a 9-hole round: `rangeLength = 9`, `segLength = 3`
(holes 0–2, 3–5, 6–8 — "Threes").

**Amendment note:** `Sixes_Contract.md` must be amended to replace the
hardcoded 6-hole segment length with this dynamic formula. The existing
engine behavior for full 18-hole rounds is unchanged — `segLength = 6`
remains the standard case.

### §3.6 Nassau midpoint for non-standard ranges

For Match games with non-standard ranges, Front and Back segments are
split at the midpoint of the game's range:
```
totalHoles = endHole - startHole + 1
midHole    = startHole + floor(totalHoles / 2)
Front:     startHole  to  midHole - 1
Back:      midHole    to  endHole
```

---

## §4. Data Model

### §4.1 New fields in `activeRound`

```js
activeRound: {
  // NEW — round-level length definition
  // Absent = start hole 0, 18 holes (full round, backward compatible)
  roundStartHole: number | undefined,   // 0-based, default 0
  roundNumHoles:  number | undefined,   // default 18
  // roundEndHole = roundStartHole + roundNumHoles - 1 (derived, never stored)

  // NEW — game-level range overrides within the round boundary
  // Absent = all games use [roundStartHole, roundEndHole]
  gameRanges: {
    [gameKey: string]: {
      startHole: number,   // 0-based; >= roundStartHole
      endHole:   number,   // 0-based; <= roundEndHole
    }
  } | undefined,

  // NEW — per-player departure data (Scenario A: one or more players leave early)
  // Absent = no departures
  earlyDepartureOpts: {
    [playerIdx: number]: {
      departureHole: number,        // 0-based — last hole this player actually scored
      gameResolutions: {
        [gameKey: string]: SegmentedResolution
      }
    }
  } | undefined,

  // EXISTING — unchanged semantics; now also set by departure resolver
  // Set for Scenario B (all players stop early)
  lastCompletedHole: number | undefined,   // 0-based, default 17
  earlyEndOpts: {
    [gameKey: string]: SegmentedResolution
  } | undefined,

  // NEW — per-player join holes (mid-round arrivals)
  playerJoinHoles: {
    [playerIdx: number]: number   // 0-based hole index where player joined
  } | undefined,
}
```

### §4.2 SegmentedResolution type

```js
type GameResolution =
  | 'abandon'          // $0 for all — game is voided
  | 'end_at_k'         // compute over holes played; departed player included
  | 'exclude_player'   // remove departed player retroactively from startHole
  | 'continue'         // remaining players continue; departed player's X scores stand

type SegmentedResolution = {
  topLevel: GameResolution,

  // Independent Pay/Abandon per segment — only present when topLevel = 'end_at_k'
  // and game has segment structure. Default 'pay' for all.
  segments?: {
    front?:   'pay' | 'abandon',
    back?:    'pay' | 'abandon',
    overall?: 'pay' | 'abandon',
    // Sixes only (seg0/seg1/seg2 regardless of segment length):
    seg0?:    'pay' | 'abandon',
    seg1?:    'pay' | 'abandon',
    seg2?:    'pay' | 'abandon',
  },

  // Independent Pay/Abandon per press — keyed by press trigger hole (0-based).
  // Only present when topLevel = 'end_at_k' and game has presses.
  // Default 'pay'. Not-started presses automatically 'abandon' (not stored).
  presses?: {
    [triggerHole: number]: 'pay' | 'abandon'
  }
}
```

**Press independence rule:** Every press is an independent bet with its own
Pay/Abandon toggle. A press may be in progress while its parent segment is
closed, or vice versa. No automatic inheritance between a press and its
parent segment.

### §4.3 `gameKey` rules

Keys in `gameRanges`, `earlyEndOpts`, and `earlyDepartureOpts.gameResolutions`
must exactly match `activeGames[]` entries. For multi-instance Match,
key = `matchDef.id`. Identical to the existing `earlyEndOpts` key rule.

### §4.4 `buildPayoutArgs` changes

New fields added to `buildPayoutArgs` output in `roundUtils.js`:
```js
{
  roundStartHole:      ar.roundStartHole      ?? 0,
  roundNumHoles:       ar.roundNumHoles       ?? 18,
  // roundEndHole derived: roundStartHole + roundNumHoles - 1
  gameRanges:          ar.gameRanges          ?? {},
  earlyDepartureOpts:  ar.earlyDepartureOpts  ?? {},
  playerJoinHoles:     ar.playerJoinHoles     ?? {},
  // lastCompletedHole and earlyEndOpts already present (existing)
}
```

### §4.5 `roundLib` changes

`fromActiveRound` must include `roundStartHole`, `roundNumHoles`, `gameRanges`,
`earlyDepartureOpts`, and `playerJoinHoles` in the history record.

`toActiveRound` must restore all five fields, defaulting to `undefined`
if absent in old records — backward compatible (§1A.7 defaults apply).

---

## §5. Detection and Classification (Early Departure)

### §5.1 When departure is detected

Two entry points:

**Entry point 1 — Long-press X (proactive — Scenario A only):**
User long-presses X on a score cell during scoring — signals that specific
player is done for the round, not just picking up on this hole. See §8.
This entry point handles one player leaving; it does not end the round
for everyone.

**Entry point 2 — Results → tap (proactive and reactive — all scenarios):**
Results → is always tappable. When tapped mid-round it shows current standings.
When scores are incomplete relative to `roundEndHole`, the classification logic
runs (§5.2) and the resolver appears if needed. This is both the proactive
"end round now for everyone" gesture (Scenario B) and the reactive entry point
for any departure scenario. See §9.

### §5.2 Classifying players at Results →

When Results transition is attempted and scores are incomplete, each player
is classified as:

| Class | Definition |
|---|---|
| **Complete** | Has a non-empty score on every hole from `roundStartHole` through `roundEndHole` |
| **Early departure** | Has scores through hole `k`, then all empty after `k` (contiguous trailing block) |
| **Missing scores** | Has at least one empty hole NOT in a contiguous trailing block |

**`roundEndHole`:** The expected last hole of the round = `roundStartHole + roundNumHoles - 1`.
This is the authoritative completion boundary.

**`highWaterMark`:** Highest hole index (within the round) where any player has
a non-empty score. Used to detect where a Scenario B group stopped — not used
to define "complete."

**Classification logic:**
```
roundEndHole = roundStartHole + roundNumHoles - 1

For each player i:
  lastScored[i]    = max hole h in [roundStartHole, roundEndHole]
                     where scores[h][i] is non-empty (real or X)
                     (-1 if no scores exist)
  trailingEmpty[i] = all holes from lastScored[i]+1 through roundEndHole are empty

  if lastScored[i] === roundEndHole    → Complete
  elif trailingEmpty[i] === true        → Early departure (left after lastScored[i])
  else                                  → Missing scores
```

### §5.3 Routing based on classification

| Situation | App behavior |
|---|---|
| All players Complete | Normal Results flow — no resolver |
| All players Early departure at same hole before `roundEndHole` | Scenario B resolver |
| All players Early departure at different holes | Scenario B resolver; `lastCompletedHole` = lowest `lastScored` |
| One or more players Early departure, rest Complete | Scenario A resolver (named player(s)) |
| Any player has Missing scores | Block Results — list which holes. No resolver. |
| Mix of Missing scores and Early departure | Block with Missing scores error. Must fix first. |

### §5.4 Scenario definitions

**Scenario A — One player (or subset) leaves early:**
Remaining players continue to `roundEndHole`.
`earlyDepartureOpts` set for departed player(s). `lastCompletedHole`
remains `roundEndHole`.

**Scenario B — All players stop early:**
Round ends for everyone. `lastCompletedHole` set to stop hole.
`earlyEndOpts` set per game.

**Scenario A + B combined:**
A player departs AND remaining players also stop early.
Both `earlyDepartureOpts` and `lastCompletedHole` / `earlyEndOpts` are set.

### §5.5 `–` display rule for unplayed holes

The `–` character is the authoritative display value for any hole a player
did not play. It is distinct from:
- A real score (numeric) — player played the hole
- `X` — player played the hole but picked up (ball in hand)
- Blank — score not yet entered (data entry in progress)

`–` is displayed in the following cases:

| Case | Where shown |
|---|---|
| Hole after `departureHole` for a departed player | ScoreGrid (locked cell), ReadOnlyScorecard, game tables |
| Hole after `lastCompletedHole` for any player (Scenario B) | ReadOnlyScorecard, game tables |
| Hole outside a game's `[startHole, endHole]` range for any player | Game tables and round summaries only (not ScoreGrid) |
| Hole before a player's `joinHole` (late arrival) | ReadOnlyScorecard, game tables |

**ScoreGrid and ZoomModal never display `–` for out-of-range holes** —
those holes are always available for score entry regardless of any game's range.

---

## §6. Per-Game Option Availability

### §6.1 Option matrix

| Game | abandon | end_at_k | exclude_player | continue | Segment pills | Press pills |
|---|---|---|---|---|---|---|
| Match | ✓ | ✓ | ✗ | ✗ | Front/Back/Overall | Per press (independent) |
| Skins ($ per hole) | ✓ | ✓ | ✗ | ✓ | None | N/A |
| Skins (pot) | ✓ | ✓ | ✗ | ✓ | None | N/A |
| Stableford (individual) | ✓ | ✓ | ✓ * | ✗ | F/B/O if segments mode | N/A |
| Stableford (team) | ✓ | ✓ | ✗ | ✗ | F/B/O if segments mode | N/A |
| Nines | ✓ | ✓ | ✗ | ✗ | F/B/O if segments mode | N/A |
| Sixes | ✓ | ✓ | ✗ | ✗ | Seg0/Seg1/Seg2 | Per press (independent) |
| Stroke Play | ✓ | ✓ | ✓ * | ✗ | F/B/O if segments mode | N/A |
| Dots | ✓ | ✓ | ✓ * | ✓ | None | N/A |

**`exclude_player` availability rules (marked *):**
- Only valid in Scenario A (one player departing — not Scenario B)
- Only offered when 3 or more players remain in the game after removal
- If the game has exactly 2 players and one departs, `exclude_player` is
  not shown — only `abandon` or `end_at_k`
- Not valid for Match — end the match rather than remove a player
- Not valid for Stableford team — team becomes incomplete
- Not valid for Nines — hard 3-player constraint; removal leaves 2
- Not valid for Sixes — hard 4-player constraint; removal leaves 3

**`exclude_player` behavior:**
Full retroactive recompute from `startHole` as if the departed player was
never in the game. The departed player's entry is removed from the game's
player subset in `activeRound` before `computePayouts` runs. The engine
receives a clean, complete subset and is unaware any player was removed.

**`continue` notes:**
- Only valid for Skins and Dots where per-hole independence makes continued
  play meaningful without spawning a new game instance
- Stableford and Stroke Play "continue as new game" is a future feature
  requiring multi-instance game spawn support (see D-2)

### §6.2 Segment pill availability

Segment pills (per-bet Pay/Abandon) are shown only when:
- The top-level resolution is `end_at_k`
- The game has a segment structure (F/B/T or Sixes segments)

Default for all segment pills: **Pay**. User may flip individual segments to Abandon.

### §6.3 Press pill availability

Press pills (per-press Pay/Abandon) are shown only when:
- The top-level resolution is `end_at_k`
- The game has active presses (Match or Sixes with autopress or manual presses)

Each press is an **independent row** with its own Pay/Abandon toggle.
A press's status (Closed / In-progress / Not-started) is shown alongside
its toggle. Default: **Pay** for Closed and In-progress presses.

Presses with trigger holes beyond `departureHole` (or `lastCompletedHole`)
are "Not started" — automatically Abandon, no toggle shown.

---

## §7. Game Family Rules

### §7.1 Clinch-segment family: Match and Sixes

A bet (segment or press) is **closed** when one side has mathematically
clinched it — the result cannot change regardless of remaining holes.

**Closed definition:**
Any segment or press of `n` holes is closed when one side has won `h`
  holes such that `h > n - h` — they lead by more holes than their
  opponent has remaining holes to win (standard dormie + 1 rule).
  This applies uniformly to segments of any length:
  - Match Front / Back (9 holes): closed at 5 holes won
  - Match Overall (18 holes): closed at 10 holes won (or dormie + 1)
  - Sixes segment, 6 holes: closed at 4 holes won
  - Sixes segment, 3 holes ("Threes"): closed at 2 holes won
  - Any press: evaluated independently on its own hole range

**Top-level choices for Match and Sixes:**
1. `abandon` — $0 all around
2. `end_at_k` "Pay closed bets only" — closed bets pay full value;
   in-progress and not-started bets → $0 automatically
3. `end_at_k` "Pay closed + in-progress bets" — closed bets pay full value;
   in-progress bets pay to current leader after last played hole; user may
   override individual bets via segment and press pills

**UI representation:**
"Pay closed bets only" and "Pay closed + in-progress bets" are presented
as two distinct top-level pill options — both map to `end_at_k` internally
with different segment/press defaults.

If "Pay closed + in-progress" is selected:
- Segment pills appear: Front, Back, Overall (Match) or Seg0/Seg1/Seg2
  (Sixes) — status badge (Closed ✓ / In progress) + Pay/Abandon toggle
- Press pills appear below: each press as an independent row — status badge
  (Closed ✓ / In progress / Not started) + Pay/Abandon toggle
- All default Pay; user flips individual bets to Abandon as desired

### §7.2 Completion-segment family: Nines, Stableford (segments), Stroke Play (segments)

A segment is **complete** when all holes in the segment have been played.
No clinch mechanic applies — all holes must be played for "complete" status.

- Front half complete: all holes from `startHole` through `midHole - 1` played
  (where `midHole = startHole + floor(rangeLength / 2)` per §3.6)
- Back half complete: all holes from `midHole` through `endHole` played
- Overall complete: `lastPlayedHole >= endHole`

**Nines `perSpread` mode:** No segments — single Pay/Abandon decision
over all played holes.

**Top-level choices:**
1. `abandon` — $0
2. `end_at_k` — compute through last played hole

If `end_at_k` selected, segment pills appear showing status (Complete /
Partial) and Pay/Abandon toggle. Default: Pay for all.

**Partial segment payout rule:** A partial segment pays to the current leader
after the last played hole in that segment's range. The engine math is
identical for complete and partial segments — Pay/Abandon is the user's
decision, not a computed outcome.

### §7.3 Hole-by-hole family: Skins and Dots

No segments. Each hole is independent.

**Skins — $ per hole:**
- `end_at_k`: departed player exits pool at `departureHole`; holes k+1
  onward played among remaining players at the original per-hole rate
- `continue`: same — departed player exits pool for k+1 onward; remaining
  players continue at the same per-hole rate

**Skins — pot:**
- `end_at_k`: pot closes at `departureHole`; settled over holes 0 through k
- `continue`: departed player stays in pot with X scores for remaining holes;
  X always loses; pot settles at `endHole`; departed player contributes to
  pot for remaining holes but wins nothing on them

**Dots:**
- `end_at_k`: departed player's dot entries frozen at `departureHole`;
  payout settled through hole k
- `continue`: remaining players continue earning/owing dots; departed
  player's frozen entries through hole k stand; no new dots after departure

**Top-level choices for Skins and Dots:**
1. `abandon` — $0
2. `end_at_k` — settle through departure hole
3. `continue` — remaining players continue

---

## §8. Long-Press X → Departure Resolver (Proactive Entry)

### §8.1 Trigger

User long-presses X in `ScoreKeypad` for player `i` on hole `h`.

### §8.2 Behavior sequence

1. Score `'X'` is **saved immediately** to `scores[h][i]` before the sheet
   appears. Player picked up on this hole regardless of departure decision.
2. Confirmation prompt appears:
   > "Is [PlayerName] done for the round?"
   Two buttons: **"Just this hole"** (dismiss — X saved, no departure recorded)
   and **"Yes, [Name] is leaving"** (open full per-game resolver).
3. If "Yes": full resolver sheet (§10) appears with `departureHole = h`
   for player `i`.
4. On resolver confirm: `earlyDepartureOpts` written to `activeRound`.
   Round continues for other players. Departed player's cells for holes
   after `h` are locked (display `–`, no input).
5. When "Results →" is tapped later, `payouts.js` uses `earlyDepartureOpts`
   to compute payouts correctly per the resolver decisions.

### §8.3 Post-departure scorecard behavior

After a player is marked as departed:
- Score cells for holes after `departureHole` show `–` (locked, no tap response)
- Name chip in scorecard header is visually dimmed (gray tint, reduced opacity)
- Player still appears in game tables in `RoundSummaryModal`; results through
  departure hole shown; subsequent holes show `–`

### §8.4 Undoing a departure

User taps a locked `–` cell. Prompt appears:
> "[Name] was marked as departed. Resume scoring for [Name]?"
Confirming removes player from `earlyDepartureOpts` and unlocks their cells.

---

## §9. Results → Gated Resolver (Reactive Entry)

### §9.1 Trigger

User taps "Results →" with incomplete scores.

### §9.2 Classification

App classifies each player per §5.2. If any player has Missing scores,
Results is blocked with error listing which holes. No resolver shown.
User must return to scorecard and enter missing scores.

### §9.3 Scenario B resolver

All players incomplete (same or different holes) relative to `roundEndHole`:
- Header: "Round ended after hole [highWaterMark + 1]" (1-based display;
  `highWaterMark` = last hole where any player has a score)
- All active games shown with resolver rows
- On confirm: `lastCompletedHole = highWaterMark`, `earlyEndOpts` set

### §9.4 Scenario A resolver

One or more players incomplete, rest complete:
- Header: "[Name] left after hole [lastScored[i] + 1]" (1-based display)
- Only games the departed player participated in are shown
- On confirm: `earlyDepartureOpts` set for each departed player

### §9.5 Multiple departed players

Two or more players classified as Early departure: resolver shows each
player's situation as a separate stacked section with a divider between them.

---

## §10. Resolver Sheet UI

### §10.1 Sheet structure

Bottom sheet modal. Scrollable if content exceeds screen height.
Cancel returns to scorecard unchanged. Confirm writes all fields and proceeds.

```
┌─────────────────────────────────────────────┐
│  Dave left after hole 13                    │  ← header (1-based)
│  How should each game be resolved?          │
│                                             │
│  ── Skins ─────────────────────────────── │
│  [Abandon] [End at hole 13] [Continue]     │
│                                             │
│  ── Match A: Dave vs Alice ─────────────  │
│  [Abandon] [Pay closed] [Pay closed+open]  │
│    ▾ expanded when Pay closed+open:        │
│    Front 9   Closed ✓      [Pay] [Abandon] │
│    Back 9    In progress   [Pay] [Abandon] │
│    Overall   In progress   [Pay] [Abandon] │
│    Press 1   Closed ✓      [Pay] [Abandon] │
│    Press 2   In progress   [Pay] [Abandon] │
│    Press 3   Not started    ——  Abandon    │
│                                             │
│  ── Nines ──────────────────────────────  │
│  [Abandon] [End at hole 13]                │
│    ▾ expanded when End at hole 13:         │
│    Front 9   Complete      [Pay] [Abandon] │
│    Back 9    Partial       [Pay] [Abandon] │
│    Overall   Partial       [Pay] [Abandon] │
│                                             │
│  ── Stableford ─────────────────────────  │
│  [Abandon] [End at hole 13] [Remove Dave]  │
│                                             │
│  ── Dots ───────────────────────────────  │
│  [Abandon] [End at hole 13] [Continue]     │
│                                             │
│  [     Cancel     ]  [     Confirm     ]   │
└─────────────────────────────────────────────┘
```

### §10.2 Default selections

- Top-level: `end_at_k` (or "Pay closed + in-progress" for Match/Sixes)
- Segment pills: Pay for all (complete and partial)
- Press pills: Pay for Closed and In-progress; Abandon for Not-started
  (automatic — no toggle shown for not-started presses)

### §10.3 Game rows shown

- Scenario A: only games the departed player participated in
- Scenario B: all active games

### §10.4 Reusable components

- `BetPillRow` — single row: label + status badge + Pay/Abandon toggle.
  Used for both segments and presses. Status values: Complete / Partial /
  Closed / In-progress / Not-started.
- `GameResolutionRow` — top-level game row: game label + top-level option
  pills + expandable `BetPillRow` list below when `end_at_k` selected.
- `DepartureResolverSheet` — full bottom sheet; composes `GameResolutionRow`
  instances; handles confirm/cancel; scrollable.

---

## §11. Engine Behavior

### §11.1 Engine firewall — `games.js` and `handicap.js` are never modified

**`games.js` and `handicap.js` are not touched by partial-round features.**

This is a hard architectural rule that protects existing full-round
functionality from any risk of regression.

All range logic, departure handling, and subset pre-processing lives
exclusively in `payouts.js` as a **pre-processing step above the engine
call sites**. The engine functions in `games.js` always receive clean,
complete inputs and are unaware that any range or departure logic exists.

**When `roundStartHole = 0`, `roundNumHoles = 18` (full-round defaults), and no departures exist, the pre-processing step is a complete no-op.** Full rounds pass through unchanged. This is the guarantee that existing functionality is safe.

**Pre-processing responsibilities (all in `payouts.js`):**
- Trim scores array to `[startHole, endHole]` before engine call
- Apply `exclude_player` subset removal before engine call
- Evaluate segment and press closed/complete/in-progress status
- Apply per-segment and per-press Pay/Abandon decisions to engine output
- Skip game block entirely for `abandon` resolution

### §11.2 `abandon` resolution

`payouts.js` skips the game block. Engine function is never called.
All players receive $0 for this game.

### §11.3 `end_at_k` resolution

`payouts.js` trims scores to `[startHole, departureHole]` (Scenario A)
or `[startHole, lastCompletedHole]` (Scenario B) before calling the engine.
Per-segment and per-press Pay/Abandon decisions are applied to the engine
output — abandoned bets produce $0 regardless of result.

### §11.4 `continue` resolution (Skins and Dots only)

`payouts.js` passes full scores through `endHole`. Departed player's X scores
for post-departure holes are already in `scores`. "X always loses" invariant
(ScoreKeypad_Contract §4.5) handles the result naturally — no special engine
logic required.

### §11.5 `exclude_player` resolution

`payouts.js` removes the departed player from the game's player subset
before calling the engine. The engine receives a complete, valid subset
and is unaware any player was removed. Recompute covers all holes from
`startHole` through `endHole` — fully retroactive from the game's start.

### §11.6 Segment status evaluation — clinch-segment family

For Match and Sixes, `payouts.js` evaluates each segment and press for
closed status before applying Pay/Abandon decisions.

Closed = one side leads by more holes won than holes remaining in that
bet's range (dormie + 1). Each press is evaluated independently.

A closed bet with Pay selected pays its full value.
An in-progress bet with Pay selected pays to the current leader after the
last played hole in its range.

### §11.7 Segment status evaluation — completion-segment family

For Nines, Stableford (segments), Stroke Play (segments):
Complete = all holes in segment played. Partial = some played, some not.

Both complete and partial segments pay to the current leader of their range
when Pay is selected. The engine math is identical — Pay/Abandon is the
user's decision, not a computed outcome.

### §11.8 Press behavior

A press with trigger hole beyond `departureHole` (or `lastCompletedHole`)
is "Not started" — produces $0 automatically; no toggle in UI.

A press with trigger hole within the effective range is evaluated
independently as Closed or In-progress with its own Pay/Abandon toggle.
A press's status is never derived from or constrained by its parent segment.

---

## §12. RoundSummaryModal and Share Image

### §12.1 Scorecard display

`ReadOnlyScorecard` shows `–` per the rules in §5.5:
- Holes after `lastCompletedHole` (Scenario B)
- Departed players' holes after their `departureHole` (Scenario A)
- Holes outside any player's effective range

### §12.2 Game tables

Each game table renders only columns for holes within its `[startHole, endHole]`
range (§2.4). No structural changes to table components are needed beyond
range-aware column rendering.

A small note below each affected game table is recommended (deferred to
polish session): "Computed over holes 1–[k]" or "Round ended after hole [k]."

---

## §13. Backward Compatibility

All new fields default gracefully when absent:
- `roundStartHole` absent → 0 (start at hole 1)
- `roundNumHoles` absent → 18 (full round)
- `gameRanges` absent → all games use `[roundStartHole, roundEndHole]`
- `earlyDepartureOpts` absent → no departures (normal behavior)
- `earlyEndOpts` absent → all games pay out (existing invariant preserved)
- `lastCompletedHole` absent → `roundEndHole` (existing invariant preserved)
- `playerJoinHoles` absent → all players joined at `roundStartHole`

Old saved rounds with none of these fields load and compute correctly.
The engine firewall (§11.1) guarantees full rounds are unaffected.

---

## §14. Invariants

1. A player classified as "Missing scores" never triggers the departure
   resolver. Scattered empty holes are always a data entry problem.
2. `earlyDepartureOpts[i].departureHole` is the last hole the departed
   player actually scored (real or X). It is never a future hole.
3. After a player is marked as departed, their post-departure cells are
   locked. The engine never receives non-empty scores for post-departure holes.
4. Every press is an independent bet with its own Pay/Abandon toggle.
   A press may be open while its parent segment is closed, or vice versa.
   No press inherits its decision from a parent segment.
5. "X always loses" invariant (ScoreKeypad_Contract §4.5) is the mechanism
   by which departed players lose post-departure holes under `continue`.
   No special engine logic is needed.
6. Zero-sum payout invariant holds for all games after departure resolution.
7. Sixes: no `exclude_player`, no `continue`. Only `abandon` or `end_at_k`.
   Sixes requires exactly 4 players. Range must be divisible by 3.
8. Nines: no `exclude_player`, no `continue`. Only `abandon` or `end_at_k`.
   Nines requires exactly 3 players.
9. `fromActiveRound` / `toActiveRound` faithfully round-trip `roundStartHole`,
   `roundNumHoles`, `gameRanges`, `earlyDepartureOpts`, and `playerJoinHoles`.
10. The reactive resolver (Results → gate) and proactive resolver
    (long-press X) produce identical `activeRound` state. Path differs;
    outcome is the same.
11. Engine range `[startHole, endHole]` is always valid:
    `roundStartHole <= startHole < endHole <= roundEndHole`.
12. `playerGameStart = max(game.startHole, player.joinHole ?? roundStartHole)`.
    `playerGameEnd   = min(game.endHole,   player.departureHole ?? roundEndHole)`.
    These are the authoritative effective ranges per player per game.
13. **`games.js` and `handicap.js` are never modified by partial-round
    features.** All range and departure logic lives in `payouts.js`.
    When `startHole = 0`, `endHole = 17`, and no departures exist, the
    pre-processing layer is a complete no-op.
14. `exclude_player` is never offered when fewer than 3 players would
    remain in the game after removal, or for Match, Nines, Sixes, or
    Stableford team format.
15. `–` is the sole display value for holes a player did not play. It is
    never confused with `X` (picked up) or blank (not yet entered).
    ScoreGrid and ZoomModal never show `–` for out-of-range holes.
16. Sixes segment length = `(endHole - startHole + 1) / 3`. For a full
    18-hole round this equals 6 (existing behavior unchanged).
17. `roundEndHole` is always derived: `roundStartHole + roundNumHoles - 1`.
    It is never stored. All completion checks use this derived value.
18. A game range can never extend beyond the round:
    `game.startHole >= roundStartHole` and `game.endHole <= roundEndHole`.

---

## §15. Open Items and Deferred Features

| # | Description | Deferred to |
|---|---|---|
| D-1 | "Continue as new game" spawn for Stableford individual and Stroke Play | After multi-instance game support |
| D-2 | Skins $ per hole dynamic pool size per hole under `continue` | 13-C.8 implementation |
| D-3 | Multiple departed players resolver layout — full visual spec | 13-C.5 planning |
| D-4 | "Computed over holes 1–k" note in game tables | Polish session |
| D-5 | Scenario A + B combined resolver flow full spec | 13-C.5 planning |
| D-6 | Team Match shorthand play (1v2 after departure) | Future contract amendment |
| D-7 | Mid-round game range picker for in-progress rounds | Sprint after 13-C.4 |
| D-8 | Stableford team `exclude_player` — shorthanded team handling | Future contract amendment |

---

## §16. Known Gaps

| # | Severity | Description |
|---|---|---|
| G-1 | High | Exact `payouts.js` pre-processing API — score trimming shape, subset changes, segment evaluation — to be specified in 13-C.5 planning before 13-C.8 build |
| G-2 | Medium | `BetPillRow` and `GameResolutionRow` component props interface — to be specified in 13-C.5 planning before 13-C.6 build |
| G-3 | Medium | Clinch detection algorithm for Match/Sixes — confirm implementation approach in 13-C.5; must match existing `games.js` closed-bet logic |
| G-4 | Low | Predetermined range minimum-hole validation rules: Nines F/B/T minimum 6 holes; Sixes minimum 9 holes with range divisible by 3; other games minimum 3 holes |

---

## §17. Final Rule

If implementation behavior conflicts with this contract, call out the conflict.
The implementation must be corrected. This document defines the truth.
