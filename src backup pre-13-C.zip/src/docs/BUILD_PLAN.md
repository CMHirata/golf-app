# The Card — Master Build Plan

_Last updated: April 2026 — Session 13-C complete (planning + contract, no code). `PartialGameContract.md` → v1.3 AUTHORITATIVE. `Early_Departure_Contract.md` and `Late_Arrival_Contract.md` superseded. Sprint 13 restructured into 13-C.2 through 13-C.7. D-C1/D-C2/D-C3 decisions confirmed. Next session: 13-C.2 (Predetermined Game Ranges — build)._
_Maintained in this chat as the authoritative sequence and history of all build sessions._
_The APP_STATE_SUMMARY.md in the project knowledge base is the authoritative record of_
_what is implemented. This file is the authoritative record of what was planned, why,_
_and in what order — including items that shifted, were skipped, reinstated, or renumbered._

---

## Critical Rules for All Future Sessions

1. **Contracts before code.** Any item marked "contract first" below must have a contract
   amendment approved before a single line of implementation code is written.

2. **Session naming is owner-assigned.** Claude must never auto-assign new session
   designations (e.g. creating "11-B" when it doesn't exist in this plan). Sub-tasks within
   a session are labeled as phases (Phase 1, Phase 2). New session rows in APP_STATE_SUMMARY.md
   are only added when the owner explicitly provides the designation.

3. **APP_STATE_SUMMARY.md is not a bug tracker.** Open items live there; closed items are
   struck through. The external spreadsheet is the master bug/feature tracker.

4. **Do not remove open items from ASS** without confirmed on-device testing by owner.

5. **Derived values are never stored.** All derived state is computed from the activeRound blob.

6. **`restoreDotDefs()` is critical.** Must always be called before using dots from any
   serialized state. Was `restoreAutoWhen()` prior to Session 11-A rename.

7. **`betType` is a static config concept only.** It lives in the `GAME_CONFIGS` constant
   and must never be stored in `gameOpts`, `activeRound`, or any persisted state.
   Decision made in 11-G-1. Do not revisit without owner approval.

8. **Nassau terminology is retired from all user-facing surfaces.** The behavior is exposed
   as Front/Back/Overall segment bet fields. Decision made in 11-G-1. Do not reintroduce
   "Nassau" as a UI term without explicit owner approval.

---

## Key Architectural Decisions

These decisions should not be revisited without good reason:

1. **Contracts are authoritative over code.** When contract language and implementation
   conflict, contracts win. Code is updated to match.

2. **Write contracts before fixing engines.** The contract defines the spec the engine
   fix must conform to.

3. **Derived values are never stored.** All derived state computed from activeRound blob.

4. **Session naming is owner-assigned.** Claude never invents new session designations.

5. **Generic swipe component** extracted when adding swipe to Players/Courses (12-F),
   not before — avoid premature abstraction.

6. **Dots/Specials shim removal** only after owner confirms all saved rounds have been
   opened and re-exported. Do not rush this.

7. **Per-player tee selection (completed in 11-I.1).** If extended further, treat as
   high-risk and own a full session.

8. **Custom keypad replaces system keyboard (13-B).** `ScoreKeypad.jsx` is the sole
   score entry component throughout the app. The hidden-input / `.focus()` pattern used
   in ZoomModal is retired after 13-B. `'X'` is a valid score value (player picked up);
   it stores as `'X'`, displays as `"NX"` (N = ESC gross), and always loses to any real
   score. Confirmed decision: no system keyboard for score entry post-13-B.

9. **`'X'` score semantics (13-B).** X = player picked up. Gross value = `par + 2 +
   strokes` (full Net, never NOL). Already ESC-capped by definition. "X always loses to
   a real score; X ties X" is the universal invariant across all 7 games.

10. **Early departure via Results gateway (13-C).** There is no "End Round Early" button
    on the scorecard. Departure is declared either via long-press X on the keypad
    (proactive) or via the Results → transition gate (reactive). Contiguous trailing empty
    cells = early departure. Scattered gaps = missing scores (blocked, must enter).

11. **Late arrival: append-only exception to lineup reset (13-D).** Adding a new player
    appended to the end of the lineup, with existing players unchanged, preserves existing
    scores. All other lineup mutations still trigger a full reset (RLC §2.6).

12. **Name display convention:** always show first name (larger/darker) + last name
    (smaller/lighter) unconditionally. No collision detection. `resolveDisplayNames`
    removed from most consumers after this decision.

13. **`PlayerDropdown.jsx`** is the shared component for all player picker UI in New Round
    setup. Do not create parallel picker implementations.

14. **Nassau terminology retired (11-G).** The betting behavior formerly called "Nassau"
    is exposed as Front/Back/Overall segment bet fields. `betType` is a static UI
    dispatch concept in `GAME_CONFIGS` — never stored in round state.

15. **Wolf is the next planned game format.** `GAME_CONFIGS` design in 11-I preserves
    a clean extension point for Wolf's rotating-player and doubling mechanics. Owner has
    confirmed Wolf will not be added until rest of app is considered solid.

16. **NOL dot selector design (11-K).** Unified segmented pill control replaces Net/NOL
    toggle. All segments in a single bordered pill: Net (if mixed round) / NOL / NOL Skins
    / NOL Match A / etc. Games with identical participant sets merged into one button.
    ZoomModal inherits the selection. Center button from setup tab triggers handleStart.

17. **ScoreKeypad nav row removed (13-B).** The ←/✓/→ navigation row was removed from
    `ScoreKeypad` after device testing confirmed it consumed too much screen space. Cell
    advancement is handled entirely by auto-advance timing (700ms for `'1'`, immediate
    for all others). Backspace retreats on second tap on an empty cell. The removed props
    (`onConfirm`, `onNavigate`, `atFirst`, `atLast`) must not be re-added without owner
    approval and a contract amendment.

---

## Numbering History & Collision Notes

- **Sessions 1–9** were numbered sequentially as work progressed.
- **Sessions 11-B and 11-C** were auto-created by Claude mid-session during the Dots
  rework, colliding with planned future sessions. Corrected: all three phases collapsed
  into **11-A** in the ASS.
- **11-B** in this plan = Shared GameTable shell (deferred to post-Sprint 12).
- **11-C** in this plan = Match/Nassau team hole display (completed).
- **11-D** in this plan = Fixed-width player name fields + PlayerDropdown (completed,
  scope exceeded plan).
- **11-E** in this plan = Disabled Btn fix + NOL label audit (completed).
- **11-G** was a planning-only session (no code). Downstream sessions renamed
  11-H, 11-I, 11-J, 11-K for cleanliness.
- **Sprint 13 restructured (April 2026).** Original 13-A (iCloud export) and 13-C
  (partial round stub) replaced with a focused 4-session sprint: 13-A = planning,
  13-B = custom keypad, 13-C = early departure, 13-D = late arrival. iCloud export
  moved to 14-D. Sprint 13 is entirely dedicated to score entry and partial round
  lifecycle features.

---

## Completed Sessions

| Session | Scope | Original Items | Notes |
|---|---|---|---|
| 1-A | Round lifecycle bugs + safety guards: cancel/delete in-progress round; New Round full reset; score-overwrite warning; history-load conflict check; "Round in Progress" banner; date defaults to today | | All confirmed |
| 1-B | History data integrity: static snapshot audit (B-1); loading old rounds restores game data (B-4); edit historical round settings (B-2) | B-1, B-2, B-4 | All confirmed |
| 1-C | Score cell shift fix (C-1, `display:block`); Specials popup iOS copy/paste callout fix (C-2, `userSelect:none`) | C-1, C-2 | All confirmed |
| 2 | History UX: swipe-left strip; full-swipe delete; RoundSummaryModal; landscape scorecard 18-hole; per-match payouts; Stroke Index gender-aware labeling | | All confirmed |
| 3 | ResultsPage redesign (B-5 partial); per-match payout breakdown (B-3); named nine labels on scorecard (C-10); HomePage recent round tap opens modal; player chips in header | B-3, C-10 | All confirmed. B-5 results page refinement still desired — open in future session |
| 4 | Back-to-setup fix (B-3 follow-up); share sheet PNG via iOS native share (B-7) | B-7 | All confirmed. B-7 subsequently superseded by portrait PDF in 11-M |
| 5 | Visual polish: logo + branding (J-1); mint bg; SVG icons replacing emojis (F-3); swipe strip redesign; headers; player chips moved | F-3, J-1 | Confirmed |
| 6 | Navigation overhaul: always-visible nav (F-1); logo super-tab; pinned action bars; scroll-to-top (C-3); divider removed between scorecard and chips (C-6); expand triangles removed (A-11 partial) | F-1, C-3, C-6, A-11 | Confirmed |
| 7 | Shared layout constants (`layout.js`); NewRoundPage extractions: `PlayerPickerPopup.jsx`, `MatchCard.jsx`, `GameConfig.jsx`; NewRoundPage 1,360→592 lines | | Confirmed on device |
| 8 | CoursesPage full extraction: 5 components + helpers to courseLib.js | | Confirmed on device |
| 9 | PWA: manifest.json, sw.js, PNG logos, home screen install (I-1) | I-1 | Confirmed on device |
| 10-A | RoundSummaryModal totals row; ESC (Adjusted Gross Score) in TotalsCard; `escTotal()` added to handicap.js; Results F9/B9/Overall zeros bug fixed; auto-export on save (A-8) added; Handicap_Contract.md → v1.5 | A-8 | Confirmed. A-8 exact session uncertain — 10-A or 10-B |
| 10-B | Visual regressions: logo heights + header consistency; landscape full-width fix; MatchNassauTable isLandscape; Courses triangles removed (A-11 final); share image complete rework (B-6) | A-11, B-6 | All confirmed on device |
| 11-A | Dots (Specials) full rework: contract v2.0→v2.1; full Specials→Dots rename at all layers; DotsTable, DotsPopup, DotBadge; discrete scoring specials; mutual exclusivity; popup redesign; pivot summary tile; retroactive autoMark; App_Data_Model_Contract v2.5 | E-1 | Complete — pending bulk round migration before shim removal |
| 11-C | D-1: Match/Nassau team hole winner display: slash-initials (C/D), colorblind-safe blue/red chips; color-coded header; Front 9 closure bug fixed; Match status columns (D-3) — "Status" column with segment results; Nassau_Match_Contract v2.4 | D-1, D-3 | Confirmed on device |
| 11-D | resolveDisplayNames rollout; PlayerDropdown.jsx new file (PlayerDropdown, StyledSel, ReadOnlyBubble); MatchCard and GameConfig/Sixes migrated to custom pickers; fixed-width chips + first-name display (C-4/C-5); Sixes dropdown widths (D-5) | C-4, C-5, D-5 | Confirmed on device. Scope significantly exceeded plan |
| 11-E | Disabled Btn style fix (F-2); NOL label audit — confirmed already consistent (F-4); name display convention unified; Sixes duplicate-team prevention | F-2, F-4 | Confirmed on device |
| 11-F | Zoom score entry modal: ZoomModal.jsx (new), hidden-input keyboard pattern, 3-hole window, stacked player names, active-cell-only border, magnifying glass button, landscape zoom | C-9 | Confirmed on device |
| 11-G | Planning session: NOL dot display design decision; betting model architecture (Nassau retired → segment betting); betType as static config; GAME_CONFIGS pattern; Wolf extension point | | No code produced |
| 11-H | Design-only session: full NewRoundPage setup UI design spec. Output: `NewRoundPage_Design_Spec.md` | | No code produced |
| 11-I.1 | 6 contracts amended (App_Data_Model v2.7, Nassau_Match v2.5, Stableford v1.3, Nines v1.3, Skins v1.5, Stroke_Play v1.4); engine read-site changes; Players card rebuilt; per-player tee selection (A-7, A-13); "Default Tee" buttons removed (A-12); course picker popup built; nine-selection shown only for 3-nine courses; shared BetRow/SimpleBetRow/ScoringDropdown/PlayerSubsetDropdown components built | A-7, A-12 | Players card confirmed on device |
| 11-I.2 | Game config UI rebuild: all game tiles (Match, Skins, Stableford, Nines, Stroke Play, Sixes, Dots); GameTile morph tile; BetSection; TeamPickerPair; MatchCard rebuilt; Stableford Teams disabled (Option Z); `cumulative` tiebreak branch added in games.js; App_Data_Model v2.8, Sixes v1.8, Nassau_Match v2.6 | D-4 | Confirmed on device |
| 11-I.3 | Semantic field rename: `scoring`→`grossNetNOL`, `tiebreak`→`scoring`; 10 contracts amended; 19 files updated; migration shims added; 3 pre-existing bugs fixed | | Confirmed on device |
| 11-J | Per-match instance labeling; `teamMode` → `'Match:{matchId}'`; migration shim; Dots dropdown enumerates per-instance options; Nassau terminology fully purged from all surfaces; App_Data_Model v3.0, Nassau_Match v2.8 | D-8 | Confirmed on device |
| 11-K | NOL dot selector: unified segmented pill; `computeNolDotOptions`; ZoomModal inheritance; center nav button → `handleStart`; `manualPresses` preservation fix; Handicap_Contract v1.6, Round_Lifecycle_Contract v1.6 | C-11 | Confirmed on device |
| 11-L | Stableford Teams engine support. Phase 1: `Stableford_Contract.md` → v1.5; `App_Data_Model_Contract.md` → v3.1. Phase 2: `handicap.js`, `games.js`, `payouts.js`, `NewRoundPage.jsx`, `GameConfig.jsx`, `StablefordTable.jsx`, `GameSection.jsx`, `ScoreGrid.jsx`, `NinesTable.jsx`, `StrokePlayTable.jsx`, `MatchNassauTable.jsx`, `ResultsPage.jsx`, `App.jsx` | | Confirmed on device |
| 11-M | Team Dots payout fix; DotsTable team layout; portrait/landscape share orientation picker; portrait share as PDF; `deriveShareDotMode`; Dots_Contract v2.3, UI_Component_Contract v1.3, Round_Lifecycle_Contract v1.7 | B-7 superseded | Confirmed on device |
| 11-N | Round totals regression restore: TotalsCard import added to RoundSummaryModal; totalsHtml block added to buildShareHtml | | Confirmed on device |
| Post-11-M | Bug fixes: SixesTable `opts` prop; ReadOnlyScorecard handicap dots; share image dots; Sixes pivot `pivotSegTot`; RLC → v1.8 | | Confirmed on device |
| 11-I.1 (also) | NinesTable subset filtering: table and payouts show only 3-player subset (D-6, D-7) | D-6, D-7 | Confirmed on device |
| 11-O | Audit session: all 7 game tables in RoundSummaryModal and share image confirmed correctly wired; C-10 nine labels confirmed; B-8 lock/unlock in HistoryPage | B-8 | Confirmed on device |
| 13-A | Planning session: custom keypad design, X score type definition, early departure model, late arrival model. Output: `ScoreKeypad_Contract.md` (v1.0 DRAFT), `Early_Departure_Contract.md` (v1.0 DRAFT), `Late_Arrival_Contract.md` (v1.0 DRAFT), `Session_Planning_Keypad_Departure_Arrival.md` | | No code produced |
| 13-B | Custom keypad + X score type. `ScoreKeypad.jsx` (new) — fixed-bottom 4-row overlay (1–9, ⌫/0/X); replaces iOS system keyboard everywhere. `'X'` score type: stores as `'X'`, displays as NX (amber), ESC-capped by definition, always loses to real score, ties another X. ZoomModal rebuilt as pure display component — no hidden input, no keyboard focus logic; keypad floats above it at zIndex 300. `ScoreGrid` owns all keypad state. `NinesTable` and `MatchNassauTable` fixed to handle X in display-layer scoring. Discard bug fixed (isDiscardingRef). `ScoreKeypad_Contract.md` → v2.1 AUTHORITATIVE. All 7 game contracts, `App_Data_Model_Contract.md`, `Round_Lifecycle_Contract.md`, `Handicap_Contract.md`, `Payout_Contract.md` amended with X score behavior. | D-B0 | Confirmed on device |
| 13-B.1 | ZoomModal stabilization + pre-13 bug fixes + touch isolation hardening. **ZoomModal final architecture:** pure display component; `onCellTap` prop → `openKeypadOnCell`; `activeKpCell` prop drives border; `cardRef` exempts card from dismiss handler. **ScoreGrid:** `openZoom` no longer calls `.focus()` (was causing iOS keyboard); `kpVisible` no longer suppressed when ZoomModal open; `zoomCardRef` added to dismiss exemption; `closeZoom` clears keypad state; `useEffect` on `[zoomOpen]` defers first cell activation; `kpAdvanceCell`/`kpRetreatCell` call `setZoomHole` on hole-crossing; `longPressFired` guard on `onCellTap` wrapper; `savedKpCellRef` + `activeKpCellRef` pattern saves/restores keypad across DotsPopup. **DotsPopup:** `touchStartedOnBackdrop` ref prevents auto-close from long-press lift; full touch isolation on backdrop and card. **ZoomModal:** backdrop touch isolation (`stopPropagation`; `e.target === e.currentTarget` close guard); card touch isolation. **Bug A:** `handleBackToSetup` `if (ar)` guard; `playerCHOverrides` restored from snapshots. **Bug B:** Sixes `autoPress !== 'none'` fix in `SixesTable` + `payouts.js`. **Bug C:** Match `legacyN` fix in `MatchNassauTable` + `games.js`. **Other:** tee blank-on-new-course; ZoomModal dot badges column-aware sizing. **Follow-on fixes (same session):** X handling in `SixesTable.holeWinFn`, `NinesTable.allData`, `StablefordTable.scoreHole`; `ScoreGrid.renderCell` cell height formula. Contract amendments: Sixes, Nines, Stableford X Score Behavior sections. Files: `ZoomModal.jsx`, `ScoreGrid.jsx`, `DotsPopup.jsx`, `App.jsx`, `NewRoundPage.jsx`, `SixesTable.jsx`, `NinesTable.jsx`, `StablefordTable.jsx`, `payouts.js`, `games.js`, `MatchNassauTable.jsx`. | | Confirmed on device |
| 14-E | Import conflict UX overhaul + id-less record fix. Root cause: AI-generated JSON files produce ID collisions (different courses sharing same ID), and `mergeById` silently dropped records with no `id` field. Fixes: (1) `makeId` assigned to id-less courses/players at import time; (2) `diffCourses` now diffs the name field — name mismatch on an ID collision is the primary signal; (3) `likelySameCourse` tightened: stop-words filtered, substring match requires ≥12 chars, word-overlap threshold raised to 80%; (4) `ImportConflictModal` rebuilt with side-by-side `CourseSummaryCard` showing both records, red header for ID conflicts with name mismatch, three actions: Keep Library / Use File / Keep Both; (5) Keep Both prompts for a new name and saves the incoming course as a fresh record with a new ID; (6) `sameId` flag passed from conflict detection through to modal. No contract changes required. | | Confirmed on device |

---

## Open Session Plan

Sessions are listed in recommended execution order. Items marked "contract first"
require a contract amendment to be written and approved before any code is produced.

---

### Sprint 11 — Remaining

**11-B: Shared GameTable shell** *(DEFERRED to post-Sprint 12)*
- Move GameTable/PlayerChips documentation into UI_Component_Contract.md
- Audit SkinsTable, SixesTable, MatchNassauTable, StrokePlayTable for further shared chrome
- Low urgency — patterns already working; documentation + optional refactor pass
- Files: `GameSection.jsx`, `UI_Component_Contract.md`

---

### Sprint 12 — Medium Priority Features

**12-B: Game table display consistency pass**
- Audit all game tile chip/total labels across all games (e.g. "pts", "$") — decide once whether labels appear, apply uniformly
- Audit player name chip display consistency across all game tables
- D-2: "pts" label on Nines total chips (original item, now part of broader audit)
- Files: `NinesTable.jsx`, `SkinsTable.jsx`, `StablefordTable.jsx`, `SixesTable.jsx`, `MatchNassauTable.jsx`, `StrokePlayTable.jsx`, `DotsTable.jsx`, `ScoreGrid.jsx`
- Priority: Medium

**12-C: Setup UX polish**
- A-5: Save game settings from prior round as defaults for next round
- Files: `NewRoundPage.jsx`, `roundLib.js`
- Priority: Medium
- Note: Course picker popup ✅ done in 11-I.1; nine-selection guard ✅ done in 11-I.1; Default Tee buttons ✅ removed in 11-I.1. Only A-5 remains.

**12-E: Players and leaderboard enhancements**
- G-1: Starred/favorite players float to top
- G-2: Include/exclude from leaderboard — filter one-off players off money list
- Files: `PlayersPage.jsx`, `HomePage.jsx`
- Priority: Medium

**12-F: Players/Courses swipe-left actions**
- Swipe-left Edit/Delete strip matching HistoryPage pattern
- Extract generic swipe component at the same time (avoid third copy of HistoryPage logic)
- Import PALE_YELLOW from ui.jsx for Edit button background (already specified in ASS gotcha)
- Files: `PlayersPage.jsx`, `CoursesPage.jsx` + new generic swipe component
- Priority: Medium

**Results page refinement** *(session to be named by owner)*
- B-5: General results page layout and presentation refinement pass
- Priority: Medium

---

### Sprint 13 — Score Entry, Partial Rounds, Lifecycle

Sprint 13 is dedicated entirely to score entry and partial round lifecycle features.
Sessions execute in order per `PartialGameContract.md` §1.3. `Early_Departure_Contract.md`
and `Late_Arrival_Contract.md` are superseded by `PartialGameContract.md`.

**13-A: Planning** ✅ *COMPLETE — no code*
- Designed custom keypad, X score type, early departure model, late arrival model
- Output: `ScoreKeypad_Contract.md` (DRAFT), `Early_Departure_Contract.md` (DRAFT),
  `Late_Arrival_Contract.md` (DRAFT)

**13-B: Custom Keypad + X Score Type** ✅ *COMPLETE*
- `ScoreKeypad.jsx` — fixed-bottom overlay, 4 rows (1-2-3 / 4-5-6 / 7-8-9 / ⌫-0-X),
  56px row height, `position:fixed bottom:0`, zIndex 300, covers nav bar
- `'X'` score type fully implemented across engine, display tables, and all contracts
- ZoomModal rebuilt as pure display component; keypad floats above it
- ScoreGrid owns all keypad state; ZoomModal calls `onCellTap` only
- Navigation row (←/✓/→) removed after device testing — too much screen space
- Discard round bug fixed (`isDiscardingRef` prevents unmount flush after clear)
- `NinesTable` and `MatchNassauTable` fixed for X in display-layer scoring
- `ScoreKeypad_Contract.md` → v2.1 AUTHORITATIVE
- 11 contracts amended: all 7 game contracts, `App_Data_Model_Contract.md`,
  `Round_Lifecycle_Contract.md`, `Handicap_Contract.md`, `Payout_Contract.md`
- Long-press X stub in place; full departure resolver wired in 13-C.5

**13-C: Partial Rounds — Planning + Contract** ✅ *COMPLETE — no code*
- Full per-game departure/range walkthrough completed with owner across all 7 games
- `Early_Departure_Contract.md` (v1.0 DRAFT) and `Late_Arrival_Contract.md` (v1.0 DRAFT)
  superseded in their entirety
- `PartialGameContract.md` → v1.3 AUTHORITATIVE
- Three concepts unified under one contract: predetermined ranges, mid-round game
  start, early departure
- Engine firewall confirmed: `games.js` and `handicap.js` never touched; all
  range/departure logic in `payouts.js` pre-processing layer only
- Key decisions confirmed: press independence; `exclude_player` availability rules
  (3+ players must remain; not valid for Match/Nines/Sixes/Stableford team);
  Sixes segment length = `rangeLength / 3`; dormie+1 clinch rule; `–` display
  for unplayed holes (distinct from `X` and blank); `games.js` firewall invariant

**13-C.2: Predetermined Game Ranges** *(next — build)*
- `gameRanges: { [gameKey]: { startHole, endHole } }` added to `activeRound`,
  `roundLib`, `buildPayoutArgs`
- `payouts.js` pre-processing layer trims scores/pars/hcps to range before every
  engine call; provably no-op for default `[0, 17]` full rounds
- `GameConfig.jsx` range picker UI (Start/End hole per game; per-game validation)
- All 7 game tables accept `startHole`/`endHole` props; render trimmed columns only
- `ReadOnlyScorecard` shows `–` for out-of-range holes
- `games.js` and `handicap.js` not touched
- Files: `roundUtils.js`, `roundLib.js`, `payouts.js`, `GameConfig.jsx`,
  `NewRoundPage.jsx`, all 7 game table components, `RoundSummaryModal.jsx`,
  `ScorecardPage.jsx`

**13-C.3: Mid-Round Game Start** *(build)*
- `playerJoinHoles` data model added; universal eligibility rule implemented
- `playerGameStart = max(game.startHole, player.joinHole ?? 0)`
- Nines fresh-start rotation; Sixes dynamic segment alignment; Nassau midpoint
- Files: `roundUtils.js`, `roundLib.js`, `payouts.js`, `NewRoundPage.jsx`,
  `GameConfig.jsx`

**13-C.4: Resolver UI Design** *(planning — no code)*
- Specify `DepartureResolverSheet`, `BetPillRow`, `GameResolutionRow` component props
- Clinch detection algorithm for Match/Sixes (close G-3)
- `payouts.js` pre-processing API for segment/press evaluation (close G-1)
- Close all remaining Known Gaps G-1 through G-4
- Output: approved spec before 13-C.5 build begins

**13-C.5: Early Departure — Proactive Entry** *(build)*
- Long-press X flow: save X → confirmation → full resolver
- `DepartureResolverSheet` built per 13-C.4 spec
- `earlyDepartureOpts` written to `activeRound` on confirm
- Locked `–` cells for departed player in `ScoreGrid`; undo tap handler
- Name chip dimming in scorecard header
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`, `DepartureResolverSheet.jsx` (new),
  `roundLib.js`, `roundUtils.js`

**13-C.6: Early Departure — Reactive Entry** *(build)*
- Results → gate: classify players; block for Missing scores; show resolver for
  Early departure (Scenario A and B)
- Write `lastCompletedHole`, `earlyEndOpts`, `earlyDepartureOpts` on confirm
- Files: `App.jsx`, `DepartureResolverSheet.jsx`

**13-C.7: Engine Departure Handling** *(build)*
- `payouts.js`: `end_at_k`, `continue`, `exclude_player` resolutions
- Per-segment and per-press Pay/Abandon applied to engine output
- `RoundSummaryModal` shows `–` for departed/stopped holes
- Files: `payouts.js`, `RoundSummaryModal.jsx`

---

### Sprint 14 — Low Priority Polish

**14-A: Cleanup** *(sequence after all major feature work complete)*
- F-5: Remove legacy shims (confirm all saved rounds migrated before removing)
- F-6: Hint text review and cleanup
- I-5: Delete hooks.js (confirmed dead code)
- H-1: Sahalee hole numbering 1–9 per nine + yardage total fix
- History date range persistence across sessions
- Files: misc
- Priority: Low — do last

**14-B: Advanced scorecard options** *(contract first)*
- C-7: Birdie/bogey indicators (amend UI_Component_Contract.md)
- C-8: Lock/pin scorecard toggle
- Files: `ScoreGrid.jsx`, `ScorecardPage.jsx`

**14-C: Security and misc** *(contract first for A-9)*
- I-3: API key / Face ID security gate
- A-9: Handicap multiplier (amend Handicap_Contract.md)
- In-app splash screen on cold load (~1.5s, logo on green)
- Replace PNG logos with SVG when designer provides file
- Files: `CoursesPage.jsx`, `storage.js`, `App.jsx`

**14-D: iCloud Export Naming**
- I-2: Confirm save-to-Files flow on iOS Safari behaves correctly with current
  naming convention (`The Card YYYY-MM-DD HH-MM.json`)
- Files: `App.jsx`
- Priority: Medium
- Risk: Low — verification only; may require minor filename fix

---

### Future — New Game Formats

Each format requires its own contract session before any code.
Recommended order:

1. **Wolf** — rotating Wolf player; highest priority next format. `GAME_CONFIGS` in 11-I preserves extension point for Wolf's doubling mechanic. Owner confirmed Wolf not until rest of app is solid.
2. **High/Low** — low ball + high ball per hole
3. **Banker (Quota)**, **Scotch/Greensomes**, **Chapman/Pinehurst**
4. **Bingo Bango Bongo**, **Vegas**, **Round Robin**, **Snake**, **Rabbit/Flags/String**
5. **Uneven team matches (1v2)**

---

## Items Requiring Contract Work Before Code

| Item | Contract | Status | Session |
|---|---|---|---|
| ~~11-L: Stableford Teams~~ | ~~`Stableford_Contract.md` → v1.5~~ | ~~✅ complete~~ | ~~11-L~~ |
| ~~13-B: Custom Keypad + X score~~ | ~~`ScoreKeypad_Contract.md`~~ | ✅ v2.1 AUTHORITATIVE | ~~13-B~~ |
| ~~13-C: Partial rounds~~ | ~~`PartialGameContract.md`~~ | ✅ v1.3 AUTHORITATIVE — supersedes Early_Departure and Late_Arrival contracts | ~~13-C~~ |
| 13-D: Late arrival (mid-round start) | `PartialGameContract.md` §3 | ✅ covered — build begins in 13-C.3 | 13-C.3 |
| 14-B: Birdie/bogey indicators | Amend `UI_Component_Contract.md` | Not started | 14-B |
| 14-C: Handicap multiplier | Amend `Handicap_Contract.md` | Not started | 14-C |
| Future: Wolf | New `Wolf_Contract.md` | Not started | Future |
| Future: Other formats | New contract per format | Not started | Future |

---

## Pending Decisions Before Implementation

The following decisions must be confirmed by the owner before Phase 2 of the
named session begins. All confirmed decisions are recorded in the Key Architectural
Decisions section above.

| ID | Session | Question | Recommendation | Status |
|---|---|---|---|---|
| D-4 | 13-D | "Starts on hole" picker visibility: in-progress only | In-progress only | ✅ Confirmed |
| D-5 | 13-D | Nines rotation at non-zero start: fresh start or absolute | Fresh start | ✅ Confirmed |
| D-B0 | 13-B | Keypad layout confirmed on device: 4 rows, 56px height, nav row removed | 4 rows, no nav row | ✅ Confirmed |
| D-C1 | 13-C | Nines `'exclude_player'`: pay through departure hole? | Yes | ✅ Confirmed — `end_at_k` through departure hole; no Nines for remaining holes |
| D-C2 | 13-C | Nassau partial segment with `'payout'`: leader wins partial? | Yes | ✅ Confirmed — partial segment pays to leader (Option A); user may override via pill |
| D-C3 | 13-C | Departed player chip visual treatment in scorecard header | Dimmed chip | ✅ Confirmed — gray tint / reduced opacity |
| D-D1 | 13-C | NOL retroactivity when late-joining player has lower courseHcp | Retroactive (Option A) | Pending — revisit in 13-C.3 |

---

## Deferred / Deprioritized

| Item | Reason deferred |
|---|---|
| 11-B: Shared GameTable shell | Pattern already working; documentation value only; post-Sprint 12 |
| Dark mode | Token structure ready in ui.jsx; low demand |
| Undo delete toast | Low impact |
| Match scorecard rows collapse by default | Low priority |
| CoursesPage GHIN/USGA API import | External dependency; low priority |
| ResultsPage share as graphic email | Done as share sheet PDF; email redesign deprioritized |
| Portrait PDF revert → PNG | If jsPDF causes issues or PDF UX not preferred, revert portrait to PNG. Full revert instructions in ASS. ~5 min to implement. |
| Scorecard options menu (gear icon) | Deferred pending dot display mode design decision |
| Press modal UX: show live match status | Low priority UX enhancement |
| MatchNassauTable column headers for non-zero-start matches | Polish — deferred to post-13-D |
| "Computed over holes 1–k" notes in game table footers | Polish — deferred to post-13-D |
| Game range indicator in game table headers | Polish — deferred to post-13-D |
