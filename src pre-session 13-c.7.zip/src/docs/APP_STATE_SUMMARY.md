# APP_STATE_SUMMARY.md

This document is the lean, current-state record of where the codebase is right now,
along with durable architectural gotchas the AI must not re-break. It is **not** a
session journal — that role belongs to `BUILD_PLAN.md`, which holds the chronological
session history and the open session plan.

This file should remain short. When a session closes, update the **Current State**
paragraph to reflect the new baseline; do not stack additional session paragraphs.

---

## Update policy — read before any session entry

Before logging a session anywhere, confirm all of the following:

1. **Session designation is owner-provided.** Do not invent. If the owner has not
   specified the exact designation (e.g. "13-C.3"), stop and ask.
2. **Every test required by the relevant contract's Testing section passed on
   device.** ("Section 8" of game contracts is the conventional Testing section
   per Universal_Contract_Template.md.) Pending on-device items keep the
   session out of the Completed Sessions table in BUILD_PLAN.
3. **BUILD_PLAN.md has been reviewed and updated** to reflect what this session
   closed, partially resolved, or invalidated. This happens before the ASS update,
   not after.
4. **Any BUILD_PLAN updates that feel wrong were flagged to the owner** before
   being silently committed. Scope creep is visible, not hidden.
5. **The "Work in Flight" block below was updated** (or cleared, if the sprint
   fully completed with this session), and the **Current State** paragraph was
   refreshed to describe the new baseline.

---

## Work in Flight

_Session 13-C.6 (Early Departure Proactive Entry — build) **COMPLETE and device-test confirmed**. Implements `DepartureResolverSheet` / `GameResolutionRow` / `BetPillRow` per `Resolver_UI_Spec.md` §2; `buildResolverGameRows` + `makeDefaultResolution` in a dedicated `pages/scorecard/resolverUtils.js`; long-press X handler in `ScoreGrid.jsx` with inline depart-confirm prompt (Cancel / Yes-leaving); locked `–` cells fully inert; long-press the dimmed player name to undo; styled in-app modal for the resume prompt; `earlyDepartureOpts` round-trip via `roundLib.js` and pass-through via `roundUtils.buildPayoutArgs`. PartialGameContract amended four times during this session: v1.7 → v1.8 (§6.1 `exclude_player` 3+ → 2+); v1.8 → v1.9 (§8.2 long-press X writes nothing); v1.9 → v1.10 (batched device-test wrap-up: `departureHole = h - 1` semantics, undo gesture moved to name td, "Overall" → "Total" rename, Match Total format detection, pill text wrap). `payouts.js` and `games.js` untouched (engine firewall intact). **Next session: 13-C.7 — Early Departure Reactive Entry** (Results→ classification + sheet open). The `payouts.js` engine reader for `earlyDepartureOpts` is 13-C.8 — until that ships, Results-page payouts compute as if the round were full (the resolver writes `earlyDepartureOpts` correctly but `payouts.js` ignores the field). A bug-fix session is queued in BUILD_PLAN.md to address `MatchNassauTable.jsx` Total row-split, keypad scroll-jump during entry, and other accumulated bugs._

---

## Current State

_Last refresh: April 2026 — post-Session 13-C.6 (build delivered, device-test confirmed)._

The partial-round UX is fully shipped end-to-end. Round length is a first-class
concept (`roundStartHole`, `roundNumHoles` in `activeRound`; `roundEndHole`
always derived). Per-game ranges (`gameRanges`) are threaded through engine,
payouts, plumbing, and all 7 game tables. F/B/T payout columns render on the
Results page for every Nassau-structure game (Stroke Play segments, Stableford
segments ind+team, Nines nassau, Match/Nassau per-match). The three game-table
components — `MatchNassauTable.jsx`, `SixesTable.jsx`, `DotsTable.jsx` — are
range-aware and trim out-of-range columns visually. ScoreGrid landscape width
constraint covers TotalsCard + game tables. X-score totals correctly include
X holes (pre-existing `parseInt('X')` = NaN bug fixed in 13-C.3 Phase 2B).
ESC is suppressed on partial rounds. Results → is always tappable; the
incomplete check lives at save-time only.

The early-departure proactive-entry path is fully shipped and device-confirmed
as of 13-C.6. Long-press X on a score cell does NOT write a score; it opens a
confirmation prompt. "Yes leaving" opens the resolver sheet with the player's
participating games; on Confirm, `earlyDepartureOpts[i] = { departureHole,
gameResolutions }` is written, and post-departure cells (hole `h_longpress`
and later) lock to non-interactive `–`. The dimmed player name is the
long-press target for undoing the departure (locked `–` cells are inert);
the undo prompt is a styled in-app modal. Match format detection works:
Nassau matches show Front/Back/Total rows; Total matches show only the
single Total row. Universal "Total" terminology across all game families
in the resolver UI. `buildResolverGameRows` lives in a dedicated
`resolverUtils.js` (kept out of `scorecardUtils.js` to prevent boundary
drift). Round-trip persistence works; `buildPayoutArgs` passes the
field through.

**`payouts.js` does not yet read `earlyDepartureOpts`** — that is 13-C.8
work; meanwhile Results-page payouts are computed as if the round were
full, which is the expected gap until 13-C.8 ships. The proactive-entry
writer is fully functional standalone — the engine reader is the missing
half.

The reactive-entry path (Results → tap with incomplete scores opens the
sheet via classification per PartialGameContract §5.2) is 13-C.7. The
engine reader is 13-C.8. After 13-C.8 ships, the resolver decisions will
flow through to actual payout computation end-to-end.

13-C.4 (Mid-Round Game Start) was deferred — `playerJoinHoles` engine work
judged not worth the effort relative to use-case frequency. See BUILD_PLAN.md
Deferred / Deprioritized table for full deferral context, scope as planned,
and the open decisions to revisit if reinstated. Sprint 13-C continues
through 13-C.8 with the early-departure work unaffected by the 13-C.4
deferral.

---

## Tech Stack

- **React 18** (JSX, hooks) — no class components
- **Vite** — dev server and bundler
- **Pure CSS-in-JS** — all styles are inline JS objects; no external CSS libraries
- **localStorage** — sole persistence layer; no backend, no database
- **Netlify** — drag-and-drop `dist/` deploy

---

## Implementation Gotchas (AI must not re-break these)

### H-1: `restoreDotDefs()` required after deserialization
Any code path that reads `dots` from localStorage or from `activeRound` must call
`restoreDotDefs(dots)` before using the dot definitions. Serialization strips the
`autoWhen` functions. Skipping this call causes auto-marking to silently fail.
Renamed from `restoreAutoWhen()` in Session 11-A.

### H-2: Score inputs must use `display: 'block'`
iOS expands the height of focused inputs unless `display: 'block'` is set explicitly.
Without this, focusing a score cell shifts the entire row downward. Fixed in 1-C.
Do not remove this style from score `<input>` elements.

### H-3: `activeRound` must be a deep clone on load
`getActiveRound()` in `App.jsx` must return a parsed copy from localStorage, never
a live reference. Mutating a cached reference corrupts the stored state silently.

### H-4: Landscape detection — single source of truth in `ScorecardPage`
`isLandscape` is computed once in `ScorecardPage.jsx` and passed down as a prop to
`ScoreGrid` and all game table components. `ScoreGrid` has a local fallback detection
only for the case where the prop is not supplied (e.g. read-only summary view).
Do not add a second independent landscape detector in `ScoreGrid` — it will diverge.

### H-5: `TotalsCard` is rendered inside `ScoreGrid`, not `ScorecardPage`
`TotalsCard` is mounted at the bottom of `ScoreGrid`'s return tree, not in
`ScorecardPage`. This is intentional — it keeps all scorecard display logic
co-located. Do not move it to `ScorecardPage` without explicit owner approval.

### H-6: `StyledSel` / `PlayerDropdown` — do not create parallel picker implementations
All player picker UI and option selects in New Round setup must use `StyledSel`,
`PlayerDropdown`, or `ReadOnlyBubble` from `PlayerDropdown.jsx`. These were created
in 11-D specifically to unify picker appearance. A second custom select component
anywhere in setup UI is a violation of this pattern.

### H-7: Name display convention — always first + last, no collision detection
The final convention (established post-11-D) is: always show first name (larger,
darker) + last name (smaller, lighter) unconditionally. `resolveDisplayNames` was
removed from most consumers after this decision. Do not reintroduce collision-aware
logic or first-name-only display without explicit owner approval.

### H-8: `GAME_CONFIGS` is static — `betType` is never stored in round state
`betType` is a UI dispatch concept that lives only in the static `GAME_CONFIGS`
constant in `NewRoundPage.jsx` (created in 11-I.1). It must never appear in
`gameOpts`, `activeRound`, or any persisted state. The game key (e.g. `'Match'`,
`'Skins'`) implies the allowed betting models — they do not need to be stored.
Adding `betType` to `gameOpts` is a contract violation.

### H-9: Nassau terminology is retired from all user-facing surfaces
As of 11-I, the word "Nassau" must not appear in any UI label, button, toggle,
game tile, or payout display. The behavior formerly called "Nassau" is exposed as
Front/Back/Overall bet fields. Code comments may retain the word for historical
clarity. Do not reintroduce "Nassau" as a UI term without explicit owner approval.

### H-10: NOL dot selector — `subsetIdxs` is authoritative, never parse `nolDotGame` value
`nolDotGame` state value can be a single-game string (`'Skins'`), a match ID
(`'Match:m_123'`), or a fingerprint string (`'1,2,3'`) when games share a subset.
`ScorecardPage` always derives `effectiveMinCourseHcp` and `nonParticipantIdxs` from
`opt.subsetIdxs` — never by parsing or inspecting the value string beyond identity
comparison (`o.value === nolDotGame`). Do not add value-string parsing logic anywhere.

### H-11: Center nav button from setup tab triggers `handleStart`, not a direct tab switch
As of 11-K, `handleCenterTap` in `App.jsx` calls `startTriggerRef.current?.()` when
`inProgress && tab === 'new-round'`. This runs the full round re-assembly (same as
"Start Scoring"), committing any game config changes to `activeRound` before the
scorecard mounts. The ref is kept current via a no-dep-array `useEffect` in
`NewRoundPage`. Do not change this back to a direct `setTab('scorecard')` call —
doing so breaks the NOL pill reset and reverts the `manualPresses` preservation fix.

### H-12: Stableford `opts.scoring` field — do not use as `grossNetNOL` fallback
As of 11-L, `gameOpts.Stableford.scoring` holds the team hole-scoring rule
(`'cumulative'` | `'bestball'`), not a handicap mode value. The generic fallback chain
`o.grossNetNOL ?? o.scoring ?? default` used by all other games must **not** be applied
to Stableford — it would corrupt `grossNetNOL` to `'cumulative'` whenever team mode is
active. `Stableford: 'net'` is explicitly listed in `GNL_DEFAULTS` in both
`NewRoundPage.allOpts` and `App.jsx getActiveRound` to short-circuit the fallback.
`payouts.js` and `StablefordTable` read `mode` as `grossNetNOL ?? 'net'` only (no
`scoring` fallback). Do not reintroduce `?? o.scoring` for Stableford at any read site.

### H-13: `'X'` is a valid score value — do not sanitize it away
`scores[h][i]` may contain `'X'` (player picked up). The score normalization guard
that sanitizes invalid values to `''` must explicitly pass `'X'` through as valid.
Sanitizing `'X'` to `''` silently converts a deliberate pickup into a missing score,
breaking payout calculations. `'X'` is never stored as `'7X'` — the computed gross
value is derived at render time via `xGrossScore()`. Do not persist display strings.

### H-14: System keyboard must never appear during score entry
`ScoreKeypad.jsx` is the sole score entry mechanism throughout the app. The
hidden-input / `.focus()` pattern in `ZoomModal.jsx` is retired as of 13-B. Any
code path that calls `.focus()` on a hidden input for score entry is a contract
violation. Do not reintroduce native `<input>` focus for score cells.

### H-15: `parseInt('X')` returns NaN — always check for `'X'` before parseInt
Any function that accepts a raw score from `scores[h][i]` must check `raw === 'X'`
before calling `parseInt(raw)`. `parseInt('X')` returns `NaN`, which silently
corrupts all downstream comparisons and totals. This applies to display tables
(`NinesTable`, `MatchNassauTable`) as well as engine functions. Both were fixed
in 13-B; ScoreGrid `grossTotal`/`netTotal` half-totals were fixed in 13-C.3 Phase
2B (same bug pattern). Do not regress this.

### H-16: `kpValue` is always seeded `''` — first digit always replaces committed score
When `openKeypadOnCell`, `kpAdvanceCell`, `kpRetreatCell`, or `handleKpNavigate`
sets a new active cell, `kpValue` is always initialized to `''`. The keypad treats
every cell activation as a fresh entry — the first digit replaces whatever committed
score is in the cell. Seeding `kpValue` from the committed score causes the
"15 bug" (digit appends to existing score and clamps to 15). Do not change this.

### H-17: ZoomModal is a pure display component — no keyboard machinery
`ZoomModal` contains no hidden input, no `.focus()` calls, no advance/retreat timer,
and no `onKeyDown` handler. Score entry flows entirely through ScoreGrid's keypad
state via the `onCellTap` prop. The active cell border is driven by the `activeKpCell`
prop. The `cardRef` prop attaches ScoreGrid's `zoomCardRef` to the card div so the
global `touchend` dismiss handler exempts touches inside ZoomModal. Do not add
keyboard focus logic or internal active-cell state back to ZoomModal.

### H-18: `zoomCardRef` must remain in dismiss handler exemption list
ScoreGrid's global `touchend` dismiss handler (which clears `activeKpCell`) exempts
three targets: `INPUT` elements, `kpContainerRef` (the keypad), and `zoomCardRef`
(the ZoomModal card). Removing `zoomCardRef` from this list causes tapping any
ZoomModal cell to immediately clear `activeKpCell` — the keypad closes on every
cell tap. Do not remove this exemption.

### H-19: DotsPopup saves/restores `activeKpCell` — do not bypass this
When a long-press fires, `startLongPress` saves `activeKpCellRef.current` to
`savedKpCellRef` and clears `activeKpCell` (hides keypad). When DotsPopup closes,
`onClose` restores from `savedKpCellRef`. This is how the keypad reappears on the
correct cell after DotsPopup without requiring the user to tap again. `activeKpCellRef`
is a ref mirror of `activeKpCell` state (updated via `useEffect`) — it always holds
the current value inside the `setTimeout` closure. Do not read `activeKpCell` state
directly inside `startLongPress`'s timer callback — the closure would capture a stale
value.

### H-20: `roundStartHole` / `roundNumHoles` — derive end hole, never store it
`activeRound` stores `roundStartHole` (0-based, default 0) and `roundNumHoles` (default
18). `roundEndHole = roundStartHole + roundNumHoles - 1` must always be derived at
the call site — never stored. Storing `roundEndHole` directly is a contract violation
(PartialGameContract invariant #17). Callers must apply `?? 0` / `?? 18` defaults at
read time since legacy records have `undefined` for both fields. The scores array is
always 18 slots regardless of round length — `roundStartHole`/`roundNumHoles` control
display and compute scope, not the array shape.

### H-21: Any new field added to `fromActiveRound`/`toActiveRound` must also go in `toSetupState`
`toSetupState` is the path by which a saved historical round is restored into
`NewRoundPage`'s init state on reload. If a field is present in `fromActiveRound`
and `toActiveRound` but absent from `toSetupState`, the field will silently reset
to its default when a round is reloaded for editing — a data-loss bug with no error.
Discovered in 13-C.2: `manual_presses` was missing from `toSetupState`, causing press
configurations to be lost on reload. `round_start_hole`/`round_num_holes` also required
explicit restoration. Rule: whenever a new field is added to `fromActiveRound`, add it
to `toSetupState` in the same change. See `App_Data_Model_Contract.md` invariant #16.

### H-22: ESC (Adjusted Gross Score) is only shown for full 18-hole rounds
`TotalsCard` omits the ESC sub-line when `roundStartHole !== 0` or `roundNumHoles !== 18`.
The engine `escTotal()` always iterates all 18 holes — on partial rounds this would show
a misleading value (and would include stale out-of-round scores for reloaded historical
rounds). Per PartialGameContract §1A.8 and GHIN requirements, ESC is only meaningful for
full 9 or 18-hole submissions. Don't show ESC for partial rounds; let players compute
their own. If `isFullRound = (rsh === 0 && rnh === 18)` is false, render nothing.

### H-23: Draft-string pattern for numeric form inputs — clamp on blur, not on keystroke
When a numeric input field needs validation/clamping (e.g. round length pickers), use
the draft-string pattern: maintain a separate `draft` state string decoupled from the
committed numeric state. `onChange` updates the draft string. `onFocus` clears the draft
to `''` (replaces on first keystroke). `onBlur` validates the draft and either commits
it or reverts to the prior committed value. Do NOT clamp on every keystroke — that
causes mid-typing snaps (e.g. typing "12" snaps to min after typing "1"). Invalid
entries (NaN, zero, out-of-range) should revert to prior value, not clamp to min.

### H-24: iOS input baseline shift — wrap `<input>` in flex-centered outer div
For numeric inputs in form UI, an `<input>` element will visually shift vertically
on iOS Safari when it transitions between empty and populated states during editing
(the browser changes internal baseline positioning between cursor-mode and text-mode).
Fix: wrap the `<input>` in an outer `<div>` that owns the visible box styling
(fixed height, border, background, `display:flex`, `alignItems:center`,
`justifyContent:center`). The inner `<input>` has no border, transparent background,
and is naturally sized by its content. This decouples the visible box dimensions from
the browser's internal text-baseline quirks. Same pattern as `ScoreGrid.renderCell`
(introduced in 13-B.1 to fix the cell sizing issue). Applied to Round Length inputs
in 13-C.2. Do not use `<input>` as its own visible box in form fields where iOS
baseline shift could occur.

---

### H-25: Verify imports for every new identifier — `grep -c` counts call sites only
When adding a new helper function call to a file, especially when refactoring or
extracting code across files, do not rely on `grep -c "newSymbol"` to verify the
edit is correct. The grep counts call sites; it does not verify that the symbol
resolves at runtime. A call to an unimported symbol throws `ReferenceError` only
when the call site executes — not at parse time, not at module load. This means
a file can pass syntax checks, brace balance, and grep-based completeness checks
yet still throw at runtime in a code path that wasn't exercised during validation.

The 13-C.6 device-test fixes uncovered this when `resolverUtils.js` called
`isNassauMatch(md)` without the matching import. The function ran fine in tests
that didn't hit the Match branch; once tested with an active Match game, the
resolver opened, threw `ReferenceError`, and silently aborted mid-execution
(prompt closed but sheet didn't open, because `setDepartPrompt(null)` ran before
the throw and `setResolverState({open: true})` never did).

Verification rule: for every new identifier added inside a file, explicitly
verify it appears in the file's `import {…}` block. Either grep the import
block specifically (`sed -n '/^import/,/^[^ ]/p' file.js | grep newSymbol`)
or include it in the staging-validation step. This is a CI-style check that
cannot be skipped on the assumption "I just added the call, the import must
be there too."

---

## Open Items

Active open work and small carry-over items that don't yet warrant their own
session entry. Larger backlog and deferred items live in BUILD_PLAN.md
(Open Session Plan, Items Requiring Contract Work, Pending Decisions, Deferred /
Deprioritized).

### Sprint 12 carry-over

**12-B Nines table display** — D-2: "pts" label on Nines total chips. Note: D-6
(NinesTable renders only 3-player subset) and D-7 (breakdown rows filter to subset)
were completed in 11-I.1 ✅. Priority: Medium.

### Sprint 13 — next session

**13-C.7 Early Departure — Reactive Entry** (build) — implements the
Results → classification path per `PartialGameContract.md` §5.2: when the
user taps Results → with incomplete scores, classify each player and route
to either the Scenario A or Scenario B resolver. Reuses
`DepartureResolverSheet` from 13-C.6. Range-validity re-evaluation per
`Resolver_UI_Spec.md` §5.5 if round length changed since departure. See
BUILD_PLAN.md for full scope.

**13-C.8 Early Departure — Engine Departure Handling** (build) — finally
makes `earlyDepartureOpts` and `earlyEndOpts` change payout computation.
`payouts.js` pre-processing API per `Resolver_UI_Spec.md` §4: dispatcher,
segment-status evaluator, per-segment / per-press abandon-zeroing,
exclude_player subset removal, end_at_k score trimming. `RoundSummaryModal`
display layer for `–` post-departure rendering. After 13-C.8 ships, the
proactive entry path will produce correct payouts end-to-end.

**13-C.4 Mid-Round Game Start — DEFERRED.** Late-arrival engine work
(`playerJoinHoles` field consumption in payouts.js) judged not worth the cost
relative to use-case frequency. Full design discussion, owner-confirmed
decisions (Skins per-skin / pot rules, carryover behavior, score sentinel
rejection), and open questions for any future reinstatement are preserved
in BUILD_PLAN.md Deferred / Deprioritized table. The `playerJoinHoles` field
remains specified in `PartialGameContract.md` §3 / §4.1 / §13 as future-facing
spec. Pending decision **D-D1** (NOL retroactivity) is withdrawn until / unless
the parent session is reinstated.

**Critical retest carried over from 13-C.3:** Load a full 18-hole round, reload
into `NewRoundPage` and shorten to 9 holes — confirm all three table components
trim correctly and engine computes only over 9 holes. This is the explicit
partial-round history-reload retest.

---

## Document Index

Contract version pins below verified against each contract's actual version
header (April 2026 audit).

### Current contracts and core docs

| Document | Version | Purpose |
|---|---|---|
| `ARCHITECTURE_FOUNDATIONS.md` | — | Mental models, layer system, the "why" |
| `App_Data_Model_Contract.md` | v3.3 | State schema, storage keys, mutation rules; v3.3 (13-C.3 Phase 2A) §5.1 `gameRanges` field; §10 `buildPayoutArgs` shape; engine firewall reference updated to invariant #13.b. v3.2 (13-C.2) `roundStartHole`/`roundNumHoles`; `toSetupState` completeness rule + invariant #16. |
| `Round_Lifecycle_Contract.md` | v2.0 | Setup→score→save flow, activeRound lifecycle; v2.0 (13-C.3) §7 `gameRanges` required, §12 invariant 22 round-trip. v1.9 (13-C.2) Results → always tappable; save-time gate; round length fields. |
| `Handicap_Contract.md` | v1.6 | USGA math, `scoreForMode`, `escTotal`, `DEFAULT_STAB`; v1.6 NOL dot selector pill spec, qualifying rule, `computeNolDotOptions`. Includes 13-B X-score amendments (§5.14 X handling in `escTotal`, §5.15 `xGrossScore()`, invariants #15–#17). |
| `Payout_Contract.md` | v1.12 | `computePayouts` entry point, `subsetMin` pattern; v1.12 (13-C.3) §3.2 generalized BreakdownEntry shape (flat vs columnar via `entry.colHeaders`); §7.1/§7.3/§7.4/§7.5 per-game updates. v1.11 §4.4 X score handling. |
| `Nassau_Match_Contract.md` | v2.9 | Nassau/Match Play rules, press system, engine API; v2.9 (13-C.3) §1.3 partial-range note + `runMatchNassau` `range` arg. v2.8 §5.6 match instance label + §16.3 Dots teamMode per-instance. |
| `Sixes_Contract.md` | v1.10 | Sixes team rotation, hole scoring, press system; v1.10 (13-C.3) §3.6 clarification + §3.7 partial-range section with dynamic segLen. Includes 13-B X-score behavior section. |
| `Skins_Contract.md` | v1.7 | Skins carryover (boolean), subset behavior; v1.7 (13-C.3) §3.1 partial-range section, `gameRanges['Skins']` resolution + carryover semantics within custom range. Includes 13-B X-score behavior section. |
| `Stableford_Contract.md` | v1.6 | Stableford points table, `betMode`, condor key `'4'`; team scoring (`cumulative`/`bestball`), team payout (per-player full-rate). v1.6 (13-C.3) §3.7 partial-range, §5.3/§5.7 colHeaders emission. Includes 13-B X-score behavior. |
| `Nines_Contract.md` | v1.5 | Nines point table, `betMode`, blitz rule, 3-player constraint; v1.5 (13-C.3) §3.7 partial-range, §5.4 colHeaders emission. Includes 13-B X-score behavior section. |
| `Stroke_Play_Contract.md` | v1.7 | Stroke play `betMode` total/segments, `strokePlayPlayers` subset, `calcStrokePlay`; v1.7 (13-C.3) split-pot tie behavior in segments mode (G-4 closed); §3.7 partial-range; §5.8/§5.9 columnar emission. Includes 13-B X-score behavior (X = unscored). |
| `Dots_Contract.md` | v2.4 | Dots/Junk: `DOTS_DEF`, discrete scoring specials, mutual exclusivity; team payout exclusion, per-segment breakdown columns, DotsTable team layout. v2.4 (13-C.3) §7.5 generalization note (columnar shape now shared with Stroke Play / Stableford / Nines / Match). Includes 13-B X-score behavior (no auto-mark on X holes). |
| `PartialGameContract.md` | v1.10 AUTHORITATIVE | Partial round, predetermined ranges, mid-round start, early departure. v1.10 (13-C.6 device-test wrap-up) — batched amendment: §4.5 + §8.2 step 3 `departureHole` semantics clarified (long-press hole h → h is FIRST locked, departureHole = h-1); §8.3 + §8.4 undo gesture moved from "tap locked cell" to "long-press dimmed player name"; locked '–' cells fully inert; styled in-app modal replaces `window.confirm`; §10 universal "Overall" → "Total" rename; §10.1 Match format detection (Nassau renders F/B/T, Total renders Total only); pill labels permitted to wrap to multi-line. v1.9 (13-C.6 post-fix) §8.2 step 1 — long-press X no longer writes 'X' to `scores[h][i]`; the gesture is pure departure-intent, not score entry. Step 2 button labels updated to Cancel / Yes-leaving. v1.8 (13-C.6) §6.1 — `exclude_player` minimum-remaining-players rule corrected from 3+ to 2+ for Stableford-individual / Stroke Play / Dots; the previous 3+ rule had no per-game justification. v1.7 (13-C.5) §6.3, §10.1, §10.2, §11.8 — not-started press treatment corrected (omitted from sheet, not auto-Abandoned row); §16 G-1 through G-4 closed with cross-references to `Resolver_UI_Spec.md`. v1.6 (13-C.3) §3.6 universal F/B/T midpoint rule; §14 invariant #13 relaxed for two surgical `range` args; §14 invariant #15 split into live (#15a) vs read-only (#15b). v1.5 (13-C.2) Start + End hole UI, ScoreGrid gray-cells, TotalsCard round-scoped + ESC omission. |
| `ScoreKeypad_Contract.md` | v2.2 AUTHORITATIVE | Custom keypad: 4-row fixed-bottom; `ScoreGrid` owns keypad state; ZoomModal pure display; X score type — `xGrossScore()`, "X always loses" invariant, per-game X behavior. v2.2 (13-B.2) §3.4–§3.8 corrected — ZoomModal prop list, `openZoom` behavior, `useEffect` cell activation, three ref patterns (`savedKpCellRef`/`activeKpCellRef`/`longPressFired`). |
| `UI_Component_Contract.md` | v1.3 | `ui.jsx` tokens, all components, `style` prop pattern; v1.3 §4.9 `ShareOrientationPicker` spec. |
| `Universal_Contract_Template.md` | v1.0 AUTHORITATIVE SKELETON | Template every game contract must conform to. |

### Process / planning docs

| Document | Purpose |
|---|---|
| `BUILD_PLAN.md` | Authoritative session history, completed sessions table, open session plan, deferred items, decision log. |
| `APP_STATE_SUMMARY.md` (this file) | Lean status, gotchas (H-1…H-25), open items, document index. |
| `Session_Intro_Template.md` | Boilerplate prompt for starting a fresh chat session. |
| `NewRoundPage_Design_Spec.md` | 11-H output: full NewRoundPage setup UI design spec. |
| `Resolver_UI_Spec.md` | v1.0 (13-C.5 output): implementation-level spec for early-departure resolver — component prop interfaces (§2), clinch detection algorithm (§3), `payouts.js` pre-processing API (§4), range validation rules (§5). Consumed by 13-C.6, 13-C.7, 13-C.8. |

### Superseded / historical

| Document | Status | Notes |
|---|---|---|
| `Early_Departure_Contract.md` | v1.0 DRAFT — superseded | Superseded by `PartialGameContract.md` in 13-C. Retained for historical reference. |
| `Late_Arrival_Contract.md` | v1.0 DRAFT — superseded | Superseded by `PartialGameContract.md` in 13-C. Retained for historical reference. |
| `Dots_Contract_v2_0.md`, `Dots_Contract_v2_1.md` | Stale duplicates | `Dots_Contract.md` is current at v2.4. **Housekeeping:** remove these two legacy files from the project knowledge base when convenient. |
