// ─── scorecard/resolverUtils.js ───────────────────────────────────────────────
// Display-logic helpers for the early-departure resolver UI.
//
// PURPOSE
//   Produces the `GameRow[]` array consumed by `DepartureResolverSheet` per
//   `Resolver_UI_Spec.md` §2.1, plus the default-resolution shape used to
//   seed the sheet's draft state per §10.2. This is the bridge between
//   the engine layer (game-result computation) and the resolver UI
//   (per-game pill display + per-segment / per-press status badges).
//
// ARCHITECTURE POSITION
//   Same layer as `scorecardUtils.js` Category-2 derived-state builders:
//   calls engine functions and interprets their output for UI consumption.
//   Extracted to its own file (and not added to scorecardUtils.js) because:
//     1. It's a coherent feature subdomain (resolver) consumed by exactly
//        one feature path, not the whole scorecard.
//     2. It will grow further in 13-C.7 (reactive Results→ entry path) and
//        likely 13-C.8 (engine reader). Keeping it isolated prevents
//        scorecardUtils.js from becoming a catch-all general-utility file
//        (warned against in ARCHITECTURE_FOUNDATIONS.md §2).
//     3. Engine-call dependencies here (runMatchNassau, runSixesSegment,
//        getSixesTeam, matchLabel) are wider than scorecardUtils.js's
//        existing engine surface — confining them here keeps the
//        scorecardUtils.js engine import minimal.
//
// ENGINE FIREWALL
//   The clinch evaluator (Resolver_UI_Spec §3.4) is pure arithmetic and
//   does NOT import from payouts.js. Its math will be reproduced inside
//   payouts.js in 13-C.8 (per Resolver_UI_Spec §3.5: "the algorithm runs
//   entirely in payouts.js pre-processing"). The engine-side and display-
//   side implementations are intentionally independent — neither imports
//   the other — keeping the engine layer free of display dependencies and
//   honoring PartialGameContract §11.1 (engine firewall absolute).
//
//   The two `_subsetMin` and `_splitRangeByMidpoint` helpers are inlined
//   here because the canonical definitions in payouts.js are not exported
//   and the session-13-C.6 engine firewall prohibits modifying payouts.js
//   to export them. If those payouts.js helpers are ever changed, this
//   file must be updated to match.
//
// CROSS-REFERENCES
//   - Resolver_UI_Spec.md §2 (component prop interfaces, GameRow shape)
//   - Resolver_UI_Spec.md §3 (clinch detection algorithm)
//   - PartialGameContract.md §4.2 (SegmentedResolution type)
//   - PartialGameContract.md §6.1 (per-game option matrix; exclude_player
//     2+ remaining rule, amended in 13-C.6 from previous 3+ rule)
//   - PartialGameContract.md §7 (game family rules — clinch / completion /
//     hole-by-hole)
//   - ARCHITECTURE_FOUNDATIONS.md §2 (three-layer model; this file sits
//     in the Display Logic Layer alongside scorecardUtils.js)
//
// SELF-CHECK STAMPS
//   ✅ Self-checked (13-C.6): Clinch evaluator pure arithmetic per §3.4 —
//   no engine logic. Engine calls (runMatchNassau, runSixesSegment) mirror
//   the existing call sites in payouts.js exactly (same arg order, same
//   shapes). Not-started presses are filtered BEFORE the GameRow.presses[]
//   array is constructed (failure-mode check 8c bullet 2). Match instances
//   where no departed player participates are skipped entirely (Scenario A
//   §10.3). `topLevelVariant` is set on clinch-family `end_at_k`
//   resolutions only — never on completion or hole-by-hole families
//   (failure-mode check 8c bullet 1). `exclude_player` offered when ≥ 2
//   players remain after removal (PartialGameContract §6.1 v1.8).
//   ✅ Self-checked (13-C.6 device-test): Nassau vs Total Match
//   detection via `isNassauMatch(md)`. Nassau matches render Front / Back
//   / Total rows as before. Total matches render only the Total row,
//   with all presses parented under it. Storage key remains `overall`
//   for backward compatibility with already-saved gameResolutions; the
//   user-facing label is "Total" in both Nassau and Total contexts.
//   "Overall" label removed everywhere — Stableford / Stroke Play / Nines
//   completion segments now render as "Total" instead.

import { runMatchNassau, runSixesSegment, getSixesTeam, matchLabel,
         isNassauMatch }
  from '../../engine/games.js';

// ─── Inlined helpers (mirror payouts.js privates) ─────────────────────────────
// Canonical definitions live in payouts.js (`subsetMin` and the local body of
// `splitRangeByMidpoint`) but that file is engine-firewall-locked per
// session 13-C.6 Section 6. These versions track those originals exactly.

function _subsetMin(cHcps, idxs, globalMin, mode) {
  if (mode !== 'netofflow' || !idxs?.length) return globalMin;
  return Math.min(...idxs.map(i => cHcps[i]));
}

function _splitRangeByMidpoint(startHole, endHole) {
  const total = endHole - startHole + 1;
  const mid   = startHole + Math.floor(total / 2);
  const front = []; const back = []; const all = [];
  for (let h = startHole; h < mid;       h++) front.push(h);
  for (let h = mid;       h <= endHole;  h++) back.push(h);
  for (let h = startHole; h <= endHole;  h++) all.push(h);
  return { front, back, all, mid };
}

// Per-game effective range — mirrors the helper inside ScoreGrid.jsx and
// payouts.js (`rangeFor`). Returns the round range when no per-game
// override is set or the override is malformed.
function _gameRange(key, gameRanges, roundStartHole, roundEndHole) {
  const e = gameRanges?.[key];
  if (e
      && Number.isInteger(e.startHole)
      && Number.isInteger(e.endHole)
      && e.startHole >= roundStartHole
      && e.endHole   <= roundEndHole
      && e.startHole <  e.endHole) {
    return { startHole: e.startHole, endHole: e.endHole };
  }
  return { startHole: roundStartHole, endHole: roundEndHole };
}

// ─── Status evaluators ────────────────────────────────────────────────────────

// Clinch-segment status evaluator (Resolver_UI_Spec §3.4).
//   betStartHole / betEndHole — 0-based, inclusive — the hole range of the bet
//   departureHole              — 0-based — last hole the departed player(s) scored
//   holesWonA / holesWonB      — hole-win counts for sides A and B at departureHole
// Returns { status, leader, lead } per spec §3.3.
//
// 'closed'      iff one side leads by more holes than holes remain (dormie + 1)
// 'in_progress' iff bet has at least one played hole and is not closed
// 'not_started' iff betStartHole > departureHole — sentinel for caller to filter
function evalClinchStatus(betStartHole, betEndHole, departureHole, holesWonA, holesWonB) {
  if (betStartHole > departureHole) {
    return { status: 'not_started', leader: null, lead: 0 };
  }
  const lead = Math.abs(holesWonA - holesWonB);
  const holesRemaining = Math.max(0, betEndHole - departureHole);
  const status = lead > holesRemaining ? 'closed' : 'in_progress';
  let leader = null;
  if      (holesWonA > holesWonB) leader = 'A';
  else if (holesWonB > holesWonA) leader = 'B';
  return { status, leader, lead };
}

// Completion-segment status (PartialGameContract §7.2).
// 'complete' iff departureHole >= last hole of segment range; otherwise 'partial'.
// Caller filters segments whose start is past departureHole BEFORE calling.
function evalCompletionStatus(segStartHole, segEndHole, departureHole) {
  return departureHole >= segEndHole ? 'complete' : 'partial';
}

// ─── buildResolverGameRows ────────────────────────────────────────────────────

/**
 * Constructs the GameRow[] array consumed by `DepartureResolverSheet` per
 * `Resolver_UI_Spec.md` §2.1. Iterates `activeRound.activeGames`, classifies
 * each game's family (clinch / completion / holeByHole), assembles
 * `topLevelOptions` per `PartialGameContract.md` §6.1's matrix, and runs the
 * §3.4 clinch evaluator (Match, Sixes) or §7.2 completion evaluator (Nines,
 * Stableford-segments, Stroke Play-segments) to produce per-segment and
 * per-press status.
 *
 * Scenario A behavior (Resolver_UI_Spec §10.3):
 *   - Match instances: only included when at least one departed player
 *     participates. Non-participating matches are skipped entirely.
 *   - Other games: only included when at least one departed player is in
 *     the game's participant subset.
 *
 * Not-started presses (`betStartHole > departureHole`) are filtered out
 * before being added to `GameRow.presses[]` per Resolver_UI_Spec §2.4(b).
 *
 * `exclude_player` rule (PartialGameContract §6.1 v1.8, amended in 13-C.6):
 *   Offered when ≥ 2 players remain in the game's subset after removing
 *   departed player(s). Not offered for Match (end the match instead),
 *   Stableford team (broken team), Nines (hard 3-player engine constraint),
 *   Sixes (hard 4-player engine constraint), Skins (per-hole independence).
 *
 * @param  {object}   activeRound          full activeRound blob
 * @param  {number[]} departedPlayerIdxs   indices into activePlayers of departed players
 * @param  {'A'|'B'}  scenario             'A' = some players remain, 'B' = all stop
 * @param  {number}   departureHole        0-based last hole the departed player(s) scored
 * @returns {GameRow[]}                    rows to render in the sheet
 */
export function buildResolverGameRows(activeRound, departedPlayerIdxs, scenario, departureHole) {
  const ar = activeRound || {};
  const players       = ar.activePlayers     || [];
  const activeGames   = ar.activeGames       || [];
  const gameOpts      = ar.gameOpts          || {};
  const matches       = ar.matches           || [];
  const scores        = ar.scores            || [];
  const hcps          = ar.hcps              || [];
  const courseHcps    = ar.courseHcps        || [];
  const minCourseHcp  = ar.minCourseHcp      ?? 0;
  const manualPresses = ar.manualPresses     || {};
  const sixesTeams    = ar.sixesTeams        || [null, null, null];
  const sixesPlayers  = ar.sixesPlayers      || [];
  const ninesPlayers  = ar.ninesPlayers      || [];
  const stabPlayers   = ar.stablefordPlayers || [];
  const spPlayers     = ar.strokePlayPlayers || [];
  const skinsPlayers  = ar.skinsPlayers      || [];
  const dotsPlayers   = ar.dotsPlayers       || [];
  const gameRanges    = ar.gameRanges        || {};
  const roundStartHole = ar.roundStartHole ?? 0;
  const roundEndHole   = roundStartHole + (ar.roundNumHoles ?? 18) - 1;

  const allIdxs = players.map((_, i) => i);
  const resolveSubset = arr => (arr && arr.length > 0) ? arr : allIdxs;
  const departedSet = new Set(departedPlayerIdxs);
  const anyDepartedIn = (subset) => subset.some(i => departedSet.has(i));
  // Returns count of subset members NOT in the departed set — i.e. the
  // game's effective remaining-player count after removal in Scenario A.
  const remainingAfterRemoval = (subset) =>
    subset.filter(i => !departedSet.has(i)).length;

  // exclude_player gate per amended §6.1 — 2+ players remaining after removal.
  // Not valid in Scenario B (per §6.1 first bullet).
  const canExcludePlayer = (subset) =>
    scenario === 'A' && remainingAfterRemoval(subset) >= 2;

  // Build "Remove [Name]" / "Remove departed players" label.
  const removePlayerLabel = (subset) => {
    const departedNames = departedPlayerIdxs
      .filter(i => subset.includes(i))
      .map(i => players[i]?.name || '?');
    return departedNames.length === 1
      ? `Remove ${departedNames[0]}`
      : 'Remove departed players';
  };

  const rows = [];

  for (const game of activeGames) {

    // ── Match / Nassau ────────────────────────────────────────────────────────
    // Clinch family. One GameRow per match instance. Only matches involving
    // at least one departed player are added in Scenario A (Spec §10.3).
    if (game === 'Match / Nassau') {
      matches.forEach((md, mi) => {
        const isTeam = md.format === 'team';
        const involved = isTeam
          ? [...(md.teamA || []), ...(md.teamB || [])]
          : [md.p1, md.p2].filter(x => x != null);
        if (!involved.length) return;
        if (scenario === 'A' && !anyDepartedIn(involved)) return;

        const matchKey  = md.id;
        const matchMode = md.grossNetNOL ?? md.scoring ?? 'net';
        const matchMin  = _subsetMin(courseHcps, involved, minCourseHcp, matchMode);

        const range = _gameRange(matchKey, gameRanges, roundStartHole, roundEndHole);

        // Mirror payouts.js call site: separate manual-press buckets per segment.
        const mpForMatch = {
          front:   manualPresses[`Match:${md.id}:Front`]   || [],
          back:    manualPresses[`Match:${md.id}:Back`]    || [],
          overall: manualPresses[`Match:${md.id}:Overall`] || [],
        };

        const { front, back, overall } = runMatchNassau(
          scores, players, hcps, md, courseHcps, matchMin, mpForMatch, range
        );

        // Derive per-segment end holes from range using engine's midpoint rule.
        const total = range.endHole - range.startHole + 1;
        const mid   = range.startHole + Math.floor(total / 2);
        const frontEnd = mid - 1;       // last hole of Front
        const backEnd  = range.endHole; // last hole of Back
        const allEnd   = range.endHole; // last hole of full-range bet

        // Segment label helper — adapts F/B labels to non-9-hole halves.
        const fLen = frontEnd - range.startHole + 1;
        const bLen = backEnd  - mid + 1;
        const isFullStandard = (range.startHole === 0 && range.endHole === 17);
        const frontLabel   = isFullStandard ? 'Front 9' : `Front ${fLen}`;
        const backLabel    = isFullStandard ? 'Back 9'  : `Back ${bLen}`;
        // 13-C.6 device-test fix: Total label for the full-range bet — both
        // for Nassau (where "Total" runs alongside Front/Back) and for
        // straight Match Play (where Total is the only bet).
        const totalLabel   = 'Total';

        // 13-C.6 device-test fix: Detect Nassau vs straight Total Match. In
        // Total mode there are no F/B bets — only the full-range bet — and
        // the resolver must show only that single row, with all manual
        // presses parented to it. The engine's `runMatchNassau` returns
        // populated `front` / `back` / `overall` arrays even for Total
        // matches (for downstream display purposes), so the resolver layer
        // is responsible for filtering down to the actually-existing bet
        // structure.
        const nassau = isNassauMatch(md);
        const segDefs = nassau ? [
          { segKey: 'front',   label: frontLabel, bets: front,   end: frontEnd, segStart: range.startHole },
          { segKey: 'back',    label: backLabel,  bets: back,    end: backEnd,  segStart: mid             },
          { segKey: 'overall', label: totalLabel, bets: overall, end: allEnd,   segStart: range.startHole },
        ] : [
          // Straight Match Play: only the Total bet exists. We keep the
          // segKey 'overall' for storage stability — old records with
          // gameResolutions keyed under 'overall' continue to work — but
          // present it to the user as "Total".
          { segKey: 'overall', label: totalLabel, bets: overall, end: allEnd,   segStart: range.startHole },
        ];

        const segRows   = [];
        const pressRows = [];
        segDefs.forEach(({ segKey, label, bets, end, segStart }) => {
          if (!bets || bets.length === 0) return;
          // Skip segment whose start is after departure (segment never began).
          if (segStart > departureHole) return;

          const baseBet  = bets[0]; // base match for this segment
          const baseEval = evalClinchStatus(
            segStart, end, departureHole, baseBet.p1w, baseBet.p2w
          );
          // (segStart > departureHole filter above means status is always
          // 'closed' or 'in_progress' here — never 'not_started'.)
          segRows.push({ segKey, label, status: baseEval.status });

          // Presses live in bets[1..n]. Each has its own startHole. Filter
          // not-started presses out BEFORE constructing pressRows[]
          // (failure-mode check 8c bullet 2).
          for (let i = 1; i < bets.length; i++) {
            const pb = bets[i];
            const pStart = pb.startHole;
            if (pStart > departureHole) continue; // not-started → omit
            const pe = evalClinchStatus(
              pStart, end, departureHole, pb.p1w, pb.p2w
            );
            pressRows.push({
              pressKey:  `Match:${md.id}:${segKey}:press[${i - 1}]`,
              label:     `Press ${i}`,
              parentSeg: segKey,
              status:    pe.status,
            });
          }
        });

        const baseLabel = matchLabel(md, players); // "Dave vs Alice" / "A & B vs C & D"
        const letter    = String.fromCharCode(65 + mi);
        const gameLabel = `Match ${letter}: ${baseLabel}`;

        rows.push({
          gameKey: matchKey,
          label:   gameLabel,
          family:  'clinch',
          topLevelOptions: [
            { value: 'abandon',                  label: 'Abandon' },
            { value: 'end_at_k_closed_only',     label: 'Pay closed' },
            { value: 'end_at_k_closed_and_open', label: 'Pay closed + open' },
          ],
          segments: segRows,
          presses:  pressRows,
        });
      });
      continue;
    }

    // ── Sixes ────────────────────────────────────────────────────────────────
    // Clinch family. 4-player game. exclude_player NEVER offered (hard
    // 4-player engine constraint).
    if (game === 'Sixes') {
      const subset = sixesPlayers.length ? sixesPlayers : allIdxs.slice(0, 4);
      if (subset.length < 4) continue;
      if (scenario === 'A' && !anyDepartedIn(subset)) continue;

      const sxOpts    = gameOpts.Sixes || {};
      const sxMode    = sxOpts.grossNetNOL ?? sxOpts.scoring ?? 'net';
      const sxScoring = sxOpts.scoring ?? sxOpts.tiebreak ?? 'none';
      const sxAutoN   = (sxOpts.autoPress && sxOpts.autoPress !== 'none')
                        ? parseInt(sxOpts.autoPress) : 0;
      const sxMin     = _subsetMin(courseHcps, subset, minCourseHcp, sxMode);

      const sxR    = _gameRange('Sixes', gameRanges, roundStartHole, roundEndHole);
      const sxLen  = sxR.endHole - sxR.startHole + 1;
      const segLen = Math.floor(sxLen / 3); // validator guarantees divisibility
      const SEG_HOLES = [
        Array.from({ length: segLen }, (_, i) => sxR.startHole + i),
        Array.from({ length: segLen }, (_, i) => sxR.startHole + segLen + i),
        Array.from({ length: segLen }, (_, i) => sxR.startHole + 2 * segLen + i),
      ];
      const SEG_KEYS = ['Sixes:seg0', 'Sixes:seg1', 'Sixes:seg2'];

      const segRows   = [];
      const pressRows = [];

      SEG_HOLES.forEach((holes, si) => {
        if (!holes.length) return;
        const segStart = holes[0];
        const segEnd   = holes[holes.length - 1];
        if (segStart > departureHole) return; // segment never started

        const team = getSixesTeam(si, sixesTeams, players);
        if (!team) return;

        const mpHoles = manualPresses[SEG_KEYS[si]] || [];

        const matchLevels = runSixesSegment(
          holes, scores, players, hcps,
          team, sxMode, sxScoring,
          courseHcps, sxMin,
          sxAutoN, mpHoles
        );
        if (!matchLevels || !matchLevels.length) return;

        const segLabel = `Seg ${si + 1}`;
        const segKey   = `seg${si}`;

        const baseLevel = matchLevels[0];
        const baseEval  = evalClinchStatus(
          segStart, segEnd, departureHole, baseLevel.abw, baseLevel.cdw
        );
        segRows.push({ segKey, label: segLabel, status: baseEval.status });

        for (let i = 1; i < matchLevels.length; i++) {
          const pb = matchLevels[i];
          const pStart = pb.startHole;
          if (pStart > departureHole) continue;
          const pe = evalClinchStatus(
            pStart, segEnd, departureHole, pb.abw, pb.cdw
          );
          pressRows.push({
            pressKey:  `Sixes:${segKey}:press[${i - 1}]`,
            label:     `Press ${i}`,
            parentSeg: segKey,
            status:    pe.status,
          });
        }
      });

      rows.push({
        gameKey: 'Sixes',
        label:   'Sixes',
        family:  'clinch',
        topLevelOptions: [
          { value: 'abandon',                  label: 'Abandon' },
          { value: 'end_at_k_closed_only',     label: 'Pay closed' },
          { value: 'end_at_k_closed_and_open', label: 'Pay closed + open' },
        ],
        segments: segRows,
        presses:  pressRows,
      });
      continue;
    }

    // ── Stableford ───────────────────────────────────────────────────────────
    // Completion family. Individual or team. Segments only when betMode is
    // 'segments'. exclude_player offered for individual mode only in
    // Scenario A when ≥ 2 players remain after removal.
    if (game === 'Stableford') {
      const stabOpts   = gameOpts.Stableford || {};
      const isStabTeam = stabOpts.format === 'team';
      const betMode    = stabOpts.betMode ?? stabOpts.stabBetMode ?? 'perpoint';

      let subset;
      if (isStabTeam) {
        subset = [...(stabOpts.teamA || []), ...(stabOpts.teamB || [])];
      } else {
        subset = resolveSubset(stabPlayers);
      }
      if (!subset.length) continue;
      if (scenario === 'A' && !anyDepartedIn(subset)) continue;

      const segments = [];
      if (betMode === 'segments') {
        const stR = _gameRange('Stableford', gameRanges, roundStartHole, roundEndHole);
        const { mid } = _splitRangeByMidpoint(stR.startHole, stR.endHole);
        const isFullStandard = (stR.startHole === 0 && stR.endHole === 17);
        const fLen = mid - stR.startHole;
        const bLen = stR.endHole - mid + 1;
        const segDefs = [
          { segKey: 'front',   label: isFullStandard ? 'Front 9' : `Front ${fLen}`,
            segStart: stR.startHole, segEnd: mid - 1 },
          { segKey: 'back',    label: isFullStandard ? 'Back 9'  : `Back ${bLen}`,
            segStart: mid,           segEnd: stR.endHole },
          { segKey: 'overall', label: 'Total',
            segStart: stR.startHole, segEnd: stR.endHole },
        ];
        segDefs.forEach(({ segKey, label, segStart, segEnd }) => {
          if (segStart > departureHole) return;
          segments.push({
            segKey, label,
            status: evalCompletionStatus(segStart, segEnd, departureHole),
          });
        });
      }

      const topLevelOptions = [
        { value: 'abandon',  label: 'Abandon' },
        { value: 'end_at_k', label: 'End at hole ' + (departureHole + 1) },
      ];
      if (!isStabTeam && canExcludePlayer(subset)) {
        topLevelOptions.push({ value: 'exclude_player', label: removePlayerLabel(subset) });
      }

      rows.push({
        gameKey: 'Stableford',
        label:   isStabTeam ? 'Stableford (team)' : 'Stableford',
        family:  'completion',
        topLevelOptions,
        segments,
      });
      continue;
    }

    // ── Stroke Play ──────────────────────────────────────────────────────────
    // Completion family. Always individual. exclude_player offered in
    // Scenario A when ≥ 2 players remain after removal.
    if (game === 'Stroke Play') {
      const subset = resolveSubset(spPlayers);
      if (!subset.length) continue;
      if (scenario === 'A' && !anyDepartedIn(subset)) continue;

      const spOpts  = gameOpts['Stroke Play'] || {};
      const betMode = spOpts.betMode ?? spOpts.strokeMode ?? 'total';

      const segments = [];
      if (betMode === 'segments') {
        const spR = _gameRange('Stroke Play', gameRanges, roundStartHole, roundEndHole);
        const { mid } = _splitRangeByMidpoint(spR.startHole, spR.endHole);
        const isFullStandard = (spR.startHole === 0 && spR.endHole === 17);
        const fLen = mid - spR.startHole;
        const bLen = spR.endHole - mid + 1;
        const segDefs = [
          { segKey: 'front',   label: isFullStandard ? 'Front 9' : `Front ${fLen}`,
            segStart: spR.startHole, segEnd: mid - 1 },
          { segKey: 'back',    label: isFullStandard ? 'Back 9'  : `Back ${bLen}`,
            segStart: mid,           segEnd: spR.endHole },
          { segKey: 'overall', label: 'Total',
            segStart: spR.startHole, segEnd: spR.endHole },
        ];
        segDefs.forEach(({ segKey, label, segStart, segEnd }) => {
          if (segStart > departureHole) return;
          segments.push({
            segKey, label,
            status: evalCompletionStatus(segStart, segEnd, departureHole),
          });
        });
      }

      const topLevelOptions = [
        { value: 'abandon',  label: 'Abandon' },
        { value: 'end_at_k', label: 'End at hole ' + (departureHole + 1) },
      ];
      if (canExcludePlayer(subset)) {
        topLevelOptions.push({ value: 'exclude_player', label: removePlayerLabel(subset) });
      }

      rows.push({
        gameKey: 'Stroke Play',
        label:   'Stroke Play',
        family:  'completion',
        topLevelOptions,
        segments,
      });
      continue;
    }

    // ── Nines ────────────────────────────────────────────────────────────────
    // Completion family. Hard 3-player engine constraint. exclude_player
    // NEVER offered (would leave 2, which Nines cannot run). Segments only
    // when betMode is 'segments'.
    if (game === 'Nines') {
      const subset = resolveSubset(ninesPlayers);
      if (subset.length < 3) continue;
      if (scenario === 'A' && !anyDepartedIn(subset)) continue;

      const nOpts   = gameOpts.Nines || {};
      const betMode = nOpts.betMode ?? nOpts.ninesMode ?? 'perpoint';

      const segments = [];
      if (betMode === 'segments') {
        const nR = _gameRange('Nines', gameRanges, roundStartHole, roundEndHole);
        const { mid } = _splitRangeByMidpoint(nR.startHole, nR.endHole);
        const isFullStandard = (nR.startHole === 0 && nR.endHole === 17);
        const fLen = mid - nR.startHole;
        const bLen = nR.endHole - mid + 1;
        const segDefs = [
          { segKey: 'front',   label: isFullStandard ? 'Front 9' : `Front ${fLen}`,
            segStart: nR.startHole, segEnd: mid - 1 },
          { segKey: 'back',    label: isFullStandard ? 'Back 9'  : `Back ${bLen}`,
            segStart: mid,          segEnd: nR.endHole },
          { segKey: 'overall', label: 'Total',
            segStart: nR.startHole, segEnd: nR.endHole },
        ];
        segDefs.forEach(({ segKey, label, segStart, segEnd }) => {
          if (segStart > departureHole) return;
          segments.push({
            segKey, label,
            status: evalCompletionStatus(segStart, segEnd, departureHole),
          });
        });
      }

      rows.push({
        gameKey: 'Nines',
        label:   'Nines',
        family:  'completion',
        topLevelOptions: [
          { value: 'abandon',  label: 'Abandon' },
          { value: 'end_at_k', label: 'End at hole ' + (departureHole + 1) },
        ],
        segments,
      });
      continue;
    }

    // ── Skins ────────────────────────────────────────────────────────────────
    // Hole-by-hole family. No segments. Top-level: abandon / end_at_k /
    // continue. exclude_player NOT offered (per §6.1 — Skins handles
    // departures via per-hole independence).
    if (game === 'Skins') {
      const subset = resolveSubset(skinsPlayers);
      if (!subset.length) continue;
      if (scenario === 'A' && !anyDepartedIn(subset)) continue;

      rows.push({
        gameKey: 'Skins',
        label:   'Skins',
        family:  'holeByHole',
        topLevelOptions: [
          { value: 'abandon',  label: 'Abandon' },
          { value: 'end_at_k', label: 'End at hole ' + (departureHole + 1) },
          { value: 'continue', label: 'Continue without departed' },
        ],
      });
      continue;
    }

    // ── Dots ─────────────────────────────────────────────────────────────────
    // Hole-by-hole family. exclude_player offered in Scenario A when ≥ 2
    // remain after removal.
    if (game === 'Dots' || game === 'Specials') {
      const subset = resolveSubset(dotsPlayers);
      if (!subset.length) continue;
      if (scenario === 'A' && !anyDepartedIn(subset)) continue;

      const topLevelOptions = [
        { value: 'abandon',  label: 'Abandon' },
        { value: 'end_at_k', label: 'End at hole ' + (departureHole + 1) },
        { value: 'continue', label: 'Continue without departed' },
      ];
      if (canExcludePlayer(subset)) {
        topLevelOptions.push({ value: 'exclude_player', label: removePlayerLabel(subset) });
      }

      rows.push({
        gameKey: 'Dots',
        label:   'Dots',
        family:  'holeByHole',
        topLevelOptions,
      });
      continue;
    }
  }

  return rows;
}

// ─── makeDefaultResolution ────────────────────────────────────────────────────

/**
 * Default resolution per Resolver_UI_Spec §10.2 — used to seed the sheet's
 * draft state on open. For clinch family, default is Pay closed + open
 * (variant 'closed_and_open') with all segments and presses defaulting to
 * 'pay'. For completion family, default is end_at_k with segments
 * defaulting to 'pay'. For hole-by-hole family, just end_at_k.
 *
 * Used by ScorecardPage to construct `initialResolutions` from the games[]
 * array returned by `buildResolverGameRows`.
 */
export function makeDefaultResolution(gameRow) {
  if (!gameRow) return { topLevel: 'end_at_k' };

  if (gameRow.family === 'clinch') {
    const segments = {};
    (gameRow.segments || []).forEach(s => { segments[s.segKey] = 'pay'; });
    const presses = {};
    (gameRow.presses || []).forEach(p => { presses[p.pressKey] = 'pay'; });
    return {
      topLevel: 'end_at_k',
      topLevelVariant: 'closed_and_open',
      segments,
      presses,
    };
  }

  if (gameRow.family === 'completion') {
    const segments = {};
    (gameRow.segments || []).forEach(s => { segments[s.segKey] = 'pay'; });
    return {
      topLevel: 'end_at_k',
      segments,
    };
  }

  // hole-by-hole
  return { topLevel: 'end_at_k' };
}
