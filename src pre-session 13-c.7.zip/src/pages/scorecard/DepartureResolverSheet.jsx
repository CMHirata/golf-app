// ─── scorecard/DepartureResolverSheet.jsx ─────────────────────────────────────
// RENDER ONLY — no business logic in this file.
// No scoring calculations. No match state computation.
// All logic must come from engine/ or scorecardUtils.js
//
// ✅ Self-checked (13-C.6): Bottom-sheet modal per Resolver_UI_Spec §2.1.
// Owns its own draft selection state internally per §2.4(a) — parent
// receives a SINGLE onConfirm event with the final committed map; no
// incremental change events. Cancel discards the draft. Re-seeded from
// `initialResolutions` whenever `open` transitions from false → true
// (failure-mode check 8c bullet 5). ESC + backdrop tap fire onCancel per
// §2.5. Multi-departed-player header text uses the comma-list-with-"and"
// convention from §2.1. Header hole number is 1-based per spec §2.1.

import { useEffect, useRef, useState } from 'react';
import { Btn, G } from '../../components/ui.jsx';
import { GameResolutionRow } from './GameResolutionRow.jsx';

// Format a list of names as "A", "A and B", "A, B and C" (Oxford-comma-free
// per spec §2.1 example: "Dave and Alice left after hole 13").
function formatNameList(names) {
  if (!names || names.length === 0) return '';
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} and ${names[1]}`;
  return `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
}

// Deep-merge a partial resolution into the draft. Sub-maps `segments` and
// `presses` are shallow-merged (the caller always sends a single-key
// object for these); other fields are replaced.
function mergeDraft(prevForGame, partial) {
  const next = { ...prevForGame, ...partial };
  if (partial.segments) {
    next.segments = { ...(prevForGame.segments || {}), ...partial.segments };
  }
  if (partial.presses) {
    next.presses = { ...(prevForGame.presses || {}), ...partial.presses };
  }
  // If topLevelVariant is explicitly undefined in the partial (i.e. the user
  // switched to abandon/continue/exclude_player or to a non-clinch end_at_k),
  // remove it so it doesn't linger and accidentally re-apply on a later
  // re-selection of a clinch variant.
  if ('topLevelVariant' in partial && partial.topLevelVariant === undefined) {
    delete next.topLevelVariant;
  }
  return next;
}

export function DepartureResolverSheet({
  open,
  scenario,
  departureHole,
  departedPlayerNames,
  games,
  initialResolutions,
  onConfirm,
  onCancel,
}) {
  const [draft, setDraft] = useState(initialResolutions || {});
  const wasOpenRef = useRef(false);
  const cardRef    = useRef(null);
  const firstFocusRef = useRef(null);

  // Re-seed draft from initialResolutions on each open (false→true transition).
  // Do NOT re-seed on every render — that would clobber the user's in-flight
  // selections every time the parent re-renders.
  useEffect(() => {
    if (open && !wasOpenRef.current) {
      setDraft(initialResolutions || {});
    }
    wasOpenRef.current = open;
  }, [open, initialResolutions]);

  // ESC closes (Cancel) per §2.5.
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') onCancel?.(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onCancel]);

  // Initial focus on first interactive control on open.
  useEffect(() => {
    if (!open) return;
    // Defer one tick so the sheet has mounted before .focus() runs.
    const t = setTimeout(() => {
      if (firstFocusRef.current && typeof firstFocusRef.current.focus === 'function') {
        try { firstFocusRef.current.focus(); } catch (_) {}
      }
    }, 0);
    return () => clearTimeout(t);
  }, [open]);

  if (!open) return null;

  const headerText = scenario === 'B'
    ? `Round ended after hole ${departureHole + 1}`
    : `${formatNameList(departedPlayerNames)} left after hole ${departureHole + 1}`;

  const handlePartial = (gameKey, partial) => {
    setDraft(prev => ({
      ...prev,
      [gameKey]: mergeDraft(prev[gameKey] || {}, partial),
    }));
  };

  const handleConfirm = () => {
    onConfirm?.(draft);
  };

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 400,
        background: 'rgba(0,0,0,0.45)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
      onClick={onCancel}
    >
      <div
        ref={cardRef}
        onClick={e => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label={headerText}
        style={{
          background: '#fff',
          borderRadius: '20px 20px 0 0',
          width: '100%',
          maxWidth: 520,
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 -4px 24px rgba(0,0,0,0.18)',
        }}
      >
        {/* ── Header ── */}
        <div style={{ padding: '18px 18px 6px' }}>
          <div style={{ fontWeight: 800, fontSize: 16, color: G }}>
            {headerText}
          </div>
          <div style={{ fontSize: 12, color: '#666', marginTop: 3 }}>
            How should each game be resolved?
          </div>
        </div>

        {/* ── Body — scrollable list of GameResolutionRow ── */}
        <div style={{
          flex: '1 1 auto',
          overflowY: 'auto',
          padding: '4px 18px 12px',
        }}>
          {(games || []).length === 0 ? (
            <div style={{ fontSize: 12, color: '#999', textAlign: 'center', padding: '24px 0' }}>
              No active games involve {scenario === 'B' ? 'this round' : 'the departed player'}.
            </div>
          ) : (
            (games || []).map((gr, idx) => (
              <div key={gr.gameKey} ref={idx === 0 ? firstFocusRef : null} tabIndex={idx === 0 ? -1 : undefined}>
                <GameResolutionRow
                  gameRow={gr}
                  resolution={draft[gr.gameKey] || {}}
                  onChange={handlePartial}
                />
              </div>
            ))
          )}
        </div>

        {/* ── Footer — pinned ── */}
        <div style={{
          flex: '0 0 auto',
          borderTop: '1px solid #eee',
          padding: '12px 18px 16px',
          paddingBottom: 'calc(16px + env(safe-area-inset-bottom))',
          display: 'flex',
          gap: 8,
        }}>
          <Btn variant="ghost" onClick={onCancel} style={{ flex: 1 }}>
            Cancel
          </Btn>
          <Btn onClick={handleConfirm} style={{ flex: 1 }}>
            Confirm
          </Btn>
        </div>
      </div>
    </div>
  );
}
